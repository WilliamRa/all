

const { createServer } = require("http");
const next = require("next");
const { Server } = require("socket.io");
const dev = process.env.NODE_ENV !== "production";

const hostname = "localhost";
const port = 3000;
const app = next({ dev, hostname, port });
const handler = app.getRequestHandler();
const { PrismaClient } = require('@prisma/client')

const prisma = new PrismaClient()
app.prepare().then(() => {
  const httpServer = createServer(handler);

  const io = new Server(httpServer);
  global.io = io; 
  
  io.on("connection", (socket) => {
    io.on("authenticate", async (userID) => {

      let isUser = await prisma.usuarios.findUnique({ where: { id: userID.id } })
      if (isUser && isUser.id) {
        let updateSocket = await prisma.usuarios.update({
          where: { id: isUser.id },
          data: {
            socket_id: socket.id
          }
        })
      } else {
        let isEstudiante = await prisma.estudiante.findUnique({ where: { id: userID.id } })
        if (isEstudiante && isEstudiante.id) {
          let updateSocketEstudiante = await prisma.estudiante.update({
            where: { id: isUser.id },
            data: {
              socket_id: socket.id
            }
          })
        }
      }
      console.log(`Authenticated user: ${userID} with socket ID: ${socket.id}`);
    });

    io.on("new-observacion", (data) => { 
      console.log("data")
    })
  });

  io.on("disconnect", async () => {
    socket
  });

  httpServer
    .once("error", (err) => {
      console.error(err);
      process.exit(1);
    })
    .listen(port, () => {
      console.log(`> Ready on http://${hostname}:${port}`);
    });
});