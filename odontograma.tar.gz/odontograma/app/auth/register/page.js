'use client'
import { Form, Input, Button, notification } from "antd";
import { useRouter } from "next/navigation";
import React, { useState } from "react";
import { TEInput, TERipple } from "tw-elements-react";

export default function Page() {
  const [registro_estudiante] = Form.useForm();
  const router = useRouter()
  const register = async (values) => {

    let res = await fetch('/api/register', {
      method: "POST",
      body: JSON.stringify(values)
    })

    if (res.status === 200) {
      router.push("/auth/login")
    } else {
      notification.error({
        message: "Error al Registrar al Estudiante"
      })
    }
  }

  return (
    <section className="h-screen">
      <div className="h-full">
        {/* <!-- Left column container with background--> */}
        <div className="g-6 flex h-full flex-wrap items-center justify-center lg:justify-between">
          <div className="shrink-1 mb-12 grow-0 basis-auto md:mb-0 md:w-9/12 md:shrink-0 lg:w-6/12 xl:w-6/12">
            <img
              src="/draw2.webp"
              className="w-full"
              alt="Sample image"
            />
          </div>

          <div className="mb-12 md:mb-0 md:w-8/12 lg:w-5/12 xl:w-5/12">
            <Form
              style={{ width: "80%" }}
              name="registro_estudiante"
              layout="horizonta"
              form={registro_estudiante}
              onFinish={register}
            >

              <Form.Item label="Nombres" name="nombres" rules={[{ required: true, message: 'Por favor ingresa los nombres' }]}>
                <Input style={{ height: "30px", textAlign: "left" }} />
              </Form.Item>

              <Form.Item style={{ marginTop: "4px" }} label="Apellidos" name="apellidos" rules={[{ required: true, message: 'Por favor ingresa los apellidos' }]}>
                <Input style={{ height: "30px", marginTop: "4px", textAlign: "left" }} />
              </Form.Item>

              <Form.Item label="Cédula" name="cedula"
                style={{ marginLeft: "12px" }}
                rules={[
                  { required: true, message: 'Por favor ingrese la Cédula' },
                  { pattern: /^[0-9]+$/, message: 'La cédula debe contener solo números.' }
                ]}>
                <Input style={{ height: "30px", textAlign: "left" }} />
              </Form.Item>

              <Form.Item label="Año" name="ano" style={{ marginLeft: "30px" }}
                rules={[{ required: true, message: 'Por favor ingrese el Año' }]}>
                <Input style={{ height: "30px", textAlign: "left" }} />
              </Form.Item>

              <Form.Item label="Grupo" name="grupo" style={{ marginLeft: "18px" }}
                rules={[{ required: true, message: 'Por favor ingrese  el Grupo' }]}>
                <Input style={{ height: "30px", textAlign: "left" }} />
              </Form.Item>

              <Form.Item label="Correo" name="correo" style={{ marginLeft: "16px" }}
                rules={[
                  { required: true, message: 'Por favor ingrese  Dato' },
                  { pattern: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, message: 'Por favor revise la estructura del correo' }

                ]}>
                <Input style={{ height: "30px", textAlign: "left" }} type="email" />
              </Form.Item>

              <Form.Item label="Contraseña" name="contraseña" style={{ marginLeft: "-12px" }}
                rules={[{ required: true, message: 'Por favor ingrese la Contraseña' }]}>
                <Input style={{ height: "30px", textAlign: "left" }} type="password" />
              </Form.Item>


              <div className="flex justify-end">
                <Form.Item >
                  <Button type="primary" htmlType="submit">
                    Registra
                  </Button>
                </Form.Item>

              </div>
            </Form>
          </div>
        </div>
      </div>
    </section>
  );
}