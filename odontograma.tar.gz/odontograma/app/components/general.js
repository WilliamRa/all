export const capitalizeFirstLetter = (str) => {
  return str
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};


export const statusString = (value) => {
  switch (value) {
    case 0:
      return "EN PROCESO"

    case 1:
      return "APROBADO"
    case 2:
      return "POR CORREGIR"
    default:
      break;
  }
};
