'use client'

import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { Form, Modal, Input, InputNumber, Select, Space, Button, notification } from "antd"
import { useSession } from "next-auth/react";
import { useState, useEffect } from "react";
const { Option } = Select;

const PacientesModal = (props) => {
  const { data: session } = useSession(authOptions)
  const [registro_paciente] = Form.useForm();
  const [spinActive, setSpinActive] = useState(false)
  const handleCancel = () => {
    props.valorCloseModal()
  }

  async function fetchData(data, callback) {
    let respon = await fetch('/api/dome', {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(async (data) => {
      let a = await data.json()
      if (a.code === 403) {
        notification.error({
          message: a.message
        })
        setSpinActive(false);
      } else {
        notification.success({
          message: a.message
        })
        callback()
      }
    })

  }

  async function fetchDataPut(data, callback) {
    let respon = await fetch('/api/dome', {
      method: "PUT",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(async (data) => {
      let a = await data.json()
      if (a.code === 403) {
        notification.error({
          message: a.message
        })
        setSpinActive(false);
      } else {
        notification.success({
          message: a.message
        })
        callback()
      }
    })
  }
  const handleOk = (values) => {
    if (values.nombres && values.apellidos && values.edad && values.cedula) {
      if (values.sexo) {
        if (props.option.option === 1) {
          let data = {
            ...values,
            estudiante: props.user.user.name.id,
            option: props.option.option
          }
          setSpinActive(true);
          fetchData(data, () => {
            props.valorCloseModal()
            registro_paciente.resetFields()
            setSpinActive(false);
          })

        } else if (props.option.option === 3) {
          let data = {
            id: props.option.id,
            ...values,
            estudiante: props.user.user.name.id,
            option: props.option.option
          }
          setSpinActive(true);
          fetchDataPut(data, () => {
            props.valorCloseModal()
            registro_paciente.resetFields()
            setSpinActive(false);
          })

        }

      }
    }
  }
  const disabled = () => {
    if (props.option.option === 2) {
      return true
    } else {
      return false
    }
  }
  let disable = disabled()

  useEffect(() => {
    if (props.option.option === 4) {

    } else if (props.option.option === 3 || props.option.option === 2) {

      registro_paciente.setFieldsValue({
        nombres: props.one && props.one.nombres,
        apellidos: props.one && props.one.apellidos,
        edad: props.one && props.one.edad,
        cedula: props.one && props.one.cedula.cedula_num,
        raza: props.one && props.one.raza,
        ocupacion: props.one && props.one.ocupacion,
        natural: props.one && props.one.natural,
        procedencia: props.one && props.one.procedencia,
        direccion: props.one && props.one.direccion,
        sexo: props.one && props.one.sexo.id

      })

    }
  }, [props.option, props.one]);


  return (
    <Modal

      title={props.option.modalHeader}
      width={800}
      style={{ top: 20 }}
      open={props.option.modal}
      onOk={handleOk}
      onCancel={handleCancel}
      confirmLoading={spinActive}
      okText={props.option.modalFooter}
      footer={null}
      okButtonProps={{
        htmlType: "submit",

      }}
    >

      <Form
        name="registro_paciente"
        layout={"horizontal"}
        form={registro_paciente}
        onFinish={handleOk}
      >
        <Form.Item style={{ height: "30px" }} label="Nombres" name="nombres" rules={[{ required: true, message: 'Por favor ingresa los nombres del paciente' }]}>
          <Input style={{ height: "30px", textAlign: "left" }} disabled={disable} />
        </Form.Item>

        <Form.Item style={{ marginTop: "4px" }} label="Apellidos" name="apellidos" rules={[{ required: true, message: 'Por favor ingresa los apellidos del paciente' }]}>
          <Input style={{ height: "30px", marginTop: "4px", textAlign: "left" }} disabled={disable} />
        </Form.Item>

        <Form.Item label="Edad" name="edad" rules={[{ required: true, message: 'Por favor ingrese la Edad' }]}>
          <Input style={{ height: "30px", textAlign: "left", marginTop: "5px" }} disabled={disable} />
        </Form.Item>

        <Form.Item label="Cédula" name="cedula" rules={[{ required: true, message: 'Por favor ingrese la Cédula' }]}>
          <Input style={{ height: "30px", textAlign: "left" }} disabled={props.option.option === 3 ? true : disable} />
        </Form.Item>

        <Form.Item label="Raza/Etnia" name="raza" rules={[{ required: true, message: 'Por favor ingrese la Raza' }]}>
          <Input style={{ height: "30px", textAlign: "left" }} disabled={disable} />
        </Form.Item>

        <Form.Item label="Ocupación" name="ocupacion" rules={[{ required: true, message: 'Por favor ingrese  Dato' }]}>
          <Input style={{ height: "30px", textAlign: "left" }} disabled={disable} />
        </Form.Item>

        <Form.Item label="Natural" name="natural" rules={[{ required: true, message: 'Por favor ingrese  Dato' }]}>
          <Input style={{ height: "30px", textAlign: "left" }} disabled={disable} />
        </Form.Item>

        <Form.Item label="Procedencia" name="procedencia" rules={[{ required: true, message: 'Por favor ingrese la Procedencia' }]}>
          <Input style={{ height: "30px", textAlign: "left" }} disabled={disable} />
        </Form.Item>

        <Form.Item label="Dirección" name="direccion" rules={[{ required: true, message: 'Por favor ingrese la Cedula' }]}>
          <Input.TextArea style={{ height: "30px", textAlign: "left" }} disabled={disable} />
        </Form.Item>

        <Form.Item label="Sexo" name="sexo" rules={[{ required: true, message: 'Por favor selecciona el género del paciente' }]} >
          <Select disabled={props.option.option === 3 ? true : disable}>
            {
              props.select && props.select.map(g => {
                return (<Option value={g.id} key={g.id}>{g.sexo_name.toUpperCase()}</Option>)
              })

            }
          </Select>

        </Form.Item>
        <div style={{ textAlign: 'right' }}>
          <Space direction='vertical'>
            <Space>
              <Form.Item >
                <Button danger onClick={handleCancel}>
                  Cancelar
                </Button>
              </Form.Item>
              {props.option.showHide === 'show' &&
                <Form.Item >
                  <Button type="primary" htmlType="submit" loading={spinActive}>
                    {props.option.modalFooter}
                  </Button>
                </Form.Item>
              }
            </Space>
          </Space>
        </div>

      </Form>
    </Modal>
  )
}

export default PacientesModal