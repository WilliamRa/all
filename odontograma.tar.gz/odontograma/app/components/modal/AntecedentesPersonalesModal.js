'use client'

import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { Form, Modal, Input, Radio, Space, Button, Tabs, notification } from "antd"
import { useSession } from "next-auth/react";
import { useState, useEffect } from "react";
import { alergias, antecedentesPersonales, enfermedades, farmacosTomados, habitos, sintomasProcedimientos, } from "./childrens/preguntas";


const AntecedentesPersonalesModal = (props) => {
  const { data: session } = useSession(authOptions)
  const [registro_historia_clinica] = Form.useForm();
  const [registro_farmacos_tomados] = Form.useForm();
  const [registro_alergias] = Form.useForm();
  const [registro_enfermedades] = Form.useForm();
  const [registro_sintomas] = Form.useForm();
  const [registro_habitos] = Form.useForm();

  const [spinActive, setSpinActive] = useState(false)
  const [tabDisable2, setTadDisable2] = useState(true)
  const [tabDisable3, setTadDisable3] = useState(true)
  const [tabDisable4, setTadDisable4] = useState(true)
  const [tabDisable5, setTadDisable5] = useState(true)
  const [tabDisable6, setTadDisable6] = useState(true)
  const [activeTab, setActiveTab] = useState("1");

  const handleFormSubmit = async () => {
    const nextTab = parseInt(activeTab) + 1;
    switch (activeTab) {
      case "1":
        await registro_historia_clinica.validateFields();
        setTadDisable2(false);
        setActiveTab(nextTab.toString());
        break;
      case "2":
        await registro_farmacos_tomados.validateFields();
        setTadDisable3(false);
        setActiveTab(nextTab.toString());
        break;
      case "3":
        await registro_alergias.validateFields();
        setTadDisable4(false);
        setActiveTab(nextTab.toString());
        break;
      case "4":
        await registro_enfermedades.validateFields();
        setTadDisable5(false);
        setActiveTab(nextTab.toString());
        break;
      case "5":
        await registro_sintomas.validateFields();
        setTadDisable6(false);
        setActiveTab(nextTab.toString());
        break;
      case "6":
        await registro_habitos.validateFields();
        break;
      default:
        break;
    }

  };

  const handleCancel = () => {
    props.valorCloseModal()
    setActiveTab('1')
    setTadDisable2(true)
    setTadDisable3(true)
    setTadDisable4(true)
    setTadDisable5(true)
    setTadDisable6(true)
    registro_historia_clinica.resetFields()
    registro_alergias.resetFields()
    registro_farmacos_tomados.resetFields()
    registro_enfermedades.resetFields()
    registro_sintomas.resetFields()
    registro_habitos.resetFields()
  }

  async function fetchData(data, callback) {

    await fetch('/api/antecedentesPersonales', {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(async (data) => {
      let a = await data.json()
      if (a.code === 403) {
        notification.error({
          message: a.message
        })
        setSpinActive(false);
      } else {
        callback()
      }
    })
  }

  async function fetchDataPut(data, callback) {
    let respon = await fetch('/api/antecedentesPersonales', {
      method: "PUT",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    callback()

  }
  const handleOk = async (values) => {
    let antecedentesPersonales = registro_historia_clinica.getFieldValue()
    let alergias = registro_alergias.getFieldValue()
    let farmacos_tomados = registro_farmacos_tomados.getFieldValue()
    let enfermedades = registro_enfermedades.getFieldValue()
    let sintomas = registro_sintomas.getFieldValue()
    let habitos = registro_habitos.getFieldValue()
    if (props.option.option === 1) {
      let data = {
        antecedentesPersonales,
        alergias,
        farmacos_tomados,
        enfermedades,
        sintomas,
        habitos,
        option: props.option.option
      }

      setSpinActive(true);
      fetchData(data, () => {
        props.valorCloseModal()
        setSpinActive(false);
        registro_historia_clinica.resetFields()
        registro_alergias.resetFields()
        registro_farmacos_tomados.resetFields()
        registro_enfermedades.resetFields()
        registro_sintomas.resetFields()
        registro_habitos.resetFields()
        setActiveTab('1')
        setTadDisable2(true)
        setTadDisable3(true)
        setTadDisable4(true)
        setTadDisable5(true)
        setTadDisable6(true)
      })

    } else if (props.option.option === 3) {
      let data = {
        id: props.option.id,
        antecedentesPersonales,
        alergias,
        farmacos_tomados,
        enfermedades,
        sintomas,
        habitos,
        option: props.option.option
      }
      setSpinActive(true);
      fetchDataPut(data, () => {
        props.valorCloseModal()
        registro_historia_clinica.resetFields()
        registro_alergias.resetFields()
        registro_farmacos_tomados.resetFields()
        registro_enfermedades.resetFields()
        registro_sintomas.resetFields()
        registro_habitos.resetFields()
        setSpinActive(false);
      })

    }

  }

  const disabled = () => {
    if (props.option.option === 2) {
      return true
    } else {
      return false
    }
  }

  let disable = disabled()

  useEffect(() => {
    if (props.option.option === 4) {

    } else if (props.option.option === 3 || props.option.option === 2) {
      setTadDisable2(false)
      setTadDisable3(false)
      setTadDisable4(false)
      setTadDisable5(false)
      setTadDisable6(false)
      registro_historia_clinica.setFieldsValue({
        nervios_al_odontologo: props.one && props.one.nervios_al_odontologo,
        dolor_boca: props.one && props.one.dolor_boca,
        dolor_dentadura: props.one && props.one.dolor_dentadura,
        dientes_sensibles: props.one && props.one.dientes_sensibles,
        sangrado_encias: props.one && props.one.sanrado_encias,
        aparato_ortopedico_odontologico: props.one && props.one.aparato_ortopedico_odontologico,
        ulcera_inflamacion: props.one && props.one.ulcera_inflamacion,
        quirurgico_rx: props.one && props.one.quirurgico_rx,
        dificultad_masticar: props.one && props.one.dificultad_masticar,
        dificultad_abrir_boca: props.one && props.one.dificultad_abrir_boca,
        sonido_mandibular_masticar: props.one && props.one.sonido_mandibular_masticar,
        problemas_senos_cabeza_cara: props.one && props.one.problema_senos_cabeza_cara,
        hemorragias_nasales: props.one && props.one.hemorragias_nasales,
        herida_grave: props.one && props.one.herida_grave,
        sangrado_largo_tiempo: props.one && props.one.sangrado_largo_tiempo,
        tratado_medico_dos_anos: props.one && props.one.tratado_medico_dos_anos,
        hospitalizado: props.one && props.one.hospitalizado,
        bajo_tratamiento_actualmente: props.one && props.one.bajo_tratamiento_actualmente,
        hemorragias_exesiva_tratamiento_especial: props.one && props.one.hemorragias_excesiva_tratamiento_especial,
        conclusiones_respuestas_positivas: props.one && props.one.conclusiones_respuestas_positivas,
      })
      registro_alergias.setFieldsValue({
        anestesicos_locales: props.one && props.one.alergias.anestesicos_locales,
        aspirina: props.one && props.one.alergias.aspirina,
        barbitulicos: props.one && props.one.alergias.barbitulicos,
        otro: props.one && props.one.alergias.otro,
        penicilina: props.one && props.one.alergias.penicilina,
        sulfamidas: props.one && props.one.alergias.sulfamidas,
      })
      registro_farmacos_tomados.setFieldsValue({
        antibioticos: props.one && props.one.farmacos_tomados.antibioticos,
        anticoagulantes: props.one && props.one.farmacos_tomados.anticoagulantes,
        antidepresivos: props.one && props.one.farmacos_tomados.antidepresivos,
        esteroides: props.one && props.one.farmacos_tomados.esteroides,
        aspirina: props.one && props.one.farmacos_tomados.aspirina,
        anticombulsivos: props.one && props.one.farmacos_tomados.anticombulsivo,
        antiglicemiante: props.one && props.one.farmacos_tomados.antiglicemiante,
        otros: props.one && props.one.farmacos_tomados.otros
      })
      registro_enfermedades.setFieldsValue({
        anemia: props.one && props.one.enfermedades.anemia,
        artritis: props.one && props.one.enfermedades.artritis,
        asma: props.one && props.one.enfermedades.asma,
        ataques_corazon: props.one && props.one.enfermedades.ataques_corazon,
        cancer: props.one && props.one.enfermedades.cancer,
        diabetes: props.one && props.one.enfermedades.diabetes,
        enfermedades_suprarenales: props.one && props.one.enfermedades.enfermedades_suprarenales,
        enfermedades_tiroideas: props.one && props.one.enfermedades.enfermedades_tiroideas,
        enfermedades_venereas: props.one && props.one.enfermedades.enfermedades_venereas,
        fiebre_reumatica: props.one && props.one.enfermedades.fiebre_reumatica,
        hepatitis: props.one && props.one.enfermedades.hepatitis,
        insuficiencia_cardiaca: props.one && props.one.enfermedades.insuficiencia_cardiaca,
        marcapasos: props.one && props.one.enfermedades.marcapasos,
        presion_alta: props.one && props.one.enfermedades.presion_alta,
        quimioterapia: props.one && props.one.enfermedades.quimioterapia,
        radioterapia: props.one && props.one.enfermedades.radioterapia,
        sida: props.one && props.one.enfermedades.sida,
        soplo_cardiaco: props.one && props.one.enfermedades.soplo_cardiaco,
        tuberculosis: props.one && props.one.enfermedades.tuberculosis,
        valvulas_cardiacas: props.one && props.one.enfermedades.valvulas_cardiacas,
      })
      registro_sintomas.setFieldsValue({
        ataques_combulsiones: props.one && props.one.sintomas_procedimientos.ataques_combulsiones,
        despierto_falta_aire: props.one && props.one.sintomas_procedimientos.despierto_falta_aire,
        dieta_especial: props.one && props.one.sintomas_procedimientos.dieta_especial,
        dolor_pecho_falta_aire: props.one && props.one.sintomas_procedimientos.dolor_pecho_falta_aire,
        ganado_perdido_peso: props.one && props.one.sintomas_procedimientos.ganado_perdido_peso,
        hinchazon_tobillos: props.one && props.one.sintomas_procedimientos.hinchazon_tobillos,
        moretones_magulladuras_facilidad: props.one && props.one.sintomas_procedimientos.moretones_magulladuras_facilidad,
        orinar_seis_veces_dia: props.one && props.one.sintomas_procedimientos.orinar_seis_veces_dia,
        siempre_sediento: props.one && props.one.sintomas_procedimientos.siempre_sediento,
        sufrido_urticaria_eruccion: props.one && props.one.sintomas_procedimientos.sufrido_urticaria_eruccion,
        transfusion_sanguinea_realizada: props.one && props.one.sintomas_procedimientos.transfusion_sanguinea_realizada,
      })
      registro_habitos.setFieldsValue({
        abrir_ganchos_dientes: props.one && props.one.habitos.abrir_ganchos_dientes,
        onicofagia: props.one && props.one.habitos.onicofagia,
        otros: props.one && props.one.habitos.otros,
        queilofagia: props.one && props.one.habitos.queilofagia,
        respirador_bucal: props.one && props.one.habitos.respirador_bucal,
        succion_digital: props.one && props.one.habitos.succion_digital,
        tabaquismo: props.one && props.one.habitos.tabaquismo,
      })
    }


  }, [props.option, props.one]);

  let items = [
    {
      key: '1',
      label: 'Antecedentes Personales',
      children: (
        <>
          <Form
            name="registro_historia_clinica"
            layout={"vertical"}
            form={registro_historia_clinica}
            onFinish={handleOk}
          >
            {
              props.option.option === 1 && (
                <Form.Item style={{ marginTop: "4px" }} label="Número de Historia" name="numero_historia"
                  rules={[
                    { required: true, message: 'Por favor ingresa el numero de Historia' },
                    { pattern: /^[0-9]+$/, message: 'La cédula debe contener solo números.' }
                  ]}
                >
                  <Input style={{ height: "30px", marginTop: "4px", textAlign: "left" }} disabled={disable} />
                </Form.Item>
              )
            }
            {
              antecedentesPersonales.map((preguntas, index) => {
                return (
                  <Form.Item label={preguntas.label} name={preguntas.name} rules={[{ required: true, message: 'Por favor ingrese seleccione una Opcion' }]} id={`${preguntas.name}`} key={index}>
                    <Radio.Group disabled={disable}>
                      <Radio value={1}> SI </Radio>
                      <Radio value={0}> NO </Radio>
                    </Radio.Group>
                  </Form.Item>
                )
              })
            }



            <Form.Item label="Conclusiones a Respuestas Positivas" name="conclusiones_respuestas_positivas" rules={[{ required: true, message: 'Por favor ingrese seleccione una Opcion' }]}>
              <Input.TextArea disabled={disable} />
            </Form.Item>

            <div style={{ textAlign: 'right' }}>
              <Space direction='vertical'>
                <Space>
                  <Form.Item >
                    <Button danger onClick={handleCancel}>
                      Cancelar
                    </Button>
                  </Form.Item>
                  {props.option.showHide === 'show' &&
                    <Form.Item >
                      <Button type="primary" onClick={handleFormSubmit}>
                        Siguiente
                      </Button>
                    </Form.Item>
                  }
                </Space>
              </Space>
            </div>
          </Form>
        </>
      )
    },
    {
      key: '2',
      label: 'Farmacos Tomados',
      disabled: tabDisable2,
      children: (
        <>
          <Form
            name="registro_farmacos_tomados"
            layout={"vertical"}
            form={registro_farmacos_tomados}
            onFinish={handleOk}
          >
            {
              farmacosTomados.map((preguntas, index) => {
                return (
                  <Form.Item label={preguntas.label} name={preguntas.name} rules={[{ required: true, message: 'Por favor ingrese seleccione una Opcion' }]} key={index}>
                    <Radio.Group disabled={disable}>
                      <Radio value={1}> SI </Radio>
                      <Radio value={0}> NO </Radio>
                    </Radio.Group>
                  </Form.Item>
                )
              })
            }




            <div style={{ textAlign: 'right' }}>
              <Space direction='vertical'>
                <Space>
                  <Form.Item >
                    <Button danger onClick={handleCancel}>
                      Cancelar
                    </Button>
                  </Form.Item>
                  {props.option.showHide === 'show' &&
                    <Form.Item >
                      <Button type="primary" onClick={handleFormSubmit}>
                        Siguiente
                      </Button>
                    </Form.Item>
                  }
                </Space>
              </Space>
            </div>
          </Form>
        </>
      )
    },
    {
      key: '3',
      label: 'Alergias',
      disabled: tabDisable3,
      children: (
        <>
          <Form
            name="registro_alergias"
            layout={"vertical"}
            form={registro_alergias}
            onFinish={handleOk}
          >
            {
              alergias.map((preguntas, index) => {
                return (
                  <Form.Item label={preguntas.label} name={preguntas.name} rules={[{ required: true, message: 'Por favor ingrese seleccione una Opcion' }]} key={index}>
                    <Radio.Group disabled={disable}>
                      <Radio value={1}> SI </Radio>
                      <Radio value={0}> NO </Radio>
                    </Radio.Group>
                  </Form.Item>
                )
              })
            }




            <div style={{ textAlign: 'right' }}>
              <Space direction='vertical'>
                <Space>
                  <Form.Item >
                    <Button danger onClick={handleCancel}>
                      Cancelar
                    </Button>
                  </Form.Item>
                  {props.option.showHide === 'show' &&
                    <Form.Item >
                      <Button type="primary" onClick={handleFormSubmit}>
                        Siguiente
                      </Button>
                    </Form.Item>
                  }
                </Space>
              </Space>
            </div>
          </Form>
        </>
      )
    },
    {
      key: '4',
      label: 'Enfermedades Padecidas',
      disabled: tabDisable4,
      children: (
        <>
          <Form
            name="registro_enfermedades"
            layout={"vertical"}
            form={registro_enfermedades}
            onFinish={handleOk}
          >
            {
              enfermedades.map((preguntas, index) => {
                return (
                  <Form.Item label={preguntas.label} name={preguntas.name} rules={[{ required: true, message: 'Por favor ingrese seleccione una Opcion' }]} key={index}>
                    <Radio.Group disabled={disable}>
                      <Radio value={1}> SI </Radio>
                      <Radio value={0}> NO </Radio>
                    </Radio.Group>
                  </Form.Item>
                )
              })
            }




            <div style={{ textAlign: 'right' }}>
              <Space direction='vertical'>
                <Space>
                  <Form.Item >
                    <Button danger onClick={handleCancel}>
                      Cancelar
                    </Button>
                  </Form.Item>
                  {props.option.showHide === 'show' &&
                    <Form.Item >
                      <Button type="primary" onClick={handleFormSubmit}>
                        Siguiente
                      </Button>
                    </Form.Item>
                  }
                </Space>
              </Space>
            </div>
          </Form>
        </>
      )
    },
    {
      key: '5',
      label: 'Sintomas o Procedimientos',
      disabled: tabDisable5,
      children: (
        <>
          <Form
            name="registro_sintomas"
            layout={"vertical"}
            form={registro_sintomas}
            onFinish={handleOk}
          >
            {
              sintomasProcedimientos.map((preguntas, index) => {
                return (
                  <Form.Item label={preguntas.label} name={preguntas.name} rules={[{ required: true, message: 'Por favor ingrese seleccione una Opcion' }]} key={index}>
                    <Radio.Group disabled={disable}>
                      <Radio value={1}> SI </Radio>
                      <Radio value={0}> NO </Radio>
                    </Radio.Group>
                  </Form.Item>
                )
              })
            }




            <div style={{ textAlign: 'right' }}>
              <Space direction='vertical'>
                <Space>
                  <Form.Item >
                    <Button danger onClick={handleCancel}>
                      Cancelar
                    </Button>
                  </Form.Item>
                  {props.option.showHide === 'show' &&
                    <Form.Item >
                      <Button type="primary" onClick={handleFormSubmit}>
                        Siguiente
                      </Button>
                    </Form.Item>
                  }
                </Space>
              </Space>
            </div>
          </Form>
        </>
      )
    },
    {
      key: '6',
      label: 'Habitos',
      disabled: tabDisable6,
      children: (
        <>
          <Form
            name="registro_habitos"
            layout={"vertical"}
            form={registro_habitos}
            onFinish={handleOk}
          >
            {
              habitos.map((preguntas, index) => {
                return (
                  <Form.Item label={preguntas.label} name={preguntas.name} rules={[{ required: true, message: 'Por favor ingrese seleccione una Opcion' }]} key={index}>
                    <Radio.Group disabled={disable}>
                      <Radio value={1}> SI </Radio>
                      <Radio value={0}> NO </Radio>
                    </Radio.Group>
                  </Form.Item>
                )
              })
            }




            <div style={{ textAlign: 'right' }}>
              <Space direction='vertical'>
                <Space>
                  <Form.Item >
                    <Button danger onClick={handleCancel}>
                      Cancelar
                    </Button>
                  </Form.Item>
                  {props.option.showHide === 'show' &&
                    <Form.Item >
                      <Button type="primary" htmlType="submit" loading={spinActive}>
                        {props.option.modalFooter}
                      </Button>
                    </Form.Item>
                  }
                </Space>
              </Space>
            </div>
          </Form>
        </>
      )
    },
  ]
  return (
    <Modal

      title={props.option.modalHeader}
      width={800}
      style={{ top: 20 }}
      open={props.option.modal}
      onOk={handleOk}
      onCancel={handleCancel}
      confirmLoading={spinActive}
      okText={props.option.modalFooter}
      footer={null}
      okButtonProps={{
        htmlType: "submit",

      }}
    >
      <Tabs defaultActiveKey={activeTab} activeKey={activeTab} items={items} onChange={setActiveTab} />
    </Modal>
  )
}

export default AntecedentesPersonalesModal