import React, { useEffect, useState } from 'react';
import { Modal, Input, Typography, Button, Form, Space } from 'antd';
import TextArea from 'antd/es/input/TextArea';

const { Text, Title } = Typography;

const ObservacionModal = ({ visible, onClose, one }) => {
  const [observations, setObservations] = useState([]);
  const [selectedObservation, setSelectedObservation] = useState(null);
  const [observacion_form] = Form.useForm();

  async function fetchData(data, callback) {
    await fetch('/api/observaciones', {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(async (data) => {
      let a = await data.json()
      if (a.code === 403) {
        notification.error({
          message: a.message
        })
        setSpinActive(false);
      } else {
        callback()
      }
    })
    

  }
  const handleOk = (values) => {
     let data = {
        ...values,
        option: 1,
        idUser: visible.id
      }
      console.log(data)
      //setSpinActive(true);
      fetchData(data, () => {
        onClose()
        observacion_form.resetFields()
        //setSpinActive(false);
      })


  }

  return (
    <Modal
      title={"Realizar Observacion"}
      open={visible.modal}
      onCancel={onClose}
      footer={null}
    >

      <Form
        name="observacion_form"
        layout={"vertical"}
        form={observacion_form}
        onFinish={handleOk}
        width={800}
      >

        <Form.Item label="Asunto" name="asunto" rules={[{ required: true, message: 'Por favor ingrese el Asunto' }]}>
          <Input style={{ height: "30px", textAlign: "left" }}  />
        </Form.Item>

        <Form.Item label="Contenido" name="contenido" rules={[{ required: true, message: 'Por favor ingrese el Contenido' }]}>
          <TextArea rows={12} style={{ textAlign: "left" }} showCount maxLength={250} />
        </Form.Item>

        <div style={{ textAlign: 'right' }}>
          <Space direction='vertical'>
            <Space>
              <Form.Item >
                <Button danger onClick={onClose}>
                  Cancelar
                </Button>
              </Form.Item>
          
                <Form.Item >
                  <Button type="primary" htmlType="submit" >
                    Realizar Observacion
                  </Button>
                </Form.Item>
              
            </Space>
          </Space>
        </div>

      </Form>
    </Modal>
  );
};

export default ObservacionModal;
