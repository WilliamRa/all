'use client'

import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { Form, Modal, Input, InputNumber, Select, Space, Button, notification } from "antd"
import { useSession } from "next-auth/react";
import { useState, useEffect } from "react";
const { Option } = Select;

const EstudianteModal = (props) => {
  const { data: session } = useSession(authOptions)
  console.log(session)
  const [registro_paciente] = Form.useForm();
  const [spinActive, setSpinActive] = useState(false)
  console.log("props", props)
  const handleCancel = () => {
    props.valorCloseModal()
  }

  async function fetchData(data, callback) {
    let respon = await fetch('/api/estudiantes', {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(async (data) => {
      let a = await data.json()
      if (a.code === 403) {
        notification.error({
          message: a.message
        })
        setSpinActive(false);
      } else {
        notification.success({
          message: a.message
        })
        callback()
      }
    })
  }

  async function fetchDataPut(data, callback) {
    let respon = await fetch('/api/estudiantes', {
      method: "PUT",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(async (data) => {
      let a = await data.json()
      if (a.code === 403) {
        notification.error({
          message: a.message
        })
        setSpinActive(false);
      } else {
        notification.success({
          message: a.message
        })
        callback()
      }
    })
  }

  const handleOk = (values) => {
    if (props.option.option === 1) {
      let data = {
        ...values,
        option: props.option.option
      }
      setSpinActive(true);
      fetchData(data, () => {
        props.valorCloseModal()
        registro_paciente.resetFields()
        setSpinActive(false);
      })

    } else if (props.option.option === 3) {
      let data = {
        id: props.option.id,
        ...values,
        option: props.option.option
      }
      setSpinActive(true);
      fetchDataPut(data, () => {
        props.valorCloseModal()
        registro_paciente.resetFields()
        setSpinActive(false);
      })

    }

  }
  const disabled = () => {
    if (props.option.option === 2) {
      return true
    } else {
      return false
    }
  }
  let disable = disabled()

  useEffect(() => {
    if (props.option.option === 4) {

    } else if (props.option.option === 3 || props.option.option === 2) {

      registro_paciente.setFieldsValue({
        nombres: props.one && props.one.nombres,
        apellidos: props.one && props.one.apellidos,
        correo: props.one && props.one.correo,
        cedula: props.one && props.one.cedula.cedula_num,
        grupo: props.one && props.one.grupo,
        ano: props.one && props.one.ano,
        contrasena: props.one && props.one.contrasena

      })

    }
  }, [props.option, props.one]);


  return (
    <Modal

      title={props.option.modalHeader}
      width={800}
      style={{ top: 20 }}
      open={props.option.modal}
      onOk={handleOk}
      onCancel={handleCancel}
      confirmLoading={spinActive}
      okText={props.option.modalFooter}
      footer={null}
      okButtonProps={{
        htmlType: "submit",

      }}
    >

      <Form
        name="registro_paciente"
        layout={"horizontal"}
        form={registro_paciente}
        onFinish={handleOk}
      >
        <Form.Item style={{ height: "30px" }} label="Nombres" name="nombres" rules={[{ required: true, message: 'Por favor ingresa los nombres del paciente' }]}>
          <Input style={{ height: "30px", textAlign: "left" }} disabled={disable} />
        </Form.Item>

        <Form.Item style={{ marginTop: "4px" }} label="Apellidos" name="apellidos" rules={[{ required: true, message: 'Por favor ingresa los apellidos del paciente' }]}>
          <Input style={{ height: "30px", marginTop: "4px", textAlign: "left" }} disabled={disable} />
        </Form.Item>

        <Form.Item label="Cédula" name="cedula" rules={[
          { required: true, message: 'Por favor ingrese la Cédula' },
          { pattern: /^[0-9]+$/, message: 'La cédula debe contener solo números.' }
        ]}>
          <Input style={{ height: "30px", textAlign: "left" }} disabled={props.option.option === 3 ? true : disable} />
        </Form.Item>

        <Form.Item label="Año" name="ano" rules={[{ required: true, message: 'Por favor ingrese la Año' }]}>
          <Input style={{ height: "30px", textAlign: "left" }} disabled={disable} />
        </Form.Item>

        <Form.Item label="Grupo" name="grupo" rules={[{ required: true, message: 'Por favor ingrese la Grupo' }]}>
          <Input style={{ height: "30px", textAlign: "left" }} disabled={disable} />
        </Form.Item>

        <Form.Item label="Correo" name="correo" rules={[
          { required: true, message: 'Por favor ingrese la Correo' },
          { pattern: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, message: 'Por favor revise la estructura del correo' }
        ]}>
          <Input style={{ height: "30px", textAlign: "left", marginTop: "5px" }} disabled={disable} />
        </Form.Item>

        <Form.Item label="Contraseña" name="contrasena" rules={[{ required: true, message: 'Por favor ingrese la Contraseña' }]}>
          <Input style={{ height: "30px", textAlign: "left" }} disabled={disable} type="password" />
        </Form.Item>

        <div style={{ textAlign: 'right' }}>
          <Space direction='vertical'>
            <Space>
              <Form.Item >
                <Button danger onClick={handleCancel}>
                  Cancelar
                </Button>
              </Form.Item>
              {props.option.showHide === 'show' &&
                <Form.Item >
                  <Button type="primary" htmlType="submit" loading={spinActive}>
                    {props.option.modalFooter}
                  </Button>
                </Form.Item>
              }
            </Space>
          </Space>
        </div>

      </Form>
    </Modal>
  )
}

export default EstudianteModal