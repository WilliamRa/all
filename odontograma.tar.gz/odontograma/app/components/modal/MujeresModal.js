'use client'

import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { Form, Modal, Input, DatePicker, Select, Space, Button, Switch, Radio, notification } from "antd"
import { useSession } from "next-auth/react";
import { useState, useEffect } from "react";
const { Option } = Select;
import dayjs from 'dayjs';
import { mujeresPreguntas } from "./childrens/preguntas";

const HistoriasFamiliaresModal = (props) => {
  const { data: session } = useSession(authOptions)
  const [registro_historia_clinica] = Form.useForm();
  const [spinActive, setSpinActive] = useState(false)
  console.log("props", props)
  const handleCancel = () => {
    props.valorCloseModal()
  }

  async function fetchData(data, callback) {
    await fetch('/api/mujeres', {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(async (data) => {
      let a = await data.json()
      if (a.code === 403) {
        notification.error({
          message: a.message
        })
        setSpinActive(false);
      } else {
        callback()
      }
    })
    

  }

  async function fetchDataPut(data, callback) {
    let respon = await fetch('/api/mujeres', {
      method: "PUT",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    callback()

  }
  const handleOk = (values) => {
    if (props.option.option === 1) {
      let data = {
        ...values,
        option: props.option.option
      }
      setSpinActive(true);
      fetchData(data, () => {
        props.valorCloseModal()
        registro_historia_clinica.resetFields()
        setSpinActive(false);
      })

    } else if (props.option.option === 3) {
      console.log(values)
      let data = {
        id: props.option.id,
        ...values,
      }
      setSpinActive(true);
      fetchDataPut(data, () => {
        props.valorCloseModal()
        registro_historia_clinica.resetFields()
        setSpinActive(false);
      })

    }

  }

  const disabled = () => {
    if (props.option.option === 2) {
      return true
    } else {
      return false
    }
  }
  let disable = disabled()

  const onchange = () => {
    if (props.option.option === 2) {
      return true
    } else {
      return false
    }
  }

  useEffect(() => {
    if (props.option.option === 4) {

    } else if (props.option.option === 3 || props.option.option === 2) {

      registro_historia_clinica.setFieldsValue({
        embarazo: props.one && props.one.emabarazo,
        pastillas_anticonceptivas: props.one && props.one.pastillas_anticonceptivas,
        desarreglos_menstruales: props.one && props.one.desarreglos_menstruales,
        menopausia: props.one && props.one.menopausia
      })

    }
  }, [props.option, props.one]);


  return (
    <Modal

      title={props.option.modalHeader}
      width={800}
      style={{ top: 20 }}
      open={props.option.modal}
      onOk={handleOk}
      onCancel={handleCancel}
      confirmLoading={spinActive}
      okText={props.option.modalFooter}
      footer={null}
      okButtonProps={{
        htmlType: "submit",

      }}
    >

      <Form
        name="registro_historia_clinica"
        layout={"vertical"}
        form={registro_historia_clinica}
        onFinish={handleOk}
      >

        {
          props.option.option === 1 && (
            <Form.Item style={{ marginTop: "4px" }} label="Número de Historia" name="numero_historia"
              rules={[
                { required: true, message: 'Por favor ingresa el numero de Historia' },
                { pattern: /^[0-9]+$/, message: 'La cédula debe contener solo números.' }
              ]}
            >
              <Input style={{ height: "30px", marginTop: "4px", textAlign: "left" }} disabled={disable} />
            </Form.Item>
          )
        }

        {mujeresPreguntas.map((preguntas, index) => {
          return (
            < Form.Item label={preguntas.label} name={preguntas.name} key={index} rules={[{ required: true, message: 'Por favor ingrese seleccione una Opcion' }]}>
              <Radio.Group disabled={disable}>
                <Radio value={1}> SI </Radio>
                <Radio value={0}> NO </Radio>
              </Radio.Group >
            </Form.Item>
          )
        })

        }


        <div style={{ textAlign: 'right' }}>
          <Space direction='vertical'>
            <Space>
              <Form.Item >
                <Button danger onClick={handleCancel}>
                  Cancelar
                </Button>
              </Form.Item>
              {props.option.showHide === 'show' &&
                <Form.Item >
                  <Button type="primary" htmlType="submit" loading={spinActive}>
                    {props.option.modalFooter}
                  </Button>
                </Form.Item>
              }
            </Space>
          </Space>
        </div>

      </Form>
    </Modal >
  )
}

export default HistoriasFamiliaresModal