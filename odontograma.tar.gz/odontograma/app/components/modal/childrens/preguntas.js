export let antecedentesPersonales = [
  {
    label: "¿Se siente nervioso al tener que acudir al odontólogo",
    name: "nervios_al_odontologo"
  },
  {
    label: "¿Tiene actualmente dolor o molestia en la boca?",
    name: "dolor_boca"
  },
  {
    label: "¿Ha tenido recientemente dolor en su dentadura?",
    name: "dolor_dentadura"
  },
  {
    label: "¿Tiene usted dientes sensibles?",
    name: "dientes_sensibles"
  },
  {
    label: "¿Le sangran a usted las encías?",
    name: "sangrado_encias"
  },
  {
    label: "¿Ha llevado aparato ortopédico u ortodóncico en boca?",
    name: "aparato_ortopedico_odontologico"
  },
  {
    label: "¿Ha tenido alguna ulceración o inflamación en boca o mandíbula?",
    name: "ulcera_inflamacion"
  },
  {
    label: "¿Le han realizado algun tratamiento quirurgico o RX en boca o cara?",
    name: "quirurgico_rx"
  },
  {
    label: "¿Tiene usted dificultad para masticar sus alimentos?",
    name: "dificultad_masticar"
  },
  {
    label: "¿Se le hace dificil abrir la boca tanto como le gustaria?",
    name: "dificultad_abrir_boca"
  },
  {
    label: "¿Le suena la mandíbula cuando mastica?",
    name: "sonido_mandibular_masticar",
  },
  {
    label: "¿Tiene usted problemas con los senos de la cabeza o de la cara?",
    name: "problemas_senos_cabeza_cara",
  },
  {
    label: "¿Sufre hemorragias nasales?",
    name: "hemorragias_nasales",
  },
  {
    label: "¿Ha tenido alguna herida grave?",
    name: "herida_grave",
  },
  {
    label: "¿Sangra usted por largo tiempo cuando se corta?",
    name: "sangrado_largo_tiempo",
  },
  {
    label: "¿Le ha tratado un médico los ultimos dos años?",
    name: "tratado_medico_dos_anos",
  },
  {
    label: "¿Ha estado hospitalizado alguna vez?",
    name: "hospitalizado",
  },
  {
    label: "¿Actualmente se encuentra bajo traramiento médico?",
    name: "bajo_tratamiento_actualmente",
  },
  {
    label: "¿Ha experimentado alguna vez una hemorragia exesiva que haya requerido tratamiento especial?",
    name: "hemorragias_exesiva_tratamiento_especial",
  },

]

export let farmacosTomados = [
  {
    label: "Antibióticos",
    name: "antibioticos"
  },
  {
    label: "Anticoagulantes",
    name: "anticoagulantes"
  },
  {
    label: "Antidepresivos",
    name: "antidepresivos"
  },
  {
    label: "Esteroides (Cortisona)",
    name: "esteroides"
  },
  {
    label: "Aspirina",
    name: "aspirina"
  },
  {
    label: "Anticonvulsivos",
    name: "anticombulsivos"
  },
  {
    label: "Antiglicemiante",
    name: "antiglicemiante"
  },
  {
    label: "Otros",
    name: "otros"
  },
]

export let alergias = [
  {
    label: "Anestésicos Locales",
    name: "anestesicos_locales"
  },
  {
    label: "Penicilina u otro Antibiótico",
    name: "penicilina"
  },
  {
    label: "Sulfamidas",
    name: "sulfamidas"
  },
  {
    label: "Barbitúrico sedantes o pastillas para dormir",
    name: "barbitulicos"
  },
  {
    label: "Aspirina",
    name: "aspirina"
  },
  {
    label: "Algun Otro",
    name: "otro"
  },
]

export let enfermedades = [
  {
    label: "Insuficiencia Cardiaca",
    name: "insuficiencia_cardiaca"
  },
  {
    label: "Presión sanguinea alta",
    name: "presion_alta"
  },
  {
    label: "Válvulas cardiacas",
    name: "valvulas_cardiacas"
  },
  {
    label: "Fiebre Reumática",
    name: "fiebre_reumatica"
  },
  {
    label: "Anemia",
    name: "anemia"
  },
  {
    label: "Tuberculosis",
    name: "tuberculosis"
  },
  {
    label: "Artritis",
    name: "artritis"
  },
  {
    label: "Enfermedades Tiroideas",
    name: "enfermedades_tiroideas"
  },
  {
    label: "Enfermedades Suprarenales",
    name: "enfermedades_suprarenales"
  },
  {
    label: "SIDA",
    name: "sida"
  },
  {
    label: "Ataques al Corazón",
    name: "ataques_corazon"
  },
  {
    label: "Enfermedades Venereas",
    name: "enfermedades_venereas"
  },
  {
    label: "Marcapasos",
    name: "marcapasos"
  },
  {
    label: "Soplo Cardíaco",
    name: "soplo_cardiaco"
  },
  {
    label: "Hepatitis, itericia",
    name: "hepatitis"
  },
  {
    label: "Asma",
    name: "asma"
  },
  {
    label: "Diabetes",
    name: "diabetes"
  },
  {
    label: "Cáncer",
    name: "cancer"
  },
  {
    label: "Radioterapia",
    name: "radioterapia"
  },
  {
    label: "Quimioterapia",
    name: "quimioterapia"
  },
]

export let sintomasProcedimientos = [
  {
    label: "¿Le han realizado alguna Transfusión Sanguinea?",
    name: "transfusion_sanguinea_realizada"
  },
  {
    label: "¿Ha sufrido de urticaria o de alguna Erupción de la Piel?",
    name: "sufrido_urticaria_eruccion"
  },
  {
    label: "¿Se le producen hematomas o magulladuras con facilidad?",
    name: "moretones_magulladuras_facilidad"
  },
  {
    label: "¿Le ha dado a usted ataques o Convulsiones alguna vez?",
    name: "ataques_combulsiones"
  },
  {
    label: "¿Orina más de seis veces al día?",
    name: "orinar_seis_veces_dia"
  },
  {
    label: "¿Esta usted siempre sediento?",
    name: "siempre_sediento"
  },
  {
    label: "¿Ha tenido dolor en el pecho o le ha faltado el aire al realizar esfuerzos?",
    name: "dolor_pecho_falta_aire"
  },
  {
    label: "¿Se le hinchan los tobillos durante el día?",
    name: "hinchazon_tobillos"
  },
  {
    label: "¿Ha ganado o perdido mas de 5kg en el ultimo año?",
    name: "ganado_perdido_peso"
  },
  {
    label: "¿Se ha despertado alguna vez porque le ha faltado el aire?",
    name: "despierto_falta_aire"
  },
  {
    label: "¿Sigue alguna dieta especial por orden médica?",
    name: "dieta_especial"
  },
]

export let habitos = [
  {
    label: "Onicofagia",
    name: "onicofagia"
  },
  {
    label: "Queilofagia",
    name: "queilofagia"
  },
  {
    label: "Succión Digital",
    name: "succion_digital"
  },
  {
    label: "Abrir ganchos con los dientes",
    name: "abrir_ganchos_dientes"
  },
  {
    label: "Respirador Bucal",
    name: "respirador_bucal"
  },
  {
    label: "Tabaquismo",
    name: "tabaquismo"
  },
  {
    label: "Otros",
    name: "otros"
  },
]

export let mujeresPreguntas = [
  {
    label: "¿Esta Embarazada?",
    name: "embarazo"
  },
  {
    label: '¿Toma pastillas anticonceptivas?',
    name: 'pastillas_anticonceptivas'
  },
  {
    label: '¿Sufre de desarreglos menstruales?',
    name: 'desarreglos_menstruales'
  },
  {
    label: '¿Menopausia?',
    name: 'menopausia'
  }
]

export let trastornosMandibulares = [
  {
    label: "Dolor ATM",
    name: "dolor_atn"
  },
  {
    label: "Dolor Facial",
    name: "dolor_facial"
  },
  {
    label: "Limitación de Apertura",
    name: "limitacion_apertura"
  },
  {
    label: "Ruidos ATM",
    name: "ruidos_atm"
  },
  {
    label: "Desviaciones de la trayetoria mandibular",
    name: "desviacion_mandibular"
  }
]