'use client'

import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { Form, Modal, Input, InputNumber, Select, Space, Button } from "antd"
import { useSession } from "next-auth/react";
import { useState, useEffect } from "react";
import Odontogram from "../odontograma/Odontogram";
const { Option } = Select;

const HistoriasClinicaOperatoriasModal = (props) => {
  const { data: session } = useSession(authOptions)
  console.log(session)
  const [registro_paciente] = Form.useForm();
  const [spinActive, setSpinActive] = useState(false)
  console.log("props", props)
  const handleCancel = () => {
    props.valorCloseModal()
  }

  async function fetchData(data, callback) {
    let respon = await fetch('/api/dome', {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    callback()

  }

  async function fetchDataPut(data, callback) {
    let respon = await fetch('/api/dome', {
      method: "PUT",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    callback()

  }
  const handleOk = (values) => {
    if (props.option.option === 1) {
      let data = {
        ...values,
        estudiante: props.user.user.name.id,
        option: props.option.option
      }
      setSpinActive(true);
      fetchData(data, () => {
        props.valorCloseModal()
        registro_paciente.resetFields()
        setSpinActive(false);
      })

    } else if (props.option.option === 3) {
      let data = {
        id: props.option.id,
        ...values,
        estudiante: props.user.user.name.id,
        option: props.option.option
      }
      setSpinActive(true);
      fetchDataPut(data, () => {
        props.valorCloseModal()
        registro_paciente.resetFields()
        setSpinActive(false);
      })

    }

  }


  const disabled = () => {
    if (props.option.option === 2) {
      return true
    } else {
      return false
    }
  }
  let disable = disabled()

  useEffect(() => {
    if (props.option.option === 4) {

    } else if (props.option.option === 3 || props.option.option === 2) {

      registro_paciente.setFieldsValue({
        nombres: props.one && props.one.nombres,
        apellidos: props.one && props.one.apellidos,
        edad: props.one && props.one.edad,
        cedula: props.one && props.one.cedula.cedula_num,
        raza: props.one && props.one.raza,
        ocupacion: props.one && props.one.ocupacion,
        natural: props.one && props.one.natural,
        procedencia: props.one && props.one.procedencia,
        direccion: props.one && props.one.direccion,
        sexo: props.one && props.one.sexo.id

      })

    }
  }, [props.option, props.one]);


  return (
    <Modal

      title={props.option.modalHeader}
      width={1000}

      style={{ top: 20 }}
      open={props.option.modal}
      onOk={handleOk}
      onCancel={handleCancel}
      confirmLoading={spinActive}
      okText={props.option.modalFooter}
      footer={null}
      okButtonProps={{
        htmlType: "submit",

      }}
    >

      <Form
        name="registro_paciente"
        layout={"horizontal"}
        form={registro_paciente}
        onFinish={handleOk}
      >
        <Form.Item style={{ height: "30px" }} label="Cédula" name="cedula"
          rules={[{
            required: true,
            message: 'Por favor ingresa la Cédula'
          },
          {
            pattern: /^[0-9]+$/,
            message: 'La cédula debe contener solo números.',
          }
          ]}>
          <Input style={{ height: "30px", textAlign: "left" }} disabled={disable} />
        </Form.Item>
        <Odontogram />


        <div style={{ textAlign: 'right' }}>
          <Space direction='vertical'>
            <Space>
              <Form.Item >
                <Button danger onClick={handleCancel}>
                  Cancelar
                </Button>
              </Form.Item>
              {props.option.showHide === 'show' &&
                <Form.Item >
                  <Button type="primary" htmlType="submit" loading={spinActive}>
                    {props.option.modalFooter}
                  </Button>
                </Form.Item>
              }
            </Space>
          </Space>
        </div>

      </Form>
    </Modal>
  )
}

export default HistoriasClinicaOperatoriasModal