import React, { useEffect, useState } from 'react';
import { Modal, List, Typography, Button } from 'antd';
import { socket } from '../../../socket';

const { Text, Title } = Typography;

const NotificationModal = ({ visible, onClose, one }) => {
  const [observations, setObservations] = useState([]);
  const [selectedObservation, setSelectedObservation] = useState(null);

  useEffect(() => {
    if (visible) {
     setObservations(one)
    }
  }, [visible]);


  const selectObservation = (observation) => {
    setSelectedObservation(observation);
    console.log(observation)
  };

  const goBackToList = () => {
    setSelectedObservation(null);
  };

  useEffect(() => {
    socket.on('new-observacion-modal', (data) => {
      console.log(data,"AAAAAAAAAAAAAAAAAAAAAAAAAAA")
      setObservations(prevObservaciones => [...data]);
    });

    return () => {
      socket.off('new-observacion-modal');
    };

  }, [socket]);

  return (
    <Modal
      title={selectedObservation ? "Detalle de la Observación" : "Bandeja de Observaciones"}
      open={visible}
      onCancel={onClose}
      footer={
        selectedObservation ? (
          <Button onClick={goBackToList}>Volver a la Lista</Button>
        ) : null
      }
    >
      {selectedObservation ? (
        <div>
          <Title level={4}>{selectedObservation.title}</Title>
          <Text strong>Asunto: {selectedObservation.asunto}</Text>
          <p>{selectedObservation.observacion}</p>
        </div>
      ) : (
        <List
          dataSource={observations}
          pagination={{
            pageSize: 5
          }}
          renderItem={item => (
            <List.Item key={item.id} onClick={() => selectObservation(item)}>
              <List.Item.Meta
                title={<Text strong>Motivo de Observacion: {item.asunto}</Text>}
                description={item.contenido}
              />
            </List.Item>
          )}
        />
      )}
    </Modal>
  );
};

export default NotificationModal;
