'use client'

import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { Form, Modal, Input, DatePicker, Select, Space, Button, Switch, Radio, notification } from "antd"
import { useSession } from "next-auth/react";
import { useState, useEffect } from "react";
import Periodontograma from "../periodontograma/Periodontograma";

const ExamenPeriodontalModal = (props) => {
  const { data: session } = useSession(authOptions)
  const [registro_historia_clinica] = Form.useForm();
  const [spinActive, setSpinActive] = useState(false)

  const handleCancel = () => {
    props.valorCloseModal()
  }

  async function fetchData(data, callback) {
    await fetch('/api/periodontograma', {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(async (data) => {
      let a = await data.json()
      if (a.code === 403) {
        notification.error({
          message: a.message
        })
        setSpinActive(false);
      } else {
        notification.success({
          message: a.message
        })
        callback()
      }
    })


  }

  async function fetchDataPut(data, callback) {
    let respon = await fetch('/api/periodontograma', {
      method: "PUT",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    callback()

  }

  const handleOk = (values) => {
    if (props.option.option === 1) {
      let data = {
        periodonto: values,
        id: props.option.id,
        option: props.option.option
      }
      setSpinActive(true);
      fetchData(data, () => {
        props.valorCloseModal()

        setSpinActive(false);
      })

    } else if (props.option.option === 3) {
      let data = {
        periodonto: values,
      }
      console.log("UPDATE", data)
      setSpinActive(true);
      fetchDataPut(data, () => {
        props.valorCloseModal()
        registro_historia_clinica.resetFields()
        setSpinActive(false);
      })

    }

  }

  const disabled = () => {
    if (props.option.option === 2) {
      return true
    } else {
      return false
    }
  }
  let disable = disabled()

  const onchange = () => {
    if (props.option.option === 2) {
      return true
    } else {
      return false
    }
  }

  useEffect(() => {
    if (props.option.option === 4) {

    } else if (props.option.option === 3 || props.option.option === 2) {

    }
  }, [props.option, props.one]);


  return (
    <Modal
      title={props.option.modalHeader}
      width={800}
      style={{ top: 20 }}
      open={props.option.modal}
      onOk={handleOk}
      onCancel={handleCancel}
      confirmLoading={spinActive}
      okText={props.option.modalFooter}
      footer={null}
      okButtonProps={{
        htmlType: "submit",

      }}
    >
      {props.one ?

        <Periodontograma
          handleOk={handleOk}
          option={props.option}
          handleCancel={handleCancel}
          spinActive={spinActive}
          one={props.one}
        /> :

        <Periodontograma
          handleOk={handleOk}
          option={props.option}
          handleCancel={handleCancel}
          spinActive={spinActive}
          one={null}
        />

      }


    </Modal >
  )
}

export default ExamenPeriodontalModal