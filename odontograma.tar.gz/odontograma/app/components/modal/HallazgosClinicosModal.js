'use client'

import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { Form, Modal, Input, DatePicker, Select, Space, Button, Upload, Radio, Tabs, notification } from "antd"
import { useSession } from "next-auth/react";
import { useState, useEffect } from "react";
import { UploadOutlined } from '@ant-design/icons';
import { trastornosMandibulares } from "./childrens/preguntas";
const { Option } = Select;
import dayjs from 'dayjs';
import TextArea from "antd/es/input/TextArea";

const HallazgosClinicosModal = (props) => {
  const { data: session } = useSession(authOptions)
  const [hallazgosClinicos] = Form.useForm();
  const [trastornosMandibularesform] = Form.useForm();
  const [diagnosticos] = Form.useForm();
  const [spinActive, setSpinActive] = useState(false)

  const [tejidosBlandos, setTejidosBlandos] = useState([]);
  const [tejidosDuros, setTejidosDuros] = useState([]);
  const [encias, setEncias] = useState([]);
  const [factoresEtiologicos, setfactoresEtiologicos] = useState([]);
  const [examenOclusal, setexamenOclusal] = useState([]);

  const [tabDisable2, setTadDisable2] = useState(true)
  const [tabDisable3, setTadDisable3] = useState(true)
  const [activeTab, setActiveTab] = useState("1");


  const handleChangeTejidosBlandos = ({ fileList: newFileList }) => setTejidosBlandos(newFileList)
  const handleChangeTejidosDuros = ({ fileList: newFileList }) => setTejidosDuros(newFileList)
  const handleChangeEncias = ({ fileList: newFileList }) => setEncias(newFileList)
  const handleChangeFactoresEtiologicos = ({ fileList: newFileList }) => setfactoresEtiologicos(newFileList)
  const handleChangeExamenOclusal = ({ fileList: newFileList }) => setexamenOclusal(newFileList)

  const handleCancel = () => {
    props.valorCloseModal()
    setActiveTab('1')
    setTadDisable2(true)
    setTadDisable3(true)

    hallazgosClinicos.resetFields()
    trastornosMandibularesform.resetFields()
    diagnosticos.resetFields()
    setSpinActive(false)
    setTejidosBlandos([])
    setTejidosDuros([])
    setEncias([])
    setfactoresEtiologicos([])
    setexamenOclusal([])
  }

  const handleFormSubmit = async () => {
    const nextTab = parseInt(activeTab) + 1;
    switch (activeTab) {
      case "1":
        await hallazgosClinicos.validateFields();
        setTadDisable2(false);
        setActiveTab(nextTab.toString());
        break;
      case "2":
        await trastornosMandibularesform.validateFields();
        setTadDisable3(false);
        setActiveTab(nextTab.toString());
        break;
      case "3":
        await diagnosticos.validateFields();
        break;

      default:
        break;
    }

  };

  const customRequest = ({ onSuccess }) => {
    setTimeout(() => {
      onSuccess('ok');
    }, 0);
  };
  const normFile = (e) => {
    console.log('Upload event:', e);

    if (Array.isArray(e)) {

      return e;
    }
    return e?.fileList;
  };

  async function fetchData(data, callback) {
    await fetch('/api/hallazgosClinicos', {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(async (data) => {
      let a = await data.json()
      if (a.code === 403) {
        notification.error({
          message: a.message
        })
        setSpinActive(false);
      } else {
        callback()
      }
    })


  }
  async function fetchDataPut(data, callback) {
    let respon = await fetch('/api/hallazgosClinicos', {
      method: "PUT",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    callback()

  }

  // const setBlob = (data) => {
  //   const jsonString = JSON.stringify(data);
  //   // Codifica la cadena JSON en Base64
  //   const base64String = btoa(jsonString);
  //   return base64String
  // }

  // const setDecodeBlob = (data) => {
  //   const jsonString = Buffer.from(data.data).toString('utf-8');
  //   const objetos = JSON.parse(jsonString);

  //   return objetos
  // }

  const handleOk = async (values) => {
    let hallazgos = hallazgosClinicos.getFieldValue()
    let trastornosMandibulares = trastornosMandibularesform.getFieldValue()
    let diagnostico = diagnosticos.getFieldValue()

    if (props.option.option === 1) {

      let data = {
        option: props.option.option,
        hallazgos: {
          ...hallazgos,
          fecha: dayjs(hallazgos.fecha),
        },
        trastornosMandibulares,
        diagnostico,
      }

      setSpinActive(true);
      console.log(data)
      fetchData(data, () => {
        props.valorCloseModal()
        setSpinActive(false);
        hallazgosClinicos.resetFields()
        trastornosMandibularesform.resetFields()
        diagnosticos.resetFields()
        setActiveTab('1')
        setTadDisable2(true)
        setTadDisable3(true)
      })

    } else if (props.option.option === 3) {
      let data = {
        id: props.option.id,
        option: props.option.option,
        hallazgos: {
          ...hallazgos,
          fecha: dayjs(hallazgos.fecha),
        
        },
        trastornosMandibulares,
        diagnostico,
      }

      setSpinActive(true);
      console.log(data)
      fetchDataPut(data, () => {
        props.valorCloseModal()
        setSpinActive(false);
        hallazgosClinicos.resetFields()
        trastornosMandibularesform.resetFields()
        diagnosticos.resetFields()
        setActiveTab('1')
        setTadDisable2(true)
        setTadDisable3(true)
      })

    }

  }

  const disabled = () => {
    if (props.option.option === 2) {
      return true
    } else {
      return false
    }
  }

  useEffect(() => {
    if ((props.option.option === 3) || (props.option.option === 2)) {
      setTadDisable2(false)
      setTadDisable3(false)

      let fec = props.one && dayjs(props.one.fecha)
      hallazgosClinicos.setFieldsValue({
        fecha: props.one && fec,
        presion_arterial: props.one && props.one.presion_arterial,
        pulso: props.one && props.one.pulso,
        frecuencia_respiratoria: props.one && props.one.ferecuencia_respiratoria,
        temperatura: props.one && props.one.temperatura,
        tejidos_blandos: props.one && props.one.tejidos_blandos,
        tejidos_duros: props.one && props.one.tejidos_duros,
        encias: props.one && props.one.encia,
        factores_etiologicos: props.one && props.one.factores_etiologicos,
        examen_oclusal: props.one && props.one.examen_oclusal
      })

      trastornosMandibularesform.setFieldsValue({
        dolor_atn: props.one && props.one.trastronos_mandibulares.dolor_atn,
        dolor_facial: props.one && props.one.trastronos_mandibulares.dolor_facial,
        limitacion_apertura: props.one && props.one.trastronos_mandibulares.limitacion_apertura,
        ruidos_atm: props.one && props.one.trastronos_mandibulares.ruidos_atm,
        desviacion_mandibular: props.one && props.one.trastronos_mandibulares.desviacion_mandivular,
        observaciones: props.one && props.one.trastronos_mandibulares.observaciones,
      })

      diagnosticos.setFieldsValue({
        diagnostico_presuntivo: props.one && props.one.diagnosticos.diagnostico_presuntivo,
        diagnostico_complementario: props.one && props.one.diagnosticos.diagnostico_complementario,
        diagnostico_definitivo: props.one && props.one.diagnosticos.diagnostico_definitivo,
        pronostico: props.one && props.one.diagnosticos.diagnostico_definitivo,
        plan_tratamiento_general: props.one && props.one.diagnosticos.plan_tratamiento_general,
        recomendaciones: props.one && props.one.diagnosticos.recomendaciones,
        conclusiones: props.one && props.one.diagnosticos.conclusiones,
      })
    }
  }, [props.option, props.one]);

  let disable = disabled()

  let items = [
    {
      key: '1',
      label: 'Hallazgos Clinicos',
      children: (
        <>
          <Form
            name="hallazgosClinicos"
            layout={"horizontal"}
            form={hallazgosClinicos}
            onFinish={handleOk}
          >

            {props.option.option === 1 &&
              <Form.Item style={{ marginTop: "4px" }} label="Numero Historia" name="numero_historia"
                rules={[
                  { required: true, message: 'Por favor ingresa la el Numero de Historia' },
                  { pattern: /^[0-9]+$/, message: 'La cédula debe contener solo números.' }
                ]}
              >
                <Input style={{ height: "30px", marginTop: "4px", textAlign: "left" }} disabled={disable} />
              </Form.Item>
            }


            <Form.Item label="Fecha" name="fecha" rules={[{ required: true, message: 'Por favor ingrese la Fecha' }]}>
              <DatePicker style={{ height: "30px", textAlign: "left" }} disabled={disable} format="DD/MM/YYYY" picker="date" />
            </Form.Item>
            <Form.Item style={{ marginTop: "4px" }} label="Presión Arterial" name="presion_arterial"
              rules={[
                { required: true, message: 'Por favor ingresa la Presión Arterial' },
                // { pattern: /^[0-9]+$/, message: 'La cédula debe contener solo números.' }
              ]}
            >
              <Input style={{ height: "30px", marginTop: "4px", textAlign: "left" }} disabled={disable} />
            </Form.Item>

            <Form.Item style={{ marginTop: "4px" }} label="Pulso" name="pulso"
              rules={[
                { required: true, message: 'Por favor ingresa el Pulso' },
               
              ]}
            >
              <Input style={{ height: "30px", marginTop: "4px", textAlign: "left" }} disabled={disable} />
            </Form.Item>

            <Form.Item style={{ marginTop: "4px" }} label="Frecuencia Respiratoria" name="frecuencia_respiratoria"
              rules={[
                { required: true, message: 'Por favor ingresa la Frecuencia Respiratoria' },
               
              ]}
            >
              <Input style={{ height: "30px", marginTop: "4px", textAlign: "left" }} disabled={disable} />
            </Form.Item>

            <Form.Item style={{ marginTop: "4px" }} label="Temperatura" name="temperatura"
              rules={[
                { required: true, message: 'Por favor ingrese la Temperatura' },
                // { pattern: /^[0-9]+$/, message: 'La cédula debe contener solo números.' }
              ]}
            >
              <Input style={{ height: "30px", marginTop: "4px", textAlign: "left" }} disabled={disable} />
            </Form.Item>

            <Form.Item
              name="tejidos_blandos"
              label="Examen de Tejidos Blandos"
              //valuePropName="fileList"

              rules={[{ required: true, message: "Pro favor agregue el examen de tejidos blandos" }]}
            >
              <TextArea
                rows={4}
                name="tejidos_blandos"
             
                disabled={disable}
              />
              

            </Form.Item>

            <Form.Item
              name="tejidos_duros"
              label="Examen de Tejidos Duros"
              //valuePropName="fileList"

              rules={[{ required: true, message: "Pro favor agregue el examen de tejidos duros" }]}
            >
              <TextArea
                 rows={4}
                name="tejidos_duros"
                disabled={disable}
              />
                

            </Form.Item>

            <Form.Item
              name="encias"
              label="Encias"
              //valuePropName="fileList"

              rules={[{ required: true, message: "Pro favor agregue el examen de encias" }]}
            >
              <TextArea
                 rows={4}
                name="encias"
                disabled={disable}
              />
              
            </Form.Item>

            <Form.Item
              name="factores_etiologicos"
              label="Factores Etiologicos"
              //valuePropName="fileList"
              rules={[{ required: true, message: "Pro favor agregue el examen de Factores Etiologicos" }]}
            >
              <TextArea
                rows={4}
                name="factores_etiologicos"
                disabled={disable}
              />
               
            </Form.Item>

            <Form.Item
              name="examen_oclusal"
              label="Examen Oclusal"
              //valuePropName="fileList"
              rules={[{ required: true, message: "Pro favor agregue el examen oclusal" }]}
            >
              <TextArea
                rows={4}
                name="examen_oclusal"
                disabled={disable}
              />
            </Form.Item>
            <div style={{ textAlign: 'right' }}>
              <Space direction='vertical'>
                <Space>
                  <Form.Item >
                    <Button danger onClick={handleCancel}>
                      Cancelar
                    </Button>
                  </Form.Item>
                  {props.option.showHide === 'show' &&
                    <Form.Item >
                      <Button type="primary" onClick={handleFormSubmit}>
                        Siguiente
                      </Button>
                    </Form.Item>
                  }
                </Space>
              </Space>
            </div>

          </Form>
        </>
      )
    },
    {
      key: '2',
      label: 'Trastornos Mandibulares',
      disabled: tabDisable2,
      children: (
        <>
          <Form
            name="trastornosMandibularesform"
            layout={"vertical"}
            form={trastornosMandibularesform}
            onFinish={handleOk}
          >
            {
              trastornosMandibulares.map((preguntas, index) => {
                return (
                  <Form.Item label={preguntas.label} name={preguntas.name} rules={[{ required: true, message: 'Por favor ingrese seleccione una Opcion' }]} key={index}>
                    <Radio.Group disabled={disable}>
                      <Radio value={1}> SI </Radio>
                      <Radio value={0}> NO </Radio>
                    </Radio.Group>
                  </Form.Item>
                )
              })
            }


            <Form.Item style={{ marginTop: "4px" }} label="Observaciones" name="observaciones"
              rules={[
                { required: true, message: 'Por favor ingresa las Observaciones' },
              ]}
            >
              <Input.TextArea style={{ height: "30px", marginTop: "4px", textAlign: "left" }} disabled={disable} />
            </Form.Item>

            <div style={{ textAlign: 'right' }}>
              <Space direction='vertical'>
                <Space>
                  <Form.Item >
                    <Button danger onClick={handleCancel}>
                      Cancelar
                    </Button>
                  </Form.Item>
                  {props.option.showHide === 'show' &&
                    <Form.Item >
                      <Button type="primary" onClick={handleFormSubmit}>
                        Siguiente
                      </Button>
                    </Form.Item>
                  }
                </Space>
              </Space>
            </div>
          </Form>
        </>
      )
    },
    {
      key: '3',
      label: 'Diagnosticos',
      disabled: tabDisable3,
      children: (
        <>
          <Form
            name="diagnosticos"
            layout={"vertical"}
            form={diagnosticos}
            onFinish={handleOk}
          >

            <Form.Item label="Diagnostico Presuntivo" name="diagnostico_presuntivo" rules={[{ required: true, message: 'Ingrese el Diagnostico Presuntivo' }]} >
              <Input.TextArea disabled={disable} />
            </Form.Item>

            <Form.Item label="Examen Complementario" name="diagnostico_complementario" rules={[{ required: true, message: 'Ingrese el Diagnostico Complementario' }]} >
              <Input.TextArea disabled={disable} />
            </Form.Item>

            <Form.Item label="Diagnostico Definitivo" name="diagnostico_definitivo" rules={[{ required: true, message: 'Ingrese el Diagnostico Definitivo' }]} >
              <Input.TextArea disabled={disable} />
            </Form.Item>

            <Form.Item label="Pronostico" name="pronostico" rules={[{ required: true, message: 'Ingrese el Pronostico' }]} >
              <Input.TextArea disabled={disable} />
            </Form.Item>
            <Form.Item label="Plan de Tratamiento General" name="plan_tratamiento_general" rules={[{ required: true, message: 'Ingrese el Plan de tratamiento General' }]} >
              <Input.TextArea disabled={disable} />
            </Form.Item>
            <Form.Item label="Recomendaciones" name="recomendaciones" rules={[{ required: true, message: 'Ingrese la Recomendaciones' }]} >
              <Input.TextArea disabled={disable} />
            </Form.Item>
            <Form.Item label="Conclusiones" name="conclusiones" rules={[{ required: true, message: 'Ingrese las Conclusiones' }]} >
              <Input.TextArea disabled={disable} />
            </Form.Item>


            <div style={{ textAlign: 'right' }}>
              <Space direction='vertical'>
                <Space>
                  <Form.Item >
                    <Button danger onClick={handleCancel}>
                      Cancelar
                    </Button>
                  </Form.Item>
                  {props.option.showHide === 'show' &&
                    <Form.Item >
                      <Button type="primary" htmlType="submit" loading={spinActive}>
                        {props.option.modalFooter}
                      </Button>
                    </Form.Item>
                  }
                </Space>
              </Space>
            </div>
          </Form>
        </>
      )
    },

  ]

  return (
    <Modal

      title={props.option.modalHeader}
      width={800}
      style={{ top: 20 }}
      open={props.option.modal}
      onOk={handleOk}
      onCancel={handleCancel}
      confirmLoading={spinActive}
      okText={props.option.modalFooter}
      footer={null}
      okButtonProps={{
        htmlType: "submit",

      }}
    >
      <Tabs defaultActiveKey={activeTab} activeKey={activeTab} items={items} onChange={setActiveTab} />

    </Modal>
  )
}

export default HallazgosClinicosModal