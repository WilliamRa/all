'use client'

import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { Form, Modal, Input, DatePicker, Select, Space, Button, Switch, Radio, notification, Upload } from "antd"
import { useSession } from "next-auth/react";
import { useState, useEffect } from "react";
const { Option } = Select;
import dayjs from 'dayjs';
import { mujeresPreguntas } from "./childrens/preguntas";
import TextArea from "antd/es/input/TextArea";
import { UploadOutlined } from '@ant-design/icons';
import { AiFillDislike } from 'react-icons/ai';
import { AiFillLike } from 'react-icons/ai';

const RadiografiasModal = (props) => {
  const { data: session } = useSession(authOptions)
  const [registro_radiografias] = Form.useForm();
  const [spinActive, setSpinActive] = useState(false)
  const [radiografia, setRadiografia] = useState([])
  const handleCancel = () => {
    props.valorCloseModal()
  }

  const setBlob = (data) => {
    const jsonString = JSON.stringify(data);

    // Codifica la cadena JSON en Base64
    const base64String = btoa(jsonString);
    return base64String

  }

  const setDecodeBlob = (data) => {
    try {
      // Decodifica la cadena Base64
      const buffer = Buffer.from(data, 'base64');
      const jsonString = buffer.toString('utf-8');

      // Convierte la cadena JSON a un objeto
      const objetos = JSON.parse(jsonString);
      return objetos;
    } catch (error) {
      console.error('Error al decodificar el blob:', error);
      return null;
    }
  };

  async function fetchData(data, callback) {
    await fetch('/api/radiografias', {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(async (data) => {
      let a = await data.json()
      if (a.code === 403) {
        notification.error({
          message: a.message
        })
        setSpinActive(false);
      } else {
        callback()
      }
    })


  }

  async function fetchDataPut(data, callback) {
    let respon = await fetch('/api/radiografias', {
      method: "PUT",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    callback()

  }
  const handleOk = (values) => {
    let radiografiaBlob = setBlob(values.radiografias)

    if (props.option.option === 1) {
      let data = {
        ...values,
        radiografias: radiografiaBlob,
        option: props.option.option
      }

      setSpinActive(true);
      fetchData(data, () => {
        props.valorCloseModal()
        registro_radiografias.resetFields()
        setSpinActive(false);
      })

    } else if (props.option.option === 3) {
      console.log(values)
      let data = {
        id: props.option.id,
        ...values,
        radiografias: radiografiaBlob,
      }
      setSpinActive(true);
      fetchDataPut(data, () => {
        props.valorCloseModal()
        registro_radiografias.resetFields()
        setSpinActive(false);
      })

    }

  }

  const disabled = () => {
    if (props.option.option === 2) {
      return true
    } else {
      return false
    }
  }

  const disabledALL = () => {
    if (props.option.option >= 2) {
      return true
    } else {
      return false
    }
  }
  let disable = disabled()

  const normFile = (e) => {
    if (Array.isArray(e)) {

      return e;
    }
    return e?.fileList;
  };

  const customRequest = ({ onSuccess }) => {
    // No subas la imagen automáticamente al servidor.
    // En su lugar, puedes usar esta función para realizar acciones personalizadas, como validar la imagen, antes de guardarla en el estado.
    setTimeout(() => {
      onSuccess('ok');
    }, 0);
  };

  const onChangeRadiografia = ({ fileList: newFileList }) => {
    setRadiografia(newFileList);
  };

  const setStatus = (status) => {
    if (props.option.option === 2) {
      let data = {
        id: props.option.id,
        option: 4,
        status
      }
      setSpinActive(true);
      fetchData(data, () => {
        props.valorCloseModal()
        registro_radiografias.resetFields()
        setSpinActive(false);
      })

    }
  }

  useEffect(() => {
    if (props.option.option === 4) {

    } else if (props.option.option === 3 || props.option.option === 2) {
      if (props.one) {
        let radiografiasBLob = setDecodeBlob(props.one.radiografias)

        registro_radiografias.setFieldsValue({
          descripcion: props.one && props.one.descripcion,
          numero_historia: props.one && props.one.historia_clinica[0].numero_historia,
          radiografias: radiografiasBLob
        })



        if (radiografia.length === 0) {
          console.log(radiografiasBLob)
          setRadiografia(radiografiasBLob)
        }
      }
    }
  }, [props.option, props.one]);


  return (
    <Modal

      title={props.option.modalHeader}
      width={800}
      style={{ top: 20 }}
      open={props.option.modal}
      onOk={handleOk}
      onCancel={handleCancel}
      confirmLoading={spinActive}
      okText={props.option.modalFooter}
      footer={null}
      okButtonProps={{
        htmlType: "submit",

      }}
    >

      <Form
        name="registro_radiografias"
        layout={"vertical"}
        form={registro_radiografias}
        onFinish={handleOk}
      >

        <Form.Item label="Numero de Historia" name="numero_historia" rules={[{ required: true, message: 'Por favor ingresa el numero de historia' }]}>
          <Input style={{ height: "30px", textAlign: "left" }} />
        </Form.Item>

        <Form.Item
          name="radiografias"
          label="Radiografia"
          //valuePropName="fileList"
          getValueFromEvent={normFile}
          extra="Radiografia"
        >
          <Upload
            name="radiografias"
            listType="picture"
            customRequest={customRequest}
            fileList={radiografia}
            onChange={onChangeRadiografia}
            disabled={disable}
          >
            <Button icon={<UploadOutlined />}>Click to upload</Button>
          </Upload>
        </Form.Item>


        {props.user.user.name.rol_id === 2 &&
          <Space direction='vertical'>
            <Space>
              <Form.Item >
                <Button danger icon={<AiFillDislike />} onClick={() => setStatus(2)}>

                </Button>
              </Form.Item>

              <Form.Item >
                <Button type="primary" icon={<AiFillLike />} onClick={(e) => setStatus(1)}>

                </Button>
              </Form.Item>

            </Space>
          </Space>
        }


        <Form.Item label="Descripcion" name="descripcion" rules={[{ required: true, message: 'Por favor ingrese la Cedula' }]}>
          <TextArea disabled={disable} showCount maxLength={250} rows={6} />
        </Form.Item>
        <div style={{ textAlign: 'right' }}>
          <Space direction='vertical'>
            <Space>
              <Form.Item >
                <Button danger onClick={handleCancel}>
                  Cancelar
                </Button>
              </Form.Item>
              {props.option.showHide === 'show' &&
                <Form.Item >
                  <Button type="primary" htmlType="submit" loading={spinActive}>
                    {props.option.modalFooter}
                  </Button>
                </Form.Item>
              }
            </Space>
          </Space>
        </div>

      </Form>
    </Modal >
  )
}

export default RadiografiasModal
