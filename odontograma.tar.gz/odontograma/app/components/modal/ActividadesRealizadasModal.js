'use client'

import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { Form, Modal, Input, InputNumber, Select, Space, Button, notification, List, DatePicker } from "antd"
import { useSession } from "next-auth/react";
import { useState, useEffect } from "react";
const { Option } = Select;
import { FolderViewOutlined, FormOutlined, SnippetsOutlined } from '@ant-design/icons';
import TextArea from "antd/es/input/TextArea";
import dayjs from "dayjs";
import { AiFillDislike, AiFillLike } from "react-icons/ai";

const ActividadesRealizadasModal = (props) => {
  const { data: session } = useSession(authOptions)
  const [actividad, setActividad] = useState([])
  const [registro_actividades] = Form.useForm();
  const [spinActive, setSpinActive] = useState(false)


  const handleCancel = () => {
    props.valorCloseModal()
  }

  async function fetchData(data, callback) {
    let respon = await fetch('/api/actividadesRealizadas', {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(async (data) => {
      let a = await data.json()
      if (a.code === 403) {
        notification.error({
          message: a.message
        })
        setSpinActive(false);
      } else {
        notification.success({
          message: a.message
        })
        callback()
      }
    })
  }

  async function fetchDataPut(data, callback) {
    let respon = await fetch('/api/actividadesRealizadas', {
      method: "PUT",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(async (data) => {
      let a = await data.json()
      if (a.code === 403) {
        notification.error({
          message: a.message
        })
        setSpinActive(false);
      } else {
        notification.success({
          message: a.message
        })
        callback()
      }
    })
  }

  const handleOk = (values) => {
    if (props.option.option === 1) {
      let data = {
        usuario: session.user.name,
        ...values,
        option: props.option.option,
        actividad: actividad
      }
      setSpinActive(true);
      fetchData(data, () => {
        props.valorCloseModal()
        registro_actividades.resetFields()
        setSpinActive(false);
      })

    } else if (props.option.option === 3) {
      let data = {
        id: props.option.id,
        ...values,
        option: props.option.option,
        actividad: actividad
      }
      setSpinActive(true);
      fetchDataPut(data, () => {
        props.valorCloseModal()
        registro_actividades.resetFields()
        setSpinActive(false);
      })

    }

  }
  const disabled = () => {
    if (props.option.option === 2) {
      return true
    } else {
      return false
    }
  }

  const addList = () => {
    let data = registro_actividades.getFieldValue()
    // Actualiza el estado `actividad`
    setActividad(prev => [
      ...prev,
      {
        fecha: data.fecha,
        actividad_realizada: data.actividad_realizada
      }
    ]);

    registro_actividades.setFieldValue('fecha', null)
    registro_actividades.setFieldValue('actividad_realizada', "")
  };

  const deleteToList = (indexToRemove) => {
    setActividad(prev => prev.filter((_, index) => index !== indexToRemove));
  };

  const setStatus = (status) => {
    if (props.option.option === 2) {
      let data = {
        usuario: session.user.name,
        id: props.option.id,
        option: 4,
        status
      }
      setSpinActive(true);
      fetchData(data, () => {
        props.valorCloseModal()
        registro_actividades.resetFields()
        setSpinActive(false);
      })

    }
  }


  let disable = disabled()

  useEffect(() => {
    if (props.option.option === 4) {

    } else if (props.option.option === 3 || props.option.option === 2) {

      registro_actividades.setFieldsValue({
        numero_historia: props.one && props.one.numero_historia,
      })
      setActividad(props.one?.actividades_realizadas || []);
    }
  }, [props.option, props.one]);


  return (
    <Modal
      title={props.option.modalHeader}
      width={800}
      style={{ top: 20 }}
      open={props.option.modal}
      onOk={handleOk}
      onCancel={handleCancel}
      confirmLoading={spinActive}
      okText={props.option.modalFooter}
      footer={null}
      okButtonProps={{
        htmlType: "submit",
      }}
    >
      <Form
        name="registro_actividades"
        layout={"horizontal"}
        form={registro_actividades}
        onFinish={handleOk}
      >
        <Form.Item style={{ marginTop: "4px" }} label="Número de Historia" name="numero_historia"
          rules={[
            { required: true, message: 'Por favor ingresa el numero de Historia' },
            { pattern: /^[0-9]+$/, message: 'La cédula debe contener solo números.' }
          ]}
        >
          <Input style={{ height: "30px", marginTop: "4px", textAlign: "left" }} disabled={disable} />
        </Form.Item>

        <Form.Item label="Fecha" name="fecha" >
          <DatePicker style={{ height: "30px", textAlign: "left" }} disabled={disable} format="DD/MM/YYYY" picker="date" />
        </Form.Item>


        <Form.Item label="Actividad" name="actividad_realizada" >
          <TextArea rows={3} disabled={disable} />
        </Form.Item>

        {props.user.user.name.rol_id === 2 &&
          <Space direction='vertical'>
            <Space>
              <Form.Item >
                <Button danger icon={<AiFillDislike />} onClick={() => setStatus(2)}>

                </Button>
              </Form.Item>

              <Form.Item >
                <Button type="primary" icon={<AiFillLike />} onClick={(e) => setStatus(1)}>

                </Button>
              </Form.Item>

            </Space>
          </Space>
        }
        <div style={{ textAlign: 'right' }}>
          <Space direction='vertical'>
            <Space>
              <Form.Item >
                <Button danger onClick={handleCancel} disabled={disable}>
                  Cancelar
                </Button>
              </Form.Item>
              <Form.Item >
                <Button type='primary' onClick={addList} disabled={disable}>
                  Agregar
                </Button>
              </Form.Item>

            </Space>
          </Space>
        </div>
        <List
          dataSource={actividad}
          // pagination={{
          //   pageSize: 5
          // }}
          renderItem={(item, index) => (
            <List.Item key={item.id}>
              <List.Item.Meta description={item.actividad_realizada} />
              <List.Item.Meta description={dayjs(item.fecha).format('DD-MM-YYYY')} />
              <div>
                <Button icon={<FormOutlined />}
                  disabled={session.user.name.rol_id === 2 ? true : false}
                  size="middle"
                  //type='primary'
                  danger
                  shape='circle'
                  //style={{ marginRight: '8px', background: "#1677ff" }}
                  onClick={() => deleteToList(index)}
                />
              </div>
            </List.Item>
          )}
        />
        <div style={{ textAlign: 'right' }}>
          <Space direction='vertical'>
            <Space>
              <Form.Item >
                <Button danger onClick={handleCancel}>
                  Cancelar
                </Button>
              </Form.Item>
              {props.option.showHide === 'show' &&
                <Form.Item >
                  <Button type="primary" htmlType="submit" loading={spinActive}>
                    {props.option.modalFooter}
                  </Button>
                </Form.Item>
              }
            </Space>
          </Space>
        </div>

      </Form>
    </Modal>
  )
}

export default ActividadesRealizadasModal
