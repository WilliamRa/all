'use client'

import { useEffect, useReducer, useRef, useState } from 'react';
import useContextMenu from 'contextmenu';
import 'contextmenu/ContextMenu.css';
import './Tooth.css';

function Tooth({ number, positionX, positionY, onChange }) {
  const initialState = {
    number: number,
    Cavities: {
      top: 0,
      bottom: 0,
      left: 0,
      right: 0
    },
    Extract: 0,
  };
 
  const [toothState, dispatch] = useReducer(reducer, initialState);
  //let [estadoDiente, setEstadoDiente] = useState()
  const [contextMenu, useCM] = useContextMenu({ submenuSymbol: '>' });




  function reducer(toothState, action) {
    console.log(toothState, action)
    switch (action.type) {

      case 'extract':
        // Validación para no permitir marcar cavidades si el diente está ausente
        if (toothState.Extract > 0) {
          return toothState; // No se realiza ningún cambio si el diente está ausente
        }
        return {
          ...toothState,
          Extract: action.value
        };
      case 'carie':
        if (toothState.Extract > 0) {
          return toothState;
        }
        return {
          ...toothState,
          Cavities: setCavities(toothState, action.zone, action.value)
        };
      case 'clear':
        return initialState;
      default:
        throw new Error();
    }
  }



  const extract = (val) => ({
    type: "extract",
    value: val
  });

  const carie = (z, val) => ({
    type: "carie",
    value: val,
    zone: z
  });

  const clear = () => ({ type: "clear" });



  const doneSubMenu = (place, value) => {
    return {
      'Cavidad': () => {
        dispatch(carie(place, value));
      },
      'Ausente': () => dispatch(extract(value)),
    }
  }

  // Todo SubMenu
  const todoSubMenu = (place, value) => {
    return {
      'Cavidad': () => dispatch(carie(place, value)),
      'Ausente': () => dispatch(extract(value)),
    }
  }

  // Main ContextMenu
  const menuConfig = (place) => {
    return {
      'Done': doneSubMenu(place, 1),
      'JSX line': <hr></hr>,
      'Clear All': () => dispatch(clear()),
    }
  };

  let getClassNamesByZone = (zone, id) => {
    if (id > 0 && id < 3) {
      console.log("FINO")
    }
    if (toothState.Cavities) {
      if (toothState.Cavities[zone] === 1) {
        return 'to-do';
      } else if (toothState.Cavities[zone] === 2) {
        return 'done';
      }
    }

    return '';
  }

  // Tooth position
  const translate = `translate(${positionX},${positionY})`;

  function setCavities(prevState, zone, value) {
    prevState.Cavities[zone] = value;

    return prevState.Cavities;
  }

 
  function drawToothActions() {
    let otherFigures = null;
    if (toothState.Extract > 0) {
      otherFigures = <g stroke={toothState.Extract === 1 ? "red" : "blue"}>
        <line x1="0" y1="0" x2="14" y2="14" strokeWidth="1.5" />
        <line x1="-2" y1="14" x2="14" y2="-2" strokeWidth="1.5" />
      </g>
    }


    return otherFigures;
  }

  const firstUpdate = useRef(true);

  useEffect(() => {
    if (firstUpdate.current) {
      firstUpdate.current = false;
      return;
    }
    onChange(number, toothState);
  }, [toothState, onChange, number]);

  return (
    <svg className="tooth">
      <g transform={translate}>
        <polygon
          points={`${-1.211},${-1.211} ${6.660},${6.660} ${14.511},${-1.211}`}
          onContextMenu={useCM(menuConfig('top'))}
          className={getClassNamesByZone('top', number)}
          id={`tooth-${number}-top`}
        />
        <polygon
          points={`${-1.211},${14.511} ${6.660},${6.660} ${14.511},${14.511}`}
          onContextMenu={useCM(menuConfig('bottom'))}
          className={getClassNamesByZone('bottom')}
          id={`tooth-${number}-bottom`}
        />
        <polygon
          points={`${-1.211},${-1.211} ${6.660},${6.660} ${-1.211},${14.511}`}
          onContextMenu={useCM(menuConfig('left'))}
          className={getClassNamesByZone('left')}
          id={`tooth-${number}-left`}
        />
        <polygon
          points={`${14.511},${-1.211} ${6.660},${6.660} ${14.511},${14.511}`}
          onContextMenu={useCM(menuConfig('right'))}
          className={getClassNamesByZone('right')}
          id={`tooth-${number}-right`}
        />
        {drawToothActions()}
        <text
          x="1"
          y="25"
          stroke="navy"
          fill="navy"
          strokeWidth="0.1"
          className="tooth">
          {number}
        </text>
      </g>
      {contextMenu}
    </svg>
  )

}

export default Tooth;