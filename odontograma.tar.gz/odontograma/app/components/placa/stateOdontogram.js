export let odontogramStateInit = {
  "11": {
      "id": 11,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0,
          " right ": 1
      },
      "Extract": 0
  },
  "12": {
      "id": 12,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "13": {
      "id": 13,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "14": {
      "id": 14,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "15": {
      "id": 15,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "16": {
      "id": 16,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "17": {
      "id": 17,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "18": {
      "id": 18,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "21": {
      "id": 21,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "22": {
      "id": 22,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "23": {
      "id": 23,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "24": {
      "id": 24,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "25": {
      "id": 25,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "26": {
      "id": 26,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "27": {
      "id": 27,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "28": {
      "id": 28,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "31": {
      "id": 31,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "32": {
      "id": 32,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "33": {
      "id": 33,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "34": {
      "id": 34,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "35": {
      "id": 35,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "36": {
      "id": 36,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "37": {
      "id": 37,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "38": {
      "id": 38,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "41": {
      "id": 41,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 1,
          "right": 0
      },
      "Extract": 0
  },
  "42": {
      "id": 42,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "43": {
      "id": 43,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "44": {
      "id": 44,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "45": {
      "id": 45,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "46": {
      "id": 46,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "47": {
      "id": 47,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  },
  "48": {
      "id": 48,
      "Cavities": {
          "top": 0,
          "bottom": 0,
          "left": 0,
          "right": 0
      },
      "Extract": 0
  }
}