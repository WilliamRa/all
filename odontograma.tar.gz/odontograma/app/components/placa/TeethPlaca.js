'use client'
import React from 'react';
import Tooth from './ToothPlaca';

function Teeth({ start, end, x, y, handleChange }) {
  let tooths = getArray(start, end);
  return (
    <g transform="scale(1.2)" id="gmain">
      {
        tooths.map((i) =>
          <Tooth
            onChange={handleChange}
            key={i}
            number={i}
            positionY={y}
            positionX={Math.abs((i - start) * 20) + x} // Ajustar el valor de positionX
          />
        )
      }
    </g>
  )
}

function getArray(start, end) {
  if (start > end) return getInverseArray(start, end);

  let list = [];
  for (var i = start; i <= end; i++) {
    list.push(i);
  }

  return list;
}

function getInverseArray(start, end) {
  let list = [];

  for (var i = start; i >= end; i--) {
    list.push(i);
  }

  return list;
}

export default Teeth;