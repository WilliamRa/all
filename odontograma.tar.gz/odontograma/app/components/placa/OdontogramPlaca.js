'use client'
import React, { useEffect, useState } from 'react';
import './Odontogram.css';
import Teeth from './TeethPlaca';
import { odontogramStateInit } from './stateOdontogram';
import { Form, Space, Button } from "antd"
import Chart from "react-apexcharts";


function OdontogramPlaca(props) {
  const [state, setState] = useState({
    options: {
      chart: {
        id: "basic-bar"
      },
      xaxis: {
        categories: [],
        tickAmount: 10,
      },
      yaxis: {
        min: 0,
        max: 100,
        tickAmount: 10,
      }
    },
    series: [
      {
        name: "series-2",
        data: []
      }
    ]
  });

  let odontogramState = {};

  const handleToothUpdate = (id, toothState) => {
    odontogramState[id] = toothState;
    console.log(odontogramState)
  };

  const handleCancel = () => {
    props.valorCloseModal()
    setState({
    options: {
      chart: {
        id: "basic-bar"
      },
      xaxis: {
        categories: [],
        tickAmount: 10,
      },
      yaxis: {
        min: 0,
        max: 100,
        tickAmount: 10,
      }
    },
    series: [
      {
        name: "Control de placa",
        data: []
      }
    ]
  })
  }
  async function fetchData(data, callback) {
    let respon = await fetch('/api/controlPlacas', {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    callback()

  }

  const handleOk = async (values) => {
    if (props.option.option === 1) {
      let contadorCaras = 0
      let contadorDientes = 32
      let calculoDiente
      let dientesExlorados
      let resultado
      Object.values(odontogramState).forEach(value => {
        if (value.Cavities.top === 1) contadorCaras++

        if (value.Cavities.bottom === 1) contadorCaras++

        if (value.Cavities.left === 1) contadorCaras++

        if (value.Cavities.right === 1) contadorCaras++

        if (value.Extract === 1) contadorDientes--
      });

      calculoDiente = contadorCaras * 100
      dientesExlorados = contadorDientes * 4
      resultado = calculoDiente / dientesExlorados
      let data = {
        option: props.option.option,
        id: props.option.id,
        placa_porcentaje: resultado
      }

      fetchData(data, () => {
        props.valorCloseModal()
      })

    } else if (props.option.option === 3) {
      let data = {
        id: props.id,
        placa_porcentaje: resultado
      }

      // fetchDataPut(data, () => {
      //   props.valorCloseModal()
      // })

    }

  }



  useEffect(() => {
    if (props.option.option === 2 && props.one) {
      setState({
        ...state,
        options: {
          ...state.options,
          xaxis: {
            categories: props.one.control,
            tickAmount: 10,
          },
          yaxis: {
            min: 0,
            max: 100,
            tickAmount: 10,
          }
        },
        series: [
          {
            name: "Control de placas",
            data: props.one.porcentaje
          }
        ]
      });
    }
  }, [props.option, props.one]);

  return (
    <div className="Odontogram">
       {props.option.option === 2 &&
      <Chart
        options={state.options}
        series={state.series}
        type="line"
        width="500"
        height="400"
      />
       }
      {props.option.option === 1 &&
        <svg version="1.1" height="100%" width="100%" >
          <Teeth start={18} end={11} x={20} y={20} handleChange={handleToothUpdate} />
          <Teeth start={21} end={28} x={180} y={20} handleChange={handleToothUpdate} />

          <Teeth start={48} end={41} x={20} y={60} handleChange={handleToothUpdate} />
          <Teeth start={31} end={38} x={180} y={60} handleChange={handleToothUpdate} />
        </svg>
      }





      <div style={{ textAlign: 'right' }}>
        <Space direction='vertical'>
          <Space>
            <Form.Item >
              <Button danger onClick={handleCancel}>
                Cancelar
              </Button>
            </Form.Item>
            {props.option.showHide === 'show' &&
              <Form.Item >
                <Button type="primary" htmlType="submit" onClick={handleOk}>
                  {props.option.modalFooter}
                </Button>
              </Form.Item>
            }
          </Space>
        </Space>
      </div>
    </div>
  );
}

export default OdontogramPlaca;