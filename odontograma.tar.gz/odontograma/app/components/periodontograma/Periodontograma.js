'use client'

import { useState, useRef, useEffect } from 'react';
import { estadosTornillos } from './states';
import { Form, Modal, Space, Button } from "antd"
import { extraccion, placaStyle, sangradoStyle, style, styleFurca1, styleTable2, styleTable3, styleTable4 } from './cambios'
import "./estilosAdaptados.css"
import { LineChart, Line, YAxis } from 'recharts';

const Periodontograma = (props) => {
  const [estadoTornillo, setEstadoTornillo] = useState(estadosTornillos);

  const handleInputChange = (idTornillo, value) => {
    const regex = /^[ABC]*$/;
    const upperCaseValue = value.toUpperCase();
    if (regex.test(upperCaseValue)) {
      setEstadoTornillo((prev) => {
        return {
          ...prev, // Mantener los estados actuales
          [idTornillo]: {
            ...estadoTornillo[idTornillo],
            movilidad: upperCaseValue
          }
        }
      });
    }
    console.log(estadoTornillo)
    console.log(estadoTornillo)
  }

  const handleChange = (idTornillo) => {
    setEstadoTornillo((prev) => {
      return {
        ...prev, // Mantener los estados actuales
        [idTornillo]: {
          id: prev[idTornillo].id,
          statusVestibular: prev[idTornillo].statusVestibular === 2 ? 0 : prev[idTornillo].statusVestibular + 1,
          statusPalatino: prev[idTornillo].statusPalatino === 2 ? 0 : prev[idTornillo].statusPalatino + 1,
          movilidad: "",
          nota: "",
          furca: {
            furcaA: 0,
            furcaB: 0
          },
          placa: {
            placaA: false,
            placaB: false,
            placaC: false,
          },
          sangrado: {
            sangradoA: 0,
            sangradoB: 0,
            sangradoC: 0
          },
          encia: [
            { name: "A", encia: 0, sondaje: 0, nulo: 10 },
            { name: "B", encia: 0, sondaje: 0, nulo: 10 },
            { name: "C", encia: 0, sondaje: 0, nulo: 10 }
          ],
          enciaInput: {
            enciaInputA: "0",
            enciaInputB: "0",
            enciaInputC: "0",
          },
          sondajeInput: {
            sondajeInputA: "0",
            sondajeInputB: "0",
            sondajeInputC: "0",
          }
        },
        [`${idTornillo}b`]: {
          id: prev[`${idTornillo}b`].id,
          statusVestibular: prev[`${idTornillo}b`].statusVestibular === 2 ? 0 : prev[`${idTornillo}b`].statusVestibular + 1,
          statusPalatino: prev[`${idTornillo}b`].statusPalatino === 2 ? 0 : prev[`${idTornillo}b`].statusPalatino + 1,
          movilidad: "",
          nota: "",
          furca: {
            furcaA: 0,
            furcaB: 0
          },
          placa: {
            placaA: false,
            placaB: false,
            placaC: false,
          },
          sangrado: {
            sangradoA: 0,
            sangradoB: 0,
            sangradoC: 0
          },
          encia: [
            { name: "A", encia: 0, sondaje: 0, nulo: 10 },
            { name: "B", encia: 0, sondaje: 0, nulo: 10 },
            { name: "C", encia: 0, sondaje: 0, nulo: 10 }
          ],
          enciaInput: {
            enciaInputA: "0",
            enciaInputB: "0",
            enciaInputC: "0",
          },
          sondajeInput: {
            sondajeInputA: "0",
            sondajeInputB: "0",
            sondajeInputC: "0",
          }
        }
      }
    });
    console.log(estadoTornillo)
  }

  const handleChangeFurca = (idFurca) => {

    switch (idFurca) {
      case "i18b-a":
        setEstadoTornillo({
          ...estadoTornillo,
          ["i18b"]: {
            ...estadoTornillo["i18b"],
            furca: {
              furcaA: estadoTornillo["i18b"].furca.furcaA === 3 ? 0 : estadoTornillo["i18b"].furca.furcaA + 1,
              furcaB: estadoTornillo["i18b"].furca.furcaB,
            }
          }
        })
        console.log(estadoTornillo[idFurca])
        break;
      case "i18b-b":
        console.log(estadoTornillo["i18b"].furca.furcaB)
        setEstadoTornillo({
          ...estadoTornillo,
          ["i18b"]: {
            ...estadoTornillo["i18b"],
            furca: {
              furcaA: estadoTornillo["i18b"].furca.furcaA,
              furcaB: estadoTornillo["i18b"].furca.furcaB === 3 ? 0 : estadoTornillo["i18b"].furca.furcaB + 1,
            }
          }
        })

        break;


      case "i17b-a":
        setEstadoTornillo({
          ...estadoTornillo,
          ["i17b"]: {
            ...estadoTornillo["i17b"],
            furca: {
              furcaA: estadoTornillo["i17b"].furca.furcaA === 3 ? 0 : estadoTornillo["i17b"].furca.furcaA + 1,
              furcaB: estadoTornillo["i17b"].furca.furcaB,
            }
          }
        })
        break;
      case "i17b-b":
        setEstadoTornillo({
          ...estadoTornillo,
          "i17b": {
            ...estadoTornillo["i17b"],
            furca: {
              furcaA: estadoTornillo["i17b"].furca.furcaA,
              furcaB: estadoTornillo["i17b"].furca.furcaA === 3 ? 0 : estadoTornillo["i17b"].furca.furcaB + 1,
            }
          }
        })
        break;

      case "i16b-a":
        setEstadoTornillo({
          ...estadoTornillo,
          ["i16b"]: {
            ...estadoTornillo["i16b"],
            furca: {
              furcaA: estadoTornillo["i16b"].furca.furcaA === 3 ? 0 : estadoTornillo["i16b"].furca.furcaA + 1,
              furcaB: estadoTornillo["i16b"].furca.furcaB,
            }
          }
        })
        break;
      case "i16b-b":
        setEstadoTornillo({
          ...estadoTornillo,
          "i16b": {
            ...estadoTornillo["i16b"],
            furca: {
              furcaA: estadoTornillo["i16b"].furca.furcaA,
              furcaB: estadoTornillo["i16b"].furca.furcaA === 3 ? 0 : estadoTornillo["i16b"].furca.furcaB + 1,
            }
          }
        })
        break;

      case "i14b-a":
        setEstadoTornillo({
          ...estadoTornillo,
          ["i14b"]: {
            ...estadoTornillo["i14b"],
            furca: {
              furcaA: estadoTornillo["i14b"].furca.furcaA === 3 ? 0 : estadoTornillo["i14b"].furca.furcaA + 1,
              furcaB: estadoTornillo["i14b"].furca.furcaB,
            }
          }
        })
        break;
      case "i14b-b":
        setEstadoTornillo({
          ...estadoTornillo,
          "i14b": {
            ...estadoTornillo["i14b"],
            furca: {
              furcaA: estadoTornillo["i14b"].furca.furcaA,
              furcaB: estadoTornillo["i14b"].furca.furcaB === 3 ? 0 : estadoTornillo["i14b"].furca.furcaB + 1,
            }
          }
        })
        break;

      case "i24b-a":
        setEstadoTornillo({
          ...estadoTornillo,
          ["i24b"]: {
            ...estadoTornillo["i24b"],
            furca: {
              furcaA: estadoTornillo["i24b"].furca.furcaA === 3 ? 0 : estadoTornillo["i24b"].furca.furcaA + 1,
              furcaB: estadoTornillo["i24b"].furca.furcaB,
            }
          }
        })
        break;
      case "i24b-b":
        setEstadoTornillo({
          ...estadoTornillo,
          "i24b": {
            ...estadoTornillo["i24b"],
            furca: {
              furcaA: estadoTornillo["i24b"].furca.furcaA,
              furcaB: estadoTornillo["i24b"].furca.furcaB === 3 ? 0 : estadoTornillo["i24b"].furca.furcaB + 1,
            }
          }
        })
        break;

      case "i26b-a":
        setEstadoTornillo({
          ...estadoTornillo,
          ["i26b"]: {
            ...estadoTornillo["i26b"],
            furca: {
              furcaA: estadoTornillo["i26b"].furca.furcaA === 3 ? 0 : estadoTornillo["i26b"].furca.furcaA + 1,
              furcaB: estadoTornillo["i26b"].furca.furcaB,
            }
          }
        })
        break;
      case "i26b-b":
        setEstadoTornillo({
          ...estadoTornillo,
          "i26b": {
            ...estadoTornillo["i26b"],
            furca: {
              furcaA: estadoTornillo["i26b"].furca.furcaA,
              furcaB: estadoTornillo["i26b"].furca.furcaB === 3 ? 0 : estadoTornillo["i26b"].furca.furcaB + 1,
            }
          }
        })
        break;

      case "i27b-a":
        setEstadoTornillo({
          ...estadoTornillo,
          ["i27b"]: {
            ...estadoTornillo["i27b"],
            furca: {
              furcaA: estadoTornillo["i27b"].furca.furcaA === 3 ? 0 : estadoTornillo["i27b"].furca.furcaA + 1,
              furcaB: estadoTornillo["i27b"].furca.furcaB,
            }
          }
        })
        break;
      case "i27b-b":
        setEstadoTornillo({
          ...estadoTornillo,
          "i27b": {
            ...estadoTornillo["i27b"],
            furca: {
              furcaA: estadoTornillo["i27b"].furca.furcaA,
              furcaB: estadoTornillo["i27b"].furca.furcaB === 3 ? 0 : estadoTornillo["i27b"].furca.furcaB + 1,
            }
          }
        })
        break;

      case "i28b-a":
        setEstadoTornillo({
          ...estadoTornillo,
          ["i28b"]: {
            ...estadoTornillo["i28b"],
            furca: {
              furcaA: estadoTornillo["i28b"].furca.furcaA === 3 ? 0 : estadoTornillo["i28b"].furca.furcaA + 1,
              furcaB: estadoTornillo["i28b"].furca.furcaB,
            }
          }
        })
        break;
      case "i28b-b":
        setEstadoTornillo({
          ...estadoTornillo,
          "i28b": {
            ...estadoTornillo["i28b"],
            furca: {
              furcaA: estadoTornillo["i28b"].furca.furcaA,
              furcaB: estadoTornillo["i28b"].furca.furcaB === 3 ? 0 : estadoTornillo["i28b"].furca.furcaB + 1,
            }
          }
        })
        break;

      default:
        setEstadoTornillo({
          ...estadoTornillo,
          [idFurca]: {
            ...estadoTornillo[idFurca],
            furca: {
              furcaA: estadoTornillo[idFurca].furca.furcaA === 3 ? 0 : estadoTornillo[idFurca].furca.furcaA + 1,
              furcaB: estadoTornillo[idFurca].furca.furcaB,
            }
          }
        })
        break;
    }

  }

  const handleChangeSangrado = (idSangrado, sangrado) => {
    switch (sangrado) {
      case "A":
        setEstadoTornillo({
          ...estadoTornillo,
          [idSangrado]: {
            ...estadoTornillo[idSangrado],
            sangrado: {
              sangradoA: estadoTornillo[idSangrado].sangrado.sangradoA === 2 ? 0 : estadoTornillo[idSangrado].sangrado.sangradoA + 1,
              sangradoB: estadoTornillo[idSangrado].sangrado.sangradoB,
              sangradoC: estadoTornillo[idSangrado].sangrado.sangradoC,
            }
          }
        })
        console.log(estadoTornillo[idSangrado])
        break;
      case "B":
        setEstadoTornillo({
          ...estadoTornillo,
          [idSangrado]: {
            ...estadoTornillo[idSangrado],
            sangrado: {
              sangradoA: estadoTornillo[idSangrado].sangrado.sangradoA,
              sangradoB: estadoTornillo[idSangrado].sangrado.sangradoB === 2 ? 0 : estadoTornillo[idSangrado].sangrado.sangradoB + 1,
              sangradoC: estadoTornillo[idSangrado].sangrado.sangradoC,
            }
          }
        })
        break;
      case "C":
        setEstadoTornillo({
          ...estadoTornillo,
          [idSangrado]: {
            ...estadoTornillo[idSangrado],
            sangrado: {
              sangradoA: estadoTornillo[idSangrado].sangrado.sangradoA,
              sangradoB: estadoTornillo[idSangrado].sangrado.sangradoB,
              sangradoC: estadoTornillo[idSangrado].sangrado.sangradoC === 2 ? 0 : estadoTornillo[idSangrado].sangrado.sangradoC + 1,
            }
          }
        })
        break;

      default:
        break;
    }
  }

  const handelChangeSondaje = (idencias, punto, data) => {
    const num = parseInt(data, 10);
    console.log("NUM", num);

    setEstadoTornillo((prev) => {
      const prevEstado = { ...prev };
      const arrayEncia = [...prevEstado[idencias].encia];
      const updatedSondajeInput = { ...prevEstado[idencias].sondajeInput };

      const puntosMap = {
        "A": 0,
        "B": 1,
        "C": 2,
      };

      const indice = puntosMap[punto];

      if (indice !== undefined) {
        arrayEncia[indice].sondaje = isNaN(num) ? 0: num;
        if (num > 6) {
          arrayEncia[indice].sondaje = 6;
          updatedSondajeInput[`sondajeInput${punto}`] ="6"
        }else{
          updatedSondajeInput[`sondajeInput${punto}`] = isNaN(num) ? "" : num.toString();
        }
      }

      prevEstado[idencias].encia = arrayEncia;
      prevEstado[idencias].sondajeInput = updatedSondajeInput;
      return prevEstado;
    });

    console.log("NUM", estadoTornillo);
  };


  let getStyle = (estado) => {
    if (estado === 1) {
      return sangradoStyle.sangrado
    } else if (estado === 2) {
      return sangradoStyle.sangradoSupuracion
    } else {
      return {}
    }
  }

  let getStyleDiente = (estado, diente) => {
    if (estado === 1) {
      return {
        vestivular: style[`diente${diente}Cambio`],
        palatino: style[`diente${diente}bCambio`]
      }
    } else if (estado === 2) {
      return {
        vestivular: extraccion[`diente${diente}Cambio`],
        palatino: extraccion[`diente${diente}bCambio`]
      }
    } else {
      return {}
    }

  }

  let registerData = () => {
    props.handleOk(estadoTornillo)
  }
  const handleCancel = () => {
    props.handleCancel()
  }

  const disabled = () => {
    if (props.option.option === 2) {
      return true
    } else {
      return false
    }
  }
  let disable = disabled()

  useEffect(() => {
    console.log(estadoTornillo)
    if (props.option.option === 4) {

    } else if (props.option.option === 3 || props.option.option === 2) {
      if (props.one) {
        setEstadoTornillo(prevEstado => {
          return props.one;
        });
      }
    }
  }, [props.option, props.one, setEstadoTornillo]);


  return (
    <div className='contenedor'>

      <div className='tabla'>
        <table id="tabla-1">

          <tbody>
            <tr>
              <td></td>
              <td className="borde">
                <div id="d18">1.8</div>
              </td>
              <td className="borde">
                <div id="d17">1.7</div>
              </td>
              <td className="borde">
                <div id="d16">1.6</div>
              </td>
              <td className="borde">
                <div id="d15">1.5</div>
              </td>
              <td className="borde">
                <div id="d14">1.4</div>
              </td>
              <td className="borde">
                <div id="d13">1.3</div>
              </td>
              <td className="borde">
                <div id="d12">1.2</div>
              </td>
              <td className="borde">
                <div id="d11">1.1</div>
              </td>

              <td className="borde">
                <div id="d21">2.1</div>
              </td>
              <td className="borde">
                <div id="d22">2.2</div>
              </td>
              <td className="borde">
                <div id="d23">2.3</div>
              </td>
              <td className="borde">
                <div id="d24">2.4</div>
              </td>
              <td className="borde">
                <div id="d25">2.5</div>
              </td>
              <td className="borde">
                <div id="d26">2.6</div>
              </td>
              <td className="borde">
                <div id="d27">2.7</div>
              </td>
              <td className="borde">
                <div id="d28">2.8</div>
              </td>
            </tr>

            <tr>
              <td className="titulo">Ausente</td>
              <td className="borde">
                <div id="i18" onClick={() => props.option.option != 2 && handleChange("i18")}></div>
              </td>
              <td className="borde">
                <div id="i17" onClick={() => props.option.option != 2 && handleChange("i17")}></div>
              </td>
              <td className="borde">
                <div id="i16" onClick={() => props.option.option != 2 && handleChange("i16")}></div>
              </td>
              <td className="borde">
                <div id="i15" onClick={() => props.option.option != 2 && handleChange("i15")}></div>
              </td>
              <td className="borde">
                <div id="i14" onClick={() => props.option.option != 2 && handleChange("i14")}></div>
              </td>
              <td className="borde">
                <div id="i13" onClick={() => props.option.option != 2 && handleChange("i13")}></div>
              </td>
              <td className="borde">
                <div id="i12" onClick={() => props.option.option != 2 && handleChange("i12")}></div>
              </td>
              <td className="borde">
                <div id="i11" onClick={() => props.option.option != 2 && handleChange("i11")}></div>
              </td>
              <td className="borde">
                <div id="i21" onClick={() => props.option.option != 2 && handleChange("i21")}></div>
              </td>
              <td className="borde">
                <div id="i22" onClick={() => props.option.option != 2 && handleChange("i22")}></div>
              </td>
              <td className="borde">
                <div id="i23" onClick={() => props.option.option != 2 && handleChange("i23")}></div>
              </td>
              <td className="borde">
                <div id="i24" onClick={() => props.option.option != 2 && handleChange("i24")}></div>
              </td>
              <td className="borde">
                <div id="i25" onClick={() => props.option.option != 2 && handleChange("i25")}></div>
              </td>
              <td className="borde">
                <div id="i26" onClick={() => props.option.option != 2 && handleChange("i26")}></div>
              </td>
              <td className="borde">
                <div id="i27" onClick={() => props.option.option != 2 && handleChange("i27")}></div>
              </td>
              <td className="borde">
                <div id="i28" onClick={() => props.option.option != 2 && handleChange("i28")}></div>
              </td>
            </tr>

            <tr>
              <td className="titulo">Movilidad</td>
              <td className="borde"><input type="text" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' id="m18" name="m18" value={estadoTornillo.i18.movilidad} tabIndex="1" disabled={props.option.option === 2 ? disable : estadoTornillo.i18.statusVestibular} onChange={(e) => handleInputChange("i18", e.target.value)} /></td>
              <td className="borde"><input type="text" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' id="m17" name="m17" value={estadoTornillo.i17.movilidad} tabIndex="2" disabled={props.option.option === 2 ? disable : estadoTornillo.i17.statusVestibular} onChange={(e) => handleInputChange("i17", e.target.value)} /></td>
              <td className="borde"><input type="text" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' id="m16" name="m16" value={estadoTornillo.i16.movilidad} tabIndex="3" disabled={props.option.option === 2 ? disable : estadoTornillo.i16.statusVestibular} onChange={(e) => handleInputChange("i16", e.target.value)} /></td>
              <td className="borde"><input type="text" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' id="m15" name="m15" value={estadoTornillo.i15.movilidad} tabIndex="4" disabled={props.option.option === 2 ? disable : estadoTornillo.i15.statusVestibular} onChange={(e) => handleInputChange("i15", e.target.value)} /></td>
              <td className="borde"><input type="text" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' id="m14" name="m14" value={estadoTornillo.i14.movilidad} tabIndex="5" disabled={props.option.option === 2 ? disable : estadoTornillo.i14.statusVestibular} onChange={(e) => handleInputChange("i14", e.target.value)} /></td>
              <td className="borde"><input type="text" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' id="m13" name="m13" value={estadoTornillo.i13.movilidad} tabIndex="6" disabled={props.option.option === 2 ? disable : estadoTornillo.i13.statusVestibular} onChange={(e) => handleInputChange("i13", e.target.value)} /></td>
              <td className="borde"><input type="text" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' id="m12" name="m12" value={estadoTornillo.i12.movilidad} tabIndex="7" disabled={props.option.option === 2 ? disable : estadoTornillo.i12.statusVestibular} onChange={(e) => handleInputChange("i12", e.target.value)} /></td>
              <td className="borde"><input type="text" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' id="m11" name="m11" value={estadoTornillo.i11.movilidad} tabIndex="8" disabled={props.option.option === 2 ? disable : estadoTornillo.i11.statusVestibular} onChange={(e) => handleInputChange("i11", e.target.value)} /></td>
              <td className="borde"><input type="text" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' id="m21" name="m21" value={estadoTornillo.i21.movilidad} tabIndex="9" disabled={props.option.option === 2 ? disable : estadoTornillo.i21.statusVestibular} onChange={(e) => handleInputChange("i21", e.target.value)} /></td>
              <td className="borde"><input type="text" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' id="m22" name="m22" value={estadoTornillo.i22.movilidad} tabIndex="10" disabled={props.option.option === 2 ? disable : estadoTornillo.i22.statusVestibular} onChange={(e) => handleInputChange("i22", e.target.value)} /></td>
              <td className="borde"><input type="text" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' id="m23" name="m23" value={estadoTornillo.i23.movilidad} tabIndex="11" disabled={props.option.option === 2 ? disable : estadoTornillo.i23.statusVestibular} onChange={(e) => handleInputChange("i23", e.target.value)} /></td>
              <td className="borde"><input type="text" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' id="m24" name="m24" value={estadoTornillo.i24.movilidad} tabIndex="12" disabled={props.option.option === 2 ? disable : estadoTornillo.i24.statusVestibular} onChange={(e) => handleInputChange("i24", e.target.value)} /></td>
              <td className="borde"><input type="text" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' id="m25" name="m25" value={estadoTornillo.i25.movilidad} tabIndex="13" disabled={props.option.option === 2 ? disable : estadoTornillo.i25.statusVestibular} onChange={(e) => handleInputChange("i25", e.target.value)} /></td>
              <td className="borde"><input type="text" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' id="m26" name="m26" value={estadoTornillo.i26.movilidad} tabIndex="14" disabled={props.option.option === 2 ? disable : estadoTornillo.i26.statusVestibular} onChange={(e) => handleInputChange("i26", e.target.value)} /></td>
              <td className="borde"><input type="text" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' id="m27" name="m27" value={estadoTornillo.i27.movilidad} tabIndex="15" disabled={props.option.option === 2 ? disable : estadoTornillo.i27.statusVestibular} onChange={(e) => handleInputChange("i27", e.target.value)} /></td>
              <td className="borde"><input type="text" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' id="m28" name="m28" value={estadoTornillo.i28.movilidad} tabIndex="16" disabled={props.option.option === 2 ? disable : estadoTornillo.i28.statusVestibular} onChange={(e) => handleInputChange("i28", e.target.value)} /></td>
            </tr>

            <tr>
              <td className="titulo">Furca</td>
              <td className="borde">
                {estadoTornillo.i18.statusVestibular ?
                  <div id="f18" disabled={disable} ></div> :
                  <div id="f18" disabled={disable} onClick={() => props.option.option != 2 && handleChangeFurca("i18")}></div>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i17.statusVestibular ?
                  <div id="f17" disabled={disable} ></div> :
                  <div id="f17" disabled={disable} onClick={() => props.option.option != 2 && handleChangeFurca("i17")}></div>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i16.statusVestibular ?
                  <div id="f16" disabled={disable} ></div> :
                  <div id="f16" disabled={disable} onClick={() => props.option.option != 2 && handleChangeFurca("i16")}></div>
                }
              </td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>

              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde">
              </td>
              <td className="borde"></td>
              <td className="borde">
                {estadoTornillo.i26.statusVestibular ?
                  <div id="f26" ></div> :
                  <div id="f26" onClick={() => props.option.option != 2 && handleChangeFurca("i26")}></div>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i27.statusVestibular ?
                  <div id="f27" ></div> :
                  <div id="f27" onClick={() => props.option.option != 2 && handleChangeFurca("i27")}></div>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i28.statusVestibular ?
                  <div id="f28" ></div> :
                  <div id="f28" onClick={() => props.option.option != 2 && handleChangeFurca("i28")}></div>
                }
              </td>
            </tr>

            <tr>
              <td className="titulo">Sangrado / Exudado</td>
              <td className="borde">
                {estadoTornillo.i18.statusVestibular ?
                  <>
                    <div id="s18-a" style={getStyle(estadoTornillo.i18.sangrado.sangradoA)}></div>
                    <div id="s18-b" style={getStyle(estadoTornillo.i18.sangrado.sangradoB)}></div>
                    <div id="s18-c" style={getStyle(estadoTornillo.i18.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s18-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i18", "A")} style={getStyle(estadoTornillo.i18.sangrado.sangradoA)}></div>
                    <div id="s18-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i18", "B")} style={getStyle(estadoTornillo.i18.sangrado.sangradoB)}></div>
                    <div id="s18-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i18", "C")} style={getStyle(estadoTornillo.i18.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i17.statusVestibular ?
                  <>
                    <div id="s17-a" style={getStyle(estadoTornillo.i17.sangrado.sangradoA)}></div>
                    <div id="s17-b" style={getStyle(estadoTornillo.i17.sangrado.sangradoB)}></div>
                    <div id="s17-c" style={getStyle(estadoTornillo.i17.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s17-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i17", "A")} style={getStyle(estadoTornillo.i17.sangrado.sangradoA)}></div>
                    <div id="s17-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i17", "B")} style={getStyle(estadoTornillo.i17.sangrado.sangradoB)}></div>
                    <div id="s17-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i17", "C")} style={getStyle(estadoTornillo.i17.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i16.statusVestibular ?
                  <>
                    <div id="s16-a" style={getStyle(estadoTornillo.i16.sangrado.sangradoA)}></div>
                    <div id="s16-b" style={getStyle(estadoTornillo.i16.sangrado.sangradoB)}></div>
                    <div id="s16-c" style={getStyle(estadoTornillo.i16.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s16-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i16", "A")} style={getStyle(estadoTornillo.i16.sangrado.sangradoA)}></div>
                    <div id="s16-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i16", "B")} style={getStyle(estadoTornillo.i16.sangrado.sangradoB)}></div>
                    <div id="s16-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i16", "C")} style={getStyle(estadoTornillo.i16.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i15.statusVestibular ?
                  <>
                    <div id="s15-a" style={getStyle(estadoTornillo.i15.sangrado.sangradoA)}></div>
                    <div id="s15-b" style={getStyle(estadoTornillo.i15.sangrado.sangradoB)}></div>
                    <div id="s15-c" style={getStyle(estadoTornillo.i15.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s15-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i15", "A")} style={getStyle(estadoTornillo.i15.sangrado.sangradoA)}></div>
                    <div id="s15-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i15", "B")} style={getStyle(estadoTornillo.i15.sangrado.sangradoB)}></div>
                    <div id="s15-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i15", "C")} style={getStyle(estadoTornillo.i15.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i14.statusVestibular ?
                  <>
                    <div id="s14-a" style={getStyle(estadoTornillo.i14.sangrado.sangradoA)}></div>
                    <div id="s14-b" style={getStyle(estadoTornillo.i14.sangrado.sangradoB)}></div>
                    <div id="s14-c" style={getStyle(estadoTornillo.i14.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s14-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i14", "A")} style={getStyle(estadoTornillo.i14.sangrado.sangradoA)}></div>
                    <div id="s14-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i14", "B")} style={getStyle(estadoTornillo.i14.sangrado.sangradoB)}></div>
                    <div id="s14-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i14", "C")} style={getStyle(estadoTornillo.i14.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i13.statusVestibular ?
                  <>
                    <div id="s13-a" style={getStyle(estadoTornillo.i13.sangrado.sangradoA)}></div>
                    <div id="s13-b" style={getStyle(estadoTornillo.i13.sangrado.sangradoB)}></div>
                    <div id="s13-c" style={getStyle(estadoTornillo.i13.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s13-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i13", "A")} style={getStyle(estadoTornillo.i13.sangrado.sangradoA)}></div>
                    <div id="s13-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i13", "B")} style={getStyle(estadoTornillo.i13.sangrado.sangradoB)}></div>
                    <div id="s13-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i13", "C")} style={getStyle(estadoTornillo.i13.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i12.statusVestibular ?
                  <>
                    <div id="s12-a" style={getStyle(estadoTornillo.i12.sangrado.sangradoA)}></div>
                    <div id="s12-b" style={getStyle(estadoTornillo.i12.sangrado.sangradoB)}></div>
                    <div id="s12-c" style={getStyle(estadoTornillo.i12.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s12-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i12", "A")} style={getStyle(estadoTornillo.i12.sangrado.sangradoA)}></div>
                    <div id="s12-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i12", "B")} style={getStyle(estadoTornillo.i12.sangrado.sangradoB)}></div>
                    <div id="s12-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i12", "C")} style={getStyle(estadoTornillo.i12.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i11.statusVestibular ?
                  <>
                    <div id="s11-a" style={getStyle(estadoTornillo.i11.sangrado.sangradoA)}></div>
                    <div id="s11-b" style={getStyle(estadoTornillo.i11.sangrado.sangradoB)}></div>
                    <div id="s11-c" style={getStyle(estadoTornillo.i11.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s11-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i11", "A")} style={getStyle(estadoTornillo.i11.sangrado.sangradoA)}></div>
                    <div id="s11-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i11", "B")} style={getStyle(estadoTornillo.i11.sangrado.sangradoB)}></div>
                    <div id="s11-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i11", "C")} style={getStyle(estadoTornillo.i11.sangrado.sangradoC)}></div>
                  </>
                }
              </td>

              <td className="borde">
                {estadoTornillo.i21.statusVestibular ?
                  <>
                    <div id="s21-a" style={getStyle(estadoTornillo.i21.sangrado.sangradoA)}></div>
                    <div id="s21-b" style={getStyle(estadoTornillo.i21.sangrado.sangradoB)}></div>
                    <div id="s21-c" style={getStyle(estadoTornillo.i21.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s21-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i21", "A")} style={getStyle(estadoTornillo.i21.sangrado.sangradoA)}></div>
                    <div id="s21-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i21", "B")} style={getStyle(estadoTornillo.i21.sangrado.sangradoB)}></div>
                    <div id="s21-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i21", "C")} style={getStyle(estadoTornillo.i21.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i22.statusVestibular ?
                  <>
                    <div id="s22-a" style={getStyle(estadoTornillo.i22.sangrado.sangradoA)}></div>
                    <div id="s22-b" style={getStyle(estadoTornillo.i22.sangrado.sangradoB)}></div>
                    <div id="s22-c" style={getStyle(estadoTornillo.i22.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s22-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i22", "A")} style={getStyle(estadoTornillo.i22.sangrado.sangradoA)}></div>
                    <div id="s22-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i22", "B")} style={getStyle(estadoTornillo.i22.sangrado.sangradoB)}></div>
                    <div id="s22-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i22", "C")} style={getStyle(estadoTornillo.i22.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i23.statusVestibular ?
                  <>
                    <div id="s23-a" style={getStyle(estadoTornillo.i23.sangrado.sangradoA)}></div>
                    <div id="s23-b" style={getStyle(estadoTornillo.i23.sangrado.sangradoB)}></div>
                    <div id="s23-c" style={getStyle(estadoTornillo.i23.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s23-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i23", "A")} style={getStyle(estadoTornillo.i23.sangrado.sangradoA)}></div>
                    <div id="s23-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i23", "B")} style={getStyle(estadoTornillo.i23.sangrado.sangradoB)}></div>
                    <div id="s23-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i23", "C")} style={getStyle(estadoTornillo.i23.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i24.statusVestibular ?
                  <>
                    <div id="s24-a" style={getStyle(estadoTornillo.i24.sangrado.sangradoA)}></div>
                    <div id="s24-b" style={getStyle(estadoTornillo.i24.sangrado.sangradoB)}></div>
                    <div id="s24-c" style={getStyle(estadoTornillo.i24.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s24-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i24", "A")} style={getStyle(estadoTornillo.i24.sangrado.sangradoA)}></div>
                    <div id="s24-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i24", "B")} style={getStyle(estadoTornillo.i24.sangrado.sangradoB)}></div>
                    <div id="s24-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i24", "C")} style={getStyle(estadoTornillo.i24.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i25.statusVestibular ?
                  <>
                    <div id="s25-a" style={getStyle(estadoTornillo.i25.sangrado.sangradoA)}></div>
                    <div id="s25-b" style={getStyle(estadoTornillo.i25.sangrado.sangradoB)}></div>
                    <div id="s25-c" style={getStyle(estadoTornillo.i25.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s25-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i25", "A")} style={getStyle(estadoTornillo.i25.sangrado.sangradoA)}></div>
                    <div id="s25-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i25", "B")} style={getStyle(estadoTornillo.i25.sangrado.sangradoB)}></div>
                    <div id="s25-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i25", "C")} style={getStyle(estadoTornillo.i25.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i26.statusVestibular ?
                  <>
                    <div id="s26-a" style={getStyle(estadoTornillo.i26.sangrado.sangradoA)}></div>
                    <div id="s26-b" style={getStyle(estadoTornillo.i26.sangrado.sangradoB)}></div>
                    <div id="s26-c" style={getStyle(estadoTornillo.i26.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s26-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i26", "A")} style={getStyle(estadoTornillo.i26.sangrado.sangradoA)}></div>
                    <div id="s26-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i26", "B")} style={getStyle(estadoTornillo.i26.sangrado.sangradoB)}></div>
                    <div id="s26-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i26", "C")} style={getStyle(estadoTornillo.i26.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i27.statusVestibular ?
                  <>
                    <div id="s27-a" style={getStyle(estadoTornillo.i27.sangrado.sangradoA)}></div>
                    <div id="s27-b" style={getStyle(estadoTornillo.i27.sangrado.sangradoB)}></div>
                    <div id="s27-c" style={getStyle(estadoTornillo.i27.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s27-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i27", "A")} style={getStyle(estadoTornillo.i27.sangrado.sangradoA)}></div>
                    <div id="s27-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i27", "B")} style={getStyle(estadoTornillo.i27.sangrado.sangradoB)}></div>
                    <div id="s27-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i27", "C")} style={getStyle(estadoTornillo.i27.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i28.statusVestibular ?
                  <>
                    <div id="s28-a" style={getStyle(estadoTornillo.i28.sangrado.sangradoA)}></div>
                    <div id="s28-b" style={getStyle(estadoTornillo.i28.sangrado.sangradoB)}></div>
                    <div id="s28-c" style={getStyle(estadoTornillo.i28.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s28-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i28", "A")} style={getStyle(estadoTornillo.i28.sangrado.sangradoA)}></div>
                    <div id="s28-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i28", "B")} style={getStyle(estadoTornillo.i28.sangrado.sangradoB)}></div>
                    <div id="s28-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i28", "C")} style={getStyle(estadoTornillo.i28.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
            </tr>

            <tr>
              <td className="titulo">Profundidad de sondaje</td>
              <td className="borde">
                <input type="text" max={6} id="ps18-a" name="ps18-a" value={estadoTornillo.i18.sondajeInput.sondajeInputA.toString()} tabIndex="97" disabled={props.option.option === 2 ? disable : estadoTornillo.i18.statusPalatino} onChange={(e) => handelChangeSondaje("i18", "A", e.target.value)} />
                <input type="text" max={6} id="ps18-b" name="ps18-b" value={estadoTornillo.i18.sondajeInput.sondajeInputB.toString()} tabIndex="98" disabled={props.option.option === 2 ? disable : estadoTornillo.i18.statusPalatino} onChange={(e) => handelChangeSondaje("i18", "B", e.target.value)} />
                <input type="text" max={6} id="ps18-c" name="ps18-c" value={estadoTornillo.i18.sondajeInput.sondajeInputC.toString()} tabIndex="99" disabled={props.option.option === 2 ? disable : estadoTornillo.i18.statusPalatino} onChange={(e) => handelChangeSondaje("i18", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps17-a" name="ps17-a" value={estadoTornillo.i17.sondajeInput.sondajeInputA} tabIndex="100" disabled={props.option.option === 2 ? disable : estadoTornillo.i17.statusPalatino} onChange={(e) => handelChangeSondaje("i17", "A", e.target.value)} />
                <input type="text" id="ps17-b" name="ps17-b" value={estadoTornillo.i17.sondajeInput.sondajeInputB} tabIndex="101" disabled={props.option.option === 2 ? disable : estadoTornillo.i17.statusPalatino} onChange={(e) => handelChangeSondaje("i17", "B", e.target.value)} />
                <input type="text" id="ps17-c" name="ps17-c" value={estadoTornillo.i17.sondajeInput.sondajeInputC} tabIndex="102" disabled={props.option.option === 2 ? disable : estadoTornillo.i17.statusPalatino} onChange={(e) => handelChangeSondaje("i17", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps16-a" name="ps16-a" value={estadoTornillo.i16.sondajeInput.sondajeInputA} tabIndex="103" disabled={props.option.option === 2 ? disable : estadoTornillo.i16.statusPalatino} onChange={(e) => handelChangeSondaje("i16", "A", e.target.value)} />
                <input type="text" id="ps16-b" name="ps16-b" value={estadoTornillo.i16.sondajeInput.sondajeInputB} tabIndex="104" disabled={props.option.option === 2 ? disable : estadoTornillo.i16.statusPalatino} onChange={(e) => handelChangeSondaje("i16", "B", e.target.value)} />
                <input type="text" id="ps16-c" name="ps16-c" value={estadoTornillo.i16.sondajeInput.sondajeInputC} tabIndex="105" disabled={props.option.option === 2 ? disable : estadoTornillo.i16.statusPalatino} onChange={(e) => handelChangeSondaje("i16", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps15-a" name="ps15-a" value={estadoTornillo.i15.sondajeInput.sondajeInputA} tabIndex="106" disabled={props.option.option === 2 ? disable : estadoTornillo.i15.statusPalatino} onChange={(e) => handelChangeSondaje("i15", "A", e.target.value)} />
                <input type="text" id="ps15-b" name="ps15-b" value={estadoTornillo.i15.sondajeInput.sondajeInputB} tabIndex="107" disabled={props.option.option === 2 ? disable : estadoTornillo.i15.statusPalatino} onChange={(e) => handelChangeSondaje("i15", "B", e.target.value)} />
                <input type="text" id="ps15-c" name="ps15-c" value={estadoTornillo.i15.sondajeInput.sondajeInputC} tabIndex="108" disabled={props.option.option === 2 ? disable : estadoTornillo.i15.statusPalatino} onChange={(e) => handelChangeSondaje("i15", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps14-a" name="ps14-a" value={estadoTornillo.i14.sondajeInput.sondajeInputA} tabIndex="109" disabled={props.option.option === 2 ? disable : estadoTornillo.i14.statusPalatino} onChange={(e) => handelChangeSondaje("i14", "A", e.target.value)} />
                <input type="text" id="ps14-b" name="ps14-b" value={estadoTornillo.i14.sondajeInput.sondajeInputB} tabIndex="110" disabled={props.option.option === 2 ? disable : estadoTornillo.i14.statusPalatino} onChange={(e) => handelChangeSondaje("i14", "B", e.target.value)} />
                <input type="text" id="ps14-c" name="ps14-c" value={estadoTornillo.i14.sondajeInput.sondajeInputC} tabIndex="111" disabled={props.option.option === 2 ? disable : estadoTornillo.i14.statusPalatino} onChange={(e) => handelChangeSondaje("i14", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps13-a" name="ps13-a" value={estadoTornillo.i13.sondajeInput.sondajeInputA} tabIndex="112" disabled={props.option.option === 2 ? disable : estadoTornillo.i13.statusPalatino} onChange={(e) => handelChangeSondaje("i13", "A", e.target.value)} />
                <input type="text" id="ps13-b" name="ps13-b" value={estadoTornillo.i13.sondajeInput.sondajeInputB} tabIndex="113" disabled={props.option.option === 2 ? disable : estadoTornillo.i13.statusPalatino} onChange={(e) => handelChangeSondaje("i13", "B", e.target.value)} />
                <input type="text" id="ps13-c" name="ps13-c" value={estadoTornillo.i13.sondajeInput.sondajeInputC} tabIndex="114" disabled={props.option.option === 2 ? disable : estadoTornillo.i13.statusPalatino} onChange={(e) => handelChangeSondaje("i13", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps12-a" name="ps12-a" value={estadoTornillo.i12.sondajeInput.sondajeInputA} tabIndex="115" disabled={props.option.option === 2 ? disable : estadoTornillo.i12.statusPalatino} onChange={(e) => handelChangeSondaje("i12", "A", e.target.value)} />
                <input type="text" id="ps12-b" name="ps12-b" value={estadoTornillo.i12.sondajeInput.sondajeInputB} tabIndex="116" disabled={props.option.option === 2 ? disable : estadoTornillo.i12.statusPalatino} onChange={(e) => handelChangeSondaje("i12", "B", e.target.value)} />
                <input type="text" id="ps12-c" name="ps12-c" value={estadoTornillo.i12.sondajeInput.sondajeInputC} tabIndex="117" disabled={props.option.option === 2 ? disable : estadoTornillo.i12.statusPalatino} onChange={(e) => handelChangeSondaje("i12", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps11-a" name="ps11-a" value={estadoTornillo.i11.sondajeInput.sondajeInputA} tabIndex="118" disabled={props.option.option === 2 ? disable : estadoTornillo.i11.statusPalatino} onChange={(e) => handelChangeSondaje("i11", "A", e.target.value)} />
                <input type="text" id="ps11-b" name="ps11-b" value={estadoTornillo.i11.sondajeInput.sondajeInputB} tabIndex="119" disabled={props.option.option === 2 ? disable : estadoTornillo.i11.statusPalatino} onChange={(e) => handelChangeSondaje("i11", "B", e.target.value)} />
                <input type="text" id="ps11-c" name="ps11-c" value={estadoTornillo.i11.sondajeInput.sondajeInputC} tabIndex="120" disabled={props.option.option === 2 ? disable : estadoTornillo.i11.statusPalatino} onChange={(e) => handelChangeSondaje("i11", "C", e.target.value)} />
              </td>

              <td className="borde">
                <input type="text" id="ps21-a" name="ps21-a" value={estadoTornillo.i21.sondajeInput.sondajeInputA} tabIndex="121" disabled={props.option.option === 2 ? disable : estadoTornillo.i21.statusPalatino} onChange={(e) => handelChangeSondaje("i21", "A", e.target.value)} />
                <input type="text" id="ps21-b" name="ps21-b" value={estadoTornillo.i21.sondajeInput.sondajeInputB} tabIndex="122" disabled={props.option.option === 2 ? disable : estadoTornillo.i21.statusPalatino} onChange={(e) => handelChangeSondaje("i21", "B", e.target.value)} />
                <input type="text" id="ps21-c" name="ps21-c" value={estadoTornillo.i21.sondajeInput.sondajeInputC} tabIndex="123" disabled={props.option.option === 2 ? disable : estadoTornillo.i21.statusPalatino} onChange={(e) => handelChangeSondaje("i21", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps22-a" name="ps22-a" value={estadoTornillo.i22.sondajeInput.sondajeInputA} tabIndex="124" disabled={props.option.option === 2 ? disable : estadoTornillo.i22.statusPalatino} onChange={(e) => handelChangeSondaje("i22", "A", e.target.value)} />
                <input type="text" id="ps22-b" name="ps22-b" value={estadoTornillo.i22.sondajeInput.sondajeInputB} tabIndex="125" disabled={props.option.option === 2 ? disable : estadoTornillo.i22.statusPalatino} onChange={(e) => handelChangeSondaje("i22", "B", e.target.value)} />
                <input type="text" id="ps22-c" name="ps22-c" value={estadoTornillo.i22.sondajeInput.sondajeInputC} tabIndex="126" disabled={props.option.option === 2 ? disable : estadoTornillo.i22.statusPalatino} onChange={(e) => handelChangeSondaje("i22", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps23-a" name="ps23-a" value={estadoTornillo.i23.sondajeInput.sondajeInputA} tabIndex="127" disabled={props.option.option === 2 ? disable : estadoTornillo.i23.statusPalatino} onChange={(e) => handelChangeSondaje("i23", "A", e.target.value)} />
                <input type="text" id="ps23-b" name="ps23-b" value={estadoTornillo.i23.sondajeInput.sondajeInputB} tabIndex="128" disabled={props.option.option === 2 ? disable : estadoTornillo.i23.statusPalatino} onChange={(e) => handelChangeSondaje("i23", "B", e.target.value)} />
                <input type="text" id="ps23-c" name="ps23-c" value={estadoTornillo.i23.sondajeInput.sondajeInputC} tabIndex="129" disabled={props.option.option === 2 ? disable : estadoTornillo.i23.statusPalatino} onChange={(e) => handelChangeSondaje("i23", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps24-a" name="ps24-a" value={estadoTornillo.i24.sondajeInput.sondajeInputA} tabIndex="130" disabled={props.option.option === 2 ? disable : estadoTornillo.i24.statusPalatino} onChange={(e) => handelChangeSondaje("i24", "A", e.target.value)} />
                <input type="text" id="ps24-b" name="ps24-b" value={estadoTornillo.i24.sondajeInput.sondajeInputB} tabIndex="131" disabled={props.option.option === 2 ? disable : estadoTornillo.i24.statusPalatino} onChange={(e) => handelChangeSondaje("i24", "B", e.target.value)} />
                <input type="text" id="ps24-c" name="ps24-c" value={estadoTornillo.i24.sondajeInput.sondajeInputC} tabIndex="132" disabled={props.option.option === 2 ? disable : estadoTornillo.i24.statusPalatino} onChange={(e) => handelChangeSondaje("i24", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps25-a" name="ps25-a" value={estadoTornillo.i25.sondajeInput.sondajeInputA} tabIndex="133" disabled={props.option.option === 2 ? disable : estadoTornillo.i25.statusPalatino} onChange={(e) => handelChangeSondaje("i25", "A", e.target.value)} />
                <input type="text" id="ps25-b" name="ps25-b" value={estadoTornillo.i25.sondajeInput.sondajeInputB} tabIndex="134" disabled={props.option.option === 2 ? disable : estadoTornillo.i25.statusPalatino} onChange={(e) => handelChangeSondaje("i25", "B", e.target.value)} />
                <input type="text" id="ps25-c" name="ps25-c" value={estadoTornillo.i25.sondajeInput.sondajeInputC} tabIndex="135" disabled={props.option.option === 2 ? disable : estadoTornillo.i25.statusPalatino} onChange={(e) => handelChangeSondaje("i25", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps26-a" name="ps26-a" value={estadoTornillo.i26.sondajeInput.sondajeInputA} tabIndex="136" disabled={props.option.option === 2 ? disable : estadoTornillo.i26.statusPalatino} onChange={(e) => handelChangeSondaje("i26", "A", e.target.value)} />
                <input type="text" id="ps26-b" name="ps26-b" value={estadoTornillo.i26.sondajeInput.sondajeInputB} tabIndex="137" disabled={props.option.option === 2 ? disable : estadoTornillo.i26.statusPalatino} onChange={(e) => handelChangeSondaje("i26", "B", e.target.value)} />
                <input type="text" id="ps26-c" name="ps26-c" value={estadoTornillo.i26.sondajeInput.sondajeInputC} tabIndex="138" disabled={props.option.option === 2 ? disable : estadoTornillo.i26.statusPalatino} onChange={(e) => handelChangeSondaje("i26", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps27-a" name="ps27-a" value={estadoTornillo.i27.sondajeInput.sondajeInputA} tabIndex="139" disabled={props.option.option === 2 ? disable : estadoTornillo.i27.statusPalatino} onChange={(e) => handelChangeSondaje("i27", "A", e.target.value)} />
                <input type="text" id="ps27-b" name="ps27-b" value={estadoTornillo.i27.sondajeInput.sondajeInputB} tabIndex="140" disabled={props.option.option === 2 ? disable : estadoTornillo.i27.statusPalatino} onChange={(e) => handelChangeSondaje("i27", "B", e.target.value)} />
                <input type="text" id="ps27-c" name="ps27-c" value={estadoTornillo.i27.sondajeInput.sondajeInputC} tabIndex="141" disabled={props.option.option === 2 ? disable : estadoTornillo.i27.statusPalatino} onChange={(e) => handelChangeSondaje("i27", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps28-a" name="ps28-a" value={estadoTornillo.i28.sondajeInput.sondajeInputA} tabIndex="142" disabled={props.option.option === 2 ? disable : estadoTornillo.i28.statusPalatino} onChange={(e) => handelChangeSondaje("i28", "A", e.target.value)} />
                <input type="text" id="ps28-b" name="ps28-b" value={estadoTornillo.i28.sondajeInput.sondajeInputB} tabIndex="143" disabled={props.option.option === 2 ? disable : estadoTornillo.i28.statusPalatino} onChange={(e) => handelChangeSondaje("i28", "B", e.target.value)} />
                <input type="text" id="ps28-c" name="ps28-c" value={estadoTornillo.i28.sondajeInput.sondajeInputC} tabIndex="144" disabled={props.option.option === 2 ? disable : estadoTornillo.i28.statusPalatino} onChange={(e) => handelChangeSondaje("i28", "C", e.target.value)} />
              </td>
            </tr>
            {/* AQUI ESTA EL VESTIBULAR */}
            <tr>
              <td className="titulo">Vestibular</td>
              <td className="noborde">
                <div id="lineas-gr"></div>
                <div id="visualization18a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-7px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i18.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dataKey="nulo" dot={false} stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                        <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dataKey="encia" stroke="red" fill="red" dot={false} />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {estadoTornillo.i18.statusVestibular === 1 &&
                  <div id="diente18-a" style={getStyleDiente(estadoTornillo.i18.statusVestibular, "18").vestivular}>
                    {
                      estadoTornillo.i18.furca.furcaA === 0 && <div id="furca18"></div>
                    }
                    {
                      estadoTornillo.i18.furca.furcaA === 1 && <div id="furca18" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i18.furca.furcaA === 2 && <div id="furca18" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i18.furca.furcaA === 3 && <div id="furca18" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i18.statusVestibular === 2 &&
                  <div id="diente18-a" style={getStyleDiente(estadoTornillo.i18.statusVestibular, "18").vestivular}>
                    {
                      estadoTornillo.i18.furca.furcaA === 0 && <div id="furca18"></div>
                    }
                    {
                      estadoTornillo.i18.furca.furcaA === 1 && <div id="furca18" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i18.furca.furcaA === 2 && <div id="furca18" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i18.furca.furcaA === 3 && <div id="furca18" style={styleFurca1.furcaLleno}></div>
                    }

                  </div>
                }

                {estadoTornillo.i18.statusVestibular === 0 &&
                  <div id="diente18-a">
                    {
                      estadoTornillo.i18.furca.furcaA === 0 && <div id="furca18"></div>
                    }
                    {
                      estadoTornillo.i18.furca.furcaA === 1 && <div id="furca18" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i18.furca.furcaA === 2 && <div id="furca18" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i18.furca.furcaA === 3 && <div id="furca18" style={styleFurca1.furcaLleno}></div>
                    }

                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization17a" style={{ width: "25px", height: "160px", position: "absolute", margin: "0 0 0 -2px", zIndex: 2 }}>
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "2px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i17.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i17.statusVestibular === 1 &&
                  <div id="diente17-a" style={getStyleDiente(estadoTornillo.i17.statusVestibular, "17").vestivular}>
                    {
                      estadoTornillo.i17.furca.furcaA === 0 && <div id="furca17"></div>
                    }
                    {
                      estadoTornillo.i17.furca.furcaA === 1 && <div id="furca17" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i17.furca.furcaA === 2 && <div id="furca17" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i17.furca.furcaA === 3 && <div id="furca17" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i17.statusVestibular === 2 &&
                  <div id="diente17-a" style={getStyleDiente(estadoTornillo.i17.statusVestibular, "17").vestivular}>
                    {
                      estadoTornillo.i17.furca.furcaA === 0 && <div id="furca17"></div>
                    }
                    {
                      estadoTornillo.i17.furca.furcaA === 1 && <div id="furca17" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i17.furca.furcaA === 2 && <div id="furca17" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i17.furca.furcaA === 3 && <div id="furca17" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i17.statusVestibular === 0 &&
                  <div id="diente17-a" >
                    {
                      estadoTornillo.i17.furca.furcaA === 0 && <div id="furca17"></div>
                    }
                    {
                      estadoTornillo.i17.furca.furcaA === 1 && <div id="furca17" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i17.furca.furcaA === 2 && <div id="furca17" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i17.furca.furcaA === 3 && <div id="furca17" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization16a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-9px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={50} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i16.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i16.statusVestibular === 1 &&
                  <div id="diente16-a" style={getStyleDiente(estadoTornillo.i16.statusVestibular, "16").vestivular}>
                    {
                      estadoTornillo.i16.furca.furcaA === 0 && <div id="furca16"></div>
                    }
                    {
                      estadoTornillo.i16.furca.furcaA === 1 && <div id="furca16" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i16.furca.furcaA === 2 && <div id="furca16" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i16.furca.furcaA === 3 && <div id="furca16" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i16.statusVestibular === 2 &&
                  <div id="diente16-a" style={getStyleDiente(estadoTornillo.i16.statusVestibular, "16").vestivular}>
                    {
                      estadoTornillo.i16.furca.furcaA === 0 && <div id="furca16"></div>
                    }
                    {
                      estadoTornillo.i16.furca.furcaA === 1 && <div id="furca16" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i16.furca.furcaA === 2 && <div id="furca16" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i16.furca.furcaA === 3 && <div id="furca16" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i16.statusVestibular === 0 &&
                  <div id="diente16-a">
                    {
                      estadoTornillo.i16.furca.furcaA === 0 && <div id="furca16"></div>
                    }
                    {
                      estadoTornillo.i16.furca.furcaA === 1 && <div id="furca16" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i16.furca.furcaA === 2 && <div id="furca16" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i16.furca.furcaA === 3 && <div id="furca16" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization15a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-12px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i15.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i15.statusVestibular === 1 && <div id="diente15-a" style={getStyleDiente(estadoTornillo.i15.statusVestibular, "15").vestivular} ></div>
                }
                {
                  estadoTornillo.i15.statusVestibular === 2 && <div id="diente15-a" style={getStyleDiente(estadoTornillo.i15.statusVestibular, "15").vestivular} ></div>
                }
                {
                  estadoTornillo.i15.statusVestibular === 0 && <div id="diente15-a"  ></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization14a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-12px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i14.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i14.statusVestibular === 1 && <div id="diente14-a" style={getStyleDiente(estadoTornillo.i14.statusVestibular, "14").vestivular}></div>
                }
                {
                  estadoTornillo.i14.statusVestibular === 2 && <div id="diente14-a" style={getStyleDiente(estadoTornillo.i14.statusVestibular, "14").vestivular}></div>
                }
                {
                  estadoTornillo.i14.statusVestibular === 0 && <div id="diente14-a" ></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization13a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-11px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i13.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i13.statusVestibular === 1 && <div id="diente13-a" style={getStyleDiente(estadoTornillo.i13.statusVestibular, "13").vestivular}></div>
                }
                {
                  estadoTornillo.i13.statusVestibular === 2 && <div id="diente13-a" style={getStyleDiente(estadoTornillo.i13.statusVestibular, "13").vestivular}></div>
                }
                {
                  estadoTornillo.i13.statusVestibular === 0 && <div id="diente13-a" ></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization12a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-11px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i12.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i12.statusVestibular === 1 && <div id="diente12-a" style={getStyleDiente(estadoTornillo.i12.statusVestibular, "12").vestivular}></div>
                }
                {
                  estadoTornillo.i12.statusVestibular === 2 && <div id="diente12-a" style={getStyleDiente(estadoTornillo.i12.statusVestibular, "12").vestivular}></div>
                }
                {
                  estadoTornillo.i12.statusVestibular === 0 && <div id="diente12-a" style={getStyleDiente(estadoTornillo.i12.statusVestibular, "12").vestivular}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization11a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-11px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i11.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i11.statusVestibular === 1 && <div id="diente11-a" style={getStyleDiente(estadoTornillo.i11.statusVestibular, "11").vestivular}></div>
                }
                {
                  estadoTornillo.i11.statusVestibular === 2 && <div id="diente11-a" style={getStyleDiente(estadoTornillo.i11.statusVestibular, "11").vestivular}></div>
                }
                {
                  estadoTornillo.i11.statusVestibular === 0 && <div id="diente11-a" ></div>
                }
              </td>

              <td className="noborde">
                <div id="lineas-gr"></div>
                <div id="visualization21a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-11px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i21.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i21.statusVestibular === 1 && <div id="diente21-a" style={getStyleDiente(estadoTornillo.i21.statusVestibular, "21").vestivular}></div>
                }
                {
                  estadoTornillo.i21.statusVestibular === 2 && <div id="diente21-a" style={getStyleDiente(estadoTornillo.i21.statusVestibular, "21").vestivular}></div>
                }
                {
                  estadoTornillo.i21.statusVestibular === 0 && <div id="diente21-a" ></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization22a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-11px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i22.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i22.statusVestibular === 1 && <div id="diente22-a" style={getStyleDiente(estadoTornillo.i22.statusVestibular, "22").vestivular}></div>
                }
                {
                  estadoTornillo.i22.statusVestibular === 2 && <div id="diente22-a" style={getStyleDiente(estadoTornillo.i22.statusVestibular, "22").vestivular}></div>
                }
                {
                  estadoTornillo.i22.statusVestibular === 0 && <div id="diente22-a"  ></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization23a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-11px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i23.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i23.statusVestibular === 1 && <div id="diente23-a" style={getStyleDiente(estadoTornillo.i23.statusVestibular, "23").vestivular}></div>
                }
                {
                  estadoTornillo.i23.statusVestibular === 2 && <div id="diente23-a" style={getStyleDiente(estadoTornillo.i23.statusVestibular, "23").vestivular}></div>
                }
                {
                  estadoTornillo.i23.statusVestibular === 0 && <div id="diente23-a" ></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization24a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-11px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i24.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i24.statusVestibular === 1 && <div id="diente24-a" style={getStyleDiente(estadoTornillo.i24.statusVestibular, "24").vestivular}></div>
                }
                {
                  estadoTornillo.i24.statusVestibular === 2 && <div id="diente24-a" style={getStyleDiente(estadoTornillo.i24.statusVestibular, "24").vestivular}></div>
                }
                {
                  estadoTornillo.i24.statusVestibular === 0 && <div id="diente24-a" ></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization25a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-11px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i25.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i25.statusVestibular === 1 && <div id="diente25-a" style={getStyleDiente(estadoTornillo.i25.statusVestibular, "25").vestivular}></div>
                }
                {
                  estadoTornillo.i25.statusVestibular === 2 && <div id="diente25-a" style={getStyleDiente(estadoTornillo.i25.statusVestibular, "25").vestivular}></div>
                }
                {
                  estadoTornillo.i25.statusVestibular === 0 && <div id="diente25-a" ></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization26a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-3px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i26.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i26.statusVestibular === 1 &&
                  <div id="diente26-a" style={getStyleDiente(estadoTornillo.i26.statusVestibular, "26").vestivular}>
                    {
                      estadoTornillo.i26.furca.furcaA === 0 && <div id="furca26"></div>
                    }
                    {
                      estadoTornillo.i26.furca.furcaA === 1 && <div id="furca26" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i26.furca.furcaA === 2 && <div id="furca26" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i26.furca.furcaA === 3 && <div id="furca26" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i26.statusVestibular === 2 &&
                  <div id="diente26-a" style={getStyleDiente(estadoTornillo.i26.statusVestibular, "26").vestivular}>
                    {
                      estadoTornillo.i26.furca.furcaA === 0 && <div id="furca26"></div>
                    }
                    {
                      estadoTornillo.i26.furca.furcaA === 1 && <div id="furca26" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i26.furca.furcaA === 2 && <div id="furca26" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i26.furca.furcaA === 3 && <div id="furca26" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i26.statusVestibular === 0 &&
                  <div id="diente26-a" >
                    {
                      estadoTornillo.i26.furca.furcaA === 0 && <div id="furca26"></div>
                    }
                    {
                      estadoTornillo.i26.furca.furcaA === 1 && <div id="furca26" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i26.furca.furcaA === 2 && <div id="furca26" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i26.furca.furcaA === 3 && <div id="furca26" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization27a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-8px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i27.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i27.statusVestibular === 1 &&
                  <div id="diente27-a" style={getStyleDiente(estadoTornillo.i27.statusVestibular, "27").vestivular}>
                    {
                      estadoTornillo.i27.furca.furcaA === 0 && <div id="furca27"></div>
                    }
                    {
                      estadoTornillo.i27.furca.furcaA === 1 && <div id="furca27" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i27.furca.furcaA === 2 && <div id="furca27" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i27.furca.furcaA === 3 && <div id="furca27" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }

                {
                  estadoTornillo.i27.statusVestibular === 2 &&
                  <div id="diente27-a" style={getStyleDiente(estadoTornillo.i27.statusVestibular, "27").vestivular}>
                    {
                      estadoTornillo.i27.furca.furcaA === 0 && <div id="furca27"></div>
                    }
                    {
                      estadoTornillo.i27.furca.furcaA === 1 && <div id="furca27" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i27.furca.furcaA === 2 && <div id="furca27" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i27.furca.furcaA === 3 && <div id="furca27" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i27.statusVestibular === 0 &&
                  <div id="diente27-a">
                    {
                      estadoTornillo.i27.furca.furcaA === 0 && <div id="furca27"></div>
                    }
                    {
                      estadoTornillo.i27.furca.furcaA === 1 && <div id="furca27" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i27.furca.furcaA === 2 && <div id="furca27" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i27.furca.furcaA === 3 && <div id="furca27" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization28a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-8px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i28.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i28.statusVestibular === 1 &&
                  <div id="diente28-a" style={getStyleDiente(estadoTornillo.i28.statusVestibular, "28").vestivular}>
                    {
                      estadoTornillo.i28.furca.furcaA === 0 && <div id="furca28"></div>
                    }
                    {
                      estadoTornillo.i28.furca.furcaA === 1 && <div id="furca28" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i28.furca.furcaA === 2 && <div id="furca28" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i28.furca.furcaA === 3 && <div id="furca28" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i28.statusVestibular === 2 &&
                  <div id="diente28-a" style={getStyleDiente(estadoTornillo.i28.statusVestibular, "28").vestivular}>
                    {
                      estadoTornillo.i28.furca.furcaA === 0 && <div id="furca28"></div>
                    }
                    {
                      estadoTornillo.i28.furca.furcaA === 1 && <div id="furca28" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i28.furca.furcaA === 2 && <div id="furca28" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i28.furca.furcaA === 3 && <div id="furca28" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i28.statusVestibular === 0 &&
                  <div id="diente28-a">
                    {
                      estadoTornillo.i28.furca.furcaA === 0 && <div id="furca28"></div>
                    }
                    {
                      estadoTornillo.i28.furca.furcaA === 1 && <div id="furca28" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i28.furca.furcaA === 2 && <div id="furca28" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i28.furca.furcaA === 3 && <div id="furca28" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

            </tr>
          </tbody>
        </table>
      </div>

      <div className='tabla'>
        <table id="tabla-2">
          <tbody>
            <tr>
              <td className="titulo">Palatino</td>
              <td className="noborde">
                <div id="lineas-gr-inf"></div>
                <div id="visualization18b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-14px", top: "-17px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i18b.encia
                          //{ name: '', uv: 0,  },

                        ]}
                      >

                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i18b.statusPalatino === 1 &&
                  <div id="diente18b-a" style={getStyleDiente(estadoTornillo.i18b.statusPalatino, "18").palatino} >
                    {
                      estadoTornillo['i18b'].furca.furcaA === 0 && <div id="furca18-a"></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaA === 1 && <div id="furca18-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaA === 2 && <div id="furca18-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaA === 3 && <div id="furca18-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i18b'].furca.furcaB === 0 && <div id="furca18-b"></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaB === 1 && <div id="furca18-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaB === 2 && <div id="furca18-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaB === 3 && <div id="furca18-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i18b.statusPalatino === 2 &&
                  <div id="diente18b-a" style={getStyleDiente(estadoTornillo.i18b.statusPalatino, "18").palatino} >
                    {
                      estadoTornillo['i18b'].furca.furcaA === 0 && <div id="furca18-a"></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaA === 1 && <div id="furca18-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaA === 2 && <div id="furca18-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaA === 3 && <div id="furca18-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i18b'].furca.furcaB === 0 && <div id="furca18-b"></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaB === 1 && <div id="furca18-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaB === 2 && <div id="furca18-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaB === 3 && <div id="furca18-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }

                {
                  estadoTornillo.i18b.statusPalatino === 0 &&
                  <div id="diente18b-a" >
                    {
                      estadoTornillo['i18b'].furca.furcaA === 0 && <div id="furca18-a"></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaA === 1 && <div id="furca18-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaA === 2 && <div id="furca18-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaA === 3 && <div id="furca18-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i18b'].furca.furcaB === 0 && <div id="furca18-b"></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaB === 1 && <div id="furca18-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaB === 2 && <div id="furca18-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i18b'].furca.furcaB === 3 && <div id="furca18-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization17b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-15px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i17b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i17b.statusPalatino === 1 &&
                  <div id="diente17b-a" style={getStyleDiente(estadoTornillo.i17b.statusPalatino, "17").palatino} >
                    {
                      estadoTornillo['i17b'].furca.furcaA === 0 && <div id="furca17-a"></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaA === 1 && <div id="furca17-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaA === 2 && <div id="furca17-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaA === 3 && <div id="furca17-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i17b'].furca.furcaB === 0 && <div id="furca17-b"></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaB === 1 && <div id="furca17-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaB === 2 && <div id="furca17-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaB === 3 && <div id="furca17-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i17b.statusPalatino === 2 &&
                  <div id="diente17b-a" style={getStyleDiente(estadoTornillo.i17b.statusPalatino, "17").palatino} >
                    {
                      estadoTornillo['i17b'].furca.furcaA === 0 && <div id="furca17-a"></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaA === 1 && <div id="furca17-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaA === 2 && <div id="furca17-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaA === 3 && <div id="furca17-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i17b'].furca.furcaB === 0 && <div id="furca17-b"></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaB === 1 && <div id="furca17-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaB === 2 && <div id="furca17-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaB === 3 && <div id="furca17-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i17b.statusPalatino === 0 &&
                  <div id="diente17b-a">
                    {
                      estadoTornillo['i17b'].furca.furcaA === 0 && <div id="furca17-a"></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaA === 1 && <div id="furca17-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaA === 2 && <div id="furca17-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaA === 3 && <div id="furca17-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i17b'].furca.furcaB === 0 && <div id="furca17-b"></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaB === 1 && <div id="furca17-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaB === 2 && <div id="furca17-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i17b'].furca.furcaB === 3 && <div id="furca17-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization16b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-14px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i16b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i16b.statusPalatino === 1 &&
                  <div id="diente16b-a" style={getStyleDiente(estadoTornillo.i16b.statusPalatino, "16").palatino}>
                    {
                      estadoTornillo['i16b'].furca.furcaA === 0 && <div id="furca16-a"></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaA === 1 && <div id="furca16-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaA === 2 && <div id="furca16-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaA === 3 && <div id="furca16-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i16b'].furca.furcaB === 0 && <div id="furca16-b"></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaB === 1 && <div id="furca16-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaB === 2 && <div id="furca16-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaB === 3 && <div id="furca16-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i16b.statusPalatino === 2 &&
                  <div id="diente16b-a" style={getStyleDiente(estadoTornillo.i16b.statusPalatino, "16").palatino}>
                    {
                      estadoTornillo['i16b'].furca.furcaA === 0 && <div id="furca16-a"></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaA === 1 && <div id="furca16-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaA === 2 && <div id="furca16-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaA === 3 && <div id="furca16-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i16b'].furca.furcaB === 0 && <div id="furca16-b"></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaB === 1 && <div id="furca16-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaB === 2 && <div id="furca16-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaB === 3 && <div id="furca16-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i16b.statusPalatino === 0 &&
                  <div id="diente16b-a">
                    {
                      estadoTornillo['i16b'].furca.furcaA === 0 && <div id="furca16-a"></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaA === 1 && <div id="furca16-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaA === 2 && <div id="furca16-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaA === 3 && <div id="furca16-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i16b'].furca.furcaB === 0 && <div id="furca16-b"></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaB === 1 && <div id="furca16-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaB === 2 && <div id="furca16-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i16b'].furca.furcaB === 3 && <div id="furca16-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization15b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-20px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i15b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i15b.statusPalatino === 1 && <div id="diente15b-a" style={getStyleDiente(estadoTornillo.i15b.statusPalatino, "15").palatino}></div>
                }
                {
                  estadoTornillo.i15b.statusPalatino === 2 && <div id="diente15b-a" style={getStyleDiente(estadoTornillo.i15b.statusPalatino, "15").palatino}></div>
                }
                {
                  estadoTornillo.i15b.statusPalatino === 0 && <div id="diente15b-a" style={getStyleDiente(estadoTornillo.i15b.statusPalatino, "15").palatino}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization14b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-20px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i14b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i14b.statusPalatino === 1 &&
                  <div id="diente14b-a" style={getStyleDiente(estadoTornillo.i14b.statusPalatino, "14").palatino}>
                    {
                      estadoTornillo['i14b'].furca.furcaA === 0 && <div id="furca14-a"></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaA === 1 && <div id="furca14-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaA === 2 && <div id="furca14-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaA === 3 && <div id="furca14-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i14b'].furca.furcaB === 0 && <div id="furca14-b"></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaB === 1 && <div id="furca14-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaB === 2 && <div id="furca14-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaB === 3 && <div id="furca14-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }

                {
                  estadoTornillo.i14b.statusPalatino === 2 &&
                  <div id="diente14b-a" style={getStyleDiente(estadoTornillo.i14b.statusPalatino, "14").palatino}>
                    {
                      estadoTornillo['i14b'].furca.furcaA === 0 && <div id="furca14-a"></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaA === 1 && <div id="furca14-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaA === 2 && <div id="furca14-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaA === 3 && <div id="furca14-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i14b'].furca.furcaB === 0 && <div id="furca14-b"></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaB === 1 && <div id="furca14-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaB === 2 && <div id="furca14-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaB === 3 && <div id="furca14-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }

                {estadoTornillo.i14b.statusPalatino === 0 &&
                  <div id="diente14b-a">
                    {
                      estadoTornillo['i14b'].furca.furcaA === 0 && <div id="furca14-a"></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaA === 1 && <div id="furca14-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaA === 2 && <div id="furca14-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaA === 3 && <div id="furca14-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i14b'].furca.furcaB === 0 && <div id="furca14-b"></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaB === 1 && <div id="furca14-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaB === 2 && <div id="furca14-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i14b'].furca.furcaB === 3 && <div id="furca14-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization13b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-20px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i13b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i13b.statusPalatino === 1 && <div id="diente13b-a" style={getStyleDiente(estadoTornillo.i13b.statusPalatino, "13").palatino}></div>
                }
                {
                  estadoTornillo.i13b.statusPalatino === 2 && <div id="diente13b-a" style={getStyleDiente(estadoTornillo.i13b.statusPalatino, "13").palatino}></div>
                }
                {
                  estadoTornillo.i13b.statusPalatino === 0 && <div id="diente13b-a" style={getStyleDiente(estadoTornillo.i13b.statusPalatino, "13").palatino}></div>
                }

              </td>

              <td className="noborde">
                <div id="visualization12b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-20px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i12b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i12b.statusPalatino === 1 &&
                  <div id="diente12b-a" style={getStyleDiente(estadoTornillo.i12b.statusPalatino, "12").palatino}></div>
                }
                {
                  estadoTornillo.i12b.statusPalatino === 2 &&
                  <div id="diente12b-a" style={getStyleDiente(estadoTornillo.i12b.statusPalatino, "12").palatino}></div>
                }
                {
                  estadoTornillo.i12b.statusPalatino === 0 &&
                  <div id="diente12b-a" style={getStyleDiente(estadoTornillo.i12b.statusPalatino, "12").palatino}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization11b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-15px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i11b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i11b.statusPalatino === 1 && <div id="diente11b-a" style={getStyleDiente(estadoTornillo.i11b.statusPalatino, "11").palatino}></div>
                }
                {
                  estadoTornillo.i11b.statusPalatino === 2 && <div id="diente11b-a" style={getStyleDiente(estadoTornillo.i11b.statusPalatino, "11").palatino}></div>
                }
                {
                  estadoTornillo.i11b.statusPalatino === 0 && <div id="diente11b-a" ></div>
                }
              </td>

              <td className="noborde">
                <div id="lineas-gr-inf"></div>
                <div id="visualization21b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-15px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i21b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i21.statusPalatino === 1 && <div id="diente21b-a" style={getStyleDiente(estadoTornillo.i21b.statusPalatino, "21").palatino}></div>
                }
                {
                  estadoTornillo.i21.statusPalatino === 2 && <div id="diente21b-a" style={getStyleDiente(estadoTornillo.i21b.statusPalatino, "21").palatino}></div>
                }
                {
                  estadoTornillo.i21.statusPalatino === 0 && <div id="diente21b-a" style={getStyleDiente(estadoTornillo.i21b.statusPalatino, "21").palatino}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization22b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-13px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i22b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i22.statusPalatino === 1 && <div id="diente22b-a" style={getStyleDiente(estadoTornillo.i22b.statusPalatino, "22").palatino}></div>
                }
                {
                  estadoTornillo.i22.statusPalatino === 2 && <div id="diente22b-a" style={getStyleDiente(estadoTornillo.i22b.statusPalatino, "22").palatino}></div>
                }
                {
                  estadoTornillo.i22.statusPalatino === 0 && <div id="diente22b-a" style={getStyleDiente(estadoTornillo.i22b.statusPalatino, "22").palatino}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization23b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-13px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i23b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i23.statusPalatino === 1 && <div id="diente23b-a" style={getStyleDiente(estadoTornillo.i23b.statusPalatino, "23").palatino}></div>
                }
                {
                  estadoTornillo.i23.statusPalatino === 2 && <div id="diente23b-a" style={getStyleDiente(estadoTornillo.i23b.statusPalatino, "23").palatino}></div>
                }
                {
                  estadoTornillo.i23.statusPalatino === 0 && <div id="diente23b-a" style={getStyleDiente(estadoTornillo.i23b.statusPalatino, "23").palatino}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization24b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-15px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i24b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i24b.statusPalatino === 1 &&
                  <div id="diente24b-a" style={getStyleDiente(estadoTornillo.i24b.statusPalatino, "24").palatino}>
                    {
                      estadoTornillo['i24b'].furca.furcaA === 0 && <div id="furca24-a"></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaA === 1 && <div id="furca24-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaA === 2 && <div id="furca24-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaA === 3 && <div id="furca24-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i24b'].furca.furcaB === 0 && <div id="furca24-b"></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaB === 1 && <div id="furca24-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaB === 2 && <div id="furca24-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaB === 3 && <div id="furca24-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i24b.statusPalatino === 2 &&
                  <div id="diente24b-a" style={getStyleDiente(estadoTornillo.i24b.statusPalatino, "24").palatino}>
                    {
                      estadoTornillo['i24b'].furca.furcaA === 0 && <div id="furca24-a"></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaA === 1 && <div id="furca24-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaA === 2 && <div id="furca24-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaA === 3 && <div id="furca24-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i24b'].furca.furcaB === 0 && <div id="furca24-b"></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaB === 1 && <div id="furca24-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaB === 2 && <div id="furca24-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaB === 3 && <div id="furca24-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i24b.statusPalatino === 0 &&
                  <div id="diente24b-a">
                    {
                      estadoTornillo['i24b'].furca.furcaA === 0 && <div id="furca24-a"></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaA === 1 && <div id="furca24-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaA === 2 && <div id="furca24-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaA === 3 && <div id="furca24-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i24b'].furca.furcaB === 0 && <div id="furca24-b"></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaB === 1 && <div id="furca24-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaB === 2 && <div id="furca24-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i24b'].furca.furcaB === 3 && <div id="furca24-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization25b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-14px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i25b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i25b.statusPalatino === 1 && <div id="diente25b-a" style={getStyleDiente(estadoTornillo.i25b.statusPalatino, "25").palatino}></div>
                }
                {
                  estadoTornillo.i25b.statusPalatino === 2 && <div id="diente25b-a" style={getStyleDiente(estadoTornillo.i25b.statusPalatino, "25").palatino}></div>
                }
                {
                  estadoTornillo.i25b.statusPalatino === 0 && <div id="diente25b-a" style={getStyleDiente(estadoTornillo.i25b.statusPalatino, "25").palatino}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization26b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-15px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i26b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i26b.statusPalatino === 1 &&
                  <div id="diente26b-a" style={getStyleDiente(estadoTornillo.i26b.statusPalatino, "26").palatino}>
                    {
                      estadoTornillo['i26b'].furca.furcaA === 0 && <div id="furca26-a"></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaA === 1 && <div id="furca26-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaA === 2 && <div id="furca26-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaA === 3 && <div id="furca26-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i26b'].furca.furcaB === 0 && <div id="furca26-b"></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaB === 1 && <div id="furca26-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaB === 2 && <div id="furca26-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaB === 3 && <div id="furca26-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i26b.statusPalatino === 2 &&
                  <div id="diente26b-a" style={getStyleDiente(estadoTornillo.i26b.statusPalatino, "26").palatino}>
                    {
                      estadoTornillo['i26b'].furca.furcaA === 0 && <div id="furca26-a"></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaA === 1 && <div id="furca26-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaA === 2 && <div id="furca26-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaA === 3 && <div id="furca26-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i26b'].furca.furcaB === 0 && <div id="furca26-b"></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaB === 1 && <div id="furca26-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaB === 2 && <div id="furca26-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaB === 3 && <div id="furca26-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i26b.statusPalatino === 0 &&
                  <div id="diente26b-a">
                    {
                      estadoTornillo['i26b'].furca.furcaA === 0 && <div id="furca26-a"></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaA === 1 && <div id="furca26-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaA === 2 && <div id="furca26-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaA === 3 && <div id="furca26-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i26b'].furca.furcaB === 0 && <div id="furca26-b"></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaB === 1 && <div id="furca26-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaB === 2 && <div id="furca26-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i26b'].furca.furcaB === 3 && <div id="furca26-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization27b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-15px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i27b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i27b.statusPalatino === 1 &&
                  <div id="diente27b-a" style={getStyleDiente(estadoTornillo.i27b.statusPalatino, "27").palatino}>
                    {
                      estadoTornillo['i27b'].furca.furcaA === 0 && <div id="furca27-a"></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaA === 1 && <div id="furca27-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaA === 2 && <div id="furca27-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaA === 3 && <div id="furca27-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i27b'].furca.furcaB === 0 && <div id="furca27-b"></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaB === 1 && <div id="furca27-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaB === 2 && <div id="furca27-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaB === 3 && <div id="furca27-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i27b.statusPalatino === 2 &&
                  <div id="diente27b-a" style={getStyleDiente(estadoTornillo.i27b.statusPalatino, "27").palatino}>
                    {
                      estadoTornillo['i27b'].furca.furcaA === 0 && <div id="furca27-a"></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaA === 1 && <div id="furca27-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaA === 2 && <div id="furca27-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaA === 3 && <div id="furca27-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i27b'].furca.furcaB === 0 && <div id="furca27-b"></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaB === 1 && <div id="furca27-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaB === 2 && <div id="furca27-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaB === 3 && <div id="furca27-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i27b.statusPalatino === 0 &&
                  <div id="diente27b-a" >
                    {
                      estadoTornillo['i27b'].furca.furcaA === 0 && <div id="furca27-a"></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaA === 1 && <div id="furca27-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaA === 2 && <div id="furca27-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaA === 3 && <div id="furca27-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i27b'].furca.furcaB === 0 && <div id="furca27-b"></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaB === 1 && <div id="furca27-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaB === 2 && <div id="furca27-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i27b'].furca.furcaB === 3 && <div id="furca27-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization28b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-15px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i28b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i28b.statusPalatino === 1 &&
                  <div id="diente28b-a" style={getStyleDiente(estadoTornillo.i28b.statusPalatino, "28").palatino}>
                    {
                      estadoTornillo['i28b'].furca.furcaA === 0 && <div id="furca28-a"></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaA === 1 && <div id="furca28-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaA === 2 && <div id="furca28-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaA === 3 && <div id="furca28-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i28b'].furca.furcaB === 0 && <div id="furca28-b"></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaB === 1 && <div id="furca28-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaB === 2 && <div id="furca28-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaB === 3 && <div id="furca28-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i28b.statusPalatino === 2 &&
                  <div id="diente28b-a" style={getStyleDiente(estadoTornillo.i28b.statusPalatino, "28").palatino}>
                    {
                      estadoTornillo['i28b'].furca.furcaA === 0 && <div id="furca28-a"></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaA === 1 && <div id="furca28-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaA === 2 && <div id="furca28-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaA === 3 && <div id="furca28-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i28b'].furca.furcaB === 0 && <div id="furca28-b"></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaB === 1 && <div id="furca28-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaB === 2 && <div id="furca28-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaB === 3 && <div id="furca28-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i28b.statusPalatino === 0 &&
                  <div id="diente28b-a">
                    {
                      estadoTornillo['i28b'].furca.furcaA === 0 && <div id="furca28-a"></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaA === 1 && <div id="furca28-a" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaA === 2 && <div id="furca28-a" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaA === 3 && <div id="furca28-a" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i28b'].furca.furcaB === 0 && <div id="furca28-b"></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaB === 1 && <div id="furca28-b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaB === 2 && <div id="furca28-b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i28b'].furca.furcaB === 3 && <div id="furca28-b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>
            </tr>

            <tr>
              <td className="titulo">Profundidad de sondaje</td>
              <td className="borde">
                <input type="text" id="ps18b-c" name="ps18b-c" value={estadoTornillo.i18b.sondajeInput.sondajeInputC} tabIndex="145" disabled={props.option.option === 2 ? disable : estadoTornillo.i18b.statusPalatino} onChange={(e) => handelChangeSondaje("i18b", "C", e.target.value)} />
                <input type="text" id="ps18b-b" name="ps18b-b" value={estadoTornillo.i18b.sondajeInput.sondajeInputB} tabIndex="146" disabled={props.option.option === 2 ? disable : estadoTornillo.i18b.statusPalatino} onChange={(e) => handelChangeSondaje("i18b", "B", e.target.value)} />
                <input type="text" id="ps18b-a" name="ps18b-a" value={estadoTornillo.i18b.sondajeInput.sondajeInputA} tabIndex="147" disabled={props.option.option === 2 ? disable : estadoTornillo.i18b.statusPalatino} onChange={(e) => handelChangeSondaje("i18b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps17b-c" name="ps17b-c" value={estadoTornillo.i17b.sondajeInput.sondajeInputC} tabIndex="148" disabled={props.option.option === 2 ? disable : estadoTornillo.i17b.statusPalatino} onChange={(e) => handelChangeSondaje("i17b", "C", e.target.value)} />
                <input type="text" id="ps17b-b" name="ps17b-b" value={estadoTornillo.i17b.sondajeInput.sondajeInputB} tabIndex="149" disabled={props.option.option === 2 ? disable : estadoTornillo.i17b.statusPalatino} onChange={(e) => handelChangeSondaje("i17b", "B", e.target.value)} />
                <input type="text" id="ps17b-a" name="ps17b-a" value={estadoTornillo.i17b.sondajeInput.sondajeInputA} tabIndex="150" disabled={props.option.option === 2 ? disable : estadoTornillo.i17b.statusPalatino} onChange={(e) => handelChangeSondaje("i17b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps16b-c" name="ps16b-c" value={estadoTornillo.i16b.sondajeInput.sondajeInputC} tabIndex="151" disabled={props.option.option === 2 ? disable : estadoTornillo.i16b.statusPalatino} onChange={(e) => handelChangeSondaje("i16b", "C", e.target.value)} />
                <input type="text" id="ps16b-b" name="ps16b-b" value={estadoTornillo.i16b.sondajeInput.sondajeInputB} tabIndex="152" disabled={props.option.option === 2 ? disable : estadoTornillo.i16b.statusPalatino} onChange={(e) => handelChangeSondaje("i16b", "B", e.target.value)} />
                <input type="text" id="ps16b-a" name="ps16b-a" value={estadoTornillo.i16b.sondajeInput.sondajeInputA} tabIndex="153" disabled={props.option.option === 2 ? disable : estadoTornillo.i16b.statusPalatino} onChange={(e) => handelChangeSondaje("i16b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps15b-c" name="ps15b-c" value={estadoTornillo.i15b.sondajeInput.sondajeInputC} tabIndex="154" disabled={props.option.option === 2 ? disable : estadoTornillo.i15b.statusPalatino} onChange={(e) => handelChangeSondaje("i15b", "C", e.target.value)} />
                <input type="text" id="ps15b-b" name="ps15b-b" value={estadoTornillo.i15b.sondajeInput.sondajeInputB} tabIndex="155" disabled={props.option.option === 2 ? disable : estadoTornillo.i15b.statusPalatino} onChange={(e) => handelChangeSondaje("i15b", "B", e.target.value)} />
                <input type="text" id="ps15b-a" name="ps15b-a" value={estadoTornillo.i15b.sondajeInput.sondajeInputA} tabIndex="156" disabled={props.option.option === 2 ? disable : estadoTornillo.i15b.statusPalatino} onChange={(e) => handelChangeSondaje("i15b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps14b-c" name="ps14b-c" value={estadoTornillo.i14b.sondajeInput.sondajeInputC} tabIndex="157" disabled={props.option.option === 2 ? disable : estadoTornillo.i14b.statusPalatino} onChange={(e) => handelChangeSondaje("i14b", "C", e.target.value)} />
                <input type="text" id="ps14b-b" name="ps14b-b" value={estadoTornillo.i14b.sondajeInput.sondajeInputB} tabIndex="158" disabled={props.option.option === 2 ? disable : estadoTornillo.i14b.statusPalatino} onChange={(e) => handelChangeSondaje("i14b", "B", e.target.value)} />
                <input type="text" id="ps14b-a" name="ps14b-a" value={estadoTornillo.i14b.sondajeInput.sondajeInputA} tabIndex="159" disabled={props.option.option === 2 ? disable : estadoTornillo.i14b.statusPalatino} onChange={(e) => handelChangeSondaje("i14b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps13b-c" name="ps13b-c" value={estadoTornillo.i13b.sondajeInput.sondajeInputC} tabIndex="160" disabled={props.option.option === 2 ? disable : estadoTornillo.i13b.statusPalatino} onChange={(e) => handelChangeSondaje("i13b", "C", e.target.value)} />
                <input type="text" id="ps13b-b" name="ps13b-b" value={estadoTornillo.i13b.sondajeInput.sondajeInputB} tabIndex="161" disabled={props.option.option === 2 ? disable : estadoTornillo.i13b.statusPalatino} onChange={(e) => handelChangeSondaje("i13b", "B", e.target.value)} />
                <input type="text" id="ps13b-a" name="ps13b-a" value={estadoTornillo.i13b.sondajeInput.sondajeInputA} tabIndex="162" disabled={props.option.option === 2 ? disable : estadoTornillo.i13b.statusPalatino} onChange={(e) => handelChangeSondaje("i13b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps12b-c" name="ps12b-c" value={estadoTornillo.i12b.sondajeInput.sondajeInputC} tabIndex="163" disabled={props.option.option === 2 ? disable : estadoTornillo.i12b.statusPalatino} onChange={(e) => handelChangeSondaje("i12b", "C", e.target.value)} />
                <input type="text" id="ps12b-b" name="ps12b-b" value={estadoTornillo.i12b.sondajeInput.sondajeInputB} tabIndex="164" disabled={props.option.option === 2 ? disable : estadoTornillo.i12b.statusPalatino} onChange={(e) => handelChangeSondaje("i12b", "B", e.target.value)} />
                <input type="text" id="ps12b-a" name="ps12b-a" value={estadoTornillo.i12b.sondajeInput.sondajeInputA} tabIndex="165" disabled={props.option.option === 2 ? disable : estadoTornillo.i12b.statusPalatino} onChange={(e) => handelChangeSondaje("i12b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps11b-c" name="ps11b-c" value={estadoTornillo.i11b.sondajeInput.sondajeInputC} tabIndex="166" disabled={props.option.option === 2 ? disable : estadoTornillo.i11b.statusPalatino} onChange={(e) => handelChangeSondaje("i11b", "C", e.target.value)} />
                <input type="text" id="ps11b-b" name="ps11b-b" value={estadoTornillo.i11b.sondajeInput.sondajeInputB} tabIndex="167" disabled={props.option.option === 2 ? disable : estadoTornillo.i11b.statusPalatino} onChange={(e) => handelChangeSondaje("i11b", "B", e.target.value)} />
                <input type="text" id="ps11b-a" name="ps11b-a" value={estadoTornillo.i11b.sondajeInput.sondajeInputA} tabIndex="168" disabled={props.option.option === 2 ? disable : estadoTornillo.i11b.statusPalatino} onChange={(e) => handelChangeSondaje("i11b", "A", e.target.value)} />
              </td>

              <td className="borde">
                <input type="text" id="ps21b-c" name="ps21b-c" value={estadoTornillo.i21b.sondajeInput.sondajeInputC} tabIndex="169" disabled={props.option.option === 2 ? disable : estadoTornillo.i21b.statusPalatino} onChange={(e) => handelChangeSondaje("i21b", "C", e.target.value)} />
                <input type="text" id="ps21b-b" name="ps21b-b" value={estadoTornillo.i21b.sondajeInput.sondajeInputB} tabIndex="170" disabled={props.option.option === 2 ? disable : estadoTornillo.i21b.statusPalatino} onChange={(e) => handelChangeSondaje("i21b", "B", e.target.value)} />
                <input type="text" id="ps21b-a" name="ps21b-a" value={estadoTornillo.i21b.sondajeInput.sondajeInputA} tabIndex="171" disabled={props.option.option === 2 ? disable : estadoTornillo.i21b.statusPalatino} onChange={(e) => handelChangeSondaje("i21b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps22b-c" name="ps22b-c" value={estadoTornillo.i22b.sondajeInput.sondajeInputC} tabIndex="172" disabled={props.option.option === 2 ? disable : estadoTornillo.i22b.statusPalatino} onChange={(e) => handelChangeSondaje("i22b", "C", e.target.value)} />
                <input type="text" id="ps22b-b" name="ps22b-b" value={estadoTornillo.i22b.sondajeInput.sondajeInputB} tabIndex="173" disabled={props.option.option === 2 ? disable : estadoTornillo.i22b.statusPalatino} onChange={(e) => handelChangeSondaje("i22b", "B", e.target.value)} />
                <input type="text" id="ps22b-a" name="ps22b-a" value={estadoTornillo.i22b.sondajeInput.sondajeInputA} tabIndex="174" disabled={props.option.option === 2 ? disable : estadoTornillo.i22b.statusPalatino} onChange={(e) => handelChangeSondaje("i22b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps23b-c" name="ps23b-c" value={estadoTornillo.i23b.sondajeInput.sondajeInputC} tabIndex="175" disabled={props.option.option === 2 ? disable : estadoTornillo.i23b.statusPalatino} onChange={(e) => handelChangeSondaje("i23b", "C", e.target.value)} />
                <input type="text" id="ps23b-b" name="ps23b-b" value={estadoTornillo.i23b.sondajeInput.sondajeInputB} tabIndex="176" disabled={props.option.option === 2 ? disable : estadoTornillo.i23b.statusPalatino} onChange={(e) => handelChangeSondaje("i23b", "B", e.target.value)} />
                <input type="text" id="ps23b-a" name="ps23b-a" value={estadoTornillo.i23b.sondajeInput.sondajeInputA} tabIndex="177" disabled={props.option.option === 2 ? disable : estadoTornillo.i23b.statusPalatino} onChange={(e) => handelChangeSondaje("i23b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps24b-c" name="ps24b-c" value={estadoTornillo.i24b.sondajeInput.sondajeInputC} tabIndex="178" disabled={props.option.option === 2 ? disable : estadoTornillo.i24b.statusPalatino} onChange={(e) => handelChangeSondaje("i24b", "C", e.target.value)} />
                <input type="text" id="ps24b-b" name="ps24b-b" value={estadoTornillo.i24b.sondajeInput.sondajeInputB} tabIndex="179" disabled={props.option.option === 2 ? disable : estadoTornillo.i24b.statusPalatino} onChange={(e) => handelChangeSondaje("i24b", "B", e.target.value)} />
                <input type="text" id="ps24b-a" name="ps24b-a" value={estadoTornillo.i24b.sondajeInput.sondajeInputA} tabIndex="180" disabled={props.option.option === 2 ? disable : estadoTornillo.i24b.statusPalatino} onChange={(e) => handelChangeSondaje("i24b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps25b-c" name="ps25b-c" value={estadoTornillo.i25b.sondajeInput.sondajeInputC} tabIndex="181" disabled={props.option.option === 2 ? disable : estadoTornillo.i25b.statusPalatino} onChange={(e) => handelChangeSondaje("i25b", "C", e.target.value)} />
                <input type="text" id="ps25b-b" name="ps25b-b" value={estadoTornillo.i25b.sondajeInput.sondajeInputB} tabIndex="182" disabled={props.option.option === 2 ? disable : estadoTornillo.i25b.statusPalatino} onChange={(e) => handelChangeSondaje("i25b", "B", e.target.value)} />
                <input type="text" id="ps25b-a" name="ps25b-a" value={estadoTornillo.i25b.sondajeInput.sondajeInputA} tabIndex="183" disabled={props.option.option === 2 ? disable : estadoTornillo.i25b.statusPalatino} onChange={(e) => handelChangeSondaje("i25b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps26b-c" name="ps26b-c" value={estadoTornillo.i26b.sondajeInput.sondajeInputC} tabIndex="184" disabled={props.option.option === 2 ? disable : estadoTornillo.i26b.statusPalatino} onChange={(e) => handelChangeSondaje("i26b", "C", e.target.value)} />
                <input type="text" id="ps26b-b" name="ps26b-b" value={estadoTornillo.i26b.sondajeInput.sondajeInputB} tabIndex="185" disabled={props.option.option === 2 ? disable : estadoTornillo.i26b.statusPalatino} onChange={(e) => handelChangeSondaje("i26b", "B", e.target.value)} />
                <input type="text" id="ps26b-a" name="ps26b-a" value={estadoTornillo.i26b.sondajeInput.sondajeInputA} tabIndex="186" disabled={props.option.option === 2 ? disable : estadoTornillo.i26b.statusPalatino} onChange={(e) => handelChangeSondaje("i26b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps27b-c" name="ps27b-c" value={estadoTornillo.i27b.sondajeInput.sondajeInputC} tabIndex="187" disabled={props.option.option === 2 ? disable : estadoTornillo.i27b.statusPalatino} onChange={(e) => handelChangeSondaje("i27b", "C", e.target.value)} />
                <input type="text" id="ps27b-b" name="ps27b-b" value={estadoTornillo.i27b.sondajeInput.sondajeInputB} tabIndex="188" disabled={props.option.option === 2 ? disable : estadoTornillo.i27b.statusPalatino} onChange={(e) => handelChangeSondaje("i27b", "B", e.target.value)} />
                <input type="text" id="ps27b-a" name="ps27b-a" value={estadoTornillo.i27b.sondajeInput.sondajeInputA} tabIndex="189" disabled={props.option.option === 2 ? disable : estadoTornillo.i27b.statusPalatino} onChange={(e) => handelChangeSondaje("i27b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps28b-c" name="ps28b-c" value={estadoTornillo.i28b.sondajeInput.sondajeInputC} tabIndex="190" disabled={props.option.option === 2 ? disable : estadoTornillo.i28b.statusPalatino} onChange={(e) => handelChangeSondaje("i28b", "C", e.target.value)} />
                <input type="text" id="ps28b-b" name="ps28b-b" value={estadoTornillo.i28b.sondajeInput.sondajeInputB} tabIndex="191" disabled={props.option.option === 2 ? disable : estadoTornillo.i28b.statusPalatino} onChange={(e) => handelChangeSondaje("i28b", "B", e.target.value)} />
                <input type="text" id="ps28b-a" name="ps28b-a" value={estadoTornillo.i28b.sondajeInput.sondajeInputA} tabIndex="192" disabled={props.option.option === 2 ? disable : estadoTornillo.i28b.statusPalatino} onChange={(e) => handelChangeSondaje("i28b", "A", e.target.value)} />
              </td>
            </tr>



            <tr>
              <td className="titulo">Sangrado / Exudado</td>
              <td className="borde">
                {estadoTornillo.i18b.statusPalatino ?
                  <>
                    <div id="s18b-a" style={getStyle(estadoTornillo.i18b.sangrado.sangradoA)}></div>
                    <div id="s18b-b" style={getStyle(estadoTornillo.i18b.sangrado.sangradoB)}></div>
                    <div id="s18b-c" style={getStyle(estadoTornillo.i18b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s18b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i18b", "A")} style={getStyle(estadoTornillo.i18b.sangrado.sangradoA)}></div>
                    <div id="s18b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i18b", "B")} style={getStyle(estadoTornillo.i18b.sangrado.sangradoB)}></div>
                    <div id="s18b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i18b", "C")} style={getStyle(estadoTornillo.i18b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i17b.statusPalatino ?
                  <>
                    <div id="s17b-a" style={getStyle(estadoTornillo.i17b.sangrado.sangradoA)}></div>
                    <div id="s17b-b" style={getStyle(estadoTornillo.i17b.sangrado.sangradoB)}></div>
                    <div id="s17b-c" style={getStyle(estadoTornillo.i17b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s17b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i17b", "A")} style={getStyle(estadoTornillo.i17b.sangrado.sangradoA)}></div>
                    <div id="s17b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i17b", "B")} style={getStyle(estadoTornillo.i17b.sangrado.sangradoB)}></div>
                    <div id="s17b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i17b", "C")} style={getStyle(estadoTornillo.i17b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i16b.statusPalatino ?
                  <>
                    <div id="s16b-a" style={getStyle(estadoTornillo.i16b.sangrado.sangradoA)}></div>
                    <div id="s16b-b" style={getStyle(estadoTornillo.i16b.sangrado.sangradoB)}></div>
                    <div id="s16b-c" style={getStyle(estadoTornillo.i16b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s16b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i16b", "A")} style={getStyle(estadoTornillo.i16b.sangrado.sangradoA)}></div>
                    <div id="s16b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i16b", "B")} style={getStyle(estadoTornillo.i16b.sangrado.sangradoB)}></div>
                    <div id="s16b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i16b", "C")} style={getStyle(estadoTornillo.i16b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i15b.statusPalatino ?
                  <>
                    <div id="s15b-a" style={getStyle(estadoTornillo.i15b.sangrado.sangradoA)}></div>
                    <div id="s15b-b" style={getStyle(estadoTornillo.i15b.sangrado.sangradoB)}></div>
                    <div id="s15b-c" style={getStyle(estadoTornillo.i15b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s15b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i15b", "A")} style={getStyle(estadoTornillo.i15b.sangrado.sangradoA)}></div>
                    <div id="s15b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i15b", "B")} style={getStyle(estadoTornillo.i15b.sangrado.sangradoB)}></div>
                    <div id="s15b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i15b", "C")} style={getStyle(estadoTornillo.i15b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i14b.statusPalatino ?
                  <>
                    <div id="s14b-a" style={getStyle(estadoTornillo.i14b.sangrado.sangradoA)}></div>
                    <div id="s14b-b" style={getStyle(estadoTornillo.i14b.sangrado.sangradoB)}></div>
                    <div id="s14b-c" style={getStyle(estadoTornillo.i14b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s14b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i14b", "A")} style={getStyle(estadoTornillo.i14b.sangrado.sangradoA)}></div>
                    <div id="s14b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i14b", "B")} style={getStyle(estadoTornillo.i14b.sangrado.sangradoB)}></div>
                    <div id="s14b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i14b", "C")} style={getStyle(estadoTornillo.i14b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i13b.statusPalatino ?
                  <>
                    <div id="s13b-a" style={getStyle(estadoTornillo.i13b.sangrado.sangradoA)}></div>
                    <div id="s13b-b" style={getStyle(estadoTornillo.i13b.sangrado.sangradoB)}></div>
                    <div id="s13b-c" style={getStyle(estadoTornillo.i13b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s13b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i13b", "A")} style={getStyle(estadoTornillo.i13b.sangrado.sangradoA)}></div>
                    <div id="s13b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i13b", "B")} style={getStyle(estadoTornillo.i13b.sangrado.sangradoB)}></div>
                    <div id="s13b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i13b", "C")} style={getStyle(estadoTornillo.i13b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i12b.statusPalatino ?
                  <>
                    <div id="s12b-a" style={getStyle(estadoTornillo.i12b.sangrado.sangradoA)}></div>
                    <div id="s12b-b" style={getStyle(estadoTornillo.i12b.sangrado.sangradoB)}></div>
                    <div id="s12b-c" style={getStyle(estadoTornillo.i12b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s12b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i12b", "A")} style={getStyle(estadoTornillo.i12b.sangrado.sangradoA)}></div>
                    <div id="s12b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i12b", "B")} style={getStyle(estadoTornillo.i12b.sangrado.sangradoB)}></div>
                    <div id="s12b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i12b", "C")} style={getStyle(estadoTornillo.i12b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i11b.statusPalatino ?
                  <>
                    <div id="s11b-a" style={getStyle(estadoTornillo.i11b.sangrado.sangradoA)}></div>
                    <div id="s11b-b" style={getStyle(estadoTornillo.i11b.sangrado.sangradoB)}></div>
                    <div id="s11b-c" style={getStyle(estadoTornillo.i11b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s11b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i11b", "A")} style={getStyle(estadoTornillo.i11b.sangrado.sangradoA)}></div>
                    <div id="s11b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i11b", "B")} style={getStyle(estadoTornillo.i11b.sangrado.sangradoB)}></div>
                    <div id="s11b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i11b", "C")} style={getStyle(estadoTornillo.i11b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>


              <td className="borde">
                {estadoTornillo.i21b.statusPalatino ?
                  <>
                    <div id="s21b-a" style={getStyle(estadoTornillo.i21b.sangrado.sangradoA)}></div>
                    <div id="s21b-b" style={getStyle(estadoTornillo.i21b.sangrado.sangradoB)}></div>
                    <div id="s21b-c" style={getStyle(estadoTornillo.i21b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s21b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i21b", "A")} style={getStyle(estadoTornillo.i21b.sangrado.sangradoA)}></div>
                    <div id="s21b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i21b", "B")} style={getStyle(estadoTornillo.i21b.sangrado.sangradoB)}></div>
                    <div id="s21b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i21b", "C")} style={getStyle(estadoTornillo.i21b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i22b.statusPalatino ?
                  <>
                    <div id="s22b-a" style={getStyle(estadoTornillo.i22b.sangrado.sangradoA)}></div>
                    <div id="s22b-b" style={getStyle(estadoTornillo.i22b.sangrado.sangradoB)}></div>
                    <div id="s22b-c" style={getStyle(estadoTornillo.i22b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s22b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i22b", "A")} style={getStyle(estadoTornillo.i22b.sangrado.sangradoA)}></div>
                    <div id="s22b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i22b", "B")} style={getStyle(estadoTornillo.i22b.sangrado.sangradoB)}></div>
                    <div id="s22b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i22b", "C")} style={getStyle(estadoTornillo.i22b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i23b.statusPalatino ?
                  <>
                    <div id="s23b-a" style={getStyle(estadoTornillo.i23b.sangrado.sangradoA)}></div>
                    <div id="s23b-b" style={getStyle(estadoTornillo.i23b.sangrado.sangradoB)}></div>
                    <div id="s23b-c" style={getStyle(estadoTornillo.i23b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s23b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i23b", "A")} style={getStyle(estadoTornillo.i23b.sangrado.sangradoA)}></div>
                    <div id="s23b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i23b", "B")} style={getStyle(estadoTornillo.i23b.sangrado.sangradoB)}></div>
                    <div id="s23b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i23b", "C")} style={getStyle(estadoTornillo.i23b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i24b.statusPalatino ?
                  <>
                    <div id="s24b-a" style={getStyle(estadoTornillo.i24b.sangrado.sangradoA)}></div>
                    <div id="s24b-b" style={getStyle(estadoTornillo.i24b.sangrado.sangradoB)}></div>
                    <div id="s24b-c" style={getStyle(estadoTornillo.i24b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s24b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i24b", "A")} style={getStyle(estadoTornillo.i24b.sangrado.sangradoA)}></div>
                    <div id="s24b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i24b", "B")} style={getStyle(estadoTornillo.i24b.sangrado.sangradoB)}></div>
                    <div id="s24b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i24b", "C")} style={getStyle(estadoTornillo.i24b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i25b.statusPalatino ?
                  <>
                    <div id="s25b-a" style={getStyle(estadoTornillo.i25b.sangrado.sangradoA)}></div>
                    <div id="s25b-b" style={getStyle(estadoTornillo.i25b.sangrado.sangradoB)}></div>
                    <div id="s25b-c" style={getStyle(estadoTornillo.i25b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s25b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i25b", "A")} style={getStyle(estadoTornillo.i25b.sangrado.sangradoA)}></div>
                    <div id="s25b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i25b", "B")} style={getStyle(estadoTornillo.i25b.sangrado.sangradoB)}></div>
                    <div id="s25b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i25b", "C")} style={getStyle(estadoTornillo.i25b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i26b.statusPalatino ?
                  <>
                    <div id="s26b-a" style={getStyle(estadoTornillo.i26b.sangrado.sangradoA)}></div>
                    <div id="s26b-b" style={getStyle(estadoTornillo.i26b.sangrado.sangradoB)}></div>
                    <div id="s26b-c" style={getStyle(estadoTornillo.i26b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s26b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i26b", "A")} style={getStyle(estadoTornillo.i26b.sangrado.sangradoA)}></div>
                    <div id="s26b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i26b", "B")} style={getStyle(estadoTornillo.i26b.sangrado.sangradoB)}></div>
                    <div id="s26b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i26b", "C")} style={getStyle(estadoTornillo.i26b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i27b.statusPalatino ?
                  <>
                    <div id="s27b-a" style={getStyle(estadoTornillo.i27b.sangrado.sangradoA)}></div>
                    <div id="s27b-b" style={getStyle(estadoTornillo.i27b.sangrado.sangradoB)}></div>
                    <div id="s27b-c" style={getStyle(estadoTornillo.i27b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s27b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i27b", "A")} style={getStyle(estadoTornillo.i27b.sangrado.sangradoA)}></div>
                    <div id="s27b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i27b", "B")} style={getStyle(estadoTornillo.i27b.sangrado.sangradoB)}></div>
                    <div id="s27b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i27b", "C")} style={getStyle(estadoTornillo.i27b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i28b.statusPalatino ?
                  <>
                    <div id="s28b-a" style={getStyle(estadoTornillo.i28b.sangrado.sangradoA)}></div>
                    <div id="s28b-b" style={getStyle(estadoTornillo.i28b.sangrado.sangradoB)}></div>
                    <div id="s28b-c" style={getStyle(estadoTornillo.i28b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s28b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i28b", "A")} style={getStyle(estadoTornillo.i28b.sangrado.sangradoA)}></div>
                    <div id="s28b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i28b", "B")} style={getStyle(estadoTornillo.i28b.sangrado.sangradoB)}></div>
                    <div id="s28b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i28b", "C")} style={getStyle(estadoTornillo.i28b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
            </tr>

            <tr>
              <td className="titulo">Furca</td>
              <td className="borde">
                {estadoTornillo.i18b.statusPalatino ?
                  <>
                    <div id="f18b-a"></div>
                    <div id="f18b-b"></div>
                  </> :
                  <>
                    <div id="f18b-a" onClick={() => props.option.option != 2 && handleChangeFurca("i18b-a")}></div>
                    <div id="f18b-b" onClick={() => props.option.option != 2 && handleChangeFurca("i18b-b")}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i17b.statusPalatino ?
                  <>
                    <div id="f17b-a" onClick={() => props.option.option != 2 && handleChangeFurca("i17b-a")}></div>
                    <div id="f17b-b" onClick={() => props.option.option != 2 && handleChangeFurca("i17b-b")}></div>
                  </> :
                  <>
                    <div id="f17b-a" onClick={() => props.option.option != 2 && handleChangeFurca("i17b-a")}></div>
                    <div id="f17b-b" onClick={() => props.option.option != 2 && handleChangeFurca("i17b-b")}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i16b.statusPalatino ?
                  <>
                    <div id="f16b-a" ></div>
                    <div id="f16b-b" ></div>
                  </> :
                  <>
                    <div id="f16b-a" onClick={() => props.option.option != 2 && handleChangeFurca("i16b-a")}></div>
                    <div id="f16b-b" onClick={() => props.option.option != 2 && handleChangeFurca("i16b-b")}></div>
                  </>
                }
              </td>
              <td className="borde"></td>
              <td className="borde">
                {estadoTornillo.i14b.statusPalatino ?
                  <>
                    <div id="f14b-a" ></div>
                    <div id="f14b-b" ></div>
                  </> :
                  <>
                    <div id="f14b-a" onClick={() => props.option.option != 2 && handleChangeFurca("i14b-a")}></div>
                    <div id="f14b-b" onClick={() => props.option.option != 2 && handleChangeFurca("i14b-b")}></div>
                  </>
                }
              </td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>

              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde">
                {estadoTornillo.i24b.statusPalatino ?
                  <>
                    <div id="f24b-a" ></div>
                    <div id="f24b-b" ></div>
                  </> :
                  <>
                    <div id="f24b-a" onClick={() => props.option.option != 2 && handleChangeFurca("i24b-a")}></div>
                    <div id="f24b-b" onClick={() => props.option.option != 2 && handleChangeFurca("i24b-b")}></div>
                  </>
                }
              </td>
              <td className="borde"></td>
              <td className="borde">
                {estadoTornillo.i26b.statusPalatino ?
                  <>
                    <div id="f26b-a" ></div>
                    <div id="f26b-b" ></div>
                  </> :
                  <>
                    <div id="f26b-a" onClick={() => props.option.option != 2 && handleChangeFurca("i26b-a")}></div>
                    <div id="f26b-b" onClick={() => props.option.option != 2 && handleChangeFurca("i26b-b")}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i27b.statusPalatino ?
                  <>
                    <div id="f27b-a" ></div>
                    <div id="f27b-b" ></div>
                  </> :
                  <>
                    <div id="f27b-a" onClick={() => props.option.option != 2 && handleChangeFurca("i27b-a")}></div>
                    <div id="f27b-b" onClick={() => props.option.option != 2 && handleChangeFurca("i27b-b")}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i28b.statusPalatino ?
                  <>
                    <div id="f28b-a"></div>
                    <div id="f28b-b"></div>
                  </> :
                  <>
                    <div id="f28b-a" onClick={() => props.option.option != 2 && handleChangeFurca("i28b-a")}></div>
                    <div id="f28b-b" onClick={() => props.option.option != 2 && handleChangeFurca("i28b-b")}></div>
                  </>
                }
              </td>
            </tr>

          </tbody>
        </table>
      </div>

      <div className='tabla'>
        <table id="tabla-5">
          <tbody>
            <tr>
              <td className="titulo">Furca</td>
              <td className="borde">
                {estadoTornillo.i48.statusPalatino ?
                  <div id="f48"></div> :
                  <div id="f48" onClick={() => props.option.option != 2 && handleChangeFurca("i48")}></div>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i47.statusPalatino ?
                  <div id="f47"></div> :
                  <div id="f47" onClick={() => props.option.option != 2 && handleChangeFurca("i47")}></div>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i46.statusPalatino ?
                  <div id="f46"></div> :
                  <div id="f46" onClick={() => props.option.option != 2 && handleChangeFurca("i46")}></div>
                }
              </td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>

              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde">
                {estadoTornillo.i36.statusPalatino ?
                  <div id="f36"></div> :
                  <div id="f36" onClick={() => props.option.option != 2 && handleChangeFurca("i36")} ></div>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i37.statusPalatino ?
                  <div id="f37" ></div> :
                  <div id="f37" onClick={() => props.option.option != 2 && handleChangeFurca("i37")} ></div>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i38.statusPalatino ?
                  <div id="f38" ></div> :
                  <div id="f38" onClick={() => props.option.option != 2 && handleChangeFurca("i38")} ></div>
                }
              </td>
            </tr>

            <tr>
              <td className="titulo">Sangrado / Exudado</td>
              <td className="borde">
                {estadoTornillo.i48.statusPalatino ?
                  <>
                    <div id="s48-a" style={getStyle(estadoTornillo.i48.sangrado.sangradoA)}></div>
                    <div id="s48-b" style={getStyle(estadoTornillo.i48.sangrado.sangradoB)}></div>
                    <div id="s48-c" style={getStyle(estadoTornillo.i48.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s48-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i48", "A")} style={getStyle(estadoTornillo.i48.sangrado.sangradoA)}></div>
                    <div id="s48-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i48", "B")} style={getStyle(estadoTornillo.i48.sangrado.sangradoB)}></div>
                    <div id="s48-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i48", "C")} style={getStyle(estadoTornillo.i48.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i47.statusPalatino ?
                  <>
                    <div id="s47-a" style={getStyle(estadoTornillo.i47.sangrado.sangradoA)}></div>
                    <div id="s47-b" style={getStyle(estadoTornillo.i47.sangrado.sangradoB)}></div>
                    <div id="s47-c" style={getStyle(estadoTornillo.i47.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s47-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i47", "A")} style={getStyle(estadoTornillo.i47.sangrado.sangradoA)}></div>
                    <div id="s47-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i47", "B")} style={getStyle(estadoTornillo.i47.sangrado.sangradoB)}></div>
                    <div id="s47-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i47", "C")} style={getStyle(estadoTornillo.i47.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i46.statusPalatino ?
                  <>
                    <div id="s46-a" style={getStyle(estadoTornillo.i46.sangrado.sangradoA)}></div>
                    <div id="s46-b" style={getStyle(estadoTornillo.i46.sangrado.sangradoB)}></div>
                    <div id="s46-c" style={getStyle(estadoTornillo.i46.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s46-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i46", "A")} style={getStyle(estadoTornillo.i46.sangrado.sangradoA)}></div>
                    <div id="s46-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i46", "B")} style={getStyle(estadoTornillo.i46.sangrado.sangradoB)}></div>
                    <div id="s46-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i46", "C")} style={getStyle(estadoTornillo.i46.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i45.statusPalatino ?
                  <>
                    <div id="s45-a" style={getStyle(estadoTornillo.i45.sangrado.sangradoA)}></div>
                    <div id="s45-b" style={getStyle(estadoTornillo.i45.sangrado.sangradoB)}></div>
                    <div id="s45-c" style={getStyle(estadoTornillo.i45.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s45-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i45", "A")} style={getStyle(estadoTornillo.i45.sangrado.sangradoA)}></div>
                    <div id="s45-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i45", "B")} style={getStyle(estadoTornillo.i45.sangrado.sangradoB)}></div>
                    <div id="s45-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i45", "C")} style={getStyle(estadoTornillo.i45.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i44.statusPalatino ?
                  <>
                    <div id="s44-a" style={getStyle(estadoTornillo.i44.sangrado.sangradoA)}></div>
                    <div id="s44-b" style={getStyle(estadoTornillo.i44.sangrado.sangradoB)}></div>
                    <div id="s44-c" style={getStyle(estadoTornillo.i44.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s44-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i44", "A")} style={getStyle(estadoTornillo.i44.sangrado.sangradoA)}></div>
                    <div id="s44-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i44", "B")} style={getStyle(estadoTornillo.i44.sangrado.sangradoB)}></div>
                    <div id="s44-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i44", "C")} style={getStyle(estadoTornillo.i44.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i43.statusPalatino ?
                  <>
                    <div id="s43-a" style={getStyle(estadoTornillo.i43.sangrado.sangradoA)}></div>
                    <div id="s43-b" style={getStyle(estadoTornillo.i43.sangrado.sangradoB)}></div>
                    <div id="s43-c" style={getStyle(estadoTornillo.i43.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s43-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i43", "A")} style={getStyle(estadoTornillo.i43.sangrado.sangradoA)}></div>
                    <div id="s43-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i43", "B")} style={getStyle(estadoTornillo.i43.sangrado.sangradoB)}></div>
                    <div id="s43-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i43", "C")} style={getStyle(estadoTornillo.i43.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i42.statusPalatino ?
                  <>
                    <div id="s42-a" style={getStyle(estadoTornillo.i42.sangrado.sangradoA)}></div>
                    <div id="s42-b" style={getStyle(estadoTornillo.i42.sangrado.sangradoB)}></div>
                    <div id="s42-c" style={getStyle(estadoTornillo.i42.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s42-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i42", "A")} style={getStyle(estadoTornillo.i42.sangrado.sangradoA)}></div>
                    <div id="s42-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i42", "B")} style={getStyle(estadoTornillo.i42.sangrado.sangradoB)}></div>
                    <div id="s42-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i42", "C")} style={getStyle(estadoTornillo.i42.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i41.statusPalatino ?
                  <>
                    <div id="s41-a" style={getStyle(estadoTornillo.i41.sangrado.sangradoA)}></div>
                    <div id="s41-b" style={getStyle(estadoTornillo.i41.sangrado.sangradoB)}></div>
                    <div id="s41-c" style={getStyle(estadoTornillo.i41.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s41-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i41", "A")} style={getStyle(estadoTornillo.i41.sangrado.sangradoA)}></div>
                    <div id="s41-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i41", "B")} style={getStyle(estadoTornillo.i41.sangrado.sangradoB)}></div>
                    <div id="s41-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i41", "C")} style={getStyle(estadoTornillo.i41.sangrado.sangradoC)}></div>
                  </>
                }
              </td>

              <td className="borde">
                {estadoTornillo.i31.statusPalatino ?
                  <>
                    <div id="s31-a" style={getStyle(estadoTornillo.i31.sangrado.sangradoA)}></div>
                    <div id="s31-b" style={getStyle(estadoTornillo.i31.sangrado.sangradoB)}></div>
                    <div id="s31-c" style={getStyle(estadoTornillo.i31.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s31-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i31", "A")} style={getStyle(estadoTornillo.i31.sangrado.sangradoA)}></div>
                    <div id="s31-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i31", "B")} style={getStyle(estadoTornillo.i31.sangrado.sangradoB)}></div>
                    <div id="s31-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i31", "C")} style={getStyle(estadoTornillo.i31.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i32.statusPalatino ?
                  <>
                    <div id="s32-a" style={getStyle(estadoTornillo.i32.sangrado.sangradoA)}></div>
                    <div id="s32-b" style={getStyle(estadoTornillo.i32.sangrado.sangradoB)}></div>
                    <div id="s32-c" style={getStyle(estadoTornillo.i32.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s32-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i32", "A")} style={getStyle(estadoTornillo.i32.sangrado.sangradoA)}></div>
                    <div id="s32-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i32", "B")} style={getStyle(estadoTornillo.i32.sangrado.sangradoB)}></div>
                    <div id="s32-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i32", "C")} style={getStyle(estadoTornillo.i32.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i33.statusPalatino ?
                  <>
                    <div id="s33-a" style={getStyle(estadoTornillo.i33.sangrado.sangradoA)}></div>
                    <div id="s33-b" style={getStyle(estadoTornillo.i33.sangrado.sangradoB)}></div>
                    <div id="s33-c" style={getStyle(estadoTornillo.i33.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s33-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i33", "A")} style={getStyle(estadoTornillo.i33.sangrado.sangradoA)}></div>
                    <div id="s33-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i33", "B")} style={getStyle(estadoTornillo.i33.sangrado.sangradoB)}></div>
                    <div id="s33-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i33", "C")} style={getStyle(estadoTornillo.i33.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i34.statusPalatino ?
                  <>
                    <div id="s34-a" style={getStyle(estadoTornillo.i34.sangrado.sangradoA)}></div>
                    <div id="s34-b" style={getStyle(estadoTornillo.i34.sangrado.sangradoB)}></div>
                    <div id="s34-c" style={getStyle(estadoTornillo.i34.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s34-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i34", "A")} style={getStyle(estadoTornillo.i34.sangrado.sangradoA)}></div>
                    <div id="s34-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i34", "B")} style={getStyle(estadoTornillo.i34.sangrado.sangradoB)}></div>
                    <div id="s34-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i34", "C")} style={getStyle(estadoTornillo.i34.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i35.statusPalatino ?
                  <>
                    <div id="s35-a" style={getStyle(estadoTornillo.i35.sangrado.sangradoA)}></div>
                    <div id="s35-b" style={getStyle(estadoTornillo.i35.sangrado.sangradoB)}></div>
                    <div id="s35-c" style={getStyle(estadoTornillo.i35.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s35-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i35", "A")} style={getStyle(estadoTornillo.i35.sangrado.sangradoA)}></div>
                    <div id="s35-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i35", "B")} style={getStyle(estadoTornillo.i35.sangrado.sangradoB)}></div>
                    <div id="s35-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i35", "C")} style={getStyle(estadoTornillo.i35.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i36.statusPalatino ?
                  <>
                    <div id="s36-a" style={getStyle(estadoTornillo.i36.sangrado.sangradoA)}></div>
                    <div id="s36-b" style={getStyle(estadoTornillo.i36.sangrado.sangradoB)}></div>
                    <div id="s36-c" style={getStyle(estadoTornillo.i36.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s36-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i36", "A")} style={getStyle(estadoTornillo.i36.sangrado.sangradoA)}></div>
                    <div id="s36-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i36", "B")} style={getStyle(estadoTornillo.i36.sangrado.sangradoB)}></div>
                    <div id="s36-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i36", "C")} style={getStyle(estadoTornillo.i36.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i37.statusPalatino ?
                  <>
                    <div id="s37-a" style={getStyle(estadoTornillo.i37.sangrado.sangradoA)}></div>
                    <div id="s37-b" style={getStyle(estadoTornillo.i37.sangrado.sangradoB)}></div>
                    <div id="s37-c" style={getStyle(estadoTornillo.i37.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s37-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i37", "A")} style={getStyle(estadoTornillo.i37.sangrado.sangradoA)}></div>
                    <div id="s37-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i37", "B")} style={getStyle(estadoTornillo.i37.sangrado.sangradoB)}></div>
                    <div id="s37-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i37", "C")} style={getStyle(estadoTornillo.i37.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i38.statusPalatino ?
                  <>
                    <div id="s38-a" style={getStyle(estadoTornillo.i38.sangrado.sangradoA)}></div>
                    <div id="s38-b" style={getStyle(estadoTornillo.i38.sangrado.sangradoB)}></div>
                    <div id="s38-c" style={getStyle(estadoTornillo.i38.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s38-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i38", "A")} style={getStyle(estadoTornillo.i38.sangrado.sangradoA)}></div>
                    <div id="s38-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i38", "B")} style={getStyle(estadoTornillo.i38.sangrado.sangradoB)}></div>
                    <div id="s38-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i38", "C")} style={getStyle(estadoTornillo.i38.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
            </tr>

            <tr>
              <td className="titulo">Profundidad de sondaje</td>
              <td className="borde">
                <input type="text" id="ps48-a" name="ps48-a" value={estadoTornillo.i48.sondajeInput.sondajeInputA} tabIndex="345" disabled={props.option.option === 2 ? disable : estadoTornillo.i48.statusPalatino} onChange={(e) => handelChangeSondaje("i48", "A", e.target.value)} />
                <input type="text" id="ps48-b" name="ps48-b" value={estadoTornillo.i48.sondajeInput.sondajeInputB} tabIndex="346" disabled={props.option.option === 2 ? disable : estadoTornillo.i48.statusPalatino} onChange={(e) => handelChangeSondaje("i48", "B", e.target.value)} />
                <input type="text" id="ps48-c" name="ps48-c" value={estadoTornillo.i48.sondajeInput.sondajeInputC} tabIndex="347" disabled={props.option.option === 2 ? disable : estadoTornillo.i48.statusPalatino} onChange={(e) => handelChangeSondaje("i48", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps47-a" name="ps47-a" value={estadoTornillo.i47.sondajeInput.sondajeInputA} tabIndex="348" disabled={props.option.option === 2 ? disable : estadoTornillo.i47.statusPalatino} onChange={(e) => handelChangeSondaje("i47", "A", e.target.value)} />
                <input type="text" id="ps47-b" name="ps47-b" value={estadoTornillo.i47.sondajeInput.sondajeInputB} tabIndex="349" disabled={props.option.option === 2 ? disable : estadoTornillo.i47.statusPalatino} onChange={(e) => handelChangeSondaje("i47", "B", e.target.value)} />
                <input type="text" id="ps47-c" name="ps47-c" value={estadoTornillo.i47.sondajeInput.sondajeInputC} tabIndex="350" disabled={props.option.option === 2 ? disable : estadoTornillo.i47.statusPalatino} onChange={(e) => handelChangeSondaje("i47", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps46-a" name="ps46-a" value={estadoTornillo.i46.sondajeInput.sondajeInputA} tabIndex="351" disabled={props.option.option === 2 ? disable : estadoTornillo.i46.statusPalatino} onChange={(e) => handelChangeSondaje("i46", "A", e.target.value)} />
                <input type="text" id="ps46-b" name="ps46-b" value={estadoTornillo.i46.sondajeInput.sondajeInputB} tabIndex="352" disabled={props.option.option === 2 ? disable : estadoTornillo.i46.statusPalatino} onChange={(e) => handelChangeSondaje("i46", "B", e.target.value)} />
                <input type="text" id="ps46-c" name="ps46-c" value={estadoTornillo.i46.sondajeInput.sondajeInputC} tabIndex="353" disabled={props.option.option === 2 ? disable : estadoTornillo.i46.statusPalatino} onChange={(e) => handelChangeSondaje("i46", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps45-a" name="ps45-a" value={estadoTornillo.i45.sondajeInput.sondajeInputA} tabIndex="354" disabled={props.option.option === 2 ? disable : estadoTornillo.i45.statusPalatino} onChange={(e) => handelChangeSondaje("i45", "A", e.target.value)} />
                <input type="text" id="ps45-b" name="ps45-b" value={estadoTornillo.i45.sondajeInput.sondajeInputB} tabIndex="355" disabled={props.option.option === 2 ? disable : estadoTornillo.i45.statusPalatino} onChange={(e) => handelChangeSondaje("i45", "B", e.target.value)} />
                <input type="text" id="ps45-c" name="ps45-c" value={estadoTornillo.i45.sondajeInput.sondajeInputC} tabIndex="356" disabled={props.option.option === 2 ? disable : estadoTornillo.i45.statusPalatino} onChange={(e) => handelChangeSondaje("i45", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps44-a" name="ps44-a" value={estadoTornillo.i44.sondajeInput.sondajeInputA} tabIndex="357" disabled={props.option.option === 2 ? disable : estadoTornillo.i44.statusPalatino} onChange={(e) => handelChangeSondaje("i44", "A", e.target.value)} />
                <input type="text" id="ps44-b" name="ps44-b" value={estadoTornillo.i44.sondajeInput.sondajeInputB} tabIndex="358" disabled={props.option.option === 2 ? disable : estadoTornillo.i44.statusPalatino} onChange={(e) => handelChangeSondaje("i44", "B", e.target.value)} />
                <input type="text" id="ps44-c" name="ps44-c" value={estadoTornillo.i44.sondajeInput.sondajeInputC} tabIndex="359" disabled={props.option.option === 2 ? disable : estadoTornillo.i44.statusPalatino} onChange={(e) => handelChangeSondaje("i44", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps43-a" name="ps43-a" value={estadoTornillo.i43.sondajeInput.sondajeInputA} tabIndex="400" disabled={props.option.option === 2 ? disable : estadoTornillo.i43.statusPalatino} onChange={(e) => handelChangeSondaje("i43", "A", e.target.value)} />
                <input type="text" id="ps43-b" name="ps43-b" value={estadoTornillo.i43.sondajeInput.sondajeInputB} tabIndex="401" disabled={props.option.option === 2 ? disable : estadoTornillo.i43.statusPalatino} onChange={(e) => handelChangeSondaje("i43", "B", e.target.value)} />
                <input type="text" id="ps43-c" name="ps43-c" value={estadoTornillo.i43.sondajeInput.sondajeInputC} tabIndex="402" disabled={props.option.option === 2 ? disable : estadoTornillo.i43.statusPalatino} onChange={(e) => handelChangeSondaje("i43", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps42-a" name="ps42-a" value={estadoTornillo.i42.sondajeInput.sondajeInputA} tabIndex="403" disabled={props.option.option === 2 ? disable : estadoTornillo.i42.statusPalatino} onChange={(e) => handelChangeSondaje("i42", "A", e.target.value)} />
                <input type="text" id="ps42-b" name="ps42-b" value={estadoTornillo.i42.sondajeInput.sondajeInputB} tabIndex="404" disabled={props.option.option === 2 ? disable : estadoTornillo.i42.statusPalatino} onChange={(e) => handelChangeSondaje("i42", "B", e.target.value)} />
                <input type="text" id="ps42-c" name="ps42-c" value={estadoTornillo.i42.sondajeInput.sondajeInputC} tabIndex="405" disabled={props.option.option === 2 ? disable : estadoTornillo.i42.statusPalatino} onChange={(e) => handelChangeSondaje("i42", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps41-a" name="ps41-a" value={estadoTornillo.i41.sondajeInput.sondajeInputA} tabIndex="406" disabled={props.option.option === 2 ? disable : estadoTornillo.i41.statusPalatino} onChange={(e) => handelChangeSondaje("i41", "A", e.target.value)} />
                <input type="text" id="ps41-b" name="ps41-b" value={estadoTornillo.i41.sondajeInput.sondajeInputB} tabIndex="407" disabled={props.option.option === 2 ? disable : estadoTornillo.i41.statusPalatino} onChange={(e) => handelChangeSondaje("i41", "B", e.target.value)} />
                <input type="text" id="ps41-c" name="ps41-c" value={estadoTornillo.i41.sondajeInput.sondajeInputC} tabIndex="408" disabled={props.option.option === 2 ? disable : estadoTornillo.i41.statusPalatino} onChange={(e) => handelChangeSondaje("i41", "C", e.target.value)} />
              </td>

              <td className="borde">
                <input type="text" id="ps31-a" name="ps31-a" value={estadoTornillo.i31.sondajeInput.sondajeInputA} tabIndex="409" disabled={props.option.option === 2 ? disable : estadoTornillo.i31.statusPalatino} onChange={(e) => handelChangeSondaje("i31", "A", e.target.value)} />
                <input type="text" id="ps31-b" name="ps31-b" value={estadoTornillo.i31.sondajeInput.sondajeInputB} tabIndex="410" disabled={props.option.option === 2 ? disable : estadoTornillo.i31.statusPalatino} onChange={(e) => handelChangeSondaje("i31", "B", e.target.value)} />
                <input type="text" id="ps31-c" name="ps31-c" value={estadoTornillo.i31.sondajeInput.sondajeInputC} tabIndex="411" disabled={props.option.option === 2 ? disable : estadoTornillo.i31.statusPalatino} onChange={(e) => handelChangeSondaje("i31", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps32-a" name="ps32-a" value={estadoTornillo.i32.sondajeInput.sondajeInputA} tabIndex="412" disabled={props.option.option === 2 ? disable : estadoTornillo.i32.statusPalatino} onChange={(e) => handelChangeSondaje("i32", "A", e.target.value)} />
                <input type="text" id="ps32-b" name="ps32-b" value={estadoTornillo.i32.sondajeInput.sondajeInputB} tabIndex="413" disabled={props.option.option === 2 ? disable : estadoTornillo.i32.statusPalatino} onChange={(e) => handelChangeSondaje("i32", "B", e.target.value)} />
                <input type="text" id="ps32-c" name="ps32-c" value={estadoTornillo.i32.sondajeInput.sondajeInputC} tabIndex="414" disabled={props.option.option === 2 ? disable : estadoTornillo.i32.statusPalatino} onChange={(e) => handelChangeSondaje("i32", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps33-a" name="ps33-a" value={estadoTornillo.i33.sondajeInput.sondajeInputA} tabIndex="415" disabled={props.option.option === 2 ? disable : estadoTornillo.i33.statusPalatino} onChange={(e) => handelChangeSondaje("i33", "A", e.target.value)} />
                <input type="text" id="ps33-b" name="ps33-b" value={estadoTornillo.i33.sondajeInput.sondajeInputB} tabIndex="416" disabled={props.option.option === 2 ? disable : estadoTornillo.i33.statusPalatino} onChange={(e) => handelChangeSondaje("i33", "B", e.target.value)} />
                <input type="text" id="ps33-c" name="ps33-c" value={estadoTornillo.i33.sondajeInput.sondajeInputC} tabIndex="417" disabled={props.option.option === 2 ? disable : estadoTornillo.i33.statusPalatino} onChange={(e) => handelChangeSondaje("i33", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps34-a" name="ps34-a" value={estadoTornillo.i34.sondajeInput.sondajeInputA} tabIndex="418" disabled={props.option.option === 2 ? disable : estadoTornillo.i34.statusPalatino} onChange={(e) => handelChangeSondaje("i34", "A", e.target.value)} />
                <input type="text" id="ps34-b" name="ps34-b" value={estadoTornillo.i34.sondajeInput.sondajeInputB} tabIndex="419" disabled={props.option.option === 2 ? disable : estadoTornillo.i34.statusPalatino} onChange={(e) => handelChangeSondaje("i34", "B", e.target.value)} />
                <input type="text" id="ps34-c" name="ps34-c" value={estadoTornillo.i34.sondajeInput.sondajeInputC} tabIndex="420" disabled={props.option.option === 2 ? disable : estadoTornillo.i34.statusPalatino} onChange={(e) => handelChangeSondaje("i34", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps35-a" name="ps35-a" value={estadoTornillo.i35.sondajeInput.sondajeInputA} tabIndex="421" disabled={props.option.option === 2 ? disable : estadoTornillo.i35.statusPalatino} onChange={(e) => handelChangeSondaje("i35", "A", e.target.value)} />
                <input type="text" id="ps35-b" name="ps35-b" value={estadoTornillo.i35.sondajeInput.sondajeInputB} tabIndex="422" disabled={props.option.option === 2 ? disable : estadoTornillo.i35.statusPalatino} onChange={(e) => handelChangeSondaje("i35", "B", e.target.value)} />
                <input type="text" id="ps35-c" name="ps35-c" value={estadoTornillo.i35.sondajeInput.sondajeInputC} tabIndex="423" disabled={props.option.option === 2 ? disable : estadoTornillo.i35.statusPalatino} onChange={(e) => handelChangeSondaje("i35", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps36-a" name="ps36-a" value={estadoTornillo.i36.sondajeInput.sondajeInputA} tabIndex="424" disabled={props.option.option === 2 ? disable : estadoTornillo.i36.statusPalatino} onChange={(e) => handelChangeSondaje("i36", "A", e.target.value)} />
                <input type="text" id="ps36-b" name="ps36-b" value={estadoTornillo.i36.sondajeInput.sondajeInputB} tabIndex="425" disabled={props.option.option === 2 ? disable : estadoTornillo.i36.statusPalatino} onChange={(e) => handelChangeSondaje("i36", "B", e.target.value)} />
                <input type="text" id="ps36-c" name="ps36-c" value={estadoTornillo.i36.sondajeInput.sondajeInputC} tabIndex="426" disabled={props.option.option === 2 ? disable : estadoTornillo.i36.statusPalatino} onChange={(e) => handelChangeSondaje("i36", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps37-a" name="ps37-a" value={estadoTornillo.i37.sondajeInput.sondajeInputA} tabIndex="427" disabled={props.option.option === 2 ? disable : estadoTornillo.i37.statusPalatino} onChange={(e) => handelChangeSondaje("i37", "A", e.target.value)} />
                <input type="text" id="ps37-b" name="ps37-b" value={estadoTornillo.i37.sondajeInput.sondajeInputB} tabIndex="428" disabled={props.option.option === 2 ? disable : estadoTornillo.i37.statusPalatino} onChange={(e) => handelChangeSondaje("i37", "B", e.target.value)} />
                <input type="text" id="ps37-c" name="ps37-c" value={estadoTornillo.i37.sondajeInput.sondajeInputC} tabIndex="429" disabled={props.option.option === 2 ? disable : estadoTornillo.i37.statusPalatino} onChange={(e) => handelChangeSondaje("i37", "C", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps38-a" name="ps38-a" value={estadoTornillo.i38.sondajeInput.sondajeInputA} tabIndex="430" disabled={props.option.option === 2 ? disable : estadoTornillo.i38.statusPalatino} onChange={(e) => handelChangeSondaje("i38", "A", e.target.value)} />
                <input type="text" id="ps38-b" name="ps38-b" value={estadoTornillo.i38.sondajeInput.sondajeInputB} tabIndex="431" disabled={props.option.option === 2 ? disable : estadoTornillo.i38.statusPalatino} onChange={(e) => handelChangeSondaje("i38", "B", e.target.value)} />
                <input type="text" id="ps38-c" name="ps38-c" value={estadoTornillo.i38.sondajeInput.sondajeInputC} tabIndex="432" disabled={props.option.option === 2 ? disable : estadoTornillo.i38.statusPalatino} onChange={(e) => handelChangeSondaje("i38", "C", e.target.value)} />
              </td>
            </tr>

            <tr>
              <td className="titulo">Lingual</td>
              <td className="noborde">
                <div id="lineas-gr"></div>
                <div id="visualization48a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-10px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={43} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i48.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i48.statusPalatino === 1 &&
                  <div id="diente48-a" style={getStyleDiente(estadoTornillo.i48.statusPalatino, "48").vestivular}>
                    {
                      estadoTornillo['i48'].furca.furcaA === 0 && <div id="furca48"></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaA === 1 && <div id="furca48" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaA === 2 && <div id="furca48" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaA === 3 && <div id="furca48" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i48'].furca.furcaB === 0 && <div id="furca48"></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaB === 1 && <div id="furca48" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaB === 2 && <div id="furca48" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaB === 3 && <div id="furca48" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i48.statusPalatino === 2 &&
                  <div id="diente48-a" style={getStyleDiente(estadoTornillo.i48.statusPalatino, "48").vestivular}>
                    {
                      estadoTornillo['i48'].furca.furcaA === 0 && <div id="furca48"></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaA === 1 && <div id="furca48" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaA === 2 && <div id="furca48" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaA === 3 && <div id="furca48" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i48'].furca.furcaB === 0 && <div id="furca48"></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaB === 1 && <div id="furca48" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaB === 2 && <div id="furca48" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaB === 3 && <div id="furca48" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i48.statusPalatino === 0 &&
                  <div id="diente48-a">
                    {
                      estadoTornillo['i48'].furca.furcaA === 0 && <div id="furca48"></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaA === 1 && <div id="furca48" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaA === 2 && <div id="furca48" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaA === 3 && <div id="furca48" style={styleFurca1.furcaLleno}></div>
                    }

                    {
                      estadoTornillo['i48'].furca.furcaB === 0 && <div id="furca48"></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaB === 1 && <div id="furca48" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaB === 2 && <div id="furca48" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i48'].furca.furcaB === 3 && <div id="furca48" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization47a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-11px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={46} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i47.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i47.statusPalatino === 1 &&
                  <div id="diente47-a" style={getStyleDiente(estadoTornillo.i47.statusPalatino, "47").vestivular}>
                    {
                      estadoTornillo['i47'].furca.furcaA === 0 && <div id="furca47"></div>
                    }
                    {
                      estadoTornillo['i47'].furca.furcaA === 1 && <div id="furca47" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i47'].furca.furcaA === 2 && <div id="furca47" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i47'].furca.furcaA === 3 && <div id="furca47" style={styleFurca1.furcaLleno}></div>
                    }

                  </div>
                }

                {
                  estadoTornillo.i47.statusPalatino === 2 &&
                  <div id="diente47-a" style={getStyleDiente(estadoTornillo.i47.statusPalatino, "47").vestivular}>
                    {
                      estadoTornillo['i47'].furca.furcaA === 0 && <div id="furca47"></div>
                    }
                    {
                      estadoTornillo['i47'].furca.furcaA === 1 && <div id="furca47" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i47'].furca.furcaA === 2 && <div id="furca47" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i47'].furca.furcaA === 3 && <div id="furca47" style={styleFurca1.furcaLleno}></div>
                    }

                  </div>
                }
                {
                  estadoTornillo.i47.statusPalatino === 0 &&
                  <div id="diente47-a">
                    {
                      estadoTornillo['i47'].furca.furcaA === 0 && <div id="furca47"></div>
                    }
                    {
                      estadoTornillo['i47'].furca.furcaA === 1 && <div id="furca47" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i47'].furca.furcaA === 2 && <div id="furca47" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i47'].furca.furcaA === 3 && <div id="furca47" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization46a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-12px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i46.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i46.statusPalatino === 1 &&
                  <div id="diente46-a" style={getStyleDiente(estadoTornillo.i46.statusPalatino, "46").vestivular}>
                    {
                      estadoTornillo['i46'].furca.furcaA === 0 && <div id="furca46"></div>
                    }
                    {
                      estadoTornillo['i46'].furca.furcaA === 1 && <div id="furca46" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i46'].furca.furcaA === 2 && <div id="furca46" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i46'].furca.furcaA === 3 && <div id="furca46" style={styleFurca1.furcaLleno}></div>
                    }

                  </div>
                }
                {
                  estadoTornillo.i46.statusPalatino === 2 &&
                  <div id="diente46-a" style={getStyleDiente(estadoTornillo.i46.statusPalatino, "46").vestivular}>
                    {
                      estadoTornillo['i46'].furca.furcaA === 0 && <div id="furca46"></div>
                    }
                    {
                      estadoTornillo['i46'].furca.furcaA === 1 && <div id="furca46" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i46'].furca.furcaA === 2 && <div id="furca46" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i46'].furca.furcaA === 3 && <div id="furca46" style={styleFurca1.furcaLleno}></div>
                    }

                  </div>
                }
                {estadoTornillo.i46.statusPalatino === 0 &&
                  <div id="diente46-a">
                    {
                      estadoTornillo['i46'].furca.furcaA === 0 && <div id="furca46"></div>
                    }
                    {
                      estadoTornillo['i46'].furca.furcaA === 1 && <div id="furca46" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i46'].furca.furcaA === 2 && <div id="furca46" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i46'].furca.furcaA === 3 && <div id="furca46" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization45a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-12px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i45.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i45.statusPalatino === 1 && <div id="diente45-a" style={getStyleDiente(estadoTornillo.i45.statusPalatino, "45").vestivular}></div>
                }
                {
                  estadoTornillo.i45.statusPalatino === 2 && <div id="diente45-a" style={getStyleDiente(estadoTornillo.i45.statusPalatino, "45").vestivular}></div>
                }
                {
                  estadoTornillo.i45.statusPalatino === 0 && <div id="diente45-a" style={getStyleDiente(estadoTornillo.i45.statusPalatino, "45").vestivular}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization44a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-12px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i44.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i44.statusPalatino === 1 && <div id="diente44-a" style={getStyleDiente(estadoTornillo.i44.statusPalatino, "44").vestivular}></div>
                }
                {
                  estadoTornillo.i44.statusPalatino === 2 && <div id="diente44-a" style={getStyleDiente(estadoTornillo.i44.statusPalatino, "44").vestivular}></div>
                }
                {
                  estadoTornillo.i44.statusPalatino === 0 && <div id="diente44-a" style={getStyleDiente(estadoTornillo.i44.statusPalatino, "44").vestivular}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization43a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-15px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i43.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i43.statusPalatino === 1 && <div id="diente43-a" style={getStyleDiente(estadoTornillo.i43.statusPalatino, "43").vestivular}></div>
                }
                {
                  estadoTornillo.i43.statusPalatino === 2 && <div id="diente43-a" style={getStyleDiente(estadoTornillo.i43.statusPalatino, "43").vestivular}></div>
                }
                {
                  estadoTornillo.i43.statusPalatino === 0 && <div id="diente43-a" style={getStyleDiente(estadoTornillo.i43.statusPalatino, "43").vestivular}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization42a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-15px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i42.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i42.statusPalatino === 1 && <div id="diente42-a" style={getStyleDiente(estadoTornillo.i42.statusPalatino, "42").vestivular}></div>
                }
                {
                  estadoTornillo.i42.statusPalatino === 2 && <div id="diente42-a" style={getStyleDiente(estadoTornillo.i42.statusPalatino, "42").vestivular}></div>
                }
                {
                  estadoTornillo.i42.statusPalatino === 0 && <div id="diente42-a" style={getStyleDiente(estadoTornillo.i42.statusPalatino, "42").vestivular}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization41a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-15px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i41.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i41.statusPalatino === 1 && <div id="diente41-a" style={getStyleDiente(estadoTornillo.i41.statusPalatino, "41").vestivular}></div>
                }
                {
                  estadoTornillo.i41.statusPalatino === 2 && <div id="diente41-a" style={getStyleDiente(estadoTornillo.i41.statusPalatino, "41").vestivular}></div>
                }
                {
                  estadoTornillo.i41.statusPalatino === 0 && <div id="diente41-a" style={getStyleDiente(estadoTornillo.i41.statusPalatino, "41").vestivular}></div>
                }
              </td>

              <td className="noborde">
                <div id="lineas-gr"></div>
                <div id="visualization31a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-15px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i31.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i31.statusPalatino === 1 && <div id="diente31-a" style={getStyleDiente(estadoTornillo.i31.statusPalatino, "31").vestivular}></div>
                }
                {
                  estadoTornillo.i31.statusPalatino === 2 && <div id="diente31-a" style={getStyleDiente(estadoTornillo.i31.statusPalatino, "31").vestivular}></div>
                }
                {
                  estadoTornillo.i31.statusPalatino === 0 && <div id="diente31-a" style={getStyleDiente(estadoTornillo.i31.statusPalatino, "31").vestivular}></div>
                }
              </td>
              <td className="noborde">
                <div id="visualization32a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-15px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i32.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i32.statusPalatino === 1 && <div id="diente32-a" style={getStyleDiente(estadoTornillo.i32.statusPalatino, "32").vestivular}></div>
                }
                {
                  estadoTornillo.i32.statusPalatino === 2 && <div id="diente32-a" style={getStyleDiente(estadoTornillo.i32.statusPalatino, "32").vestivular}></div>
                }
                {
                  estadoTornillo.i32.statusPalatino === 0 && <div id="diente32-a" style={getStyleDiente(estadoTornillo.i32.statusPalatino, "32").vestivular}></div>
                }
              </td>
              <td className="noborde">
                <div id="visualization33a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-12px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i33.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i33.statusPalatino === 1 && <div id="diente33-a" style={getStyleDiente(estadoTornillo.i33.statusPalatino, "33").vestivular}></div>
                }
                {
                  estadoTornillo.i33.statusPalatino === 2 && <div id="diente33-a" style={getStyleDiente(estadoTornillo.i33.statusPalatino, "33").vestivular}></div>
                }
                {
                  estadoTornillo.i33.statusPalatino === 0 && <div id="diente33-a" style={getStyleDiente(estadoTornillo.i33.statusPalatino, "33").vestivular}></div>
                }
              </td>
              <td className="noborde">
                <div id="visualization34a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-15px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i34.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i34.statusPalatino === 1 && <div id="diente34-a" style={getStyleDiente(estadoTornillo.i34.statusPalatino, "34").vestivular}></div>
                }
                {
                  estadoTornillo.i34.statusPalatino === 2 && <div id="diente34-a" style={getStyleDiente(estadoTornillo.i34.statusPalatino, "34").vestivular}></div>
                }
                {
                  estadoTornillo.i34.statusPalatino === 0 && <div id="diente34-a" style={getStyleDiente(estadoTornillo.i34.statusPalatino, "34").vestivular}></div>
                }
              </td>
              <td className="noborde">
                <div id="visualization35a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-10px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i35.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i35.statusPalatino === 1 && <div id="diente35-a" style={getStyleDiente(estadoTornillo.i35.statusPalatino, "35").vestivular}></div>
                }
                {
                  estadoTornillo.i35.statusPalatino === 2 && <div id="diente35-a" style={getStyleDiente(estadoTornillo.i35.statusPalatino, "35").vestivular}></div>
                }
                {
                  estadoTornillo.i35.statusPalatino === 0 && <div id="diente35-a" style={getStyleDiente(estadoTornillo.i35.statusPalatino, "35").vestivular}></div>
                }
              </td>
              <td className="noborde">
                <div id="visualization36a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-7px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i36.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {estadoTornillo.i36.statusPalatino === 1 &&
                  <div id="diente36-a" style={getStyleDiente(estadoTornillo.i36.statusPalatino, "36").vestivular} >
                    {
                      estadoTornillo['i36'].furca.furcaA === 0 && <div id="furca36"></div>
                    }
                    {
                      estadoTornillo['i36'].furca.furcaA === 1 && <div id="furca36" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i36'].furca.furcaA === 2 && <div id="furca36" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i36'].furca.furcaA === 3 && <div id="furca36" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i36.statusPalatino === 2 &&
                  <div id="diente36-a" style={getStyleDiente(estadoTornillo.i36.statusPalatino, "36").vestivular} >
                    {
                      estadoTornillo['i36'].furca.furcaA === 0 && <div id="furca36"></div>
                    }
                    {
                      estadoTornillo['i36'].furca.furcaA === 1 && <div id="furca36" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i36'].furca.furcaA === 2 && <div id="furca36" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i36'].furca.furcaA === 3 && <div id="furca36" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i36.statusPalatino === 0 &&
                  <div id="diente36-a" style={getStyleDiente(estadoTornillo.i36.statusPalatino, "36").vestivular} >
                    {
                      estadoTornillo['i36'].furca.furcaA === 0 && <div id="furca36"></div>
                    }
                    {
                      estadoTornillo['i36'].furca.furcaA === 1 && <div id="furca36" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i36'].furca.furcaA === 2 && <div id="furca36" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i36'].furca.furcaA === 3 && <div id="furca36" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>
              <td className="noborde">
                <div id="visualization37a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-10px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={42} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i37.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {estadoTornillo.i37.statusPalatino === 1 &&
                  <div id="diente37-a" style={getStyleDiente(estadoTornillo.i37.statusPalatino, "37").vestivular} >
                    {
                      estadoTornillo['i37'].furca.furcaA === 0 && <div id="furca37"></div>
                    }
                    {
                      estadoTornillo['i37'].furca.furcaA === 1 && <div id="furca37" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i37'].furca.furcaA === 2 && <div id="furca37" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i37'].furca.furcaA === 3 && <div id="furca37" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i37.statusPalatino === 2 &&
                  <div id="diente37-a" style={getStyleDiente(estadoTornillo.i37.statusPalatino, "37").vestivular} >
                    {
                      estadoTornillo['i37'].furca.furcaA === 0 && <div id="furca37"></div>
                    }
                    {
                      estadoTornillo['i37'].furca.furcaA === 1 && <div id="furca37" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i37'].furca.furcaA === 2 && <div id="furca37" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i37'].furca.furcaA === 3 && <div id="furca37" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i37.statusPalatino === 0 &&
                  <div id="diente37-a">
                    {
                      estadoTornillo['i37'].furca.furcaA === 0 && <div id="furca37"></div>
                    }
                    {
                      estadoTornillo['i37'].furca.furcaA === 1 && <div id="furca37" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i37'].furca.furcaA === 2 && <div id="furca37" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i37'].furca.furcaA === 3 && <div id="furca37" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>
              <td className="noborde">
                <div id="visualization38a">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-9px", top: "0px", width: "100%", height: "100%" }}>
                      <LineChart width={42} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i38.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {estadoTornillo.i38.statusPalatino === 1 &&
                  <div id="diente38-a" style={getStyleDiente(estadoTornillo.i38.statusPalatino, "38").vestivular} >
                    {
                      estadoTornillo['i38'].furca.furcaA === 0 && <div id="furca38"></div>
                    }
                    {
                      estadoTornillo['i38'].furca.furcaA === 1 && <div id="furca38" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i38'].furca.furcaA === 2 && <div id="furca38" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i38'].furca.furcaA === 3 && <div id="furca38" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i38.statusPalatino === 2 &&
                  <div id="diente38-a" style={getStyleDiente(estadoTornillo.i38.statusPalatino, "38").vestivular} >
                    {
                      estadoTornillo['i38'].furca.furcaA === 0 && <div id="furca38"></div>
                    }
                    {
                      estadoTornillo['i38'].furca.furcaA === 1 && <div id="furca38" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i38'].furca.furcaA === 2 && <div id="furca38" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i38'].furca.furcaA === 3 && <div id="furca38" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i38.statusPalatino === 0 &&
                  <div id="diente38-a">
                    {
                      estadoTornillo['i38'].furca.furcaA === 0 && <div id="furca38"></div>
                    }
                    {
                      estadoTornillo['i38'].furca.furcaA === 1 && <div id="furca38" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo['i38'].furca.furcaA === 2 && <div id="furca38" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo['i38'].furca.furcaA === 3 && <div id="furca38" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>
            </tr>
          </tbody>
        </table>
      </div>


      <div className='tabla'>
        <table id="tabla-7">
          <tbody>
            <tr>
              <td className="titulo">Vestibular</td>
              <td className="noborde">
                <div id="lineas-gr-inf"></div>
                <div id="visualization48b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-13px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i48b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i48b.statusVestibular === 1 &&
                  <div id="diente48b-a" style={getStyleDiente(estadoTornillo.i48b.statusPalatino, "48").palatino} >
                    {
                      estadoTornillo.i48b.furca.furcaA === 0 && <div id="furca48b"></div>
                    }
                    {
                      estadoTornillo.i48b.furca.furcaA === 1 && <div id="furca48b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i48b.furca.furcaA === 2 && <div id="furca48b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i48b.furca.furcaA === 3 && <div id="furca48b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i48b.statusVestibular === 2 &&
                  <div id="diente48b-a" style={getStyleDiente(estadoTornillo.i48b.statusPalatino, "48").palatino} >
                    {
                      estadoTornillo.i48b.furca.furcaA === 0 && <div id="furca48b"></div>
                    }
                    {
                      estadoTornillo.i48b.furca.furcaA === 1 && <div id="furca48b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i48b.furca.furcaA === 2 && <div id="furca48b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i48b.furca.furcaA === 3 && <div id="furca48b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i48b.statusVestibular === 0 &&
                  <div id="diente48b-a" style={getStyleDiente(estadoTornillo.i48b.statusPalatino, "48").palatino} >
                    {
                      estadoTornillo.i48b.furca.furcaA === 0 && <div id="furca48b"></div>
                    }
                    {
                      estadoTornillo.i48b.furca.furcaA === 1 && <div id="furca48b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i48b.furca.furcaA === 2 && <div id="furca48b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i48b.furca.furcaA === 3 && <div id="furca48b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization47b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-16px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i47b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i47b.statusVestibular === 1 &&
                  <div id="diente47b-a" style={getStyleDiente(estadoTornillo.i47b.statusPalatino, "47").palatino} >
                    {
                      estadoTornillo.i47b.furca.furcaA === 0 && <div id="furca47b"></div>
                    }
                    {
                      estadoTornillo.i47b.furca.furcaA === 1 && <div id="furca47b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i47b.furca.furcaA === 2 && <div id="furca47b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i47b.furca.furcaA === 3 && <div id="furca47b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i47b.statusVestibular === 2 &&
                  <div id="diente47b-a" style={getStyleDiente(estadoTornillo.i47b.statusPalatino, "47").palatino} >
                    {
                      estadoTornillo.i47b.furca.furcaA === 0 && <div id="furca47b"></div>
                    }
                    {
                      estadoTornillo.i47b.furca.furcaA === 1 && <div id="furca47b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i47b.furca.furcaA === 2 && <div id="furca47b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i47b.furca.furcaA === 3 && <div id="furca47b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i47b.statusVestibular === 0 &&
                  <div id="diente47b-a"  >
                    {
                      estadoTornillo.i47b.furca.furcaA === 0 && <div id="furca47b"></div>
                    }
                    {
                      estadoTornillo.i47b.furca.furcaA === 1 && <div id="furca47b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i47b.furca.furcaA === 2 && <div id="furca47b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i47b.furca.furcaA === 3 && <div id="furca47b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization46b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-19px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i46b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i46b.statusVestibular === 1 &&
                  <div id="diente46b-a" style={getStyleDiente(estadoTornillo.i46b.statusPalatino, "46").palatino} >
                    {
                      estadoTornillo.i46b.furca.furcaA === 0 && <div id="furca46b"></div>
                    }
                    {
                      estadoTornillo.i46b.furca.furcaA === 1 && <div id="furca46b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i46b.furca.furcaA === 2 && <div id="furca46b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i46b.furca.furcaA === 3 && <div id="furca46b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i46b.statusVestibular === 2 &&
                  <div id="diente46b-a" style={getStyleDiente(estadoTornillo.i46b.statusPalatino, "46").palatino} >
                    {
                      estadoTornillo.i46b.furca.furcaA === 0 && <div id="furca46b"></div>
                    }
                    {
                      estadoTornillo.i46b.furca.furcaA === 1 && <div id="furca46b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i46b.furca.furcaA === 2 && <div id="furca46b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i46b.furca.furcaA === 3 && <div id="furca46b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i46b.statusVestibular === 0 &&
                  <div id="diente46b-a"  >
                    {
                      estadoTornillo.i46b.furca.furcaA === 0 && <div id="furca46b"></div>
                    }
                    {
                      estadoTornillo.i46b.furca.furcaA === 1 && <div id="furca46b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i46b.furca.furcaA === 2 && <div id="furca46b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i46b.furca.furcaA === 3 && <div id="furca46b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization45b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-21px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i45b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i45b.statusPalatino === 1 && <div id="diente45b-a" style={getStyleDiente(estadoTornillo.i45b.statusPalatino, "45").palatino}></div>
                }
                {
                  estadoTornillo.i45b.statusPalatino === 2 && <div id="diente45b-a" style={getStyleDiente(estadoTornillo.i45b.statusPalatino, "45").palatino}></div>
                }
                {
                  estadoTornillo.i45b.statusPalatino === 0 && <div id="diente45b-a" style={getStyleDiente(estadoTornillo.i45b.statusPalatino, "45").palatino}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization44b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-21px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i44b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i44b.statusPalatino === 1 && <div id="diente44b-a" style={getStyleDiente(estadoTornillo.i44b.statusPalatino, "44").palatino}></div>
                }
                {
                  estadoTornillo.i44b.statusPalatino === 2 && <div id="diente44b-a" style={getStyleDiente(estadoTornillo.i44b.statusPalatino, "44").palatino}></div>
                }
                {
                  estadoTornillo.i44b.statusPalatino === 0 && <div id="diente44b-a" style={getStyleDiente(estadoTornillo.i44b.statusPalatino, "44").palatino}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization43b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-22px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i43b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i43b.statusPalatino === 1 && <div id="diente43b-a" style={getStyleDiente(estadoTornillo.i43b.statusPalatino, "43").palatino}></div>
                }
                {
                  estadoTornillo.i43b.statusPalatino === 2 && <div id="diente43b-a" style={getStyleDiente(estadoTornillo.i43b.statusPalatino, "43").palatino}></div>
                }
                {
                  estadoTornillo.i43b.statusPalatino === 0 && <div id="diente43b-a" style={getStyleDiente(estadoTornillo.i43b.statusPalatino, "43").palatino}></div>
                }
              </td>
              <td className="noborde">
                <div id="visualization42b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-22px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i42b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i42b.statusPalatino === 1 && <div id="diente42b-a" style={getStyleDiente(estadoTornillo.i42b.statusPalatino, "42").palatino}></div>
                }
                {
                  estadoTornillo.i42b.statusPalatino === 2 && <div id="diente42b-a" style={getStyleDiente(estadoTornillo.i42b.statusPalatino, "42").palatino}></div>
                }
                {
                  estadoTornillo.i42b.statusPalatino === 0 && <div id="diente42b-a" style={getStyleDiente(estadoTornillo.i42b.statusPalatino, "42").palatino}></div>
                }
              </td>
              <td className="noborde">
                <div id="visualization41b">
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-22px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i41b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i41b.statusPalatino === 1 && <div id="diente41b-a" style={getStyleDiente(estadoTornillo.i41b.statusPalatino, "41").palatino}></div>
                }
                {
                  estadoTornillo.i41b.statusPalatino === 2 && <div id="diente41b-a" style={getStyleDiente(estadoTornillo.i41b.statusPalatino, "41").palatino}></div>
                }
                {
                  estadoTornillo.i41b.statusPalatino === 0 && <div id="diente41b-a" style={getStyleDiente(estadoTornillo.i41b.statusPalatino, "41").palatino}></div>
                }
              </td>

              <td className="noborde">
                <div id="lineas-gr-inf"></div>
                <div id="visualization31b" style={{ width: "23px", height: "160px", position: "absolute", margin: "0 0 0 7px" }}>
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-20px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i31b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>

                </div>
                {
                  estadoTornillo.i31b.statusPalatino === 1 && <div id="diente31b-a" style={getStyleDiente(estadoTornillo.i31b.statusPalatino, "31").palatino}></div>
                }
                {
                  estadoTornillo.i31b.statusPalatino === 2 && <div id="diente31b-a" style={getStyleDiente(estadoTornillo.i31b.statusPalatino, "31").palatino}></div>
                }
                {
                  estadoTornillo.i31b.statusPalatino === 0 && <div id="diente31b-a" style={getStyleDiente(estadoTornillo.i31b.statusPalatino, "31").palatino}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization32b" style={{ width: "22px", height: "160px", position: "absolute", margin: "0 0 0 7px" }}>
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-20px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i32b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i32b.statusPalatino === 1 && <div id="diente32b-a" style={getStyleDiente(estadoTornillo.i32b.statusPalatino, "32").palatino}></div>
                }
                {
                  estadoTornillo.i32b.statusPalatino === 2 && <div id="diente32b-a" style={getStyleDiente(estadoTornillo.i32b.statusPalatino, "32").palatino}></div>
                }
                {
                  estadoTornillo.i32b.statusPalatino === 0 && <div id="diente32b-a" style={getStyleDiente(estadoTornillo.i32b.statusPalatino, "32").palatino}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization33b" style={{ width: "25px", height: "160px", position: "absolute", margin: "0 0 0 8px" }}>
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-20px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i33b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i33b.statusPalatino === 1 && <div id="diente33b-a" style={getStyleDiente(estadoTornillo.i33b.statusPalatino, "33").palatino}></div>
                }
                {
                  estadoTornillo.i33b.statusPalatino === 2 && <div id="diente33b-a" style={getStyleDiente(estadoTornillo.i33b.statusPalatino, "33").palatino}></div>
                }
                {
                  estadoTornillo.i33b.statusPalatino === 0 && <div id="diente33b-a" style={getStyleDiente(estadoTornillo.i33b.statusPalatino, "33").palatino}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization34b" style={{ width: "22px", height: "160px", position: "absolute", margin: "0 0 0 10px" }}>
                  <div dir="ltr" style={{ position: "relative", width: "47px", height: "153px" }}>
                    <div style={{ position: "absolute", left: "-20px", top: "-18px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                      <LineChart width={40} height={78}
                        data={[
                          // { name: '', uv: 0,  },
                          ...estadoTornillo.i34b.encia
                          //{ name: '', uv: 0,  },
                        ]}
                      >
                        {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                        <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                           <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                        <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                      </LineChart>
                    </div>
                  </div>
                </div>
                {
                  estadoTornillo.i34.statusPalatino === 1 && <div id="diente34b-a" style={getStyleDiente(estadoTornillo.i34b.statusPalatino, "34").palatino}></div>
                }
                {
                  estadoTornillo.i34.statusPalatino === 2 && <div id="diente34b-a" style={getStyleDiente(estadoTornillo.i34b.statusPalatino, "34").palatino}></div>
                }
                {
                  estadoTornillo.i34.statusPalatino === 0 && <div id="diente34b-a" style={getStyleDiente(estadoTornillo.i34b.statusPalatino, "34").palatino}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization35b" style={{ width: "25px", height: "160px", position: "absolute", margin: "0 0 0 8px" }}>
                  <div style={{ position: "absolute", left: "3px", top: "-25px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                    <LineChart width={40} height={78}
                      data={[
                        // { name: '', uv: 0,  },
                        ...estadoTornillo.i35b.encia
                        //{ name: '', uv: 0,  },
                      ]}
                    >
                      {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                      <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                         <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                      <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                    </LineChart>
                  </div>
                </div>
                {
                  estadoTornillo.i35b.statusPalatino === 1 && <div id="diente35b-a" style={getStyleDiente(estadoTornillo.i35b.statusPalatino, "35").palatino}></div>
                }
                {
                  estadoTornillo.i35b.statusPalatino === 2 && <div id="diente35b-a" style={getStyleDiente(estadoTornillo.i35b.statusPalatino, "35").palatino}></div>
                }
                {
                  estadoTornillo.i35b.statusPalatino === 0 && <div id="diente35b-a" style={getStyleDiente(estadoTornillo.i35b.statusPalatino, "35").palatino}></div>
                }
              </td>

              <td className="noborde">
                <div id="visualization36b" style={{ width: "50px", height: "160px", position: "absolute", margin: "0 0 0 8px" }}>
                  <div style={{ position: "absolute", left: "-18px", top: "-25px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                    <LineChart width={40} height={78}
                      data={[
                        // { name: '', uv: 0,  },
                        ...estadoTornillo.i36b.encia
                        //{ name: '', uv: 0,  },
                      ]}
                    >
                      {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                      <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                         <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                      <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                    </LineChart>
                  </div>
                </div>
                {
                  estadoTornillo.i36b.statusVestibular === 1 &&
                  <div id="diente36b-a" style={getStyleDiente(estadoTornillo.i36b.statusPalatino, "36").palatino}>
                    {
                      estadoTornillo.i36b.furca.furcaA === 0 && <div id="furca36b"></div>
                    }
                    {
                      estadoTornillo.i36b.furca.furcaA === 1 && <div id="furca36b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i36b.furca.furcaA === 2 && <div id="furca36b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i36b.furca.furcaA === 3 && <div id="furca36b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {
                  estadoTornillo.i36b.statusVestibular === 2 &&
                  <div id="diente36b-a" style={getStyleDiente(estadoTornillo.i36b.statusPalatino, "36").palatino}>
                    {
                      estadoTornillo.i36b.furca.furcaA === 0 && <div id="furca36b"></div>
                    }
                    {
                      estadoTornillo.i36b.furca.furcaA === 1 && <div id="furca36b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i36b.furca.furcaA === 2 && <div id="furca36b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i36b.furca.furcaA === 3 && <div id="furca36b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i36b.statusVestibular === 0 &&
                  <div id="diente36b-a">
                    {
                      estadoTornillo.i36b.furca.furcaA === 0 && <div id="furca36b"></div>
                    }
                    {
                      estadoTornillo.i36b.furca.furcaA === 1 && <div id="furca36b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i36b.furca.furcaA === 2 && <div id="furca36b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i36b.furca.furcaA === 3 && <div id="furca36b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization37b" style={{ width: "47px", height: "160px", position: "absolute", margin: "0 0 0 8px" }}>
                  <div style={{ position: "absolute", left: "-16px", top: "-25px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                    <LineChart width={40} height={78}
                      data={[
                        // { name: '', uv: 0,  },
                        ...estadoTornillo.i37b.encia
                        //{ name: '', uv: 0,  },
                      ]}
                    >
                      {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                      <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                         <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                      <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                    </LineChart>
                  </div>
                </div>
                {
                  estadoTornillo.i37b.statusVestibular === 1 &&
                  <div id="diente37b-a" style={getStyleDiente(estadoTornillo.i37b.statusPalatino, "37").palatino}>
                    {
                      estadoTornillo.i37b.furca.furcaA === 0 && <div id="furca37b"></div>
                    }
                    {
                      estadoTornillo.i37b.furca.furcaA === 1 && <div id="furca37b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i37b.furca.furcaA === 2 && <div id="furca37b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i37b.furca.furcaA === 3 && <div id="furca37b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }

                {
                  estadoTornillo.i37b.statusVestibular === 2 &&
                  <div id="diente37b-a" style={getStyleDiente(estadoTornillo.i37b.statusPalatino, "37").palatino}>
                    {
                      estadoTornillo.i37b.furca.furcaA === 0 && <div id="furca37b"></div>
                    }
                    {
                      estadoTornillo.i37b.furca.furcaA === 1 && <div id="furca37b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i37b.furca.furcaA === 2 && <div id="furca37b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i37b.furca.furcaA === 3 && <div id="furca37b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }

                {estadoTornillo.i37b.statusVestibular === 0 &&
                  <div id="diente37b-a">
                    {
                      estadoTornillo.i37b.furca.furcaA === 0 && <div id="furca37b"></div>
                    }
                    {
                      estadoTornillo.i37b.furca.furcaA === 1 && <div id="furca37b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i37b.furca.furcaA === 2 && <div id="furca37b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i37b.furca.furcaA === 3 && <div id="furca37b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>

              <td className="noborde">
                <div id="visualization38b" style={{ width: "47px", height: "160px", position: "absolute", margin: "0 0 0 8px" }}>
                  <div style={{ position: "absolute", left: "-14px", top: "-25px", width: "100%", height: "100%", transform: "rotate(180deg)" }}>
                    <LineChart width={40} height={78}
                      data={[
                        // { name: '', uv: 0,  },
                        ...estadoTornillo.i38b.encia
                        //{ name: '', uv: 0,  },
                      ]}
                    >
                      {/* <YAxis ticks={[0, 1, 2, 3, 4, 5, 6]} domain={[0, 6]} />  */}
                      <Line type="monotone" dot={false} dataKey="nulo" stroke="rgb(255 255 255 / 0%)" fill="rgb(255 255 255 / 0%)" />
                         <Line type="monotone" dataKey="sondaje" dot={false} strokeDasharray="5 5" stroke="blue" />
                      <Line type="monotone" dot={false} dataKey="encia" stroke="red" fill="red" />
                    </LineChart>
                  </div>
                </div>
                {estadoTornillo.i38b.statusVestibular === 1 &&
                  <div id="diente38b-a" style={getStyleDiente(estadoTornillo.i38b.statusPalatino, "38").palatino}>
                    {
                      estadoTornillo.i38b.furca.furcaA === 0 && <div id="furca38b"></div>
                    }
                    {
                      estadoTornillo.i38b.furca.furcaA === 1 && <div id="furca38b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i38b.furca.furcaA === 2 && <div id="furca38b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i38b.furca.furcaA === 3 && <div id="furca38b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i38b.statusVestibular === 2 &&
                  <div id="diente38b-a" style={getStyleDiente(estadoTornillo.i38b.statusPalatino, "38").palatino}>
                    {
                      estadoTornillo.i38b.furca.furcaA === 0 && <div id="furca38b"></div>
                    }
                    {
                      estadoTornillo.i38b.furca.furcaA === 1 && <div id="furca38b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i38b.furca.furcaA === 2 && <div id="furca38b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i38b.furca.furcaA === 3 && <div id="furca38b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
                {estadoTornillo.i38b.statusVestibular === 0 &&
                  <div id="diente38b-a" style={getStyleDiente(estadoTornillo.i38b.statusPalatino, "38").palatino}>
                    {
                      estadoTornillo.i38b.furca.furcaA === 0 && <div id="furca38b"></div>
                    }
                    {
                      estadoTornillo.i38b.furca.furcaA === 1 && <div id="furca38b" style={styleFurca1.furcaVacio}></div>
                    }
                    {
                      estadoTornillo.i38b.furca.furcaA === 2 && <div id="furca38b" style={styleFurca1.furcaMediolleno}></div>
                    }
                    {
                      estadoTornillo.i38b.furca.furcaA === 3 && <div id="furca38b" style={styleFurca1.furcaLleno}></div>
                    }
                  </div>
                }
              </td>
            </tr>

            <tr>
              <td className="titulo">Profundidad de sondaje</td>
              <td className="borde">
                <input type="text" id="ps48b-c" name="ps48b-c" value={estadoTornillo.i48b.sondajeInput.sondajeInputC} tabIndex="433" disabled={props.option.option === 2 ? disable : estadoTornillo.i48b.statusPalatino} onChange={(e) => handelChangeSondaje("i48b", "C", e.target.value)} />
                <input type="text" id="ps48b-b" name="ps48b-b" value={estadoTornillo.i48b.sondajeInput.sondajeInputB} tabIndex="434" disabled={props.option.option === 2 ? disable : estadoTornillo.i48b.statusPalatino} onChange={(e) => handelChangeSondaje("i48b", "B", e.target.value)} />
                <input type="text" id="ps48b-a" name="ps48b-a" value={estadoTornillo.i48b.sondajeInput.sondajeInputA} tabIndex="435" disabled={props.option.option === 2 ? disable : estadoTornillo.i48b.statusPalatino} onChange={(e) => handelChangeSondaje("i48b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps47b-c" name="ps47b-c" value={estadoTornillo.i47b.sondajeInput.sondajeInputC} tabIndex="436" disabled={props.option.option === 2 ? disable : estadoTornillo.i47b.statusPalatino} onChange={(e) => handelChangeSondaje("i47b", "C", e.target.value)} />
                <input type="text" id="ps47b-b" name="ps47b-b" value={estadoTornillo.i47b.sondajeInput.sondajeInputB} tabIndex="437" disabled={props.option.option === 2 ? disable : estadoTornillo.i47b.statusPalatino} onChange={(e) => handelChangeSondaje("i47b", "B", e.target.value)} />
                <input type="text" id="ps47b-a" name="ps47b-a" value={estadoTornillo.i47b.sondajeInput.sondajeInputA} tabIndex="438" disabled={props.option.option === 2 ? disable : estadoTornillo.i47b.statusPalatino} onChange={(e) => handelChangeSondaje("i47b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps46b-c" name="ps46b-c" value={estadoTornillo.i46b.sondajeInput.sondajeInputC} tabIndex="439" disabled={props.option.option === 2 ? disable : estadoTornillo.i46b.statusPalatino} onChange={(e) => handelChangeSondaje("i46b", "C", e.target.value)} />
                <input type="text" id="ps46b-b" name="ps46b-b" value={estadoTornillo.i46b.sondajeInput.sondajeInputB} tabIndex="440" disabled={props.option.option === 2 ? disable : estadoTornillo.i46b.statusPalatino} onChange={(e) => handelChangeSondaje("i46b", "B", e.target.value)} />
                <input type="text" id="ps46b-a" name="ps46b-a" value={estadoTornillo.i46b.sondajeInput.sondajeInputA} tabIndex="441" disabled={props.option.option === 2 ? disable : estadoTornillo.i46b.statusPalatino} onChange={(e) => handelChangeSondaje("i46b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps45b-c" name="ps45b-c" value={estadoTornillo.i45b.sondajeInput.sondajeInputC} tabIndex="442" disabled={props.option.option === 2 ? disable : estadoTornillo.i45b.statusPalatino} onChange={(e) => handelChangeSondaje("i45b", "C", e.target.value)} />
                <input type="text" id="ps45b-b" name="ps45b-b" value={estadoTornillo.i45b.sondajeInput.sondajeInputB} tabIndex="443" disabled={props.option.option === 2 ? disable : estadoTornillo.i45b.statusPalatino} onChange={(e) => handelChangeSondaje("i45b", "B", e.target.value)} />
                <input type="text" id="ps45b-a" name="ps45b-a" value={estadoTornillo.i45b.sondajeInput.sondajeInputA} tabIndex="444" disabled={props.option.option === 2 ? disable : estadoTornillo.i45b.statusPalatino} onChange={(e) => handelChangeSondaje("i45b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps44b-c" name="ps44b-c" value={estadoTornillo.i44b.sondajeInput.sondajeInputC} tabIndex="445" disabled={props.option.option === 2 ? disable : estadoTornillo.i44b.statusPalatino} onChange={(e) => handelChangeSondaje("i44b", "C", e.target.value)} />
                <input type="text" id="ps44b-b" name="ps44b-b" value={estadoTornillo.i44b.sondajeInput.sondajeInputB} tabIndex="446" disabled={props.option.option === 2 ? disable : estadoTornillo.i44b.statusPalatino} onChange={(e) => handelChangeSondaje("i44b", "B", e.target.value)} />
                <input type="text" id="ps44b-a" name="ps44b-a" value={estadoTornillo.i44b.sondajeInput.sondajeInputA} tabIndex="447" disabled={props.option.option === 2 ? disable : estadoTornillo.i44b.statusPalatino} onChange={(e) => handelChangeSondaje("i44b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps43b-c" name="ps43b-c" value={estadoTornillo.i43b.sondajeInput.sondajeInputC} tabIndex="448" disabled={props.option.option === 2 ? disable : estadoTornillo.i43b.statusPalatino} onChange={(e) => handelChangeSondaje("i43b", "C", e.target.value)} />
                <input type="text" id="ps43b-b" name="ps43b-b" value={estadoTornillo.i43b.sondajeInput.sondajeInputB} tabIndex="449" disabled={props.option.option === 2 ? disable : estadoTornillo.i43b.statusPalatino} onChange={(e) => handelChangeSondaje("i43b", "B", e.target.value)} />
                <input type="text" id="ps43b-a" name="ps43b-a" value={estadoTornillo.i43b.sondajeInput.sondajeInputA} tabIndex="450" disabled={props.option.option === 2 ? disable : estadoTornillo.i43b.statusPalatino} onChange={(e) => handelChangeSondaje("i43b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps42b-c" name="ps42b-c" value={estadoTornillo.i42b.sondajeInput.sondajeInputC} tabIndex="451" disabled={props.option.option === 2 ? disable : estadoTornillo.i42b.statusPalatino} onChange={(e) => handelChangeSondaje("i42b", "C", e.target.value)} />
                <input type="text" id="ps42b-b" name="ps42b-b" value={estadoTornillo.i42b.sondajeInput.sondajeInputB} tabIndex="452" disabled={props.option.option === 2 ? disable : estadoTornillo.i42b.statusPalatino} onChange={(e) => handelChangeSondaje("i42b", "B", e.target.value)} />
                <input type="text" id="ps42b-a" name="ps42b-a" value={estadoTornillo.i42b.sondajeInput.sondajeInputA} tabIndex="453" disabled={props.option.option === 2 ? disable : estadoTornillo.i42b.statusPalatino} onChange={(e) => handelChangeSondaje("i42b", "A", e.target.value)} />
              </td>
              <td className="borde">
                <input type="text" id="ps41b-c" name="ps41b-c" value={estadoTornillo.i41b.sondajeInput.sondajeInputC} tabIndex="454" disabled={props.option.option === 2 ? disable : estadoTornillo.i41b.statusPalatino} onChange={(e) => handelChangeSondaje("i41b", "C", e.target.value)} />
                <input type="text" id="ps41b-b" name="ps41b-b" value={estadoTornillo.i41b.sondajeInput.sondajeInputB} tabIndex="455" disabled={props.option.option === 2 ? disable : estadoTornillo.i41b.statusPalatino} onChange={(e) => handelChangeSondaje("i41b", "B", e.target.value)} />
                <input type="text" id="ps41b-a" name="ps41b-a" value={estadoTornillo.i41b.sondajeInput.sondajeInputA} tabIndex="456" disabled={props.option.option === 2 ? disable : estadoTornillo.i41b.statusPalatino} onChange={(e) => handelChangeSondaje("i41b", "A", e.target.value)} />
              </td>

              <td className="borde">
                <input type="text" id="ps31b-c" name="ps31b-c" value={estadoTornillo.i31b.sondajeInput.sondajeInputC} tabIndex="457" disabled={props.option.option === 2 ? disable : estadoTornillo.i31b.statusPalatino} onChange={(e) => handelChangeSondaje("i31b", "C", e.target.value)} />
                <input type="text" id="ps31b-b" name="ps31b-b" value={estadoTornillo.i31b.sondajeInput.sondajeInputB} tabIndex="458" disabled={props.option.option === 2 ? disable : estadoTornillo.i31b.statusPalatino} onChange={(e) => handelChangeSondaje("i31b", "B", e.target.value)} />
                <input type="text" id="ps31b-a" name="ps31b-a" value={estadoTornillo.i31b.sondajeInput.sondajeInputA} tabIndex="459" disabled={props.option.option === 2 ? disable : estadoTornillo.i31b.statusPalatino} onChange={(e) => handelChangeSondaje("i31b", "A", e.target.value)} />
              </td>

              <td className="borde">
                <input type="text" id="ps32b-c" name="ps32b-c" value={estadoTornillo.i32b.sondajeInput.sondajeInputC} tabIndex="460" disabled={props.option.option === 2 ? disable : estadoTornillo.i32b.statusPalatino} onChange={(e) => handelChangeSondaje("i32b", "C", e.target.value)} />
                <input type="text" id="ps32b-b" name="ps32b-b" value={estadoTornillo.i32b.sondajeInput.sondajeInputB} tabIndex="461" disabled={props.option.option === 2 ? disable : estadoTornillo.i32b.statusPalatino} onChange={(e) => handelChangeSondaje("i32b", "B", e.target.value)} />
                <input type="text" id="ps32b-a" name="ps32b-a" value={estadoTornillo.i32b.sondajeInput.sondajeInputA} tabIndex="462" disabled={props.option.option === 2 ? disable : estadoTornillo.i32b.statusPalatino} onChange={(e) => handelChangeSondaje("i32b", "A", e.target.value)} />
              </td>

              <td className="borde">
                <input type="text" id="ps33b-c" name="ps33b-c" value={estadoTornillo.i33b.sondajeInput.sondajeInputC} tabIndex="463" disabled={props.option.option === 2 ? disable : estadoTornillo.i33b.statusPalatino} onChange={(e) => handelChangeSondaje("i33b", "C", e.target.value)} />
                <input type="text" id="ps33b-b" name="ps33b-b" value={estadoTornillo.i33b.sondajeInput.sondajeInputB} tabIndex="464" disabled={props.option.option === 2 ? disable : estadoTornillo.i33b.statusPalatino} onChange={(e) => handelChangeSondaje("i33b", "B", e.target.value)} />
                <input type="text" id="ps33b-a" name="ps33b-a" value={estadoTornillo.i33b.sondajeInput.sondajeInputA} tabIndex="465" disabled={props.option.option === 2 ? disable : estadoTornillo.i33b.statusPalatino} onChange={(e) => handelChangeSondaje("i33b", "A", e.target.value)} />
              </td>

              <td className="borde">
                <input type="text" id="ps34b-c" name="ps34b-c" value={estadoTornillo.i34b.sondajeInput.sondajeInputC} tabIndex="466" disabled={props.option.option === 2 ? disable : estadoTornillo.i34b.statusPalatino} onChange={(e) => handelChangeSondaje("i34b", "C", e.target.value)} />
                <input type="text" id="ps34b-b" name="ps34b-b" value={estadoTornillo.i34b.sondajeInput.sondajeInputB} tabIndex="467" disabled={props.option.option === 2 ? disable : estadoTornillo.i34b.statusPalatino} onChange={(e) => handelChangeSondaje("i34b", "B", e.target.value)} />
                <input type="text" id="ps34b-a" name="ps34b-a" value={estadoTornillo.i34b.sondajeInput.sondajeInputA} tabIndex="468" disabled={props.option.option === 2 ? disable : estadoTornillo.i34b.statusPalatino} onChange={(e) => handelChangeSondaje("i34b", "A", e.target.value)} />
              </td>

              <td className="borde">
                <input type="text" id="ps35b-c" name="ps35b-c" value={estadoTornillo.i35b.sondajeInput.sondajeInputC} tabIndex="469" disabled={props.option.option === 2 ? disable : estadoTornillo.i35b.statusPalatino} onChange={(e) => handelChangeSondaje("i35b", "C", e.target.value)} />
                <input type="text" id="ps35b-b" name="ps35b-b" value={estadoTornillo.i35b.sondajeInput.sondajeInputB} tabIndex="470" disabled={props.option.option === 2 ? disable : estadoTornillo.i35b.statusPalatino} onChange={(e) => handelChangeSondaje("i35b", "B", e.target.value)} />
                <input type="text" id="ps35b-a" name="ps35b-a" value={estadoTornillo.i35b.sondajeInput.sondajeInputA} tabIndex="471" disabled={props.option.option === 2 ? disable : estadoTornillo.i35b.statusPalatino} onChange={(e) => handelChangeSondaje("i35b", "A", e.target.value)} />
              </td>

              <td className="borde">
                <input type="text" id="ps36b-c" name="ps36b-c" value={estadoTornillo.i36b.sondajeInput.sondajeInputC} tabIndex="472" disabled={props.option.option === 2 ? disable : estadoTornillo.i36b.statusPalatino} onChange={(e) => handelChangeSondaje("i36b", "C", e.target.value)} />
                <input type="text" id="ps36b-b" name="ps36b-b" value={estadoTornillo.i36b.sondajeInput.sondajeInputB} tabIndex="473" disabled={props.option.option === 2 ? disable : estadoTornillo.i36b.statusPalatino} onChange={(e) => handelChangeSondaje("i36b", "B", e.target.value)} />
                <input type="text" id="ps36b-a" name="ps36b-a" value={estadoTornillo.i36b.sondajeInput.sondajeInputA} tabIndex="474" disabled={props.option.option === 2 ? disable : estadoTornillo.i36b.statusPalatino} onChange={(e) => handelChangeSondaje("i36b", "A", e.target.value)} />
              </td>

              <td className="borde">
                <input type="text" id="ps37b-c" name="ps37b-c" value={estadoTornillo.i37b.sondajeInput.sondajeInputC} tabIndex="475" disabled={props.option.option === 2 ? disable : estadoTornillo.i37b.statusPalatino} onChange={(e) => handelChangeSondaje("i37b", "C", e.target.value)} />
                <input type="text" id="ps37b-b" name="ps37b-b" value={estadoTornillo.i37b.sondajeInput.sondajeInputB} tabIndex="476" disabled={props.option.option === 2 ? disable : estadoTornillo.i37b.statusPalatino} onChange={(e) => handelChangeSondaje("i37b", "B", e.target.value)} />
                <input type="text" id="ps37b-a" name="ps37b-a" value={estadoTornillo.i37b.sondajeInput.sondajeInputA} tabIndex="477" disabled={props.option.option === 2 ? disable : estadoTornillo.i37b.statusPalatino} onChange={(e) => handelChangeSondaje("i37b", "A", e.target.value)} />
              </td>

              <td className="borde">
                <input type="text" id="ps38b-c" name="ps38b-c" value={estadoTornillo.i38b.sondajeInput.sondajeInputC} tabIndex="478" disabled={props.option.option === 2 ? disable : estadoTornillo.i38b.statusPalatino} onChange={(e) => handelChangeSondaje("i38b", "C", e.target.value)} />
                <input type="text" id="ps38b-b" name="ps38b-b" value={estadoTornillo.i38b.sondajeInput.sondajeInputB} tabIndex="479" disabled={props.option.option === 2 ? disable : estadoTornillo.i38b.statusPalatino} onChange={(e) => handelChangeSondaje("i38b", "B", e.target.value)} />
                <input type="text" id="ps38b-a" name="ps38b-a" value={estadoTornillo.i38b.sondajeInput.sondajeInputA} tabIndex="480" disabled={props.option.option === 2 ? disable : estadoTornillo.i38b.statusPalatino} onChange={(e) => handelChangeSondaje("i38b", "A", e.target.value)} />
              </td>
            </tr>

            <tr>
              <td className="titulo">Sangrado / Exudado</td>
              <td className="borde">
                {estadoTornillo.i48b.statusVestibular ?
                  <>
                    <div id="s48b-a" style={getStyle(estadoTornillo.i48b.sangrado.sangradoA)}></div>
                    <div id="s48b-b" style={getStyle(estadoTornillo.i48b.sangrado.sangradoB)}></div>
                    <div id="s48b-c" style={getStyle(estadoTornillo.i48b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s48b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i48b", "A")} style={getStyle(estadoTornillo.i48b.sangrado.sangradoA)}></div>
                    <div id="s48b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i48b", "B")} style={getStyle(estadoTornillo.i48b.sangrado.sangradoB)}></div>
                    <div id="s48b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i48b", "C")} style={getStyle(estadoTornillo.i48b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i47b.statusVestibular ?
                  <>
                    <div id="s47b-a" style={getStyle(estadoTornillo.i47b.sangrado.sangradoA)}></div>
                    <div id="s47b-b" style={getStyle(estadoTornillo.i47b.sangrado.sangradoB)}></div>
                    <div id="s47b-c" style={getStyle(estadoTornillo.i47b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s47b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i47b", "A")} style={getStyle(estadoTornillo.i47b.sangrado.sangradoA)}></div>
                    <div id="s47b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i47b", "B")} style={getStyle(estadoTornillo.i47b.sangrado.sangradoB)}></div>
                    <div id="s47b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i47b", "C")} style={getStyle(estadoTornillo.i47b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i46b.statusVestibular ?
                  <>
                    <div id="s46b-a" style={getStyle(estadoTornillo.i46b.sangrado.sangradoA)}></div>
                    <div id="s46b-b" style={getStyle(estadoTornillo.i46b.sangrado.sangradoB)}></div>
                    <div id="s46b-c" style={getStyle(estadoTornillo.i46b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s46b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i46b", "A")} style={getStyle(estadoTornillo.i46b.sangrado.sangradoA)}></div>
                    <div id="s46b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i46b", "B")} style={getStyle(estadoTornillo.i46b.sangrado.sangradoB)}></div>
                    <div id="s46b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i46b", "C")} style={getStyle(estadoTornillo.i46b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i45b.statusVestibular ?
                  <>
                    <div id="s45b-a" style={getStyle(estadoTornillo.i45b.sangrado.sangradoA)}></div>
                    <div id="s45b-b" style={getStyle(estadoTornillo.i45b.sangrado.sangradoB)}></div>
                    <div id="s45b-c" style={getStyle(estadoTornillo.i45b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s45b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i45b", "A")} style={getStyle(estadoTornillo.i45b.sangrado.sangradoA)}></div>
                    <div id="s45b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i45b", "B")} style={getStyle(estadoTornillo.i45b.sangrado.sangradoB)}></div>
                    <div id="s45b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i45b", "C")} style={getStyle(estadoTornillo.i45b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i44b.statusVestibular ?
                  <>
                    <div id="s44b-a" style={getStyle(estadoTornillo.i44b.sangrado.sangradoA)}></div>
                    <div id="s44b-b" style={getStyle(estadoTornillo.i44b.sangrado.sangradoB)}></div>
                    <div id="s44b-c" style={getStyle(estadoTornillo.i44b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s44b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i44b", "A")} style={getStyle(estadoTornillo.i44b.sangrado.sangradoA)}></div>
                    <div id="s44b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i44b", "B")} style={getStyle(estadoTornillo.i44b.sangrado.sangradoB)}></div>
                    <div id="s44b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i44b", "C")} style={getStyle(estadoTornillo.i44b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i43b.statusVestibular ?
                  <>
                    <div id="s43b-a" style={getStyle(estadoTornillo.i43b.sangrado.sangradoA)}></div>
                    <div id="s43b-b" style={getStyle(estadoTornillo.i43b.sangrado.sangradoB)}></div>
                    <div id="s43b-c" style={getStyle(estadoTornillo.i43b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s43b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i43b", "A")} style={getStyle(estadoTornillo.i43b.sangrado.sangradoA)}></div>
                    <div id="s43b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i43b", "B")} style={getStyle(estadoTornillo.i43b.sangrado.sangradoB)}></div>
                    <div id="s43b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i43b", "C")} style={getStyle(estadoTornillo.i43b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i42b.statusVestibular ?
                  <>
                    <div id="s42b-a" style={getStyle(estadoTornillo.i42b.sangrado.sangradoA)}></div>
                    <div id="s42b-b" style={getStyle(estadoTornillo.i42b.sangrado.sangradoB)}></div>
                    <div id="s42b-c" style={getStyle(estadoTornillo.i42b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s42b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i42b", "A")} style={getStyle(estadoTornillo.i42b.sangrado.sangradoA)}></div>
                    <div id="s42b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i42b", "B")} style={getStyle(estadoTornillo.i42b.sangrado.sangradoB)}></div>
                    <div id="s42b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i42b", "C")} style={getStyle(estadoTornillo.i42b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i41b.statusVestibular ?
                  <>
                    <div id="s41b-a" style={getStyle(estadoTornillo.i41b.sangrado.sangradoA)}></div>
                    <div id="s41b-b" style={getStyle(estadoTornillo.i41b.sangrado.sangradoB)}></div>
                    <div id="s41b-c" style={getStyle(estadoTornillo.i41b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s41b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i41b", "A")} style={getStyle(estadoTornillo.i41b.sangrado.sangradoA)}></div>
                    <div id="s41b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i41b", "B")} style={getStyle(estadoTornillo.i41b.sangrado.sangradoB)}></div>
                    <div id="s41b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i41b", "C")} style={getStyle(estadoTornillo.i41b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>

              <td className="borde">
                {estadoTornillo.i31b.statusVestibular ?
                  <>
                    <div id="s31b-a" style={getStyle(estadoTornillo.i31b.sangrado.sangradoA)}></div>
                    <div id="s31b-b" style={getStyle(estadoTornillo.i31b.sangrado.sangradoB)}></div>
                    <div id="s31b-c" style={getStyle(estadoTornillo.i31b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s31b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i31b", "A")} style={getStyle(estadoTornillo.i31b.sangrado.sangradoA)}></div>
                    <div id="s31b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i31b", "B")} style={getStyle(estadoTornillo.i31b.sangrado.sangradoB)}></div>
                    <div id="s31b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i31b", "C")} style={getStyle(estadoTornillo.i31b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i32b.statusVestibular ?
                  <>
                    <div id="s32b-a" style={getStyle(estadoTornillo.i32b.sangrado.sangradoA)}></div>
                    <div id="s32b-b" style={getStyle(estadoTornillo.i32b.sangrado.sangradoB)}></div>
                    <div id="s32b-c" style={getStyle(estadoTornillo.i32b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s32b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i32b", "A")} style={getStyle(estadoTornillo.i32b.sangrado.sangradoA)}></div>
                    <div id="s32b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i32b", "B")} style={getStyle(estadoTornillo.i32b.sangrado.sangradoB)}></div>
                    <div id="s32b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i32b", "C")} style={getStyle(estadoTornillo.i32b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i33b.statusVestibular ?
                  <>
                    <div id="s33b-a" style={getStyle(estadoTornillo.i33b.sangrado.sangradoA)}></div>
                    <div id="s33b-b" style={getStyle(estadoTornillo.i33b.sangrado.sangradoB)}></div>
                    <div id="s33b-c" style={getStyle(estadoTornillo.i33b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s33b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i33b", "A")} style={getStyle(estadoTornillo.i33b.sangrado.sangradoA)}></div>
                    <div id="s33b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i33b", "B")} style={getStyle(estadoTornillo.i33b.sangrado.sangradoB)}></div>
                    <div id="s33b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i33b", "C")} style={getStyle(estadoTornillo.i33b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i34b.statusVestibular ?
                  <>
                    <div id="s34b-a" style={getStyle(estadoTornillo.i34b.sangrado.sangradoA)}></div>
                    <div id="s34b-b" style={getStyle(estadoTornillo.i34b.sangrado.sangradoB)}></div>
                    <div id="s34b-c" style={getStyle(estadoTornillo.i34b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s34b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i34b", "A")} style={getStyle(estadoTornillo.i34b.sangrado.sangradoA)}></div>
                    <div id="s34b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i34b", "B")} style={getStyle(estadoTornillo.i34b.sangrado.sangradoB)}></div>
                    <div id="s34b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i34b", "C")} style={getStyle(estadoTornillo.i34b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i35b.statusVestibular ?
                  <>
                    <div id="s35b-a" style={getStyle(estadoTornillo.i35b.sangrado.sangradoA)}></div>
                    <div id="s35b-b" style={getStyle(estadoTornillo.i35b.sangrado.sangradoB)}></div>
                    <div id="s35b-c" style={getStyle(estadoTornillo.i35b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s35b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i35b", "A")} style={getStyle(estadoTornillo.i35b.sangrado.sangradoA)}></div>
                    <div id="s35b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i35b", "B")} style={getStyle(estadoTornillo.i35b.sangrado.sangradoB)}></div>
                    <div id="s35b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i35b", "C")} style={getStyle(estadoTornillo.i35b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i36b.statusVestibular ?
                  <>
                    <div id="s36b-a" style={getStyle(estadoTornillo.i36b.sangrado.sangradoA)}></div>
                    <div id="s36b-b" style={getStyle(estadoTornillo.i36b.sangrado.sangradoB)}></div>
                    <div id="s36b-c" style={getStyle(estadoTornillo.i36b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s36b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i36b", "A")} style={getStyle(estadoTornillo.i36b.sangrado.sangradoA)}></div>
                    <div id="s36b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i36b", "B")} style={getStyle(estadoTornillo.i36b.sangrado.sangradoB)}></div>
                    <div id="s36b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i36b", "C")} style={getStyle(estadoTornillo.i36b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i37b.statusVestibular ?
                  <>
                    <div id="s37b-a" style={getStyle(estadoTornillo.i37b.sangrado.sangradoA)}></div>
                    <div id="s37b-b" style={getStyle(estadoTornillo.i37b.sangrado.sangradoB)}></div>
                    <div id="s37b-c" style={getStyle(estadoTornillo.i37b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s37b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i37b", "A")} style={getStyle(estadoTornillo.i37b.sangrado.sangradoA)}></div>
                    <div id="s37b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i37b", "B")} style={getStyle(estadoTornillo.i37b.sangrado.sangradoB)}></div>
                    <div id="s37b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i37b", "C")} style={getStyle(estadoTornillo.i37b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i38b.statusVestibular ?
                  <>
                    <div id="s38b-a" style={getStyle(estadoTornillo.i38b.sangrado.sangradoA)}></div>
                    <div id="s38b-b" style={getStyle(estadoTornillo.i38b.sangrado.sangradoB)}></div>
                    <div id="s38b-c" style={getStyle(estadoTornillo.i38b.sangrado.sangradoC)}></div>
                  </> :
                  <>
                    <div id="s38b-a" onClick={() => props.option.option != 2 && handleChangeSangrado("i38b", "A")} style={getStyle(estadoTornillo.i38b.sangrado.sangradoA)}></div>
                    <div id="s38b-b" onClick={() => props.option.option != 2 && handleChangeSangrado("i38b", "B")} style={getStyle(estadoTornillo.i38b.sangrado.sangradoB)}></div>
                    <div id="s38b-c" onClick={() => props.option.option != 2 && handleChangeSangrado("i38b", "C")} style={getStyle(estadoTornillo.i38b.sangrado.sangradoC)}></div>
                  </>
                }
              </td>
            </tr>

            <tr>
              <td className="titulo">Furca</td>
              <td className="borde">
                {estadoTornillo.i48b.statusVestibular ?
                  <div id="f48b"></div> :
                  <div id="f48b" onClick={() => props.option.option != 2 && handleChangeFurca("i48b")}></div>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i47b.statusVestibular ?
                  <div id="f47b"></div> :
                  <div id="f47b" onClick={() => props.option.option != 2 && handleChangeFurca("i47b")}></div>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i46b.statusVestibular ?
                  <div id="f46b" ></div> :
                  <div id="f46b" onClick={() => props.option.option != 2 && handleChangeFurca("i46b")}></div>
                }
              </td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>

              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde"></td>
              <td className="borde">
                {estadoTornillo.i36b.statusVestibular ?
                  <div id="f36b" ></div> :
                  <div id="f36b" onClick={() => props.option.option != 2 && props.option.option != 2 && handleChangeFurca("i36b")}></div>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i37b.statusVestibular ?
                  <div id="f37b" ></div> :
                  <div id="f37b" onClick={() => props.option.option != 2 && props.option.option != 2 && handleChangeFurca("i37b")}></div>
                }
              </td>
              <td className="borde">
                {estadoTornillo.i38b.statusVestibular ?
                  <div id="f38b" ></div> :
                  <div id="f38b" onClick={() => props.option.option != 2 && props.option.option != 2 && handleChangeFurca("i38b")}></div>
                }
              </td>
            </tr>


            <tr>
              <td className="titulo">Movilidad</td>
              <td className="borde"><input type="text" id="m48b" name="m48b" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' value={estadoTornillo.i48b.movilidad} tabIndex="561" disabled={props.option.option === 2 ? disable : estadoTornillo.i48b.statusPalatino} onChange={(e) => handleInputChange("i48b", e.target.value)} /></td>
              <td className="borde"><input type="text" id="m47b" name="m47b" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' value={estadoTornillo.i47b.movilidad} tabIndex="562" disabled={props.option.option === 2 ? disable : estadoTornillo.i47b.statusPalatino} onChange={(e) => handleInputChange("i47b", e.target.value)} /></td>
              <td className="borde"><input type="text" id="m46b" name="m46b" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' value={estadoTornillo.i46b.movilidad} tabIndex="563" disabled={props.option.option === 2 ? disable : estadoTornillo.i46b.statusPalatino} onChange={(e) => handleInputChange("i46b", e.target.value)} /></td>
              <td className="borde"><input type="text" id="m45b" name="m45b" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' value={estadoTornillo.i45b.movilidad} tabIndex="564" disabled={props.option.option === 2 ? disable : estadoTornillo.i45b.statusPalatino} onChange={(e) => handleInputChange("i45b", e.target.value)} /></td>
              <td className="borde"><input type="text" id="m44b" name="m44b" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' value={estadoTornillo.i44b.movilidad} tabIndex="565" disabled={props.option.option === 2 ? disable : estadoTornillo.i44b.statusPalatino} onChange={(e) => handleInputChange("i44b", e.target.value)} /></td>
              <td className="borde"><input type="text" id="m43b" name="m43b" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' value={estadoTornillo.i43b.movilidad} tabIndex="566" disabled={props.option.option === 2 ? disable : estadoTornillo.i43b.statusPalatino} onChange={(e) => handleInputChange("i43b", e.target.value)} /></td>
              <td className="borde"><input type="text" id="m42b" name="m42b" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' value={estadoTornillo.i42b.movilidad} tabIndex="567" disabled={props.option.option === 2 ? disable : estadoTornillo.i42b.statusPalatino} onChange={(e) => handleInputChange("i42b", e.target.value)} /></td>
              <td className="borde"><input type="text" id="m41b" name="m41b" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' value={estadoTornillo.i41b.movilidad} tabIndex="568" disabled={props.option.option === 2 ? disable : estadoTornillo.i41b.statusPalatino} onChange={(e) => handleInputChange("i41b", e.target.value)} /></td>
              <td className="borde"><input type="text" id="m31b" name="m31b" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' value={estadoTornillo.i31b.movilidad} tabIndex="569" disabled={props.option.option === 2 ? disable : estadoTornillo.i31b.statusPalatino} onChange={(e) => handleInputChange("i31b", e.target.value)} /></td>
              <td className="borde"><input type="text" id="m32b" name="m32b" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' value={estadoTornillo.i32b.movilidad} tabIndex="570" disabled={props.option.option === 2 ? disable : estadoTornillo.i32b.statusPalatino} onChange={(e) => handleInputChange("i32b", e.target.value)} /></td>
              <td className="borde"><input type="text" id="m33b" name="m33b" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' value={estadoTornillo.i33b.movilidad} tabIndex="571" disabled={props.option.option === 2 ? disable : estadoTornillo.i33b.statusPalatino} onChange={(e) => handleInputChange("i33b", e.target.value)} /></td>
              <td className="borde"><input type="text" id="m34b" name="m34b" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' value={estadoTornillo.i34b.movilidad} tabIndex="572" disabled={props.option.option === 2 ? disable : estadoTornillo.i34b.statusPalatino} onChange={(e) => handleInputChange("i34b", e.target.value)} /></td>
              <td className="borde"><input type="text" id="m35b" name="m35b" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' value={estadoTornillo.i35b.movilidad} tabIndex="573" disabled={props.option.option === 2 ? disable : estadoTornillo.i35b.statusPalatino} onChange={(e) => handleInputChange("i35b", e.target.value)} /></td>
              <td className="borde"><input type="text" id="m36b" name="m36b" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' value={estadoTornillo.i36b.movilidad} tabIndex="574" disabled={props.option.option === 2 ? disable : estadoTornillo.i36b.statusPalatino} onChange={(e) => handleInputChange("i36b", e.target.value)} /></td>
              <td className="borde"><input type="text" id="m37b" name="m37b" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' value={estadoTornillo.i37b.movilidad} tabIndex="575" disabled={props.option.option === 2 ? disable : estadoTornillo.i37b.statusPalatino} onChange={(e) => handleInputChange("i37b", e.target.value)} /></td>
              <td className="borde"><input type="text" id="m38b" name="m38b" maxLength={1} style={{ textTransform: "uppercase" }} pattern='^[ABC]*$' value={estadoTornillo.i38b.movilidad} tabIndex="576" disabled={props.option.option === 2 ? disable : estadoTornillo.i38b.statusPalatino} onChange={(e) => handleInputChange("i38b", e.target.value)} /></td>
            </tr>

            <tr>
              <td className="titulo">Ausente</td>
              <td className="borde">
                <div id="i48b" onClick={() => props.option.option != 2 && handleChange("i48")}></div>
              </td>
              <td className="borde">
                <div id="i47b" onClick={() => props.option.option != 2 && handleChange("i47")}></div>
              </td>
              <td className="borde">
                <div id="i46b" onClick={() => props.option.option != 2 && handleChange("i46")}></div>
              </td>
              <td className="borde">
                <div id="i45b" onClick={() => props.option.option != 2 && handleChange("i45")}></div>
              </td>
              <td className="borde">
                <div id="i44b" onClick={() => props.option.option != 2 && handleChange("i44")}></div>
              </td>
              <td className="borde">
                <div id="i43b" onClick={() => props.option.option != 2 && handleChange("i43")}></div>
              </td>
              <td className="borde">
                <div id="i42b" onClick={() => props.option.option != 2 && handleChange("i42")}></div>
              </td>
              <td className="borde">
                <div id="i41b" onClick={() => props.option.option != 2 && handleChange("i41")}></div>
              </td>

              <td className="borde">
                <div id="i31b" onClick={() => props.option.option != 2 && handleChange("i31")}></div>
              </td>
              <td className="borde">
                <div id="i32b" onClick={() => props.option.option != 2 && handleChange("i32")}></div>
              </td>
              <td className="borde">
                <div id="i33b" onClick={() => props.option.option != 2 && handleChange("i33")}></div>
              </td>
              <td className="borde">
                <div id="i34b" onClick={() => props.option.option != 2 && handleChange("i34")}></div>
              </td>
              <td className="borde">
                <div id="i35b" onClick={() => props.option.option != 2 && handleChange("i35")}></div>
              </td>
              <td className="borde">
                <div id="i36b" onClick={() => props.option.option != 2 && handleChange("i36")}></div>
              </td>
              <td className="borde">
                <div id="i37b" onClick={() => props.option.option != 2 && handleChange("i37")}></div>
              </td>
              <td className="borde">
                <div id="i38b" onClick={() => props.option.option != 2 && handleChange("i38")}></div>
              </td>
            </tr>

            <tr>
              <td className="titulo"></td>
              <td className="borde">
                <div id="d48b">4.8</div>
              </td>
              <td className="borde">
                <div id="d47b">4.7</div>
              </td>
              <td className="borde">
                <div id="d46b">4.6</div>
              </td>
              <td className="borde">
                <div id="d45b">4.5</div>
              </td>
              <td className="borde">
                <div id="d44b">4.4</div>
              </td>
              <td className="borde">
                <div id="d43b">4.3</div>
              </td>
              <td className="borde">
                <div id="d42b">4.2</div>
              </td>
              <td className="borde">
                <div id="d41b">4.1</div>
              </td>
              <td className="borde">
                <div id="d31b">3.1</div>
              </td>
              <td className="borde">
                <div id="d32b">3.2</div>
              </td>
              <td className="borde">
                <div id="d33b">3.3</div>
              </td>
              <td className="borde">
                <div id="d34b">3.4</div>
              </td>
              <td className="borde">
                <div id="d35b">3.5</div>
              </td>
              <td className="borde">
                <div id="d36b">3.6</div>
              </td>
              <td className="borde">
                <div id="d37b">3.7</div>
              </td>
              <td className="borde">
                <div id="d38b">3.8</div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div style={{ textAlign: 'right' }}>
        <Space direction='vertical'>
          <Space>
            <Form.Item >
              <Button danger onClick={handleCancel}>
                Cancelar
              </Button>
            </Form.Item>
            {props.option.showHide === 'show' &&
              <Form.Item >
                <Button type="primary" onClick={registerData} loading={props.spinActive}>
                  {props.option.modalFooter}
                </Button>
              </Form.Item>
            }
          </Space>
        </Space>
      </div>
    </div>
  )
};

export default Periodontograma;