export let estadosTornillos = {
  "i11": {
    statusVestibular: 0,
    statusPalatino: 0,
    movilidad: "",
    nota: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [
      { name: "A", encia: 0, sondaje: 0, nulo: 10 }, 
      { name: "B", encia: 0, sondaje: 0, nulo: 10 },
      { name: "C", encia: 0, sondaje: 0, nulo: 10 }
    ],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i12": {
    id:null,
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i13": {
    id:null,
    statusVestibular: 0,
    statusPalatino: 0,
    movilidad: "",
    nota: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i14": {
    id:null,
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i15": {
    id:null,
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i16": {
    id:null,
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i17": {
    id:null,
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: { furcaA: 0, furcaB: 0 },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i18": {
    id:null,
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },

  "i11b": {
    id:null,
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i12b": {
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i13b": {
    id:null,
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i14b": {
    id:null,
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i15b": {
    id:null,
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i16b": {
    id:null,
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i17b": {
    id:null,
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i18b": {
    id:null,
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },

  "i21": {
    id:null,
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i22": {
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i23": {
    statusVestibular: 0,
    statusPalatino: 0,
    movilidad: "",
    nota: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i24": {
    statusVestibular: 0,
    statusPalatino: 0,
    movilidad: "",
    nota: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i25": {
    statusVestibular: 0,
    statusPalatino: 0,
    movilidad: "",
    nota: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i26": {
    statusVestibular: 0,
    statusPalatino: 0,
    movilidad: "",
    nota: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i27": {
    statusVestibular: 0,
    statusPalatino: 0,
    movilidad: "",
    nota: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i28": {
    statusVestibular: 0,
    statusPalatino: 0,
    movilidad: "",
    nota: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },

  "i21b": {
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i22b": {
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i23b": {
    statusVestibular: 0,
    statusPalatino: 0,
    movilidad: "",
    nota: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i24b": {
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i25b": {
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i26b": {
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i27b": {
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i28b": {
    statusVestibular: 0,
    statusPalatino: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },

  "i48": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i47": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i46": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i45": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i44": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i43": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i42": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i41": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },

  "i48b": {
    statusPalatino: 0,
    statusVestibular: 0,
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i47b": {
    statusPalatino: 0,
    statusVestibular: 0,
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i46b": {
    statusPalatino: 0,
    statusVestibular: 0,
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i45b": {
    statusPalatino: 0,
    statusVestibular: 0,
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i44b": {
    statusPalatino: 0,
    statusVestibular: 0,
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i43b": {
    statusPalatino: 0,
    statusVestibular: 0,
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i42b": {
    statusPalatino: 0,
    statusVestibular: 0,
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i41b": {
    statusPalatino: 0,
    statusVestibular: 0,
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },

  "i31b": {
    statusPalatino: 0,
    statusVestibular: 0,
    movilidad: "",
    nota: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i32b": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i33b": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i34b": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i35b": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i36b": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i37b": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i38b": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota: "",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },

  "i31": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota:"",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i32": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota:"",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i33": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota:"",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i34": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota:"",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i35": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota:"",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i36": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota:"",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i37": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota:"",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
  "i38": {
    statusPalatino: 0,
    statusVestibular: 0,
    nota:"",
    movilidad: "",
    furca: {
      furcaA: 0,
      furcaB: 0
    },
    placa: {
      placaA: false,
      placaB: false,
      placaC: false,
    },
    sangrado: {
      sangradoA: 0,
      sangradoB: 0,
      sangradoC: 0
    },
    encia: [{ name: "A", encia: 0, sondaje: 0, nulo: 10 }, { name: "B", encia: 0, sondaje: 0, nulo: 10 }, { name: "C", encia: 0, sondaje: 0, nulo: 10 }],
    enciaInput: {
      enciaInputA: "0",
      enciaInputB: "0",
      enciaInputC: "0",
    },
    sondajeInput: {
      sondajeInputA: "0",
      sondajeInputB: "0",
      sondajeInputC: "0",
    }
  },
}