'use client';
import * as d3 from 'd3';
import { useRef, useEffect } from 'react';

const SondajeDepthChart = ({ depth }) => {
  const svgRef = useRef();

  useEffect(() => {
    const svg = d3.select(svgRef.current);

    // Define el ancho y la altura del gráfico
    const width = 420;
    const height = 100;

    // Escala para mapear los datos a la posición en el gráfico
    const xScale = d3.scaleLinear()
      .domain([0, depth.length - 1])
      .range([0, width]);

    const yScale = d3.scaleLinear()
      .domain([0, d3.max(depth)])
      .range([height, 0]);

    // Crea la línea recta hacia arriba
    const initialLine = d3.line()
      .x((_, i) => xScale(i))
      .y(_ => yScale(0));

    // Agrega la línea al SVG
    svg.selectAll("*").remove(); // Borra cualquier elemento previo
    svg.append("path")
      .datum(depth)
      .attr("fill", "none")
      .attr("stroke", "steelblue") // Puedes cambiar el color aquí
      .attr("stroke-width", 2)
      .attr("d", initialLine);
  }, [depth]);

  return <svg ref={svgRef} width="450" height="200" />;
};

export default SondajeDepthChart;
