export const style = {
  diente18Cambio: {
    backgroundImage: "url('/img/tabla1/tachados/periodontograma-dientes-arriba-tachados-18.png')",
    backgroundPosition: "0 -2px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente18bCambio: {
    backgroundImage: "url('/img/tabla3/tachados/periodontograma-dientes-arriba-tachados-18b.png')",
    backgroundPosition: "0 30px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente17bCambio: {
    backgroundImage: "url('/img/tabla3/tachados/periodontograma-dientes-arriba-tachados-17b.png')",
    backgroundPosition: "0 35px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente17Cambio: {
    backgroundImage: "url('/img/tabla1/tachados/periodontograma-dientes-arriba-tachados-17.png')",
    backgroundPosition: "0px 3px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente16bCambio: {
    backgroundImage: "url('/img/tabla3/tachados/periodontograma-dientes-arriba-tachados-16b.png')",
    backgroundPosition: "0 36px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente16Cambio: {
    backgroundImage: "url('/img/tabla1/tachados/periodontograma-dientes-arriba-tachados-16.png')",
    backgroundPosition: "0 12px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente15bCambio: {
    backgroundImage: "url('/img/tabla3/tachados/periodontograma-dientes-arriba-tachados-15b.png')",
    backgroundPosition: "0 30px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },

  diente15Cambio: {
    backgroundImage: "url('/img/tabla1/tachados/periodontograma-dientes-arriba-tachados-15.png')",
    backgroundPosition: "0 2px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "31px"
  },

  diente14bCambio: {
    backgroundImage: "url('/img/tabla3/tachados/periodontograma-dientes-arriba-tachados-14b.png')",
    backgroundPosition: "0 30px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },

  diente14Cambio: {
    backgroundImage: "url('/img/tabla1/tachados/periodontograma-dientes-arriba-tachados-14.png')",
    backgroundPosition: "0 2px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "34px"
  },

  diente13bCambio: {
    backgroundImage: "url('/img/tabla3/tachados/periodontograma-dientes-arriba-tachados-13b.png')",
    backgroundPosition: "0 30px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },

  diente13Cambio: {
    backgroundImage: "url('/img/tabla1/tachados/periodontograma-dientes-arriba-tachados-13.png')",
    backgroundPosition: "top",
    backgroundRepeat: "no-repeat",
    backgroundSize: "32px"
  },

  diente12bCambio: {
    backgroundImage: "url('/img/tabla3/tachados/periodontograma-dientes-arriba-tachados-12b.png')",
    backgroundPosition: "0 31px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },

  diente12Cambio: {
    backgroundImage: "url('/img/tabla1/tachados/periodontograma-dientes-arriba-tachados-12.png')",
    backgroundPosition: "0 6px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "28px"
  },

  diente11bCambio: {
    backgroundImage: "url('/img/tabla3/tachados/periodontograma-dientes-arriba-tachados-11b.png')",
    backgroundPosition: "0 23px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "36px"
  },

  diente11Cambio: {
    backgroundImage: "url('/img/tabla1/tachados/periodontograma-dientes-arriba-tachados-11.png')",
    backgroundPosition: "0px 17px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "38px"
  },
  diente21Cambio: {
    backgroundImage: "url('/img/tabla2/tachados/periodontograma-dientes-arriba-tachados-21.png')",
    backgroundPosition: "0px 12px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "38px"
  },

  diente21bCambio: {
    backgroundImage: "url('/img/tabla4/tachados/periodontograma-dientes-arriba-tachados-21b.png')",
    backgroundPosition: "0px 23px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "36px"
  },

  diente22Cambio: {
    backgroundImage: "url('/img/tabla2/tachados/periodontograma-dientes-arriba-tachados-22.png')",
    backgroundPosition: "0 0px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "29px"
  },
  diente22bCambio: {
    backgroundImage: "url('/img/tabla4/tachados/periodontograma-dientes-arriba-tachados-22b.png')",
    backgroundPosition: "0 25px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "35px"
  },

  diente23Cambio: {
    backgroundImage: "url('/img/tabla2/tachados/periodontograma-dientes-arriba-tachados-23.png')",
    backgroundPosition: "0px 5px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },
  diente23bCambio: {
    backgroundImage: "url('/img/tabla4/tachados/periodontograma-dientes-arriba-tachados-23b.png')",
    backgroundPosition: "0px 25px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "32px"
  },

  diente24Cambio: {
    backgroundImage: "url('/img/tabla2/tachados/periodontograma-dientes-arriba-tachados-24.png')",
    //backgroundPosition: "top",
    backgroundRepeat: "no-repeat",
    backgroundSize: "31px"
  },
  diente24bCambio: {
    backgroundImage: "url('/img/tabla4/tachados/periodontograma-dientes-arriba-tachados-24b.png')",
    backgroundPosition: " 0 28px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },

  diente25Cambio: {
    backgroundImage: "url('/img/tabla2/tachados/periodontograma-dientes-arriba-tachados-25.png')",
    backgroundPosition: "0 5px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },
  diente25bCambio: {
    backgroundImage: "url('/img/tabla4/tachados/periodontograma-dientes-arriba-tachados-25b.png')",
    backgroundPosition: "0 27px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "32px"
  },

  diente26Cambio: {
    backgroundImage: "url('/img/tabla2/tachados/periodontograma-dientes-arriba-tachados-26.png')",
    backgroundPosition: "0 15px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente26bCambio: {
    backgroundImage: "url('/img/tabla4/tachados/periodontograma-dientes-arriba-tachados-26b.png')",
    backgroundPosition: "0 34px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente27Cambio: {
    backgroundImage: "url('/img/tabla2/tachados/periodontograma-dientes-arriba-tachados-27.png')",
    backgroundPosition: "0 0px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente27bCambio: {
    backgroundImage: "url('/img/tabla4/tachados/periodontograma-dientes-arriba-tachados-27b.png')",
    backgroundPosition: "0 35px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente28Cambio: {
    backgroundImage: "url('/img/tabla2/tachados/periodontograma-dientes-arriba-tachados-28.png')",
    backgroundPosition: "0 -2px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente28bCambio: {
    backgroundImage: "url('/img/tabla4/tachados/periodontograma-dientes-arriba-tachados-28b.png')",
    backgroundPosition: "0 31px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente48Cambio: {
    backgroundImage: "url('/img/tabla5/tachados/periodontograma-dientes-abajo-tachados-48.png')",
    backgroundPosition: "0 10px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px",
    margin: "0px 0px"
  },
  diente48bCambio: {
    backgroundImage: "url('/img/tabla7/tachados/periodontograma-dientes-abajo-tachados-48b.png')",
    backgroundPosition: "0 35px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente47Cambio: {
    backgroundImage: "url('/img/tabla5/tachados/periodontograma-dientes-abajo-tachados-47.png')",
    backgroundPosition: "0 4px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente47bCambio: {
    backgroundImage: "url('/img/tabla7/tachados/periodontograma-dientes-abajo-tachados-47b.png')",
    backgroundPosition: "0 34px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente46Cambio: {
    backgroundImage: "url('/img/tabla5/tachados/periodontograma-dientes-abajo-tachados-46.png')",
    backgroundPosition: "0 13px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente46bCambio: {
    backgroundImage: "url('/img/tabla7/tachados/periodontograma-dientes-abajo-tachados-46b.png')",
    backgroundPosition: "0 38px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente45Cambio: {
    backgroundImage: "url('/img/tabla5/tachados/periodontograma-dientes-abajo-tachados-45.png')",
    backgroundPosition: "0px 2px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "32px"

  },
  diente45bCambio: {
    backgroundImage: "url('/img/tabla7/tachados/periodontograma-dientes-abajo-tachados-45b.png')",
    backgroundPosition: "0 32px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "32px"
  },

  diente44Cambio: {
    backgroundImage: "url('/img/tabla5/tachados/periodontograma-dientes-abajo-tachados-44.png')",
    backgroundPosition: "0 4px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "31px"
  },
  diente44bCambio: {
    backgroundImage: "url('/img/tabla7/tachados/periodontograma-dientes-abajo-tachados-44b.png')",
    backgroundPosition: "0 28px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },

  diente43Cambio: {
    backgroundImage: "url('/img/tabla5/tachados/periodontograma-dientes-abajo-tachados-43.png')",
    backgroundPosition: "0 7px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "29px"

  },
  diente43bCambio: {
    backgroundImage: "url('/img/tabla7/tachados/periodontograma-dientes-abajo-tachados-43b.png')",
    backgroundPosition: "0 22px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "28px"
  },

  diente42Cambio: {
    backgroundImage: "url('/img/tabla5/tachados/periodontograma-dientes-abajo-tachados-42.png')",
    backgroundPosition: "0 3px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "26px"

  },
  diente42bCambio: {
    backgroundImage: "url('/img/tabla7/tachados/periodontograma-dientes-abajo-tachados-42b.png')",
    backgroundPosition: "0 25px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "28px"
  },

  diente41Cambio: {
    backgroundImage: "url('/img/tabla5/tachados/periodontograma-dientes-abajo-tachados-41.png')",
    backgroundPosition: "0 1px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "26px"

  },
  diente41bCambio: {
    backgroundImage: "url('/img/tabla7/tachados/periodontograma-dientes-abajo-tachados-41b.png')",
    backgroundPosition: "0 23px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "28px"
  },
  diente31bCambio: {
    backgroundImage: "url('/img/tabla8/tachados/periodontograma-dientes-abajo-tachados-31b.png')",
    backgroundPosition: "0 25px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "28px"
  },
  diente32bCambio: {
    backgroundImage: "url('/img/tabla8/tachados/periodontograma-dientes-abajo-tachados-32b.png')",
    backgroundPosition: "0 25px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "28px"
  },
  diente33bCambio: {
    backgroundImage: "url('/img/tabla8/tachados/periodontograma-dientes-abajo-tachados-33b.png')",
    backgroundPosition: "0 24px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "28px"
  },
  diente34bCambio: {
    backgroundImage: "url('/img/tabla8/tachados/periodontograma-dientes-abajo-tachados-34b.png')",
    backgroundPosition: "0 28px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },
  diente35bCambio: {
    backgroundImage: "url('/img/tabla8/tachados/periodontograma-dientes-abajo-tachados-35b.png')",
    backgroundPosition: "0 30px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "31px"
  },
  diente36bCambio: {
    backgroundImage: "url('/img/tabla8/tachados/periodontograma-dientes-abajo-tachados-36b.png')",
    backgroundPosition: "0 37px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente37bCambio: {
    backgroundImage: "url('/img/tabla8/tachados/periodontograma-dientes-abajo-tachados-37b.png')",
    backgroundPosition: "0 35px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente38bCambio: {
    backgroundImage: "url('/img/tabla8/tachados/periodontograma-dientes-abajo-tachados-38b.png')",
    backgroundPosition: "0 36px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente38Cambio: {
    backgroundImage: "url('/img/tabla6/tachados/periodontograma-dientes-abajo-tachados-38.png')",
    backgroundPosition: "0 11px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente37Cambio: {
    backgroundImage: "url('/img/tabla6/tachados/periodontograma-dientes-abajo-tachados-37.png')",
    backgroundPosition: "0 7px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente36Cambio: {
    backgroundImage: "url('/img/tabla6/tachados/periodontograma-dientes-abajo-tachados-36.png')",
    backgroundPosition: "0 14px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente35Cambio: {
    backgroundImage: "url('/img/tabla6/tachados/periodontograma-dientes-abajo-tachados-35.png')",
    backgroundPosition: "0 1px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "33px"
  },
  diente34Cambio: {
    backgroundImage: "url('/img/tabla6/tachados/periodontograma-dientes-abajo-tachados-34.png')",
    backgroundPosition: "0 5px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },
  diente33Cambio: {
    backgroundImage: "url('/img/tabla6/tachados/periodontograma-dientes-abajo-tachados-33.png')",
    backgroundPosition: "0 7px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },
  diente32Cambio: {
    backgroundImage: "url('/img/tabla6/tachados/periodontograma-dientes-abajo-tachados-32.png')",
    backgroundPosition: "0 3px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "27px"
  },
  diente31Cambio: {
    backgroundImage: "url('/img/tabla6/tachados/periodontograma-dientes-abajo-tachados-31.png')",
    backgroundPosition: "0 1px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "27px"
  },
}


export const extraccion = {
  diente18Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-18.png')",
    backgroundPosition: "0 -2px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente18bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-18b.png')",
    backgroundPosition: "0 30px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente17bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-17b.png')",
    backgroundPosition: "0 35px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente17Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-17.png')",
    backgroundPosition: "0px 3px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente16bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-16b.png')",
    backgroundPosition: "0 36px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente16Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-16.png')",
    backgroundPosition: "0 12px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente15bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-15b.png')",
    backgroundPosition: "0 30px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },

  diente15Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-15.png')",
    backgroundPosition: "0 2px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "31px"
  },

  diente14bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-14b.png')",
    backgroundPosition: "0 30px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },

  diente14Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-14.png')",
    backgroundPosition: "0 2px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "34px"
  },

  diente13bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-13b.png')",
    backgroundPosition: "0 30px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },

  diente13Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-13.png')",
    backgroundPosition: "top",
    backgroundRepeat: "no-repeat",
    backgroundSize: "32px"
  },

  diente12bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-12b.png')",
    backgroundPosition: "0 31px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },

  diente12Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-12.png')",
    backgroundPosition: "0 6px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "28px"
  },

  diente11bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-11b.png')",
    backgroundPosition: "0 23px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "36px"
  },

  diente11Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-11.png')",
    backgroundPosition: "0px 17px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "38px"
  },
  diente21Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-21.png')",
    backgroundPosition: "0px 12px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "38px"
  },

  diente21bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-21b.png')",
    backgroundPosition: "0px 23px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "36px"
  },

  diente22Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-22.png')",
    backgroundPosition: "0 0px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "29px"
  },
  diente22bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-22b.png')",
    backgroundPosition: "0 25px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "35px"
  },

  diente23Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-23.png')",
    backgroundPosition: "0px 5px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },
  diente23bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-23b.png')",
    backgroundPosition: "0px 25px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "32px"
  },

  diente24Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-24.png')",
    //backgroundPosition: "top",
    backgroundRepeat: "no-repeat",
    backgroundSize: "31px"
  },
  diente24bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-24b.png')",
    backgroundPosition: " 0 28px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },

  diente25Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-25.png')",
    backgroundPosition: "0 5px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },
  diente25bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-25b.png')",
    backgroundPosition: "0 27px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "32px"
  },

  diente26Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-26.png')",
    backgroundPosition: "0 15px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente26bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-26b.png')",
    backgroundPosition: "0 34px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente27Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-27.png')",
    backgroundPosition: "0 0px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente27bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-27b.png')",
    backgroundPosition: "0 35px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente28Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-28.png')",
    backgroundPosition: "0 -2px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente28bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-arriba-extraccion-28b.png')",
    backgroundPosition: "0 31px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente48Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-48.png')",
    backgroundPosition: "0 10px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px",
    margin: "0px 0px"
  },
  diente48bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-48b.png')",
    backgroundPosition: "0 35px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente47Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-47.png')",
    backgroundPosition: "0 4px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente47bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-47b.png')",
    backgroundPosition: "0 34px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente46Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-46.png')",
    backgroundPosition: "0 13px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente46bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-46b.png')",
    backgroundPosition: "0 38px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente45Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-45.png')",
    backgroundPosition: "0px 2px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "32px"

  },
  diente45bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-45b.png')",
    backgroundPosition: "0 32px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "32px"
  },

  diente44Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-44.png')",
    backgroundPosition: "0 4px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "31px"
  },
  diente44bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-44b.png')",
    backgroundPosition: "0 28px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },

  diente43Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-43.png')",
    backgroundPosition: "0 7px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "29px"

  },
  diente43bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-43b.png')",
    backgroundPosition: "0 22px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "28px"
  },

  diente42Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-42.png')",
    backgroundPosition: "0 3px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "26px"

  },
  diente42bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-42b.png')",
    backgroundPosition: "0 25px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "28px"
  },

  diente41Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-41.png')",
    backgroundPosition: "0 1px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "26px"

  },
  diente41bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-41b.png')",
    backgroundPosition: "0 23px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "28px"
  },

  diente31bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-31b.png')",
    backgroundPosition: "0 25px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "28px"
  },
  diente32bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-32b.png')",
    backgroundPosition: "0 25px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "28px"
  },
  diente33bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-33b.png')",
    backgroundPosition: "0 24px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "28px"
  },
  diente34bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-34b.png')",
    backgroundPosition: "0 28px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },
  diente35bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-35b.png')",
    backgroundPosition: "0 30px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "31px"
  },
  diente36bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-36b.png')",
    backgroundPosition: "0 37px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente37bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-37b.png')",
    backgroundPosition: "0 35px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente38bCambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-38b.png')",
    backgroundPosition: "0 36px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },

  diente38Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-38.png')",
    backgroundPosition: "0 11px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente37Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-37.png')",
    backgroundPosition: "0 7px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente36Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-36.png')",
    backgroundPosition: "0 14px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "40px"
  },
  diente35Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-35.png')",
    backgroundPosition: "0 1px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "33px"
  },
  diente34Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-34.png')",
    backgroundPosition: "0 5px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },
  diente33Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-33.png')",
    backgroundPosition: "0 7px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "30px"
  },
  diente32Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-32.png')",
    backgroundPosition: "0 3px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "27px"
  },
  diente31Cambio: {
    backgroundImage: "url('/img/extraccion/periodontograma-dientes-abajo-extraccion-31.png')",
    backgroundPosition: "0 1px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "27px"
  },
}

export const styleFurca1 = {
  furcaVacio: {
    background: "rgba(255, 255, 255, 0%) url('/img/vacio.png')",
    backgroundRepeat: 'no-repeat',
    backgroundPosition: 'center',
    backgroundSize: "12px"
  },
  furcaMediolleno: {
    background: "rgba(255, 255, 255, 0%) url('/img/mediolleno.png')",
    backgroundRepeat: 'no-repeat',
    backgroundPosition: 'center',
    backgroundSize: "12px"
  },
  furcaLleno: {
    background: "rgba(255, 255, 255, 0%) url('/img/lleno.png')",
    backgroundRepeat: 'no-repeat',
    backgroundPosition: 'center',
    backgroundSize: "12px"
  },
}


export const placaStyle = {
  placaLleno: {
    background: "rgb(88, 172, 250)"
  }
}

export const sangradoStyle = {
  sangrado:{
    background:"rgb(250, 88, 88)"
  },
  sangradoSupuracion:{
    backgroundImage: "url('/img/sangrado-supuracion.png')",
  }
}