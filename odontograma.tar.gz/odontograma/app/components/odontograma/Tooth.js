'use client'
import React, { useEffect, useReducer, useRef } from 'react';
import useContextMenu from 'contextmenu';
import 'contextmenu/ContextMenu.css';
import './Tooth.css';

function Tooth({ number, positionX, positionY, onChange, option, one, odontogramState }) {
  let initialState = option !== 1 ? odontogramState : {
    Exodoncia: 0,
    Crown: 0,
    Rash: 0,
    DentalMigration: 0,
    Fracture: 0,
    Endodoncia: 0,
    Astriccion: 0,
    Giroversion: 0,
    Sealant: 0,
    Cavities: {
      center: 0,
      top: 0,
      bottom: 0,
      left: 0,
      right: 0
    },
    Restoration: {
      center: 0,
      top: 0,
      bottom: 0,
      left: 0,
      right: 0
    },
    Erosion: {
      top: 0,
      bottom: 0,
      left: 0,
      right: 0
    },
    Diastema: {
      left: 0,
      right: 0
    },
    Giroversion: 0,
    FaultyRestoration: {
      center: 0,
      top: 0,
      bottom: 0,
      left: 0,
      right: 0
    },
  };

  const [toothState, dispatch] = useReducer(reducer, initialState);
  const [contextMenu, useCM] = useContextMenu({ submenuSymbol: '>' });
  const firstUpdate = useRef(true);

  function reducer(toothState, action) {
    switch (action.type) {
      case 'crown':
        return {
          ...toothState,
          Crown: action.value
        };
      case 'rash':
        return {
          ...toothState,
          Rash: action.value
        };
      case 'exodoncia':
        if (toothState.Exodoncia > 0) {
          return toothState;
        }
        return {
          ...toothState,
          Exodoncia: action.value
        };
      case 'dental migration':
        if (toothState.Exodoncia > 0) {
          return toothState;
        }
        return {
          ...toothState,
          DentalMigration: action.value
        };
      case 'fracture':
        if (toothState.Exodoncia > 0) {
          return toothState;
        }
        return {
          ...toothState,
          Fracture: action.value
        };
      case 'carie':
        if (toothState.Exodoncia > 0) {
          return toothState;
        }
        return {
          ...toothState,
          Cavities: setCavities(toothState, action.zone, action.value)
        };
      case 'endodoncia':
        if (toothState.Exodoncia > 0) {
          return toothState;
        }
        return {
          ...toothState,
          Endodoncia: action.value
        };
      case 'astriccion':
        if (toothState.Exodoncia > 0) {
          return toothState;
        }
        return {
          ...toothState,
          Astriccion: action.value
        };
      case 'restoration':
        if (toothState.Exodoncia > 0) {
          return toothState;
        }
        return {
          ...toothState,
          Restoration: setCaries(toothState, action.zone, action.value)
        };
      case 'erosion':
        if (toothState.Exodoncia > 0) {
          return toothState;
        }
        return {
          ...toothState,
          Erosion: setErosion(toothState, action.zone, action.value)
        };
      case 'diastema':
        if (toothState.Exodoncia > 0) {
          return toothState;
        }
        return {
          ...toothState,
          Diastema: setDiastema(toothState, action.zone, action.value)
        };
      case 'giroversion':
        if (toothState.Exodoncia > 0) {
          return toothState;
        }
        return {
          ...toothState,
          Giroversion: action.value
        };
      case 'furcation':
        if (toothState.Exodoncia > 0) {
          return toothState;
        }
        return {
          ...toothState,
          Furcation: action.value
        };
      case 'sealant':
        if (toothState.Exodoncia > 0) {
          return toothState;
        }
        return {
          ...toothState,
          Sealant: action.value
        };
      case 'faultyRestoration':
        if (toothState.Exodoncia > 0) {
          return toothState;
        }
        return {
          ...toothState,
          FaultyRestoration: setFaultyRestoration(toothState, action.zone, action.value)
        };
      case 'clear':
        return {
          Exodoncia: 0,
          Crown: 0,
          Rash: 0,
          DentalMigration: 0,
          Fracture: 0,
          Endodoncia: 0,
          Astriccion: 0,
          Giroversion: 0,
          Sealant: 0,
          Cavities: {
            center: 0,
            top: 0,
            bottom: 0,
            left: 0,
            right: 0
          },
          Restoration: {
            center: 0,
            top: 0,
            bottom: 0,
            left: 0,
            right: 0
          },
          Erosion: {
            top: 0,
            bottom: 0,
            left: 0,
            right: 0
          },
          Diastema: {
            left: 0,
            right: 0
          },
          FaultyRestoration: {
            center: 0,
            top: 0,
            bottom: 0,
            left: 0,
            right: 0
          },
        };
      default:
        throw new Error();
    }
  }

  const crown = (val) => ({
    type: "crown",
    value: val
  });

  const rash = (val) => ({
    type: "rash",
    value: val
  });

  const exodoncia = (val) => ({
    type: "exodoncia",
    value: val
  });

  const dentalMigration = (val) => ({
    type: "dental migration",
    value: val
  });

  const fracture = (val) => ({
    type: "fracture",
    value: val
  });

  const carie = (z, val) => {
    return {
      type: "carie",
      value: val,
      zone: z
    };
  }

  const endodoncia = (val) => ({
    type: "endodoncia",
    value: val
  });

  const astriccion = (val) => ({
    type: "astriccion",
    value: val
  });

  const restoration = (z, val) => ({
    type: "restoration",
    value: val,
    zone: z
  });

  const erosion = (z, val) => {
    return {
      type: "erosion",
      value: val,
      zone: z
    };
  };

  const diastema = (z, val) => ({
    type: "diastema",
    value: val,
    zone: z
  });

  const giroversion = (val) => ({
    type: "giroversion",
    value: val
  });

  const faultyRestoration = (z, val) => ({
    type: "faultyRestoration",
    value: val,
    zone: z
  });

  const sealant = (val) => ({
    type: "sealant",
    value: val
  });

  const clear = () => ({ type: "clear" });

  const doneSubMenu = (place, value) => {
    return {
      'Caries Incipiente': () => dispatch(restoration(place, value)),
      'Caries Moderada': () => dispatch(carie(place, value)),
      'Exodoncia Indicada': () => dispatch(exodoncia(value)),
      'Corona': () => dispatch(crown(value)),
      'Fractura': () => dispatch(fracture(value)),
      'Atrición': () => dispatch(astriccion(value)),
      'Migracion Dental': () => dispatch(dentalMigration(value)),
      'Endodoncia': () => dispatch(endodoncia(value)),
      'Abfracción': () => dispatch(erosion(place, value)),
      'Giroversion': () => dispatch(giroversion(value)),
      'Diastema': () => dispatch(diastema(place, value)),
      'Sellante Indicado': () => dispatch(sealant(value)),
    }
  };

  const todoSubMenu = (place, value) => {
    return {
      'Restauracion Correcta': () => dispatch(carie(place, value)),
      'Restauracion Defectuosa': () => dispatch(faultyRestoration(place, value)),
      'Exodoncia Realizada': () => dispatch(exodoncia(value)),
      'Corona': () => dispatch(crown(value)),
      'Erupción': () => dispatch(rash(value)),
      'Endodoncia': () => dispatch(endodoncia(value)),
      'Giroversion': () => dispatch(giroversion(value)),
      'Sellante Realizado': () => dispatch(sealant(value)),
    }
  };


  const menuConfig = (place) => {
    if (option === 1 || option === 3) {
      return {
        'Realizado': todoSubMenu(place, 2),
        'Indicado': doneSubMenu(place, 1),
        'JSX line': <hr />,
        'Limpiar': () => dispatch(clear()),
      }
    }
    return {}
  };

  let getClassNamesByZone = (zone) => {
    if (toothState.Cavities) {
      if (toothState.Cavities[zone] === 1) {
        return 'to-do';
      } else if (toothState.Cavities[zone] === 2) {
        return 'done';
      }
    }

    if (toothState.FaultyRestoration) {
      if (toothState.FaultyRestoration[zone] === 2) {
        return 'restore';
      }
    }

    return '';
  }

  const translate = `translate(${positionX},${positionY})`;

  function setCavities(prevState, zone, value) {
    if (prevState && prevState.Cavities) {
      if (zone === "all") {
        prevState.Cavities = {
          center: value,
          top: value,
          bottom: value,
          left: value,
          right: value
        }
      } else {
        prevState.Cavities[zone] = value;
      }
      return prevState.Cavities;
    }
  }

  function setErosion(prevState, zone, value) {
    if (prevState && prevState.Erosion) {
      if (zone === "all") {
        prevState.Erosion = {
          top: value,
          bottom: value,
          left: value,
          right: value
        }
      } else {
        prevState.Erosion[zone] = value;
      }
      return prevState.Erosion;
    }
  }

  function setCaries(prevState, zone, value) {
    if (prevState && prevState.Restoration) {
      if (zone === "all") {
        prevState.Restoration = {
          center: value,
          top: value,
          bottom: value,
          left: value,
          right: value
        }
      } else {
        prevState.Restoration[zone] = value;
      }
      return prevState.Restoration;
    }
  }

  function setFaultyRestoration(prevState, zone, value) {
    if (prevState && prevState.FaultyRestoration) {
      if (zone === "all") {
        prevState.FaultyRestoration = {
          center: value,
          top: value,
          bottom: value,
          left: value,
          right: value
        }
      } else {
        prevState.FaultyRestoration[zone] = value;
      }
      return prevState.FaultyRestoration;
    }
  }

  function setDiastema(prevState, zone, value) {
    if (prevState && prevState.Diastema) {
      prevState.Diastema[zone] = value;
      return prevState.Diastema;
    }
  }

  function drawToothActions() {
    let otherFigures = null;
    if (toothState.Exodoncia > 0) {
      otherFigures = (
        <g stroke={toothState.Exodoncia === 1 ? "red" : "blue"}>
          <line x1="0" y1="0" x2="20.5" y2="20.5" strokeWidth="2" />
          <line x1="0" y1="21" x2="21" y2="0" strokeWidth="2" />
        </g>
      );
    }

    if (toothState.Fracture > 0) {
      otherFigures = (
        <g stroke={toothState.Fracture === 1 ? "red" : "blue"}>
          <line x1="15" y1="15" x2="5" y2="5" strokeWidth="2"></line>
        </g>
      );
    }

    if (toothState.DentalMigration > 0) {
      otherFigures = (
        <svg width="100" height="100" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">

          <path d="M50,20 L57,38 H53 V70 H47 V38 H43 Z" fill={toothState.DentalMigration === 1 ? "red" : "blue"} transform="scale(0.3) translate(-10, 90)" />


          <path d="M50,80 L43,62 H47 V30 H53 V62 H57 Z" fill={toothState.DentalMigration === 1 ? "red" : "blue"} transform="scale(0.3) translate(-10, 100)" />


          <path d="M80,50 L62,57 V53 H30 V47 H62 V43 Z" fill={toothState.DentalMigration === 1 ? "red" : "blue"} transform="scale(0.3) translate(-9, 95)" />


          <path d="M20,50 L38,43 V47 H70 V53 H38 V57 Z" fill={toothState.DentalMigration === 1 ? "red" : "blue"} transform="scale(0.3) translate(-15, 95)" />
        </svg>

      );
    }

    if (toothState.Crown > 0) {
      otherFigures = (
        <circle
          cx="10"
          cy="10"
          r="10"
          fillOpacity="0.5"
          fill={toothState.Crown === 1 ? "red" : "blue"}
          stroke={toothState.Crown === 1 ? "red" : "blue"}
          strokeWidth="2"
        />
      );
    }

    if (toothState.Rash > 0) {
      otherFigures = (
        <circle
          cx="10"
          cy="10"
          r="10"
          fill="none"
          stroke={toothState.Rash === 1 ? "red" : "blue"}
          strokeWidth="2"
        />
      );
    }

    if (toothState.Endodoncia > 0) {
      otherFigures = (
        <rect
          key="endodoncia"
          x="9"
          y="1"
          width="2"
          height="20"
          fill={toothState.Endodoncia === 1 ? "red" : "blue"}
        />

      );
    }

    if (toothState.Astriccion > 0) {
      otherFigures = (
        <rect
          x="5"
          y="9"
          width="10"
          height="2"
          fill={toothState.Astriccion === 1 ? "red" : "blue"}
        />
      );
    }

    if (toothState.Restoration.right > 0) {
      otherFigures = (
        <>
          <circle
            cx="19"
            cy="10"
            r="2"
            fill={toothState.Restoration.right === 1 ? "red" : "blue"}
          />

          {toothState.Restoration.top > 0 &&
            <circle
              cx="10"
              cy="2"
              r="2"
              fill={toothState.Restoration.top === 1 ? "red" : "blue"}
            />
          }

          {toothState.Restoration.bottom > 0 &&
            <circle
              cx="10"
              cy="19"
              r="2"
              fill={toothState.Restoration.bottom === 1 ? "red" : "blue"}
            />
          }

          {toothState.Restoration.left > 0 &&
            <circle
              cx="2"
              cy="10"
              r="2"
              fill={toothState.Restoration.left === 1 ? "red" : "blue"}
            />
          }
          {toothState.Restoration.center > 0 &&
            <circle
              cx="10.5"
              cy="10.5"
              r="2"
              fill={toothState.Restoration.center === 1 ? "red" : "blue"}
            />
          }
        </>
      );
    }

    if (toothState.Restoration.top > 0) {
      otherFigures = (
        <>
          <circle
            cx="10"
            cy="2"
            r="2"
            fill={toothState.Restoration.top === 1 ? "red" : "blue"}
          />

          {toothState.Restoration.right > 0 &&
            <circle
              cx="19"
              cy="10"
              r="2"
              fill={toothState.Restoration.right === 1 ? "red" : "blue"}
            />
          }

          {toothState.Restoration.bottom > 0 &&
            <circle
              cx="10"
              cy="19"
              r="2"
              fill={toothState.Restoration.bottom === 1 ? "red" : "blue"}
            />
          }

          {toothState.Restoration.left > 0 &&
            <circle
              cx="2"
              cy="10"
              r="2"
              fill={toothState.Restoration.left === 1 ? "red" : "blue"}
            />
          }

          {toothState.Restoration.center > 0 &&
            <circle
              cx="10.5"
              cy="10.5"
              r="2"
              fill={toothState.Restoration.center === 1 ? "red" : "blue"}
            />
          }
        </>
      );
    }

    if (toothState.Restoration.bottom > 0) {
      otherFigures = (
        <>
          <circle
            cx="10"
            cy="19"
            r="2"
            fill={toothState.Restoration.bottom === 1 ? "red" : "blue"}
          />

          {toothState.Restoration.right > 0 &&
            <circle
              cx="19"
              cy="10"
              r="2"
              fill={toothState.Restoration.right === 1 ? "red" : "blue"}
            />
          }

          {toothState.Restoration.top > 0 &&
            <circle
              cx="10"
              cy="2"
              r="2"
              fill={toothState.Restoration.top === 1 ? "red" : "blue"}
            />
          }
          {toothState.Restoration.left > 0 &&
            <circle
              cx="2"
              cy="10"
              r="2"
              fill={toothState.Restoration.left === 1 ? "red" : "blue"}
            />
          }

          {toothState.Restoration.center > 0 &&
            <circle
              cx="10.5"
              cy="10.5"
              r="2"
              fill={toothState.Restoration.center === 1 ? "red" : "blue"}
            />
          }
        </>
      );
    }

    if (toothState.Restoration.left > 0) {
      otherFigures = (
        <>
          <circle
            cx="2"
            cy="10"
            r="2"
            fill={toothState.Restoration.left === 1 ? "red" : "blue"}
          />

          {toothState.Restoration.right > 0 &&
            <circle
              cx="19"
              cy="10"
              r="2"
              fill={toothState.Restoration.right === 1 ? "red" : "blue"}
            />
          }

          {toothState.Restoration.top > 0 &&
            <circle
              cx="10"
              cy="2"
              r="2"
              fill={toothState.Restoration.top === 1 ? "red" : "blue"}
            />
          }

          {toothState.Restoration.bottom > 0 &&
            <circle
              cx="10"
              cy="19"
              r="2"
              fill={toothState.Restoration.bottom === 1 ? "red" : "blue"}
            />
          }

          {toothState.Restoration.center > 0 &&
            <circle
              cx="10.5"
              cy="10.5"
              r="2"
              fill={toothState.Restoration.center === 1 ? "red" : "blue"}
            />
          }
        </>
      );
    }

    if (toothState.Restoration.center > 0) {
      otherFigures = (
        <>
          <circle
            cx="10.5"
            cy="10.5"
            r="2"
            fill={toothState.Restoration.center === 1 ? "red" : "blue"}
          />

          {toothState.Restoration.right > 0 &&
            <circle
              cx="19"
              cy="10"
              r="2"
              fill={toothState.Restoration.right === 1 ? "red" : "blue"}
            />
          }

          {toothState.Restoration.top > 0 &&
            <circle
              cx="10"
              cy="2"
              r="2"
              fill={toothState.Restoration.top === 1 ? "red" : "blue"}
            />
          }

          {toothState.Restoration.bottom > 0 &&
            <circle
              cx="10"
              cy="19"
              r="2"
              fill={toothState.Restoration.bottom === 1 ? "red" : "blue"}
            />
          }

          {toothState.Restoration.left > 0 &&
            <circle
              cx="2"
              cy="10"
              r="2"
              fill={toothState.Restoration.left === 1 ? "red" : "blue"}
            />
          }
        </>
      );
    }

    if (toothState.Erosion.top > 0) {
      otherFigures = (
        <>
          <rect
            x="0"
            y="0"
            width="20"
            height="1.2"
            fill={toothState.Erosion.top === 1 ? "red" : "blue"}
          />

          {toothState.Erosion.right > 0 &&
            <rect
              x="20"
              y="0"
              width="1.2"
              height="20"
              fill={toothState.Erosion.right === 1 ? "red" : "blue"}
            />
          }

          {toothState.Erosion.left > 0 &&
            <rect
              x="0"
              y="0"
              width="1.2"
              height="20"
              fill={toothState.Erosion.left === 1 ? "red" : "blue"}
            />
          }

          {toothState.Erosion.bottom > 0 &&
            <rect
              x="0"
              y="21"
              width="21"
              height="1.2"
              fill={toothState.Erosion.bottom === 1 ? "red" : "blue"}
            />
          }
        </>
      );
    }

    if (toothState.Erosion.right > 0) {
      otherFigures = (
        <>
          <rect
            x="20"
            y="0"
            width="1.2"
            height="20"
            fill={toothState.Erosion.right === 1 ? "red" : "blue"}
          />

          {toothState.Erosion.top > 0 &&
            <rect
              x="0"
              y="0"
              width="21"
              height="1.2"
              fill={toothState.Erosion.top === 1 ? "red" : "blue"}
            />
          }

          {toothState.Erosion.left > 0 &&
            <rect
              x="0"
              y="0"
              width="1.2"
              height="20"
              fill={toothState.Erosion.left === 1 ? "red" : "blue"}
            />
          }

          {toothState.Erosion.bottom > 0 &&
            <rect
              x="0"
              y="21"
              width="21"
              height="1.2"
              fill={toothState.Erosion.bottom === 1 ? "red" : "blue"}
            />
          }
        </>
      );
    }

    if (toothState.Erosion.bottom > 0) {
      otherFigures = (
        <>
          <rect
            x="0"
            y="21"
            width="20"
            height="1.2"
            fill={toothState.Erosion.bottom === 1 ? "red" : "blue"}
          />

          {toothState.Erosion.right > 0 &&
            <rect
              x="20"
              y="0"
              width="1.2"
              height="20"
              fill={toothState.Erosion.right === 1 ? "red" : "blue"}
            />
          }

          {toothState.Erosion.top > 0 &&
            <rect
              x="0"
              y="0"
              width="21"
              height="1.2"
              fill={toothState.Erosion.top === 1 ? "red" : "blue"}
            />
          }

          {toothState.Erosion.left > 0 &&
            <rect
              x="0"
              y="0"
              width="1.2"
              height="20"
              fill={toothState.Erosion.left === 1 ? "red" : "blue"}
            />
          }
        </>
      );
    }

    if (toothState.Erosion.left > 0) {
      otherFigures = (
        <>
          <rect
            x="0"
            y="0"
            width="1.2"
            height="20"
            fill={toothState.Erosion.left === 1 ? "red" : "blue"}
          />

          {toothState.Erosion.right > 0 &&
            <rect
              x="20"
              y="0"
              width="1.2"
              height="20"
              fill={toothState.Erosion.right === 1 ? "red" : "blue"}
            />
          }

          {toothState.Erosion.top > 0 &&
            <rect
              x="0"
              y="0"
              width="21"
              height="1.2"
              fill={toothState.Erosion.top === 1 ? "red" : "blue"}
            />
          }

          {toothState.Erosion.bottom > 0 &&
            <rect
              x="0"
              y="20"
              width="21"
              height="1.2"
              fill={toothState.Erosion.bottom === 1 ? "red" : "blue"}
            />
          }
        </>
      );
    }

    if (toothState.Prosthesis > 0) {
      otherFigures = (
        <g fill={toothState.Prosthesis === 1 ? "red" : "blue"}>
          <rect x="5" y="5" width="10" height="10" />
          <path d="M5,5 Q10,0 15,5" />
        </g>
      );
    }

    if (toothState.Inlay > 0) {
      otherFigures = (
        <circle
          cx="10"
          cy="10"
          r="6"
          fill="none"
          stroke={toothState.Inlay === 1 ? "red" : "blue"}
          strokeWidth="3"
        />
      );
    }

    if (toothState.Furcation > 0) {
      otherFigures = (
        <polygon
          points="10,15 5,5 15,5"
          fill={toothState.Furcation === 1 ? "red" : "blue"}
        />
      );
    }

    if (toothState.Sealant > 0) {
      otherFigures = (
        <text x="10" y="11" textAnchor="middle" fill={toothState.Sealant === 1 ? "red" : "blue"} fontSize="11" dy=".3em">S</text>

      );
    }

    if (toothState.Giroversion > 0) {
      otherFigures = (
        <path d="M5,30.8 Q10,40 15,30.8" stroke={toothState.Giroversion === 1 ? "red" : "blue"} stroke-width="2" fill="none" />
      );
    }

    if (toothState.Diastema.right > 0) {
      otherFigures = (
        <>
          <rect
            x="20"
            y="25"
            width="2"
            height="10"
            fill={toothState.Diastema.right === 1 ? "red" : "blue"}
          />

          {toothState.Diastema.left > 0 &&
            <rect
              x="0"
              y="25"
              width="2"
              height="10"
              fill={toothState.Diastema.left === 1 ? "red" : "blue"}
            />
          }
        </>
      );
    }

    if (toothState.Diastema.left > 0) {
      otherFigures = (
        <>
          <rect
            x="0"
            y="25"
            width="2"
            height="10"
            fill={toothState.Diastema.left === 1 ? "red" : "blue"}
          />

          {toothState.Diastema.right > 0 &&
            <rect
              x="20"
              y="25"
              width="2"
              height="10"
              fill={toothState.Diastema.right === 1 ? "red" : "blue"}
            />
          }
        </>
      );
    }

    return otherFigures;
  }

  useEffect(() => {
    if (firstUpdate.current) {
      firstUpdate.current = false;
      return;
    }

    if (option === 1) {
      onChange(number, toothState)
      return
    } else {
      if (one) {
        Object.values(one).forEach(value => {
          initialState = value
          onChange(number, toothState)
          // console.log(toothState)
        });
      }


    }
  }, [number, option, one, toothState]);

  useEffect(() => {
    if (option === 3) {
      onChange(number, toothState)
      console.log(number, toothState)
    }
  }, [number, option, one, toothState])

  return (
    <svg className="tooth">
      <g transform={translate}>
        {
          /* 20,0 15,5 15,12 */
        }
        <polygon
          points="0,0 20,0 15,5 15,5 14,5 13,5 12,5 11,5 10,5 9,5 8,5 7,5 6,5"
          onContextMenu={useCM(menuConfig('top'))}
          className={getClassNamesByZone('top')}
        />

        {/* 5,15 15,15 20,20 0,20 */}
        <polygon
          points="5.5,16.6 15.5,16.5  20,21 0.9,21"
          onContextMenu={useCM(menuConfig('bottom'))}
          className={getClassNamesByZone('bottom')}
        />

        {/*  */}
        <polygon
          points="16.5,6 21,1 21,20 16.5,15"
          onContextMenu={useCM(menuConfig('right'))}
          className={getClassNamesByZone('right')}
        />
        {/* 0,0 5,5 5,15 0,20 */}
        <polygon
          points="0,2 5,6 5,15 0,20"
          onContextMenu={useCM(menuConfig('left'))}
          className={getClassNamesByZone('left')}
        />

        {/* 14,5 15,15 5,15 */}
        <polygon
          points="6.3,6.5 15,6.5 15,15 6.3,15"
          onContextMenu={useCM(menuConfig('center'))}
          className={getClassNamesByZone('center')}
        />
        {drawToothActions()}
        <text
          x="6"
          y="30"
          stroke="navy"
          fill="navy"
          strokeWidth="0.1"
          className="tooth">
          {number}
        </text>
      </g>
      {contextMenu}
    </svg>
  )
}

export default Tooth;
