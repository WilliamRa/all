'use client'
import './Odontogram.css';
import Teeth from './Teeth';

import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { Form, Modal, Input, InputNumber, Select, Space, Button, notification } from "antd"
import { useSession } from "next-auth/react";
import { useState, useEffect } from "react";
const { Option } = Select;

function Odontogram(props) {

  let [odontogramState, setOdontogramState] = useState({});
  const [spinActive, setSpinActive] = useState(false)
  const handleToothUpdate = (id, toothState) => {
    if (props.option.option === 1) {
      console.log(id, toothState)
      setOdontogramState(prev => ({ ...prev, [id]: { ...toothState, numero: id } }))
    } else {
      setOdontogramState(prev => ({ ...prev, [id]: { ...toothState, numero: id } }))
    }
  };

  // const [spinActive, setSpinActive] = useState(false)
  const handleCancel = () => {
    props.valorCloseModal()
    setOdontogramState({})

    console.log("props", props)
  }

  async function fetchData(data, callback) {
    await fetch('/api/historiasClinicasOperatorias', {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(async (data) => {
      let a = await data.json()
      if (a.code === 403) {
        notification.error({
          message: a.message
        })
        setSpinActive(false);
      } else {
        notification.success({

        })
        callback()
      }
    })
    callback()

  }

  async function fetchDataPut(data, callback) {
    let respon = await fetch('/api/historiasClinicasOperatorias', {
      method: "PUT",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    callback()

  }
  const handleOk = (values) => {
    if (props.option.option === 1) {
      let data = {
        odontograma: odontogramState,
        id: props.option.id,
        option: props.option.option
      }
      setSpinActive(true);
      fetchData(data, () => {
        props.valorCloseModal()
        //registro_paciente.resetFields()
        setSpinActive(false);
      })

    } else if (props.option.option === 3) {
      let data = {
        odontograma: odontogramState,
        id: props.option.id,
        option: props.option.option
      }
      console.log(data)

      //setSpinActive(true);
      fetchDataPut(data, () => {
        props.valorCloseModal()
        //registro_paciente.resetFields()
        setSpinActive(false);
      })

    }

  }


  const disabled = () => {
    if (props.option.option === 2) {
      return true
    } else {
      return false
    }
  }
  let disable = disabled()

  useEffect(() => {
    console.log("AAAAAAAAAAAAAAAAAAAA")
    if (props.option.option === 4) {

    } else if (props.option.option === 3 || props.option.option === 2) {
      //setOdontogramState(props.one)
      console.log("AAAAAAAAAAAAAAAAAAAA")
    }
  }, [props.option,odontogramState ]);

  return (
    <div className="Odontogram">
      <svg version="1.1" height="70%" width="100%" >
        <Teeth start={18} end={11} x={0} y={0} handleChange={handleToothUpdate} odontogramState={odontogramState} option={props.option.option} one={props.one ? props.one : null} />
        <Teeth start={21} end={28} x={210} y={0} handleChange={handleToothUpdate} odontogramState={odontogramState} option={props.option.option} one={props.one ? props.one : null} />


        <Teeth start={48} end={41} x={0} y={60} handleChange={handleToothUpdate} odontogramState={odontogramState} option={props.option.option} one={props.one ? props.one : null} />
        <Teeth start={31} end={38} x={210} y={60} handleChange={handleToothUpdate} odontogramState={odontogramState} option={props.option.option} one={props.one ? props.one : null} />
      </svg>
      <div style={{ textAlign: 'right' }}>
        <Space direction='vertical'>
          <Space>
            <Form.Item >
              <Button danger onClick={handleCancel}>
                Cancelar
              </Button>
            </Form.Item>
            {props.option.showHide === 'show' &&
              <Form.Item >
                <Button type="primary" htmlType="submit" onClick={handleOk} loading={spinActive}>
                  {props.option.modalFooter}
                </Button>
              </Form.Item>
            }
          </Space>
        </Space>
      </div>
    </div>
  );
}

export default Odontogram;