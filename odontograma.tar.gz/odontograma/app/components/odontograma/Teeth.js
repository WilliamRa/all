'use client'

import Tooth from './Tooth';
import React, { useEffect, useReducer, useRef, useState } from 'react';

function Teeth({ start, end, x, y, handleChange, option, one, odontogramState }) {
  let tooths = getArray(start, end);
  //let [status, setStatus] = useState(true)
 

  const dataModel = (data) => {
    let limpia = {
      numero: data.numero,
      id: data.id,
      Cavities: {
        center: data.cavidad_centro,
        top: data.cavidad_arriba,
        bottom: data.cavidad_abajo,
        left: data.cavidad_izquierda,
        right: data.cavidad_derecha
      },
      Exodoncia: data.exodoncia,
      Crown: data.corona,
      Rash: data.rash,
      Fracture: data.fractura,
      Endodoncia: data.endodoncia,
      Astriccion: data.astriccion,
      DentalMigration: data.dental_migration,
      Sealant: data.sealant,
      Restoration: {
        center: data.restauracion_center,
        top: data.restauracion_top,
        bottom: data.restauracion_bottom,
        left: data.restauracion_left,
        right: data.restauracion_right
      },
      Erosion: {
        top: data.erosion_top,
        bottom: data.erosion_bottom,
        left: data.erosion_left,
        right: data.erosion_right,
      },
      Diastema: {
        left: data.diastema_left,
        right: data.diastema_right
      },
      Giroversion: data.giroversion,
      FaultyRestoration: {
        center: data.restauracion_defectuosa_center,
        top: data.restauracion_defectuosa_top,
        bottom: data.restauracion_defectuosa_bottom,
        left: data.restauracion_defectuosa_left,
        right:data.restauracion_defectuosa_right,
      },
      paciente_id: data.paciente_id
    }
    return limpia
  }
  return (
    <g transform="scale(1.3)" id="gmain">
      {one &&
        tooths.map((i) =>
          one.map((data, index) => {
            if (data.numero === i) {
              let cleanData = dataModel(data)
              return (
                <Tooth onChange={handleChange}
                  key={i}
                  number={i}
                  positionY={y}
                  positionX={Math.abs((i - start) * 25) + x}
                  option={option}
                  one={one ? one : null}
                  odontogramState={cleanData}
                />
              )
            }
          })
        )
      }
      {option ===1 &&
        tooths.map((i) => (
          <Tooth onChange={handleChange}
            key={i}
            number={i}
            positionY={y}
            positionX={Math.abs((i - start) * 25) + x}
            option={option}
            odontogramState={odontogramState}
          />
        ))
      }

    </g>
  )
}

function getArray(start, end) {
  if (start > end) return getInverseArray(start, end);

  let list = [];
  for (var i = start; i <= end; i++) {
    list.push(i);
  }

  return list;
}

function getInverseArray(start, end) {
  let list = [];

  for (var i = start; i >= end; i--) {
    list.push(i);
  }

  return list;
}

export default Teeth;