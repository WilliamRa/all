import { prisma } from "@/app/db/db";
import { NextResponse } from "next/server";

export async function GET(req) {
  let clean = []
  let allHistorias = await prisma.historia_familiar.findMany()

  allHistorias.map(data => {
    clean.push({
      id: data.id,
      enfermedades_cardiobasculares: data.enfermedades_cardiobasculares === 0 ? "NO" : "SI",
      enfermedades_hemorragicas: data.enfermedades_hemorragicas === 0 ? "NO" : "SI",
      enfermedades_endocrinas: data.enfermedades_endocrinas === 0 ? "NO" : "SI",
      enfermedades_venereas: data.enfermedades_venereas === 0 ? "NO" : "SI",
      alergias: data.alergias === 0 ? "NO" : "SI",
      cancer: data.cancer === 0 ? "NO" : "SI",
      otras_enfermedades: data.otras_enfermedades === 0 ? "NO" : "SI",
      key: data.id
    })
  })

  let full = {
    allHistorias: clean
  }
  return NextResponse.json(full)


}

export async function POST(req) {
  let data = await req.json()

  switch (data.option) {
    case 1:

      const paciente = await prisma.paciente.findUnique({
        where: {
          id: data.id
        }
      })

      const existePeriodonto = await prisma.periodonto.findMany({
        where: {
          paciente_id: paciente.id
        }
      })

      if (existePeriodonto.length > 0) return NextResponse.json({
        message: "Solo se puede registrar 1 sola Diagrama por paciente",
        code: 403
      }, { status: 403 })

      let dientesParaPrisma = await Object.keys(data.periodonto).map(key => {
        return {
          numero: key,
          ...data.periodonto[key]
        };
      });
      const register = await Promise.all(dientesParaPrisma);

      for (let diente in register) {
        let tooth = register[diente];
        let enciaA = tooth.encia && tooth.encia[0] ? tooth.encia[0].encia : 0;
        let enciaB = tooth.encia && tooth.encia[1] ? tooth.encia[1].encia : 0;
        let enciaC = tooth.encia && tooth.encia[2] ? tooth.encia[2].encia : 0;
        let sondajeA = tooth.encia && tooth.encia[0] ? tooth.encia[0].sondaje : 0;
        let sondajeB = tooth.encia && tooth.encia[1] ? tooth.encia[1].sondaje : 0;
        let sondajeC = tooth.encia && tooth.encia[2] ? tooth.encia[2].sondaje : 0;

        let registerPeriodonto = await prisma.periodonto.create({
          data: {
            numero_diente: register[diente].numero,
            paciente_id: paciente.id,
            estado_dental: {
              create: {
                movilidad: register[diente].movilidad,
                nota: "",
                status_vestibular: register[diente].statusVestibular,
                status_palatino: register[diente].statusPalatino,

              }
            },
            furca: {
              create: {
                furca_a: register[diente].furca.furcaA,
                furca_b: register[diente].furca.furcaB,
              }
            },
            placa_periodonto: {
              create: {
                placa_a: register[diente].placa.placaA ? 1 : 0,
                placa_b: register[diente].placa.placaB ? 1 : 0,
                placa_c: register[diente].placa.placaC ? 1 : 0
              }
            },
            sangrado: {
              create: {
                sangrado_a: register[diente].sangrado.sangradoA,
                sangrado_b: register[diente].sangrado.sangradoB,
                sangrado_c: register[diente].sangrado.sangradoC
              }
            },
            EnciaInput: {
              create: {
                encia_input_a: register[diente].enciaInput.enciaInputA === "" ? "0" : register[diente].enciaInput.enciaInputA,
                encia_input_b: register[diente].enciaInput.enciaInputB === "" ? "0" : register[diente].enciaInput.enciaInputB,
                encia_input_c: register[diente].enciaInput.enciaInputC === "" ? "0" : register[diente].enciaInput.enciaInputC,
              }
            },
            SondajeInput: {
              create: {
                sondaje_input_a: register[diente].sondajeInput.sondajeInputA === "" ? "0" : register[diente].sondajeInput.sondajeInputA,
                sondaje_input_b: register[diente].sondajeInput.sondajeInputB === "" ? "0" : register[diente].sondajeInput.sondajeInputB,
                sondaje_input_c: register[diente].sondajeInput.sondajeInputC === "" ? "0" : register[diente].sondajeInput.sondajeInputC
              }
            },
            encia: {
              create: {
                encia_a: enciaA,
                encia_b: enciaB,
                encia_c: enciaC,
                sondaje_a: sondajeA,
                sondaje_b: sondajeB,
                sondaje_c: sondajeC,

              }
            },

          }
        })
      }
      prisma.$disconnect()
      return NextResponse.json({
        message: "exito"
      })

    case 2:
      const one = await prisma.periodonto.findMany({
        where: {
          paciente_id: data.id
        },
        include: {
          encia: true,
          furca: true,
          EnciaInput: true,
          SondajeInput: true,
          sangrado: true,
          estado_dental: true,
          placa_periodonto: true
        }
      })

      if (one.length === 0) return NextResponse.json({
        message: "No hay Registro Para este usuario",
        code: 403
      }, {
        status: 403
      })

      const transformedData = {};


      one.forEach((diente) => {
        const enciaData = diente.encia[0]; // Asumiendo que encia siempre tiene un solo objeto como mencionaste

        const encia = [
          { name: "A", encia: enciaData.encia_a, sondaje: enciaData.sondaje_a, nulo: 10 },
          { name: "B", encia: enciaData.encia_b, sondaje: enciaData.sondaje_b, nulo: 10 },
          { name: "C", encia: enciaData.encia_c, sondaje: enciaData.sondaje_c, nulo: 10 },
        ];

        transformedData[diente.numero_diente] = {
          id: diente.id,
          statusVestibular: diente.estado_dental[0].status_vestibular ,
          statusPalatino: diente.estado_dental[0].status_palatino,
          movilidad: diente.estado_dental[0].movilidad,
          nota: diente.estado_dental[0].nota,
          furca: {
            furcaA: diente.furca[0].furca_a,
            furcaB: diente.furca[0].furca_b
          },
          placa: {
            placaA: diente.placa_periodonto[0].placa_a === 1 ? true : false,
            placaB: diente.placa_periodonto[0].placa_b === 1 ? true : false,
            placaC: diente.placa_periodonto[0].placa_c === 1 ? true : false,
          },
          sangrado: {
            sangradoA: diente.sangrado[0].sangrado_a,
            sangradoB: diente.sangrado[0].sangrado_b,
            sangradoC: diente.sangrado[0].sangrado_c
          },
          encia: encia,
          enciaInput: {
            enciaInputA: diente.EnciaInput[0].encia_input_a,
            enciaInputB: diente.EnciaInput[0].encia_input_b,
            enciaInputC: diente.EnciaInput[0].encia_input_c,
          },
          sondajeInput: {
            sondajeInputA: diente.SondajeInput[0].sondaje_input_a,
            sondajeInputB: diente.SondajeInput[0].sondaje_input_b,
            sondajeInputC: diente.SondajeInput[0].sondaje_input_c,
          }
        };
      });
      console.log(transformedData)
      return NextResponse.json({ one: transformedData })

    case 3:
      const ones = await prisma.periodonto.findMany({
        where: {
          paciente_id: data.id
        },
        include: {
          encia: true,
          furca: true,
          EnciaInput: true,
          SondajeInput: true,
          sangrado: true,
          estado_dental: true,
          placa_periodonto: true
        }
      })
      if (ones.length === 0) return NextResponse.json({
        message: "No hay Registro Para este usuario",
        code: 403
      }, {
        status: 403
      })

      const transformed = {};


      ones.forEach((diente) => {
        const enciaData = diente.encia[0]; // Asumiendo que encia siempre tiene un solo objeto como mencionaste

        const encia = [
          { name: "A", encia: enciaData.encia_a, sondaje: enciaData.sondaje_a, nulo: 10 },
          { name: "B", encia: enciaData.encia_b, sondaje: enciaData.sondaje_b, nulo: 10 },
          { name: "C", encia: enciaData.encia_c, sondaje: enciaData.sondaje_c, nulo: 10 },
        ];

        transformed[diente.numero_diente] = {
          id: diente.id,
          statusVestibular: diente.estado_dental[0].status_vestibular,
          statusPalatino: diente.estado_dental[0].status_palatino,
          movilidad: diente.estado_dental[0].movilidad,
          nota: diente.estado_dental[0].nota,
          furca: {
            furcaA: diente.furca[0].furca_a,
            furcaB: diente.furca[0].furca_b
          },
          placa: {
            placaA: diente.placa_periodonto[0].placa_a === 1 ? true : false,
            placaB: diente.placa_periodonto[0].placa_b === 1 ? true : false,
            placaC: diente.placa_periodonto[0].placa_c === 1 ? true : false,
          },
          sangrado: {
            sangradoA: diente.sangrado[0].sangrado_a,
            sangradoB: diente.sangrado[0].sangrado_b,
            sangradoC: diente.sangrado[0].sangrado_c
          },
          encia: encia,
          enciaInput: {
            enciaInputA: diente.EnciaInput[0].encia_input_a,
            enciaInputB: diente.EnciaInput[0].encia_input_b,
            enciaInputC: diente.EnciaInput[0].encia_input_c,
          },
          sondajeInput: {
            sondajeInputA: diente.SondajeInput[0].sondaje_input_a,
            sondajeInputB: diente.SondajeInput[0].sondaje_input_b,
            sondajeInputC: diente.SondajeInput[0].sondaje_input_c,
          }
        };
      });

      return NextResponse.json({ one: transformed })

    default:
      break;
  }
}

export async function PUT(req) {
  let data = await req.json()
  let dientesParaPrisma = await Object.keys(data.periodonto).map(key => {
    return {
      numero: key,
      ...data.periodonto[key]
    };
  });
  const update = await Promise.all(dientesParaPrisma);
  for (let diente in update) {
    let tooth = update[diente];
    let enciaA = tooth.encia && tooth.encia[0] ? tooth.encia[0].encia : 0;
    let enciaB = tooth.encia && tooth.encia[1] ? tooth.encia[1].encia : 0;
    let enciaC = tooth.encia && tooth.encia[2] ? tooth.encia[2].encia : 0;
    let sondajeA = tooth.encia && tooth.encia[0] ? tooth.encia[0].sondaje : 0;
    let sondajeB = tooth.encia && tooth.encia[1] ? tooth.encia[1].sondaje : 0;
    let sondajeC = tooth.encia && tooth.encia[2] ? tooth.encia[2].sondaje : 0;


    let updatedata = await prisma.periodonto.update({
      where: {
        id: update[diente].id
      },
      data: {
        numero_diente: update[diente].numero,
        estado_dental: {
          updateMany: {
            where: { periodonto_id: update[diente].id },
            data: {
              movilidad: update[diente].movilidad,
              nota: "",
              status_vestibular: update[diente].statusVestibular,
              status_palatino: update[diente].statusPalatino,
            }
          }
        },
        furca: {
          updateMany: {
            where: { periodonto_id: update[diente].id },
            data: {
              furca_a: update[diente].furca.furcaA,
              furca_b: update[diente].furca.furcaB,
            }
          }
        },
        placa_periodonto: {
          updateMany: {
            where: { periodonto_id: update[diente].id },
            data: {
              placa_a: update[diente].placa.placaA ? 1 : 0,
              placa_b: update[diente].placa.placaB ? 1 : 0,
              placa_c: update[diente].placa.placaC ? 1 : 0,
            }
          }
        },
        sangrado: {
          updateMany: {
            where: { periodonto_id: update[diente].id },
            data: {
              sangrado_a: update[diente].sangrado.sangradoA,
              sangrado_b: update[diente].sangrado.sangradoB,
              sangrado_c: update[diente].sangrado.sangradoC,
            }
          }
        },
        EnciaInput: {
          updateMany: {
            where: { periodonto_id: update[diente].id },
            data: {
              encia_input_a: update[diente].enciaInput.enciaInputA,
              encia_input_b: update[diente].enciaInput.enciaInputB,
              encia_input_c: update[diente].enciaInput.enciaInputC,
            }
          }
        },
        SondajeInput: {
          updateMany: {
            where: { periodonto_id: update[diente].id },
            data: {
              sondaje_input_a: update[diente].sondajeInput.sondajeInputA,
              sondaje_input_b: update[diente].sondajeInput.sondajeInputB,
              sondaje_input_c: update[diente].sondajeInput.sondajeInputC,
            }
          }
        },
        encia: {
          updateMany: {
            where: { periodonto_id: update[diente].id },
            data: {
              encia_a: enciaA,
              encia_b: enciaB,
              encia_c: enciaC,
              sondaje_a: sondajeA,
              sondaje_b: sondajeB,
              sondaje_c: sondajeC,
            }
          }
        }
      }
    });
  }

  prisma.$disconnect();
  return NextResponse.json({ message: "Actualización exitosa" });
}
