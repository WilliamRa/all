import { prisma } from "@/app/db/db";
import { PrismaClient } from "@prisma/client";
import { NextResponse } from "next/server";

export async function POST(req) {
  let data = await req.json()

  let registerEstudiante = await prisma.estudiante.create({
    data: {
      nombres: data.nombres,
      apellidos: data.apellidos,
      ano: data.ano,
      grupo: data.grupo,
      correo: data.correo,
      contrasena: data.contraseña,
      cedula: {
        create: {
          cedula_num: data.cedula
        }
      },
      rol: {
        connect: {
          id: 1
        }
      }

    }
  })
  prisma.$disconnect()

  if (!registerEstudiante) return NextResponse.json({},{
    status: 403,
    statusText:"Estudiante ya esta registrado"
  })

  return NextResponse.json({
    status: 200,
  },{
    status: 200
  })
}
