import { capitalizeFirstLetter, statusString } from "@/app/components/general";
import { prisma } from "@/app/db/db";
import { NextResponse } from "next/server";

export async function POST(req) {
  let data = await req.json()

  switch (data.option) {
    case 0:
      let clean = []
      let estudianteOroot = await prisma.usuarios.findFirst({
        where: {
          id: data.usuario.id,
          correo: data.usuario.correo
        }
      })


      let allHistorias = await prisma.radiografias.findMany({
        where: {
          historia_clinica: {
            some: {
              paciente: {
                some: {
                  estudiante_id: data.usuario.id
                }
              }
            }
          }
        },
        include: {
          historia_clinica: {
            select: {
              numero_historia: true
            }
          }
        }
      })

      if (estudianteOroot) {
        let allHistoriasRoot = await prisma.radiografias.findMany({
          include: {
            historia_clinica: {
              select: {
                numero_historia: true
              }
            }
          }
        })

        allHistoriasRoot.map(data => {
          clean.push({
            ...data,
            key: data.id,
            numero_historia: data.historia_clinica[0].numero_historia
          })
        })
        prisma.$disconnect()
        return NextResponse.json({
          allHistorias: clean
        })
      }



      allHistorias.map(data => {
        clean.push({
          ...data,
          numero_historia: data.historia_clinica[0].numero_historia,
          key: data.id
        })
      })

      let full = {
        allHistorias: clean
      }
      prisma.$disconnect()
      return NextResponse.json(full)

    case 1:

      const numeroHistoria = await prisma.historia_clinica.findUnique({
        where: {
          numero_historia: data.numero_historia
        }
      })

      if (!numeroHistoria.id) return NextResponse.json({
        code: 403,
        message: "numero de historia duplicado o inexistente"
      }, { status: 403 })

      if (numeroHistoria.radiografias_id) return NextResponse.json({
        message: "Solo se puede registrar 1 registro por paciente",
        code: 403
      }, { status: 403 })


      const registrarradiografias = await prisma.radiografias.create({
        data: {
          descripcion: data.descripcion,
          radiografias: data.radiografias,
          status: 0
        },
        include: {
          historia_clinica: {
            select: {
              numero_historia: true
            }
          }
        }
      })

      const actualizar = await prisma.historia_clinica.update({
        where: {
          id: numeroHistoria.id
        },
        data: {
          radiografias_id: registrarradiografias.id
        },
      })
      prisma.$disconnect()

      if (global.io) {
        global.io.emit('updateRadiografias', {
          ...registrarradiografias,
          key: registrarradiografias.id,
          numero_historia: numeroHistoria.numero_historia
        });
      }
      return NextResponse.json({
        actualizar: "exito"
      })

    case 2:
      let one = await prisma.radiografias.findFirst({
        where: {
          id: data.id
        },
        include: {
          historia_clinica: {
            select: {
              numero_historia: true
            }
          }
        }
      })
      prisma.$disconnect()
      return NextResponse.json({ one })

    case 3:
      let ones = await prisma.radiografias.findFirst({
        where: {
          id: data.id
        },
        include: {
          historia_clinica: {
            select: {
              numero_historia: true
            }
          }
        }
      })
      prisma.$disconnect()
      return NextResponse.json({ one: ones })

    case 4:
      const updateRadiografias = await prisma.radiografias.update({
        where: {
          id: data.id
        },
        data: {
          status: data.status
        },
        include: {
          historia_clinica: {
            select: {
              numero_historia: true
            }
          }
        }
      })
      prisma.$disconnect()

      if (global.io) {
        global.io.emit('updateRadiografias', {
          ...updateRadiografias,
          key: updateRadiografias.id,
          numero_historia: updateRadiografias.historia_clinica[0].numero_historia,
        });
      }
      prisma.$disconnect()
      return NextResponse.json({
        message: "Se a Corregido la Historia Clinica"
      })
    default:
      break;
  }
}


export async function PUT(req) {
  let data = await req.json()
  const updateRadiografias = await prisma.radiografias.update({
    where: {
      id: data.id
    },
    data: {
      descripcion: data.descripcion,
      radiografias: data.radiografias
    },
    include: {
      historia_clinica: {
        select: {
          numero_historia: true
        }
      }
    }
  })
  prisma.$disconnect()

  if (global.io) {
    global.io.emit('updateRadiografias', {
      ...updateRadiografias,
      key: updateRadiografias.id
    });
  }
  return NextResponse.json("put")
}
