import { prisma } from "@/app/db/db";
import NextAuth from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"

export const authOptions = {
  pages: {
    signIn: '/auth/login',
  },
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        correo: { label: "Correo electrónico", type: "email", placeholder: "correo@email.com" },
        contraseña: { label: "Contraseña", type: "password" }
      },
      async authorize(credentials) {
        const userRoot = await prisma.usuarios.findFirst({
          where: {
            correo: credentials.correo,
            contrasena: credentials.contraseña,
          },
          include: {
            rol: true
          }
        });
        const user = await prisma.estudiante.findFirst({
          where: {
            correo: credentials.correo,
            contrasena: credentials.contraseña,
          },
          include: {
            rol: true
          }
        });

        if (!userRoot) {
          if (!user) throw new Error("Correo o Contraseña Incorrecta, por favor verifique")
          return { name: user }
        } else {
          prisma.$disconnect()
          return {
            name: userRoot
          }
        }
        return null
      },
    }),
  ],
  //adapter: PrismaAdapter(prisma),
  callbacks: {
    async jwt({ token, account }) {
      // Persist the OAuth access_token to the token right after signin
      if (account) {
        token.accessToken = account.access_token
      }
      return token
    },
    async session({ session, token, user }) {
      // Send properties to the client, like an access_token from a provider.
      session.accessToken = token.accessToken
      return session
    },

    async redirect({ url, baseUrl }) {
      console.log(url, baseUrl)
      if (url.startsWith(baseUrl)) {
        return url;
      } else {
        // Si la URL no comienza con la URL base, redirige al usuario a la ruta /dashboard
        return baseUrl + "/dashboard";
      }
    }
  }
}

const handler = NextAuth(authOptions)
export { handler as GET, handler as POST, handler as PUT }
