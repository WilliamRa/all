import { prisma } from "@/app/db/db";
import { NextResponse } from "next/server";


export async function POST(req) {
  let data = await req.json()
  switch (data.option) {
    case 1:
      const dientesParaPrisma = await Object.values(data.odontograma).map((diente) => {
        console.log(diente)
        return {
          cavidad_abajo: diente.Cavities.bottom,
          cavidad_arriba: diente.Cavities.top,
          cavidad_centro: diente.Cavities.center,
          cavidad_derecha: diente.Cavities.right,
          cavidad_izquierda: diente.Cavities.left,
          exodoncia: diente.Exodoncia,
          corona: diente.Crown,
          rash: diente.Rash,
          fractura: diente.Fracture,
          dental_migration: diente.DentalMigration,
          restauracion_top: diente.Restoration.top,
          restauracion_right: diente.Restoration.right,
          restauracion_bottom: diente.Restoration.bottom,
          restauracion_center: diente.Restoration.center,
          restauracion_left: diente.Restoration.left,
          endodoncia: diente.Endodoncia,
          periodontal: diente.Periodontal,
          astriccion: diente.Astriccion,
          erosion_top: diente.Erosion.top,
          erosion_right: diente.Erosion.right,
          erosion_bottom: diente.Erosion.bottom,
          erosion_left: diente.Erosion.left,
          giroversion: diente.Giroversion,
          diastema_left: diente.Diastema.left,
          diastema_right: diente.Diastema.right,
          restauracion_defectuosa_top: diente.FaultyRestoration.top,
          restauracion_defectuosa_right: diente.FaultyRestoration.right,
          restauracion_defectuosa_bottom: diente.FaultyRestoration.bottom,
          restauracion_defectuosa_left: diente.FaultyRestoration.left,
          restauracion_defectuosa_center: diente.FaultyRestoration.center,
          sealant: diente.Sealant,
          paciente_id: data.id,
          numero: diente.numero,
        }
      });


      const dientesParaPrismaPromise = await Promise.all(dientesParaPrisma);

      const dienteExiste = await prisma.diente.findMany({
        where: {
          paciente_id: data.id
        }
      })
      if (dienteExiste.length > 0) return NextResponse.json({
        message: "Solo se puede realizar un registro por paciente",
        code: 403
      }, { status: 403 })

      const dientesCreados = await prisma.diente.createMany({
        data: dientesParaPrismaPromise,
      });

      prisma.$disconnect()
      return NextResponse.json({

      })
    case 2:
      let one = await prisma.diente.findMany({
        where: {
          paciente_id: data.id
        },
      })
      prisma.$disconnect()
      return NextResponse.json({ one })
    case 3:
      let ones = await prisma.diente.findMany({
        where: {
          paciente_id: data.id
        },
      })
      prisma.$disconnect()
      return NextResponse.json({ one: ones })
    default:
      break;
  }
}

export async function PUT(req) {
  let data = await req.json()

  const dientesParaPrisma = Object.values(data.odontograma).map((diente) => ({
    cavidad_abajo: diente.Cavities.bottom,
    cavidad_arriba: diente.Cavities.top,
    cavidad_centro: diente.Cavities.center,
    cavidad_derecha: diente.Cavities.right,
    cavidad_izquierda: diente.Cavities.left,
    exodoncia: diente.Exodoncia,
    corona: diente.Crown,
    rash: diente.Rash,
    fractura: diente.Fracture,
    dental_migration: diente.DentalMigration,
    restauracion_top: diente.Restoration.top,
    restauracion_right: diente.Restoration.right,
    restauracion_bottom: diente.Restoration.bottom,
    restauracion_center: diente.Restoration.center,
    restauracion_left: diente.Restoration.left,
    endodoncia: diente.Endodoncia,
    periodontal: diente.Periodontal,
    astriccion: diente.Astriccion,
    erosion_top: diente.Erosion.top,
    erosion_right: diente.Erosion.right,
    erosion_bottom: diente.Erosion.bottom,
    erosion_left: diente.Erosion.left,
    giroversion: diente.Giroversion,
    diastema_left: diente.Diastema.left,
    diastema_right: diente.Diastema.right,
    restauracion_defectuosa_top: diente.FaultyRestoration.top,
    restauracion_defectuosa_right: diente.FaultyRestoration.right,
    restauracion_defectuosa_bottom: diente.FaultyRestoration.bottom,
    restauracion_defectuosa_left: diente.FaultyRestoration.left,
    restauracion_defectuosa_center: diente.FaultyRestoration.center,
    sealant: diente.Sealant,
    paciente_id: data.id,
    numero: diente.numero,
  }));
  const dientesParaPrismaPromise = await Promise.all(dientesParaPrisma);
  console.log(dientesParaPrismaPromise)
  dientesParaPrismaPromise.map(async (datos) => {
    const dientesCreados = await prisma.diente.updateMany({
      where: {
        paciente_id: data.id,
        numero: datos.numero
      },
      data: datos,
    });
  })
  prisma.$disconnect()
  return NextResponse.json("put")
}