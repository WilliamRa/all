import { capitalizeFirstLetter, statusString } from "@/app/components/general";
import { prisma } from "@/app/db/db";
import { NextResponse } from "next/server";

export async function GET(req) {
  let clean = []
  let allHistorias = await prisma.historia_clinica.findMany()

  allHistorias.map(data => {
    clean.push({ ...data, key: data.id })
  })

  let full = {
    allHistorias: clean
  }
  prisma.$disconnect()
  return NextResponse.json(full)
}

export async function POST(req) {
  let data = await req.json()
  switch (data.option) {
    case 0:
      let clean = []
      let estudianteOroot = await prisma.usuarios.findFirst({
        where: {
          id: data.usuario.id,
          correo: data.usuario.correo
        }
      })

      if (estudianteOroot) {
        let allHistorias = await prisma.historia_clinica.findMany()

        allHistorias.map(data => {
          clean.push({
            ...data,
            key: data.id,
          })
        })
        prisma.$disconnect()
        return NextResponse.json({
          allHistorias: clean
        })
      }

      let allHistorias = await prisma.historia_clinica.findMany({
        where: {
          paciente: {
            some: {
              estudiante_id: data.usuario.id,
            }
          }
        }
      })

      allHistorias.map(data => {
        clean.push({
          ...data,
          key: data.id,
          numero_historia: data.numero_historia,
          enfermedad_actual: capitalizeFirstLetter(data.enfermedad_actual),
          motivo_consulta: capitalizeFirstLetter(data.motivo_consulta),
          status: data.status
        })
      })

      let full = {
        allHistorias: clean
      }
      prisma.$disconnect()
      return NextResponse.json(full)

    case 1:
      const cedula = await prisma.cedula.findUnique({
        where: {
          cedula_num: data.cedula
        }
      })

      if (!cedula) return NextResponse.json({
        status: 403,
        message: "Cedula Inexistenete"
      }, {
        status: 403,
      })

      const existeHistoriaEnUsuario = await prisma.paciente.findFirst({
        where: {
          cedula_id: cedula.id
        }
      })

      if (existeHistoriaEnUsuario.historia_clinica_id) return NextResponse.json({
        status: 403,
        message: "Paciente Ya Posee una Historia Clinica"
      }, {
        status: 403,
      })

      const registrarHistoriaClinica = await prisma.historia_clinica.create({
        data: {
          fecha: data.fecha,
          enfermedad_actual: data.enfermedad_actual,
          motivo_consulta: data.motivo_consulta,
          numero_historia: data.numero_historia,
          status: 0
        }
      })

      const actualizar = await prisma.paciente.update({
        where: { id: existeHistoriaEnUsuario.id },
        data: {
          historia_clinica_id: registrarHistoriaClinica.id
        }
      })
      prisma.$disconnect()

      if (global.io) {
        global.io.emit('updateHistoriasClinicas', {
          ...registrarHistoriaClinica,
          key: registrarHistoriaClinica.numero_historia
        });
      }
      return NextResponse.json({
        paciente: "exito"
      })

    case 2:
      let one = await prisma.historia_clinica.findFirst({
        where: {
          id: data.id
        },
      })
       prisma.$disconnect()
      return NextResponse.json({ one })
    case 3:
      let ones = await prisma.historia_clinica.findFirst({
        where: {
          id: data.id
        },
      })
      prisma.$disconnect()
      return NextResponse.json({ one: ones })
    default:
      break;
  }
}

export async function PUT(req) {
  let data = await req.json()
  const updateHistoriasClinicas = await prisma.historia_clinica.update({
    where: {
      id: data.id
    },
    data: {
      fecha: data.fecha,
      enfermedad_actual: data.enfermedad_actual,
      motivo_consulta: data.motivo_consulta,
      numero_historia: data.numero_historia
    }
  })
  prisma.$disconnect()

  if (global.io) {
    global.io.emit('updateHistoriasClinicas', {
      ...updateHistoriasClinicas,
      key: updateHistoriasClinicas.numero_historia
    });
  }
  return NextResponse.json("put")
}
