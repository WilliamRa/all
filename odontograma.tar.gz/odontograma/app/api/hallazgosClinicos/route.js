import { prisma } from "@/app/db/db";
import dayjs from "dayjs";
import { NextResponse } from "next/server";


export async function GET(req) {
  let clean = []
  let allHistorias = await prisma.hallazgos_clinicos.findMany()

  allHistorias.map(data => {
    clean.push({
      ...data,
      key: data.id,
      fecha: dayjs(data.fecha)
    })
  })

  let full = {
    allHistorias: clean
  }
  prisma.$disconnect()
  return NextResponse.json(full)
}

export async function POST(req) {
  let data = await req.json()

  switch (data.option) {
    case 0:
      let clean = []
      let sexo = await prisma.sexo.findMany()
      let estudianteOroot = await prisma.usuarios.findFirst({
        where: {
          id: data.usuario.id,
          correo: data.usuario.correo
        }
      })
      if (estudianteOroot) {
        let allhallazgosClinicosRoot = await prisma.hallazgos_clinicos.findMany()
        
        console.log("ROOT",allhallazgosClinicosRoot)
        allhallazgosClinicosRoot.map(data => {
          clean.push({
            ...data,
            key: data.id,
            fecha: dayjs(data.fecha)
          })
        })

        prisma.$disconnect()
        return NextResponse.json({
          sexo,
          allHistorias: clean
        })
      }

      let allHistorias = await prisma.hallazgos_clinicos.findMany({
        where: {
          historia_clinica: {
            some: {
              paciente: {
                some: {
                  estudiante_id: data.usuario.id
                }
              }
            }
          }
        }
      })

      allHistorias.map(data => {
        clean.push({
          ...data,
          key: data.id,
          fecha: dayjs(data.fecha)
        })
      })

      let full = {
        allHistorias: clean
      }
      prisma.$disconnect()
      return NextResponse.json(full)
    case 1:

      const numeroHistoria = await prisma.historia_clinica.findUnique({
        where: {
          numero_historia: data.hallazgos.numero_historia
        }
      })

      if (!numeroHistoria) return NextResponse.json({
        message: "Numero de historia no se encuentra registrado",
        code: 403
      }, { status: 403 })


      if (numeroHistoria.diagnostico_id) return NextResponse.json({
        message: "Solo se puede registrar 1 diagnostico por Historia Clinica",
        code: 403
      }, { status: 403 })

      if (numeroHistoria.hallazgos_clinicos_id) return NextResponse.json({
        message: "Solo se puede Registrar 1 solo hallazgo Clinico por paciente",
        code: 403
      }, { status: 403 })

      const registrarHallazgosClinicos = await prisma.hallazgos_clinicos.create({
        data: {
          fecha: data.hallazgos.fecha,
          presion_arterial: data.hallazgos.presion_arterial,
          pulso: data.hallazgos.pulso,
          ferecuencia_respiratoria: data.hallazgos.frecuencia_respiratoria,
          temperatura: data.hallazgos.temperatura,
          tejidos_blandos: data.hallazgos.tejidos_blandos,
          tejidos_duros: data.hallazgos.tejidos_duros,
          encia: data.hallazgos.encias,
          factores_etiologicos: data.hallazgos.factores_etiologicos,
          examen_oclusal: data.hallazgos.examen_oclusal,
          trastronos_mandibulares: {
            create: {
              dolor_atn: data.trastornosMandibulares.dolor_atn,
              dolor_facial: data.trastornosMandibulares.dolor_facial,
              limitacion_apertura: data.trastornosMandibulares.limitacion_apertura,
              ruidos_atm: data.trastornosMandibulares.ruidos_atm,
              desviacion_mandivular: data.trastornosMandibulares.desviacion_mandibular,
              observaciones: data.trastornosMandibulares.observaciones
            }
          }
        }
      })

      const registroObservaciones = await prisma.diagnostico.create({
        data: {
          diagnostico_presuntivo: data.diagnostico.diagnostico_presuntivo,
          diagnostico_complementario: data.diagnostico.diagnostico_complementario,
          diagnostico_definitivo: data.diagnostico.diagnostico_definitivo,
          pronostico: data.diagnostico.pronostico,
          plan_tratamiento_general: data.diagnostico.plan_tratamiento_general,
          recomendaciones: data.diagnostico.recomendaciones,
          conclusiones: data.diagnostico.conclusiones
        }
      })

      const updateHistoriaClinica = await prisma.historia_clinica.update({
        where: {
          id: numeroHistoria.id
        },
        data: {
          diagnostico_id: registroObservaciones.id,
          hallazgos_clinicos_id: registrarHallazgosClinicos.id
        }
      })
      prisma.$disconnect()
      if (global.io) {
        global.io.emit("updateHallazgozClinicos", registrarHallazgosClinicos)
      }
      return NextResponse.json({
        paciente: "exito"
      })
    case 2:
      let one = await prisma.hallazgos_clinicos.findFirst({
        where: {
          id: data.id
        },
        include: {
          historia_clinica: true,
          trastronos_mandibulares: true
        }
      })
      let diagnosticos = await prisma.diagnostico.findUnique({ where: { id: one.historia_clinica[0].diagnostico_id } })

      let allOne = {
        ...one,
        diagnosticos
      }
      prisma.$disconnect()
      return NextResponse.json({one: allOne})
    case 3:
      let ones = await prisma.hallazgos_clinicos.findFirst({
        where: {
          id: data.id
        },
        include: {
          historia_clinica: true,
          trastronos_mandibulares: true
        }
      })
      let diagnosticosOnes = await prisma.diagnostico.findUnique({ where: { id: ones.historia_clinica[0].diagnostico_id } })

      let allOnes = {
        ...ones,
        diagnosticos: diagnosticosOnes
      }
      prisma.$disconnect()
      return NextResponse.json({ one: allOnes })
    default:
      break;
  }
}

export async function PUT(req) {
  let data = await req.json()

  const registrarHallazgosClinicos = await prisma.hallazgos_clinicos.update({
    where: {
      id: data.id
    },
    data: {
      fecha: data.hallazgos.fecha,
      presion_arterial: data.hallazgos.presion_arterial,
      pulso: data.hallazgos.pulso,
      ferecuencia_respiratoria: data.hallazgos.ferecuencia_respiratoria,
      temperatura: data.hallazgos.temperatura,
      tejidos_blandos: data.hallazgos.tejidos_blandos,
      tejidos_duros: data.hallazgos.tejidos_duros,
      encia: data.hallazgos.encias,
      factores_etiologicos: data.hallazgos.factores_etiologicos,
      examen_oclusal: data.hallazgos.examen_oclusal,
      trastronos_mandibulares: {
        update: {
          dolor_atn: data.trastornosMandibulares.dolor_atn,
          dolor_facial: data.trastornosMandibulares.dolor_facial,
          limitacion_apertura: data.trastornosMandibulares.limitacion_apertura,
          ruidos_atm: data.trastornosMandibulares.ruidos_atm,
          desviacion_mandivular: data.trastornosMandibulares.desviacion_mandibular,
          observaciones: data.trastornosMandibulares.observaciones
        }
      },
    }
  })

  const getHistoriaClinica = await prisma.historia_clinica.findFirst({
    where: {
      hallazgos_clinicos_id: registrarHallazgosClinicos.id
    }
  })

  const registroObservaciones = await prisma.diagnostico.update({
    where: {
      id: getHistoriaClinica.diagnostico_id
    },
    data: {
      diagnostico_complementario: data.diagnostico.diagnostico_complementario,
      diagnostico_definitivo: data.diagnostico.diagnostico_definitivo,
      diagnostico_presuntivo: data.diagnostico.diagnostico_presuntivo,
      historia_clinica: data.diagnostico.historia_clinica,
      plan_tratamiento_general: data.diagnostico.plan_tratamiento_general,
      conclusiones: data.diagnostico.conclusiones,
      pronostico: data.diagnostico.pronostico,
      recomendaciones: data.diagnostico.recomendaciones,
    }
  })

  prisma.$disconnect()

  if (global.io) {
    global.io.emit("updateHallazgozClinicos", registrarHallazgosClinicos)
  }
  return NextResponse.json({
    paciente: "exito"
  })
}
