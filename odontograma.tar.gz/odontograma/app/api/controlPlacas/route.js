import { prisma } from "@/app/db/db";
import { NextResponse } from "next/server";

export async function GET(req) {
  let sexo = await prisma.sexo.findMany()
  let clean = []

  let allPacientes = await prisma.paciente.findMany({
    include: {
      sexo: true
    }
  })

  allPacientes.map(data => {
    clean.push({ ...data, key: data.id, sexo: data.sexo.sexo_name })
  })

  let full = {
    sexo,
    allPacientes: clean
  }
  prisma.$disconnect()
  return NextResponse.json(full)
}

export async function POST(req) {
  let data = await req.json()

  switch (data.option) {
    case 1:
      const getUltimoControl = await prisma.placa.findMany({
        where: {
          paciente_id: data.id
        }
      })
      if (!getUltimoControl) {
        const registerFirtsControl = await prisma.placa.create({
          data: {
            placa_porcentaje: data.placa_porcentaje,
            numero_control: 1,
            paciente_id: data.id
          }
        })
        return NextResponse.json({
          message: "Registro Exitoso",
          status: 200
        })
      }

      const registerControl = await prisma.placa.create({
        data: {
          placa_porcentaje: data.placa_porcentaje,
          numero_control: getUltimoControl.length + 1,
          paciente_id: data.id
        }
      })
      prisma.$disconnect()
      return NextResponse.json({
        message: "Registro Exitoso",
        status: 200
      })
    case 2:
      let one = await prisma.placa.findMany({
        orderBy: {
          numero_control: "asc"
        },
        where: {
          paciente_id: data.id
        },
      })
      let control = one.map(data => data.numero_control)
      let porcentaje = one.map(data => data.placa_porcentaje)
      prisma.$disconnect()
      return NextResponse.json({
        one: {
          control,
          porcentaje
        }
      })
    case 3:
      let ones = await prisma.paciente.findFirst({
        where: {
          id: data.id
        },
        include: {
          cedula: true,
          sexo: true
        }
      })
      prisma.$disconnect()
      return NextResponse.json({ one: ones })
    default:
      break;
  }
}

export async function PUT(req) {
  let data = await req.json()
  console.log(data)
  const updateDonante = await prisma.paciente.update({
    where: {
      id: data.id
    },
    data: {
      nombres: data.nombres,
      apellidos: data.apellidos,
      edad: data.edad,
      cedula: {
        update: {
          cedula_num: data.cedula
        }
      },
      raza: data.raza,
      ocupacion: data.ocupacion,
      natural: data.natural,
      procedencia: data.procedencia,
      direccion: data.direccion,
      sexo: {
        connect: {
          id: data.sexo
        }
      },
      estudiante: {
        connect: {
          id: data.estudiante
        }
      },
    }
  })
  prisma.$disconnect()
  return NextResponse.json("put")
}