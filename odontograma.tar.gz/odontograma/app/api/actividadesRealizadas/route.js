import { habitos } from "@/app/components/modal/childrens/preguntas";
import { prisma } from "@/app/db/db";
import { NextResponse } from "next/server";

export async function GET(req) {
  let clean = []
  let allHistorias = await prisma.antecedentes_personales.findMany()

  allHistorias.map(data => {
    clean.push({
      id: data.id,
      nervios_al_odontologo: data.nervios_al_odontologo === 0 ? "NO" : "SI",
      dolor_boca: data.dolor_boca === 0 ? "NO" : "SI",
      dolor_dentadura: data.dolor_dentadura === 0 ? "NO" : "SI",
      key: data.id
    })
  })

  let full = {
    allHistorias: clean
  }
  prisma.$disconnect()
  return NextResponse.json(full)


}

export async function POST(req) {
  let data = await req.json()
  switch (data.option) {
    case 0:
      let clean = []
      let estudianteOroot = await prisma.usuarios.findFirst({
        where: {
          id: data.usuario.id,
          correo: data.usuario.correo
        }
      })

      if (estudianteOroot) {
        let allAntecedentesPersonalesRoot = await prisma.historia_clinica.findMany({
          include: {
            actividades_realizadas: true
          }
        })

        allAntecedentesPersonalesRoot.map(data => {
          clean.push({
            ...data,
            key: data.id
          })
        })

        prisma.$disconnect()
        return NextResponse.json({
          allHistorias: clean
        })
      }

      let allHistorias = await prisma.historia_clinica.findMany({
        where: {
          paciente: {
            some: {
              estudiante_id: data.usuario.id,
            }
          }
        },
        include: {
          actividades_realizadas: true
        }
      })

      allHistorias.map(data => {
        clean.push({
          ...data,
          key: data.id
        })
      })

      let full = {
        allHistorias: clean
      }
      prisma.$disconnect()
      return NextResponse.json(full)

    case 1:
      const numeroHistoria = await prisma.historia_clinica.findUnique({
        where: {
          numero_historia: data.numero_historia
        }
      })

      const dientesParaPrisma = await Object.values(data.actividad).map((actividad) => {
        return {
          ...actividad,
          fecha: new Date(actividad.fecha),
          historia_clinica_id: numeroHistoria.id
        }
      });


      const dientesParaPrismaPromise = await Promise.all(dientesParaPrisma);


      const actividades = await prisma.actividades_realizadas.createMany({
        data: dientesParaPrismaPromise
      })


      if (global.io) {
        let updateAll = await prisma.historia_clinica.findMany({
          where: {
            paciente: {
              some: {
                estudiante_id: data.usuario.id,
              }
            }
          },
          include: {
            actividades_realizadas: true
          }
        })
        let cleaner = []
        console.log(updateAll, "update")
        updateAll.map(data => {
          cleaner.push({
            ...data,
            key: data.id
          })
        })

        global.io.emit('updateActividades', cleaner);
      }

      prisma.$disconnect()
      return NextResponse.json({
        message: "Exito"
      })

    case 2:
      let one = await prisma.historia_clinica.findFirst({
        where: {
          id: data.id
        },
        include: {
          actividades_realizadas: true

        }
      })
      prisma.$disconnect()
      return NextResponse.json({ one })

    case 3:
      let ones = await prisma.historia_clinica.findFirst({
        where: {
          id: data.id
        },
        include: {
          actividades_realizadas: true

        }
      })
      prisma.$disconnect()
      return NextResponse.json({ one: ones })

    case 4:
      const updateRadiografias = await prisma.historia_clinica.update({
        where: {
          id: data.id
        },
        data: {
          status: data.status
        },
        include: {
          actividades_realizadas: true
        }
      })
      prisma.$disconnect()

      if (global.io) {
        let updateAll = await prisma.historia_clinica.findMany({
          include: {
            actividades_realizadas: true
          }
        })
        let cleaner = []
        console.log(updateAll, "update")
        updateAll.map(data => {
          cleaner.push({
            ...data,
            key: data.id
          })
        })

        global.io.emit('updateActividades', cleaner);
      }
      prisma.$disconnect()
      return NextResponse.json({
        message: "Se a Corregido la Historia Clinica"
      })

    default:
      break;
  }
}

export async function PUT(req) {
  let data = await req.json()

  console.log(data)
  const actividadesDelete = await prisma.actividades_realizadas.delete({
    where: { id: data.id },
  })

  prisma.$disconnect()

  if (global.io) {
    let updateAll = await prisma.historia_clinica.findMany({
      where: {
        paciente: {
          some: {
            estudiante_id: data.usuario.id,
          }
        }
      },
      include: {
        actividades_realizadas: true
      }
    })
    let cleaner = []
    console.log(updateAll, "update")
    updateAll.map(data => {
      cleaner.push({
        ...data,
        key: data.id
      })
    })

    global.io.emit('updateActividades', cleaner);
  }
  
  return NextResponse.json({
    message: "exito"
  })
}
