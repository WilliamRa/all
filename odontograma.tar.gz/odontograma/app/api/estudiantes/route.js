import { capitalizeFirstLetter } from "@/app/components/general";
import { prisma } from "@/app/db/db";
import { NextResponse } from "next/server";

export async function GET(req) {
  let clean = []
  let allEstudiante = await prisma.estudiante.findMany({
    include: {
      cedula: true
    }
  })

  allEstudiante.map(data => {
    clean.push({ ...data, 
      key: data.id, 
      cedula: data.cedula.cedula_num,
      nombres: capitalizeFirstLetter(data.nombres),
      apellidos: capitalizeFirstLetter(data.apellidos)
    })
  })

  let full = {
    allEstudiante: clean
  }
  prisma.$disconnect()
  return NextResponse.json(full)


}

export async function POST(req) {
  let data = await req.json()

  switch (data.option) {
    case 1:
      const cedulaExiste = await prisma.cedula.findUnique({
        where: {
          cedula_num: data.cedula
        },
      });

      if (cedulaExiste) return NextResponse.json({
        message: "La Contraseñá ya esta registrada",
        code: 403
      }, {
        status: 403
      })

      const cedulaRegister = await prisma.cedula.create({
        data: {
          cedula_num: data.cedula
        },
      });

      const estudiante = await prisma.estudiante.create({
        data: {
          nombres: data.nombres,
          apellidos: data.apellidos,
          cedula: {
            connect: {
              id: cedulaRegister.id
            }
          },
          ano: data.ano,
          grupo: data.grupo,
          correo: data.correo,
          contrasena: data.contrasena,
          rol: {
            connect: {
              id: 1
            }
          }
        },
        include:{
          cedula: true
        }
      })

      prisma.$disconnect()
      global.io.emit("updateEstudiente", estudiante)
      return NextResponse.json({
        message: "Estudiante Registrado"
      })
    case 2:
      let one = await prisma.estudiante.findFirst({
        where: {
          id: data.id
        },
        include: {
          cedula: true,
        }
      })
      prisma.$disconnect()
      return NextResponse.json({ one })
    case 3:
      let ones = await prisma.estudiante.findFirst({
        where: {
          id: data.id
        },
        include: {
          cedula: true,
        }
      })
      prisma.$disconnect()
      return NextResponse.json({ one: ones })
    default:
      break;
  }
}

export async function PUT(req) {
  let data = await req.json()

  const estudianteUpdate = await prisma.estudiante.update({
    where: {
      id: data.id
    },
    data: {
      nombres: data.nombres,
      apellidos: data.apellidos,
      ano: data.ano,
      grupo: data.grupo,
      correo: data.correo,
      contrasena: data.contrasena,
    },
    include:{
      cedula: true
    }
  })
  global.io.emit("updateEstudiente", estudianteUpdate)
  prisma.$disconnect()
  return NextResponse.json({
    message: "Estudiante Actualizado"
  })
}