import { capitalizeFirstLetter } from "@/app/components/general";
import { prisma } from "@/app/db/db";
import { NextResponse } from "next/server";

export async function GET(req) {
  let sexo = await prisma.sexo.findMany()
  let clean = []

  let allPacientes = await prisma.paciente.findMany({
    include: {
      sexo: true
    }
  })

  allPacientes.map(data => {
    clean.push({ ...data, key: data.id, sexo: data.sexo.sexo_name })
  })

  let full = {
    sexo,
    allPacientes: clean
  }
  prisma.$disconnect()
  return NextResponse.json(full)
}

export async function POST(req) {
  let data = await req.json()
  console.log(data)
  switch (data.option) {
    case 0:
      let sexo = await prisma.sexo.findMany()
      let clean = []
      let estudianteOroot = await prisma.usuarios.findFirst({
        where: {
          id: data.usuario.id,
          correo: data.usuario.correo

        }
      })

      if (estudianteOroot) {
        let allPacientesRoot = await prisma.paciente.findMany({
          include: {
            sexo: true
          }
        })

        allPacientesRoot.map(data => {
          clean.push({
            ...data,
            key: data.id,
            sexo: data.sexo.sexo_name,
            nombres: capitalizeFirstLetter(data.nombres),
            apellidos: capitalizeFirstLetter(data.apellidos)
          })
        })

        prisma.$disconnect()
        return NextResponse.json({
          sexo,
          allPacientes: clean
        })
      }

      let allPacientes = await prisma.paciente.findMany({
        where: {
          estudiante_id: data.usuario.id,
        },
        include: {
          sexo: true
        }
      })

      allPacientes.map(data => {
        clean.push({ 
          ...data, 
          key: data.id, 
          sexo: data.sexo.sexo_name,
          nombres: capitalizeFirstLetter(data.nombres),
          apellidos: capitalizeFirstLetter(data.apellidos)
        })
      })

      let full = {
        sexo,
        allPacientes: clean
      }
      prisma.$disconnect()
      return NextResponse.json(full)

    case 1:
      const cedulaExiste = await prisma.cedula.findUnique({
        where: {
          cedula_num: data.cedula
        },
      });

      if (cedulaExiste) return NextResponse.json({
        message: "La Cedula esta Registrada"
      }, { status: 403 })

      const cedula = await prisma.cedula.create({
        data: {
          cedula_num: data.cedula
        },
      });

      const paciente = await prisma.paciente.create({
        data: {
          nombres: data.nombres,
          apellidos: data.apellidos,
          edad: data.edad,
          direccion: data.direccion,
          ocupacion: data.ocupacion,
          raza: data.raza,
          natural: data.natural,
          cedula_id: cedula.id,
          procedencia: data.procedencia,
          sexo_id: data.sexo,
          estudiante_id: data.estudiante,
        },
        include:{
          sexo: true
        }
      })

      prisma.$disconnect()
      if (global.io) {
        global.io.emit('updatePaciente', paciente);
      }
      return NextResponse.json({
        message: "Registro Exitoso"
      })
    case 2:
      let one = await prisma.paciente.findFirst({
        where: {
          id: data.id
        },
        include: {
          cedula: true,
          sexo: true
        }
      })
      prisma.$disconnect()
      return NextResponse.json({ one })
    case 3:
      let ones = await prisma.paciente.findFirst({
        where: {
          id: data.id
        },
        include: {
          cedula: true,
          sexo: true
        }
      })
      prisma.$disconnect()
      return NextResponse.json({ one: ones })
    default:
      break;
  }
}

export async function PUT(req) {
  let data = await req.json()
  const updatePaciente = await prisma.paciente.update({
    where: {
      id: data.id,

    },
    data: {
      nombres: data.nombres,
      apellidos: data.apellidos,
      edad: data.edad,
      cedula: {
        update: {
          cedula_num: data.cedula
        }
      },
      raza: data.raza,
      ocupacion: data.ocupacion,
      natural: data.natural,
      procedencia: data.procedencia,
      direccion: data.direccion,
    },
    include:{
      sexo: true
    }
  })

  if (global.io) {
    global.io.emit('updatePaciente', updatePaciente);
  }
  prisma.$disconnect()
  return NextResponse.json({
    message: "Paciente Actualizado"
  })
}