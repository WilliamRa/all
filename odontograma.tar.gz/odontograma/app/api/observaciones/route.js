import { prisma } from "@/app/db/db";
import { socket } from "@/socket";
import { NextResponse } from "next/server";
import { Server } from 'socket.io';

export async function POST(req) {
  let data = await req.json()
  switch (data.option) {
    case 0:
      let getObservaciones = await prisma.observaciones.findMany({
        where: { estudiante_id: data.id }
      })
      return NextResponse.json({
        one: getObservaciones
      })
      
    case 1:
      let userExiste = await prisma.estudiante.findUnique({ where: { id: data.idUser } })

      if (!userExiste.id) return NextResponse.json({
        message: "El Estudiante no esta Registrado",
        code: 403
      }, { status: 403 })

      let registerObservacion = await prisma.observaciones.create({
        data: {
          asunto: data.asunto,
          observacion: data.contenido,
          estudiante_id: userExiste.id
        }
      })

      let postRegister = await prisma.observaciones.findMany({
        where: { estudiante_id: registerObservacion.estudiante_id }
      })
      console.log(postRegister)

      if (global.io) {
        global.io.emit('new-observacion-boton', postRegister);
        global.io.emit('new-observacion-modal', postRegister);
      }
      return NextResponse.json({
        message: "Exito"
      })

    default:
      break;
  }
}