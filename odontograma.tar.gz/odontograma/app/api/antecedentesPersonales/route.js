import { habitos } from "@/app/components/modal/childrens/preguntas";
import { prisma } from "@/app/db/db";
import { NextResponse } from "next/server";

export async function GET(req) {
  let clean = []
  let allHistorias = await prisma.antecedentes_personales.findMany()

  allHistorias.map(data => {
    clean.push({
      id: data.id,
      nervios_al_odontologo: data.nervios_al_odontologo === 0 ? "NO" : "SI",
      dolor_boca: data.dolor_boca === 0 ? "NO" : "SI",
      dolor_dentadura: data.dolor_dentadura === 0 ? "NO" : "SI",
      key: data.id
    })
  })

  let full = {
    allHistorias: clean
  }
  prisma.$disconnect()
  return NextResponse.json(full)


}

export async function POST(req) {
  let data = await req.json()
  switch (data.option) {
    case 0:
      let clean = []
      let estudianteOroot = await prisma.usuarios.findFirst({
        where: {
          id: data.usuario.id,
          correo: data.usuario.correo
        }
      })
      
      console.log("SOYROOT", estudianteOroot)
      if (estudianteOroot) {
        let allAntecedentesPersonalesRoot = await prisma.antecedentes_personales.findMany()
        allAntecedentesPersonalesRoot.map(data => {
          clean.push({
            id: data.id,
            nervios_al_odontologo: data.nervios_al_odontologo === 0 ? "NO" : "SI",
            dolor_boca: data.dolor_boca === 0 ? "NO" : "SI",
            dolor_dentadura: data.dolor_dentadura === 0 ? "NO" : "SI",
            key: data.id
          })
        })
        prisma.$disconnect()
        return NextResponse.json({
          allHistorias: clean
        })
      }

      let allHistorias = await prisma.antecedentes_personales.findMany({
        where: {
          historia_clinica: {
            some: {
              paciente: {
                some: {
                  estudiante_id: data.usuario.id
                }
              }
            }
          }
        }
      })

      allHistorias.map(data => {
        clean.push({
          id: data.id,
          nervios_al_odontologo: data.nervios_al_odontologo === 0 ? "NO" : "SI",
          dolor_boca: data.dolor_boca === 0 ? "NO" : "SI",
          dolor_dentadura: data.dolor_dentadura === 0 ? "NO" : "SI",
          key: data.id
        })
      })

      let full = {
        allHistorias: clean
      }
      prisma.$disconnect()
      return NextResponse.json(full)

    case 1:
      const numeroHistoria = await prisma.historia_clinica.findUnique({
        where: {
          numero_historia: data.antecedentesPersonales.numero_historia
        }
      })

      if (!numeroHistoria) return NextResponse.json({
        message: "Numero de Historia erroneo o duplicado",
        code: 403
      }, {
        status: 403,
      })

      if (numeroHistoria.antecedentes_personales_id) return NextResponse.json({
        message: "Solo se puede Realizar 1 solo registro por historial",
        code: 403
      }, { status: 403, })

      const procedimiento = await prisma.sintomas_procedimientos.create({
        data: {
          ataques_combulsiones: data.sintomas.ataques_combulsiones,
          despierto_falta_aire: data.sintomas.despierto_falta_aire,
          dieta_especial: data.sintomas.dieta_especial,
          dolor_pecho_falta_aire: data.sintomas.dolor_pecho_falta_aire,
          ganado_perdido_peso: data.sintomas.ganado_perdido_peso,
          hinchazon_tobillos: data.sintomas.hinchazon_tobillos,
          moretones_magulladuras_facilidad: data.sintomas.moretones_magulladuras_facilidad,
          orinar_seis_veces_dia: data.sintomas.orinar_seis_veces_dia,
          siempre_sediento: data.sintomas.siempre_sediento,
          sufrido_urticaria_eruccion: data.sintomas.sufrido_urticaria_eruccion,
          transfusion_sanguinea_realizada: data.sintomas.transfusion_sanguinea_realizada,
        }
      })

      const farmacosTomados = await prisma.farmacos_tomados.create({
        data: {
          antibioticos: data.farmacos_tomados.antibioticos,
          anticoagulantes: data.farmacos_tomados.anticoagulantes,
          anticombulsivo: data.farmacos_tomados.anticombulsivos,
          antidepresivos: data.farmacos_tomados.antidepresivos,
          antiglicemiante: data.farmacos_tomados.antiglicemiante,
          aspirina: data.farmacos_tomados.aspirina,
          esteroides: data.farmacos_tomados.esteroides,
          otros: data.farmacos_tomados.otros
        }
      })
      const alergia = await prisma.alergias.create({
        data: {
          anestesicos_locales: data.alergias.anestesicos_locales,
          aspirina: data.alergias.aspirina,
          barbitulicos: data.alergias.barbitulicos,
          penicilina: data.alergias.penicilina,
          sulfamidas: data.alergias.sulfamidas,
          otro: data.alergias.otro,
        }
      })
      const enfermedades = await prisma.enfermedades.create({
        data: {
          anemia: data.enfermedades.anemia,
          artritis: data.enfermedades.artritis,
          asma: data.enfermedades.asma,
          ataques_corazon: data.enfermedades.ataques_corazon,
          cancer: data.enfermedades.cancer,
          diabetes: data.enfermedades.diabetes,
          enfermedades_suprarenales: data.enfermedades.enfermedades_suprarenales,
          enfermedades_tiroideas: data.enfermedades.enfermedades_tiroideas,
          enfermedades_venereas: data.enfermedades.enfermedades_venereas,
          fiebre_reumatica: data.enfermedades.fiebre_reumatica,
          hepatitis: data.enfermedades.hepatitis,
          marcapasos: data.enfermedades.marcapasos,
          insuficiencia_cardiaca: data.enfermedades.insuficiencia_cardiaca,
          presion_alta: data.enfermedades.presion_alta,
          quimioterapia: data.enfermedades.quimioterapia,
          radioterapia: data.enfermedades.radioterapia,
          sida: data.enfermedades.sida,
          soplo_cardiaco: data.enfermedades.soplo_cardiaco,
          tuberculosis: data.enfermedades.tuberculosis,
          valvulas_cardiacas: data.enfermedades.valvulas_cardiacas,
        }
      })
      const habito = await prisma.habitos.create({
        data: {
          abrir_ganchos_dientes: data.habitos.abrir_ganchos_dientes,
          onicofagia: data.habitos.onicofagia,
          queilofagia: data.habitos.queilofagia,
          respirador_bucal: data.habitos.respirador_bucal,
          succion_digital: data.habitos.succion_digital,
          tabaquismo: data.habitos.tabaquismo,
          otros: data.habitos.otros,
        }
      })

      const antecedentes_personales = await prisma.antecedentes_personales.create({
        data: {
          aparato_ortopedico_odontologico: data.antecedentesPersonales.aparato_ortopedico_odontologico,
          bajo_tratamiento_actualmente: data.antecedentesPersonales.bajo_tratamiento_actualmente,
          conclusiones_respuestas_positivas: data.antecedentesPersonales.conclusiones_respuestas_positivas,
          dientes_sensibles: data.antecedentesPersonales.dientes_sensibles,
          dificultad_abrir_boca: data.antecedentesPersonales.dificultad_abrir_boca,
          dificultad_masticar: data.antecedentesPersonales.dificultad_masticar,
          dolor_boca: data.antecedentesPersonales.dolor_boca,
          dolor_dentadura: data.antecedentesPersonales.dolor_dentadura,
          hemorragias_excesiva_tratamiento_especial: data.antecedentesPersonales.hemorragias_exesiva_tratamiento_especial,
          hemorragias_nasales: data.antecedentesPersonales.hemorragias_nasales,
          herida_grave: data.antecedentesPersonales.herida_grave,
          hospitalizado: data.antecedentesPersonales.hospitalizado,
          nervios_al_odontologo: data.antecedentesPersonales.nervios_al_odontologo,
          problema_senos_cabeza_cara: data.antecedentesPersonales.problemas_senos_cabeza_cara,
          quirurgico_rx: data.antecedentesPersonales.quirurgico_rx,
          sangrado_largo_tiempo: data.antecedentesPersonales.sangrado_largo_tiempo,
          sanrado_encias: data.antecedentesPersonales.sangrado_encias,
          sonido_mandibular_masticar: data.antecedentesPersonales.sonido_mandibular_masticar,
          tratado_medico_dos_anos: data.antecedentesPersonales.tratado_medico_dos_anos,
          ulcera_inflamacion: data.antecedentesPersonales.ulcera_inflamacion,
          alergias: {
            connect: {
              id: alergia.id
            }
          },
          enfermedades: {
            connect: {
              id: enfermedades.id
            }
          },
          habitos: {
            connect: {
              id: habito.id
            }
          },
          sintomas_procedimientos: {
            connect: {
              id: procedimiento.id
            }
          },
          farmacos_tomados: {
            connect: {
              id: farmacosTomados.id
            }
          }
        }
      })

      const update_historia_clinica = await prisma.historia_clinica.update({
        where: {
          id: numeroHistoria.id
        },
        data: {
          antecedentes_personales_id: antecedentes_personales.id
        }
      })
      prisma.$disconnect()
      global.io.emit("updateAntecedentesPersonales", antecedentes_personales)
      return NextResponse.json({
        actualizar: "exito"
      })

    case 2:
      let one = await prisma.antecedentes_personales.findFirst({
        where: {
          id: data.id
        },
        include: {
          alergias: true,
          enfermedades: true,
          farmacos_tomados: true,
          habitos: true,
          sintomas_procedimientos: true,

        }
      })
      prisma.$disconnect()
      return NextResponse.json({ one })

    case 3:
      let ones = await prisma.antecedentes_personales.findFirst({
        where: {
          id: data.id
        },
        include: {
          alergias: true,
          enfermedades: true,
          farmacos_tomados: true,
          habitos: true,
          sintomas_procedimientos: true,

        }
      })
      prisma.$disconnect()
      return NextResponse.json({ one: ones })

    default:
      break;
  }
}

export async function PUT(req) {
  let data = await req.json()

  const antecedentes_personales = await prisma.antecedentes_personales.update({
    where: {
      id: data.id
    },
    data: {
      aparato_ortopedico_odontologico: data.antecedentesPersonales.aparato_ortopedico_odontologico,
      bajo_tratamiento_actualmente: data.antecedentesPersonales.bajo_tratamiento_actualmente,
      conclusiones_respuestas_positivas: data.antecedentesPersonales.conclusiones_respuestas_positivas,
      dientes_sensibles: data.antecedentesPersonales.dientes_sensibles,
      dificultad_abrir_boca: data.antecedentesPersonales.dificultad_abrir_boca,
      dificultad_masticar: data.antecedentesPersonales.dificultad_masticar,
      dolor_boca: data.antecedentesPersonales.dolor_boca,
      dolor_dentadura: data.antecedentesPersonales.dolor_dentadura,
      hemorragias_excesiva_tratamiento_especial: data.antecedentesPersonales.hemorragias_exesiva_tratamiento_especial,
      hemorragias_nasales: data.antecedentesPersonales.hemorragias_nasales,
      herida_grave: data.antecedentesPersonales.herida_grave,
      hospitalizado: data.antecedentesPersonales.hospitalizado,
      nervios_al_odontologo: data.antecedentesPersonales.nervios_al_odontologo,
      problema_senos_cabeza_cara: data.antecedentesPersonales.problemas_senos_cabeza_cara,
      quirurgico_rx: data.antecedentesPersonales.quirurgico_rx,
      sangrado_largo_tiempo: data.antecedentesPersonales.sangrado_largo_tiempo,
      sanrado_encias: data.antecedentesPersonales.sangrado_encias,
      sonido_mandibular_masticar: data.antecedentesPersonales.sonido_mandibular_masticar,
      tratado_medico_dos_anos: data.antecedentesPersonales.tratado_medico_dos_anos,
      ulcera_inflamacion: data.antecedentesPersonales.ulcera_inflamacion,

      alergias: {
        update: {
          data: {
            anestesicos_locales: data.alergias.anestesicos_locales,
            aspirina: data.alergias.aspirina,
            barbitulicos: data.alergias.barbitulicos,
            penicilina: data.alergias.penicilina,
            sulfamidas: data.alergias.sulfamidas,
            otro: data.alergias.otro,
          }
        }
      },
      enfermedades: {
        update: {
          anemia: data.enfermedades.anemia,
          artritis: data.enfermedades.artritis,
          asma: data.enfermedades.asma,
          ataques_corazon: data.enfermedades.ataques_corazon,
          cancer: data.enfermedades.cancer,
          diabetes: data.enfermedades.diabetes,
          enfermedades_suprarenales: data.enfermedades.enfermedades_suprarenales,
          enfermedades_tiroideas: data.enfermedades.enfermedades_tiroideas,
          enfermedades_venereas: data.enfermedades.enfermedades_venereas,
          fiebre_reumatica: data.enfermedades.fiebre_reumatica,
          hepatitis: data.enfermedades.hepatitis,
          marcapasos: data.enfermedades.marcapasos,
          insuficiencia_cardiaca: data.enfermedades.insuficiencia_cardiaca,
          presion_alta: data.enfermedades.presion_alta,
          quimioterapia: data.enfermedades.quimioterapia,
          radioterapia: data.enfermedades.radioterapia,
          sida: data.enfermedades.sida,
          soplo_cardiaco: data.enfermedades.soplo_cardiaco,
          tuberculosis: data.enfermedades.tuberculosis,
          valvulas_cardiacas: data.enfermedades.valvulas_cardiacas,
        }
      },
      habitos: {
        update: {
          abrir_ganchos_dientes: data.habitos.abrir_ganchos_dientes,
          onicofagia: data.habitos.onicofagia,
          queilofagia: data.habitos.queilofagia,
          respirador_bucal: data.habitos.respirador_bucal,
          succion_digital: data.habitos.succion_digital,
          tabaquismo: data.habitos.tabaquismo,
          otros: data.habitos.otros,
        }
      },
      sintomas_procedimientos: {
        update: {
          ataques_combulsiones: data.sintomas.ataques_combulsiones,
          despierto_falta_aire: data.sintomas.despierto_falta_aire,
          dieta_especial: data.sintomas.dieta_especial,
          dolor_pecho_falta_aire: data.sintomas.dolor_pecho_falta_aire,
          ganado_perdido_peso: data.sintomas.ganado_perdido_peso,
          hinchazon_tobillos: data.sintomas.hinchazon_tobillos,
          moretones_magulladuras_facilidad: data.sintomas.moretones_magulladuras_facilidad,
          orinar_seis_veces_dia: data.sintomas.orinar_seis_veces_dia,
          siempre_sediento: data.sintomas.siempre_sediento,
          sufrido_urticaria_eruccion: data.sintomas.sufrido_urticaria_eruccion,
          transfusion_sanguinea_realizada: data.sintomas.transfusion_sanguinea_realizada,
        }
      },
      farmacos_tomados: {
        update: {
          antibioticos: data.farmacos_tomados.antibioticos,
          anticoagulantes: data.farmacos_tomados.anticoagulantes,
          anticombulsivo: data.farmacos_tomados.anticombulsivos,
          antidepresivos: data.farmacos_tomados.antidepresivos,
          antiglicemiante: data.farmacos_tomados.antiglicemiante,
          aspirina: data.farmacos_tomados.aspirina,
          esteroides: data.farmacos_tomados.esteroides,
          otros: data.farmacos_tomados.otros
        }
      }
    }
  })

  prisma.$disconnect()
  global.io.emit("updateAntecedentesPersonales", antecedentes_personales)
  return NextResponse.json({
    actualizar: "exito"
  })
}
