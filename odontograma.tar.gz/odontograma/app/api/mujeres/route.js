import { prisma } from "@/app/db/db";
import { PrismaClient } from "@prisma/client";
import { NextResponse } from "next/server";

export async function GET() {
  let clean = []
  let allHistorias = await prisma.mujeres.findMany()

  allHistorias.map(data => {
    clean.push({
      id: data.id,
      desarreglos_menstruales: data.desarreglos_menstruales === 0 ? "NO" : "SI",
      emabarazo: data.emabarazo === 0 ? "NO" : "SI",
      menopausia: data.menopausia === 0 ? "NO" : "SI",
      pastillas_anticonceptivas: data.pastillas_anticonceptivas === 0 ? "NO" : "SI",
      key: data.id,
    })
  })

  let full = {
    allHistorias: clean
  }
  prisma.$disconnect()
  return NextResponse.json(full)


}

export async function POST(req) {
  let data = await req.json()

  switch (data.option) {
    case 0:
      let clean = []
      let estudianteOroot = await prisma.usuarios.findFirst({
        where: {
          id: data.usuario.id,
          correo: data.usuario.correo
        }
      })

      if (estudianteOroot) {
        let allmujeresRoot = await prisma.mujeres.findMany()

        allmujeresRoot.map(data => {
          clean.push({
            id: data.id,
            desarreglos_menstruales: data.desarreglos_menstruales === 0 ? "NO" : "SI",
            emabarazo: data.emabarazo === 0 ? "NO" : "SI",
            menopausia: data.menopausia === 0 ? "NO" : "SI",
            pastillas_anticonceptivas: data.pastillas_anticonceptivas === 0 ? "NO" : "SI",
            key: data.id,
          })
        })
        prisma.$disconnect()
        return NextResponse.json({
          allHistorias: clean
        })
      }

      let allHistorias = await prisma.mujeres.findMany({
        where: {
          antecedentes_personales: {
            some: {
              historia_clinica: {
                some: {
                  paciente: {
                    some: {
                      estudiante_id: data.usuario.id
                    }
                  }
                }
              }
            }
          }
        }
      })

      allHistorias.map(data => {
        clean.push({
          id: data.id,
          desarreglos_menstruales: data.desarreglos_menstruales === 0 ? "NO" : "SI",
          emabarazo: data.emabarazo === 0 ? "NO" : "SI",
          menopausia: data.menopausia === 0 ? "NO" : "SI",
          pastillas_anticonceptivas: data.pastillas_anticonceptivas === 0 ? "NO" : "SI",
          key: data.id,
        })
      })

      let full = {
        allHistorias: clean
      }
      prisma.$disconnect()
      return NextResponse.json(full)

    case 1:
      const numeroHistoria = await prisma.historia_clinica.findUnique({
        where: {
          numero_historia: data.numero_historia
        },
        include: {
          antecedentes_personales: true,
          paciente: {
            include: {
              sexo: true
            }
          }
        }
      })
      
      const antecedenteRegistrado = await prisma.antecedentes_personales.findUnique({
        where: {
          id: numeroHistoria.antecedentes_personales_id
        }
      })

      if (antecedenteRegistrado.mujeres_id) return NextResponse.json({
        message: "Ya Existe un Registro a hacia este paciente",
        code: 403
      }, { status: 403 })

      if (!numeroHistoria.id) return NextResponse.json({
        message: "Numero de Historia erroneo o duplicado",
        code: 403
      }, { status: 403 })


      if (numeroHistoria.paciente[0].sexo.id === 1) return NextResponse.json({
        message: "Solo se puede registrar si el paciente es mujer",
        code: 403
      }, { status: 403, })

      const mujeres = await prisma.mujeres.create({
        data: {
          emabarazo: data.embarazo,
          desarreglos_menstruales: data.desarreglos_menstruales,
          menopausia: data.menopausia,
          pastillas_anticonceptivas: data.pastillas_anticonceptivas,

        }
      })

      const updateAntecedentes = await prisma.antecedentes_personales.update({
        where: {
          id: numeroHistoria.antecedentes_personales_id
        },
        data: {
          mujeres_id: mujeres.id
        }
      })

      prisma.$disconnect()
      if(global.io){
        global.io.emit("updateMujeres", mujeres)
      }
      return NextResponse.json({
        actualizar: "exito"
      })

    case 2:
      const one = await prisma.mujeres.findUnique({
        where: {
          id: data.id
        }
      })
      prisma.$disconnect()
      return NextResponse.json({ one })

    case 3:
      const ones = await prisma.mujeres.findUnique({
        where: {
          id: data.id
        }
      })
      prisma.$disconnect()
      return NextResponse.json({ one: ones })

    default:
      break;
  }
}

export async function PUT(req) {
  let data = await req.json()
  console.log(data)
  const updateMujer = await prisma.mujeres.update({
    where: {
      id: data.id
    },
    data: {
      desarreglos_menstruales: data.desarreglos_menstruales,
      emabarazo: data.embarazo,
      menopausia: data.menopausia,
      pastillas_anticonceptivas: data.pastillas_anticonceptivas,
    }
  })

  if(global.io){
    global.io.emit("updateMujeres", updateMujer)
  }
  prisma.$disconnect()
  return NextResponse.json("put")
}
