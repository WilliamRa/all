import { prisma } from "@/app/db/db";
import { NextResponse } from "next/server";

export async function GET(req) {
  let clean = []
  let allHistorias = await prisma.historia_familiar.findMany()

  allHistorias.map(data => {
    clean.push({
      id: data.id,
      enfermedades_cardiobasculares: data.enfermedades_cardiobasculares === 0 ? "NO" : "SI",
      enfermedades_hemorragicas: data.enfermedades_hemorragicas === 0 ? "NO" : "SI",
      enfermedades_endocrinas: data.enfermedades_endocrinas === 0 ? "NO" : "SI",
      enfermedades_venereas: data.enfermedades_venereas === 0 ? "NO" : "SI",
      alergias: data.alergias === 0 ? "NO" : "SI",
      cancer: data.cancer === 0 ? "NO" : "SI",
      otras_enfermedades: data.otras_enfermedades === 0 ? "NO" : "SI",
      key: data.id
    })
  })

  let full = {
    allHistorias: clean
  }
  return NextResponse.json(full)


}

export async function POST(req) {
  let data = await req.json()

  switch (data.option) {
    case 0:
      console.log(data)
      let clean = []
      let estudianteOroot = await prisma.usuarios.findFirst({
        where: {
          id: data.usuario.id,
          correo: data.usuario.correo
        }
      })


      let allHistorias = await prisma.historia_familiar.findMany({
        where: {
          historia_clinica: {
            some: {
              paciente: {
                some: {
                  estudiante_id: data.usuario.id
                }
              }
            }
          }
        }
      })

      if (estudianteOroot) {
        let allHistoriasRoot = await prisma.historia_familiar.findMany()

        allHistoriasRoot.map(data => {
          clean.push({
            id: data.id,
            enfermedades_cardiobasculares: data.enfermedades_cardiobasculares === 0 ? "NO" : "SI",
            enfermedades_hemorragicas: data.enfermedades_hemorragicas === 0 ? "NO" : "SI",
            enfermedades_endocrinas: data.enfermedades_endocrinas === 0 ? "NO" : "SI",
            enfermedades_venereas: data.enfermedades_venereas === 0 ? "NO" : "SI",
            alergias: data.alergias === 0 ? "NO" : "SI",
            cancer: data.cancer === 0 ? "NO" : "SI",
            otras_enfermedades: data.otras_enfermedades === 0 ? "NO" : "SI",
            key: data.id
          })
        })
        prisma.$disconnect()
        return NextResponse.json({
          allHistorias: clean
        })
      }



      allHistorias.map(data => {
        clean.push({
          id: data.id,
          enfermedades_cardiobasculares: data.enfermedades_cardiobasculares === 0 ? "NO" : "SI",
          enfermedades_hemorragicas: data.enfermedades_hemorragicas === 0 ? "NO" : "SI",
          enfermedades_endocrinas: data.enfermedades_endocrinas === 0 ? "NO" : "SI",
          enfermedades_venereas: data.enfermedades_venereas === 0 ? "NO" : "SI",
          alergias: data.alergias === 0 ? "NO" : "SI",
          cancer: data.cancer === 0 ? "NO" : "SI",
          otras_enfermedades: data.otras_enfermedades === 0 ? "NO" : "SI",
          key: data.id
        })
      })

      let full = {
        allHistorias: clean
      }
      return NextResponse.json(full)

    case 1:
      const numeroHistoria = await prisma.historia_clinica.findUnique({
        where: {
          numero_historia: data.numero_historia
        }
      })
      console.log(numeroHistoria)
      if (!numeroHistoria.id) return NextResponse.json({
        code: 403,
        message: "numero de historia duplicado o inexistente"
      }, { status: 403 })

      if (numeroHistoria.historia_familiar_id) return NextResponse.json({
        message: "Solo se puede registrar 1 sola histora familiar por paciente",
        code: 403
      }, { status: 403 })

      
      const registrarHistoriaFamiliar = await prisma.historia_familiar.create({
        data: {
          enfermedades_cardiobasculares: data.enfermedades_cardiobasculares,
          enfermedades_hemorragicas: data.enfermedades_hemorragicas,
          enfermedades_endocrinas: data.enfermedades_endocrinas,
          enfermedades_venereas: data.enfermedades_venereas,
          alergias: data.alergias,
          cancer: data.cancer,
          otras_enfermedades: data.otras_enfermedades
        }
      })

      const actualizar = await prisma.historia_clinica.update({
        where: {
          id: numeroHistoria.id
        },
        data: {
          historia_familiar_id: registrarHistoriaFamiliar.id
        }
      })
      prisma.$disconnect()

      if (global.io) {
        global.io.emit("updateHitoriaFamiliar", {
          id: data.id,
          enfermedades_cardiobasculares: registrarHistoriaFamiliar.enfermedades_cardiobasculares === 0 ? "NO" : "SI",
          enfermedades_hemorragicas: registrarHistoriaFamiliar.enfermedades_hemorragicas === 0 ? "NO" : "SI",
          enfermedades_endocrinas: registrarHistoriaFamiliar.enfermedades_endocrinas === 0 ? "NO" : "SI",
          enfermedades_venereas: registrarHistoriaFamiliar.enfermedades_venereas === 0 ? "NO" : "SI",
          alergias: registrarHistoriaFamiliar.alergias === 0 ? "NO" : "SI",
          cancer: registrarHistoriaFamiliar.cancer === 0 ? "NO" : "SI",
          otras_enfermedades: registrarHistoriaFamiliar.otras_enfermedades === 0 ? "NO" : "SI",
          key: registrarHistoriaFamiliar.id
        })
      }
      return NextResponse.json({
        actualizar: "exito"
      })

    case 2:
      let one = await prisma.historia_familiar.findFirst({
        where: {
          id: data.id
        },
      })
      return NextResponse.json({ one })

    case 3:
      let ones = await prisma.historia_familiar.findFirst({
        where: {
          id: data.id
        },
      })
      return NextResponse.json({ one: ones })

    default:
      break;
  }
}

export async function PUT(req) {
  let data = await req.json()
  console.log(data)
  const updateHistoriaFamiliar = await prisma.historia_familiar.update({
    where: {
      id: data.id
    },
    data: {
      enfermedades_cardiobasculares: data.enfermedades_cardiobasculares,
      enfermedades_hemorragicas: data.enfermedades_hemorragicas,
      enfermedades_endocrinas: data.enfermedades_endocrinas,
      enfermedades_venereas: data.enfermedades_venereas,
      alergias: data.alergias,
      cancer: data.cancer,
      otras_enfermedades: data.otras_enfermedades
    }
  })

  if (global.io) {
    global.io.emit("updateHitoriaFamiliar", {
      id: data.id,
      enfermedades_cardiobasculares: updateHistoriaFamiliar.enfermedades_cardiobasculares === 0 ? "NO" : "SI",
      enfermedades_hemorragicas: updateHistoriaFamiliar.enfermedades_hemorragicas === 0 ? "NO" : "SI",
      enfermedades_endocrinas: updateHistoriaFamiliar.enfermedades_endocrinas === 0 ? "NO" : "SI",
      enfermedades_venereas: updateHistoriaFamiliar.enfermedades_venereas === 0 ? "NO" : "SI",
      alergias: updateHistoriaFamiliar.alergias === 0 ? "NO" : "SI",
      cancer: updateHistoriaFamiliar.cancer === 0 ? "NO" : "SI",
      otras_enfermedades: updateHistoriaFamiliar.otras_enfermedades === 0 ? "NO" : "SI",
      key: updateHistoriaFamiliar.id
    })
  }
  return NextResponse.json("put")
}
