'use client'

import { Table, Button } from "antd"
import { FolderViewOutlined, FormOutlined, SnippetsOutlined } from '@ant-design/icons';
import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import EstudianteModal from "@/app/components/modal/EstudianteModal";
import ObservacionModal from "@/app/components/modal/ObservacionModal";
import { socket } from '../../../socket';
import { SiMinutemailer } from "react-icons/si";


export default function Page() {
  const [option, setOption] = useState({
    modal: false,
    option: 0,
    modalHeader: '',
    modalFooter: '',
    disabled: false,
    showHide: 'show',
    id: null
  })
  const [visible, setVisible] = useState({
    modal: false,
    id: null
  });
  const [getData, setGetData] = useState(null)
  const { data: session } = useSession(authOptions)
  const columns = [
    { title: 'NOMBRES', dataIndex: 'nombres', key: 'nombres' },
    { title: 'APELLIDOS', dataIndex: 'apellidos', key: 'apellidos' },
    { title: 'CEDULA', dataIndex: 'cedula', key: 'cedula' },
    { title: 'CORREO', dataIndex: 'correo', key: 'correo' },
    {
      title: 'ACCION', key: 'action', render: (record) => {
        return (
          <div>
            <Button icon={<FolderViewOutlined />}
              size="middle"
              type='primary'
              shape='circle'

              style={{ marginRight: '8px', background: "#1677ff" }}
              onClick={() => showModal(2, record.key)}
            />

            <Button icon={<FormOutlined />}
              size="middle"
              type='primary'
              shape='circle'
              style={{ marginRight: '8px', background: "#1677ff" }}
              onClick={() => showModal(3, record.key)}
            />

            <Button icon={<SiMinutemailer   />}
              size="middle"
              type='primary'
              shape='circle'
              style={{ marginRight: '8px', background: "#1677ff" }}
              onClick={() => showModalObservacion(record.key)}
            />
          </div>
        )
      }
    },
  ];

  const showModalObservacion = (id) => {
    setVisible({
      modal: true,
      id: id
    });     
  };

  const hideModal = () => {
    setVisible({
      modal: false,
      id: null
    });
  };

  const showModal = (option, _id) => {
    if (option === 1) {
      setOption({
        modal: true,
        option: option,
        modalHeader: 'Registrar Estudiante',
        modalFooter: 'Guardar',
        disabled: false,
        showHide: 'show',
        id: null
      })
    } else if (option === 2) {
      fetchPostData(option, _id)

      setOption({
        modal: true,
        option: 2,
        modalHeader: 'Ver Estudiante',
        modalFooter: '',
        disabled: true,
        showHide: 'hide',
        id: _id
      })

    } else if (option === 3) {
      fetchPostData(option, _id)
      setOption({
        modal: true,
        option: option,
        modalHeader: 'Editar Estudiante',
        modalFooter: 'Editar',
        disabled: false,
        showHide: 'show',
        id: _id
      })
    }

  };

  const valorCloseModal = () => {
    setOption({
      modal: false,
      option: 0,
      modalHeader: '',
      modalFooter: '',
      disabled: false,
      showHide: 'show',
      id: null
    })
  }

  async function fetchData() {
    let response = await fetch('/api/estudiantes', {
      method: "get",
      headers: {
        'Content-Type': 'application/json'
      }
    })
    const result = await response.json();

    setGetData(result)

  }

  async function fetchPostData(option, id) {
    let response = await fetch('/api/estudiantes', {
      method: "Post",
      body: JSON.stringify({
        option, id
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    const result = await response.json();

    setGetData(prevData => ({
      ...prevData,
      ...result
    }));
    console.log("getData", getData)
  }

  useEffect(() => {
    fetchData()
  }, [!getData])


  useEffect(() => {
    const handleUpdatePaciente = (data) => {
      console.log({
        ...data,
        key: data.id,
      })
      if (getData) {
        setGetData(prevData => {
          const pacienteExists = prevData.allEstudiante.some(paciente => paciente.key === data.id);

          if (pacienteExists) {

            return {
              ...prevData,
              allEstudiante: prevData.allEstudiante.map(paciente => {
                if (paciente.key === data.id) {
                  return {
                    ...data,
                    key: data.id,
                    cedula: data.cedula.cedula_num,
                  };
                }
                return paciente;
              })
            };
          } else {
            // Agrega un nuevo paciente
            return {
              ...prevData,
              allEstudiante: [
                ...prevData.allEstudiante,
                {
                  ...data,
                  cedula: data.cedula.cedula_num,
                  key: data.id,
                }
              ]
            };
          }
        });
      }
    };

    socket.on("updateEstudiente", handleUpdatePaciente);

    return () => {
      socket.off("updateEstudiente");
    };
  }, [getData]);

  return (
    <>
      <div className="containerGeneral" style={{ "marginBottom": "1.8%" }}>
        <div className="container-button">
          <Button color="success"
            type="primary" onClick={() => showModal(1, null)}
          // disabled={disabledCreate}>
          >
            Agregar
          </Button>
        </div>
      </div>
      <ObservacionModal
        visible={visible}
        onClose={hideModal}
        one={getData ? getData.one : getData}
      />
      <EstudianteModal
        one={getData ? getData.one : getData}
        option={option}
        valorCloseModal={valorCloseModal}
        user={session}
      //router={router}
      />
      <Table
        columns={columns}
        dataSource={getData ? getData.allEstudiante : []}
        size='small'
      //loading={loading}
      />
    </>
  )
}