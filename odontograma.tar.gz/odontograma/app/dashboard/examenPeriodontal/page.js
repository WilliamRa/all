'use client'

import { Table, Button, notification} from "antd"
import { FolderViewOutlined, FormOutlined, FileAddOutlined } from '@ant-design/icons';
import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import ExamenPeriodontalModal from "@/app/components/modal/ExamenPeriodontalModal";



export default function Page() {
  const [option, setOption] = useState({
    modal: false,
    option: 0,
    modalHeader: '',
    modalFooter: '',
    disabled: false,
    showHide: 'show',
    id: null
  })
  const [getData, setGetData] = useState(null)
  const { data: session, status } = useSession()
  const columns = [
    { title: 'NOMBRES', dataIndex: 'nombres', key: 'nombres' },
    { title: 'APELLIDOS', dataIndex: 'apellidos', key: 'apellidos' },
    { title: 'EDAD', dataIndex: 'edad', key: 'edad' },
    {
      title: 'ACCION', key: 'action', render: (record) => {
        return (
          <div>
            <Button icon={<FileAddOutlined />}
              size="middle"
              type='primary'
              shape='circle'
              disabled={session.user.name.rol_id === 2 ? true : false}
              style={{ marginRight: '8px', background: "#1677ff" }}
              onClick={() => showModal(1, record.key)}
            />
            <Button icon={<FolderViewOutlined />}
              size="middle"
              type='primary'
              shape='circle'

              style={{ marginRight: '8px', background: "#1677ff" }}
              onClick={() => showModal(2, record.key)}
            />

            <Button icon={<FormOutlined />}
              size="middle"
              type='primary'
              shape='circle'
              disabled={session.user.name.rol_id === 2 ? true : false}
              style={{ marginRight: '8px', background: "#1677ff" }}
              onClick={() => showModal(3, record.key)}
            />
          </div>
        )
      }
    },
  ];

  const showModal = (option, _id) => {
    if (option === 1) {
      setOption({
        modal: true,
        option: option,
        modalHeader: 'Registrar Historia Clinica',
        modalFooter: 'Guardar',
        disabled: false,
        showHide: 'show',
        id: _id
      })
    } else if (option === 2) {
       fetchPostData(option, _id).then((data) => {
        console.log(data)
        if (data.code === 403) {
          notification.error({
            message: data.message
          })
        } else {
          setOption({
            modal: true,
            option: 2,
            modalHeader: 'Ver Historia Clinica',
            modalFooter: '',
            disabled: true,
            showHide: 'hide',
            id: _id
          })
        }
      })

    } else if (option === 3) {
      fetchPostData(option, _id).then((data) => {
        console.log(data)
        if (data.code === 403) {
          notification.error({
            message: data.message
          })
        } else {
          setOption({
            modal: true,
            option: option,
            modalHeader: 'Editar Historia Clinica',
            modalFooter: 'Editar',
            disabled: false,
            showHide: 'show',
            id: _id
          })
        }
      })
    }

  };

  const valorCloseModal = () => {
    setOption({
      modal: false,
      option: 0,
      modalHeader: '',
      modalFooter: '',
      disabled: false,
      showHide: 'show',
      id: null
    })

    setGetData((prev) => ({ ...prev, one: null }))
  }


  async function fetchData(data) {
    let response = await fetch('/api/dome', {
      method: "POST",
      body: JSON.stringify({
        option: 0,
        usuario: data
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    const result = await response.json();

    setGetData(result)

  }

  async function fetchPostData(option, id) {
    let response = await fetch('/api/periodontograma', {
      method: "Post",
      body: JSON.stringify({
        option, id
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    const result = await response.json();
    setGetData(prevData => ({
      ...prevData,
      ...result
    }));

    return result
  }

  useEffect(() => {
    if (status === "authenticated" && session) {
      fetchData(session.user.name)
      console.log("getData", session, status)
      console.log("EFECTO",)
    }
  }, [!getData, session])

  return (
    <>

      <ExamenPeriodontalModal
        select={getData ? getData.sexo : getData}
        one={getData ? getData.one : getData}
        option={option}
        valorCloseModal={valorCloseModal}
        user={session}
      //router={router}
      />
      <Table
        columns={columns}
        dataSource={getData ? getData.allPacientes : []}
        size='small'
      //loading={loading}
      />
    </>
  )
}