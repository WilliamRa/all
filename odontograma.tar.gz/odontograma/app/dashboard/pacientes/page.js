'use client'

import { Table, Button, Badge } from "antd"
import { FolderViewOutlined, FormOutlined, SnippetsOutlined, } from '@ant-design/icons';
import { useEffect, useState } from "react";
import PacientesModal from '../../components/modal/PacientesModal';
import { useSession } from "next-auth/react";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { socket } from '../../../socket';


export default function Page() {
  const [option, setOption] = useState({
    modal: false,
    option: 0,
    modalHeader: '',
    modalFooter: '',
    disabled: false,
    showHide: 'show',
    id: null
  })
  const [getData, setGetData] = useState(null)
  const { data: session, status } = useSession();
  const columns = [
    { title: 'NOMBRES', dataIndex: 'nombres', key: 'nombres' },
    { title: 'APELLIDOS', dataIndex: 'apellidos', key: 'apellidos' },
    { title: 'EDAD', dataIndex: 'edad', key: 'edad' },
    { title: 'SEXO', dataIndex: 'sexo', key: 'sexo' },
    {
      title: 'ACCION', key: 'action', render: (record) => {
        return (
          <div>
            <Button icon={<FolderViewOutlined />}
              size="middle"
              type='primary'
              shape='circle'

              style={{ marginRight: '8px', background: "#1677ff" }}
              onClick={() => showModal(2, record.key)}
            />

            <Button icon={<FormOutlined />}
              disabled={session.user.name.rol_id === 2 ? true : false}
              size="middle"
              type='primary'
              shape='circle'
              style={{ marginRight: '8px', background: "#1677ff" }}
              onClick={() => showModal(3, record.key)}
            />
            {/* 
            <Badge dot={true}>
              <Button icon={<FormOutlined />}
                disabled={session.user.name.rol_id === 2 ? true : false}
                size="middle"
                type='primary'
                shape='circle'
                style={{ marginRight: '8px', background: "#1677ff" }}
                onClick={() => showModal(3, record.key)}
              />

            </Badge> */}
          </div>
        )
      }
    },
  ];

  const showModal = (option, _id) => {
    if (option === 1) {
      setOption({
        modal: true,
        option: option,
        modalHeader: 'Registrar Paciente',
        modalFooter: 'Guardar',
        disabled: false,
        showHide: 'show',
        id: null
      })
    } else if (option === 2) {
      fetchPostData(option, _id)

      setOption({
        modal: true,
        option: 2,
        modalHeader: 'Ver Paciente',
        modalFooter: '',
        disabled: true,
        showHide: 'hide',
        id: _id
      })

    } else if (option === 3) {
      fetchPostData(option, _id)
      setOption({
        modal: true,
        option: option,
        modalHeader: 'Editar Paciente',
        modalFooter: 'Editar',
        disabled: false,
        showHide: 'show',
        id: _id
      })
    }

  };

  const valorCloseModal = () => {
    setOption({
      modal: false,
      option: 0,
      modalHeader: '',
      modalFooter: '',
      disabled: false,
      showHide: 'show',
      id: null
    })
  }

  async function fetchData(data) {
    let response = await fetch('/api/dome', {
      method: "post",
      body: JSON.stringify({
        option: 0,
        id_estudiante: data.id,
        usuario: data
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    const result = await response.json();

    setGetData(prevData => ({
      ...prevData,
      ...result
    }));

  }

  async function fetchPostData(option, id) {
    let response = await fetch('/api/dome', {
      method: "Post",
      body: JSON.stringify({
        option, id
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    const result = await response.json();

    setGetData(prevData => ({
      ...prevData,
      ...result
    }));
    console.log("getData", getData)
  }

  useEffect(() => {
    if (status === "authenticated" || session) {
      fetchData(session.user.name)
    }
  }, [!getData, session])

  useEffect(() => {
    if (status === "authenticated" && session) {
      fetchData(session.user.name);
    }
  }, [status, session]);
  
  useEffect(() => {
    const handleUpdatePaciente = (data) => {
      console.log(data, "PACIENTE");
    
      if (getData) {
        setGetData(prevData => {
          const pacienteExists = prevData.allPacientes.some(paciente => paciente.key === data.id);
    
          if (pacienteExists) {
            // Actualiza el paciente existente
            return {
              ...prevData,
              allPacientes: prevData.allPacientes.map(paciente => {
                if (paciente.key === data.id) {
                  return {
                    ...data,
                    key: data.id,
                    sexo: data.sexo.sexo_name
                  };
                }
                return paciente;
              })
            };
          } else {
            // Agrega un nuevo paciente
            return {
              ...prevData,
              allPacientes: [
                ...prevData.allPacientes,
                {
                  ...data,
                  key: data.id,
                  sexo: data.sexo.sexo_name
                }
              ]
            };
          }
        });
      }
    };
  
    socket.on("updatePaciente", handleUpdatePaciente);
  
    return () => {
      socket.off("updatePaciente", handleUpdatePaciente);
    };
  }, [getData]);
  
  return (
    <>
      <div className="containerGeneral" style={{ "marginBottom": "1.8%" }}>
        <div className="container-button">
          <Button color="success"
            type="primary" onClick={() => showModal(1, null)}
            disabled={session.user.name.rol_id === 2 ? true : false}
          >
            Agregar
          </Button>
        </div>
      </div>
      <PacientesModal
        select={getData ? getData.sexo : getData}
        one={getData ? getData.one : getData}
        option={option}
        valorCloseModal={valorCloseModal}
        user={session}
      //router={router}
      />
      <Table
        columns={columns}
        dataSource={getData ? getData.allPacientes : []}
        size='small'
      //loading={loading}
      />
    </>
  )
}