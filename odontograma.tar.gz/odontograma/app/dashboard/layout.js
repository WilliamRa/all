
'use client'
import React, { useState, useEffect } from 'react';
import {
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  UploadOutlined,
  VideoCameraOutlined,
  UserAddOutlined,
  FolderOpenFilled
} from '@ant-design/icons';
import { Button, Layout, Menu, Spin, theme, Flex, FloatButton } from 'antd';
import { signOut, useSession } from 'next-auth/react';
import { authOptions } from '../api/auth/[...nextauth]/route';
import Link from 'next/link';
import NotificationModal from '../components/modal/NotificacionModal';
import { socket } from '../../socket';
import { GoPasskeyFill } from 'react-icons/go';
import { SlBookOpen } from "react-icons/sl";
import { SlSymbleFemale } from "react-icons/sl";
import { TfiLayoutTab } from "react-icons/tfi";
import { TfiLayoutTabV } from "react-icons/tfi";
import { FiFileText } from "react-icons/fi";
import { FaTooth } from "react-icons/fa";
import { GiTooth } from "react-icons/gi";
import { LiaToothSolid } from "react-icons/lia";
import { SiMinutemailer } from "react-icons/si";
import { MdOutlineMailOutline } from "react-icons/md";
const { Header, Sider, Content } = Layout;

const DashboardLayout = ({ children }) => {
  const [collapsed, setCollapsed] = useState(true);
  const { data: session, status } = useSession(authOptions)
  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();

  let [rutas, setRutas] = useState([
    {
      key: '1',
      icon: <GoPasskeyFill />,
      label: (
        <Link href={"/dashboard/estudiantes"}>
          Estudiantes
        </Link>
      ),
    },
    {
      key: '2',
      icon: <UserAddOutlined />,
      label: (
        <Link href={"/dashboard/pacientes"}>
          Pacientes
        </Link>
      ),
    },
    {
      key: '3',
      icon: <FolderOpenFilled />,
      label: 'Historiales Medicos',
      children: [
        {
          key: '3.1',
          icon: <SlBookOpen />,
          label: (
            <Link href={"/dashboard/historiasClinicas"}>
              Historia Clinica
            </Link>
          ),
        },
        {
          key: '3.2',
          icon: <FiFileText />,
          label: (
            <Link href={"/dashboard/historiasFamiliares"}>
              Historias Familiares
            </Link>
          ),
        },
        {
          key: '3.3',
          icon: <TfiLayoutTab />,
          label: (
            <Link href={"/dashboard/antecedentesPersonales"}>
              Antecedentes Personales
            </Link>
          ),
        },
        {
          key: '3.4',
          icon: <SlSymbleFemale />,
          label: (
            <Link href={"/dashboard/mujeres"}>
              Mujeres
            </Link>
          ),
        },
        {
          key: '3.5',
          icon: <TfiLayoutTabV />,
          label: (
            <Link href={"/dashboard/hallazgosClinicos"}>
              Hallazgos Clinicos
            </Link>
          ),
        },
        {
          key: '3.6',
          icon: <TfiLayoutTabV />,
          label: (
            <Link href={"/dashboard/actividadesRealizadas"}>
              Actividades Realizadas
            </Link>
          ),
        }

      ]
    },
    {
      key: '4',
      icon: <LiaToothSolid />,
      label: 'Historiales Clinicos Operatorios',
      children: [
        {
          key: '4.1',
          icon: <FaTooth />,
          label: (
            <Link href={"/dashboard/historiasClinicasOperatoria"}>
              Odontodiagrama
            </Link>
          ),
        },
        {
          key: '4.2',
          icon: <GiTooth />,
          label: (
            <Link href={"/dashboard/examenPeriodontal"}>
              Periodontodiagrama
            </Link>
          ),
        },
        {
          key: '4.3',
          icon: <FaTooth />,
          label: (
            <Link href={"/dashboard/radiografias"}>
              Radiografias
            </Link>
          ),
        },
      ]
    }
  ])
  const [visible, setVisible] = useState(false);
  const [getData, setGetData] = useState(null)
  const [activo, setActivo] = useState(false)
  const showModal = () => {
    setVisible(true);
    setActivo(false)
  };

  const hideModal = () => {
    setVisible(false);
  };
  const notificaciones = (data) => {
    if ((data) && (data.lenght > 0)) {
      return true
    } else {
      return false
    }
  }

  async function fetchPostData(data) {
    let response = await fetch('/api/observaciones', {
      method: "Post",
      body: JSON.stringify({
        option: 0,
        id: data.id
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    const result = await response.json();

    setGetData(prevData => ({
      ...prevData,
      ...result
    }));
    console.log("getData", getData)
  }

  useEffect(() => {
    if (session) {
      if (!rutas && !session) {
        return []
      } else {

        switch (session.user.name.rol.nombre) {
          case "estudiante":
            let estudia = rutas.filter((items) => items.key !== '1')
            setRutas(estudia)
            socket.emit("authenticate", session.user.name);
            fetchPostData(session.user.name)
            break
          case "admin":
            socket.emit("authenticate", session.user.name);
            fetchPostData(session.user.name)
            break;

          default:
            break;
        }
      };
    }


  }, [session])

  useEffect(() => {
    socket.on('new-observacion-boton', (data) => {
      console.log(data)
      setGetData(prevObservaciones => [...data]);
      console.log("AUXILIO")
      setActivo(true)
    });

    return () => {
      socket.off('new-observacion-boton');
    };

  }, [socket]);
  return (
    <Layout style={{ minHeight: "100vh", justifyContent: "center" }}>

      {session ? (
        <>
          <Sider trigger={null} collapsible collapsed={collapsed}>
            <div className="demo-logo-vertical" />

            <Menu
              theme="dark"
              mode="inline"

              items={rutas}
            />
          </Sider>
          <Layout>
            <Header
              style={{
                padding: 0,
                background: colorBgContainer,
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <Button
                    type="text"
                    icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
                    onClick={() => setCollapsed(!collapsed)}
                    style={{
                      fontSize: '16px',
                      width: 64,
                      height: 64,
                    }}
                  />


                </div>
                <div>
                  <Button size="large" style={{ marginRight: '8px', border: "0px" }} onClick={() => signOut()}>
                    Salir
                  </Button>
                </div>
              </div>


            </Header>
            <Content
              style={{
                margin: '24px 16px',
                padding: 24,
                minHeight: 280,
                background: colorBgContainer,
                borderRadius: borderRadiusLG,
              }}
            >
              <NotificationModal
                visible={visible}
                onClose={hideModal}
                one={getData ? getData.one : getData}
              />
              {session.user.name.rol_id !== 2 &&
                <FloatButton
                  shape="circle"
                  type='primary'
                  onClick={showModal}
                  icon={<MdOutlineMailOutline />}
                  badge={{
                    dot: activo,
                  }}
                  style={{
                    right: 25,
                  }}
                />
              }
              {children}
            </Content>


          </Layout>
        </>
      ) :
        (
          <>
            <Flex justify="center" align="center" vertical >

              <Spin size="large" />
            </Flex>
          </>
        )
      }
    </Layout>
  );
};
export default DashboardLayout;
