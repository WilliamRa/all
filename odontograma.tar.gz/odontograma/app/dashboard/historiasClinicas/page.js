'use client'

import { Table, Button, Tag } from "antd"
import { FolderViewOutlined, FormOutlined, SnippetsOutlined } from '@ant-design/icons';
import { useEffect, useState } from "react";
import HistoriasClinicasModal from '../../components/modal/HistoriasClinicasModal';
import { useSession } from "next-auth/react";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { socket } from '../../../socket';
import { statusString } from "@/app/components/general";


export default function Page() {
  const [option, setOption] = useState({
    modal: false,
    option: 0,
    modalHeader: '',
    modalFooter: '',
    disabled: false,
    showHide: 'show',
    id: null
  })
  const [getData, setGetData] = useState(null)
  const { data: session, status } = useSession();
  const columns = [
    { title: 'NUMERO DE HISTORIA', dataIndex: 'numero_historia', key: 'numero_histora' },
    { title: 'ENFERMEDAD ACTUAL', dataIndex: 'enfermedad_actual', key: 'enfernedad_actual' },
    { title: 'MOTIVO', dataIndex: 'motivo_consulta', key: 'motivo_consulta' },
    {
      title: 'ACCION', key: 'action', render: (record) => {
        return (
          <div>
            <Button icon={<FolderViewOutlined />}
              size="middle"
              type='primary'
              shape='circle'

              style={{ marginRight: '8px', background: "#1677ff" }}
              onClick={() => showModal(2, record.key)}
            />

            <Button icon={<FormOutlined />}
              disabled={session.user.name.rol_id === 2 ? true : false}
              size="middle"
              type='primary'
              shape='circle'
              style={{ marginRight: '8px', background: "#1677ff" }}
              onClick={() => showModal(3, record.key)}
            />
          </div>
        )
      }
    },
  ];

  const showModal = (option, _id) => {
    if (option === 1) {
      setOption({
        modal: true,
        option: option,
        modalHeader: 'Registrar Historia Clinica',
        modalFooter: 'Guardar',
        disabled: false,
        showHide: 'show',
        id: null
      })
    } else if (option === 2) {
      fetchPostData(option, _id)

      setOption({
        modal: true,
        option: 2,
        modalHeader: 'Ver Historia Clinica',
        modalFooter: '',
        disabled: true,
        showHide: 'hide',
        id: _id
      })

    } else if (option === 3) {
      fetchPostData(option, _id)
      setOption({
        modal: true,
        option: option,
        modalHeader: 'Editar Historia Clinica',
        modalFooter: 'Editar',
        disabled: false,
        showHide: 'show',
        id: _id
      })
    }

  };

  const valorCloseModal = () => {
    setOption({
      modal: false,
      option: 0,
      modalHeader: '',
      modalFooter: '',
      disabled: false,
      showHide: 'show',
      id: null
    })
  }

  async function fetchData(data) {
    let response = await fetch('/api/historiasClinicas', {
      method: "POST",
      body: JSON.stringify({
        option: 0,
        usuario: data
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    const result = await response.json();

    setGetData(result)

  }

  async function fetchPostData(option, id) {
    let response = await fetch('/api/historiasClinicas', {
      method: "Post",
      body: JSON.stringify({
        option, id
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    const result = await response.json();

    setGetData(prevData => ({
      ...prevData,
      ...result
    }));
    console.log("getData", getData)
  }

  useEffect(() => {
    if (status === "authenticated" && session) {
      fetchData(session.user.name)
      console.log("getData", session, status)
      console.log("EFECTO",)
    }
  }, [!getData, session])

  useEffect(() => {
    const handleUpdatePaciente = (data) => {
      console.log(data, "PACIENTE");

      if (getData) {
        setGetData(prevData => {
          const pacienteExists = prevData.allHistorias.some(paciente => paciente.key === data.id);

          if (pacienteExists) {
            // Actualiza el paciente existente
            return {
              ...prevData,
              allHistorias: prevData.allHistorias.map(paciente => {
                if (paciente.key === data.id) {
                  return {
                    ...data,
                    key: data.id,
                  };
                }
                return paciente;
              })
            };
          } else {
            // Agrega un nuevo paciente
            return {
              ...prevData,
              allHistorias: [
                ...prevData.allHistorias,
                {
                  ...data,
                  key: data.id,
                }
              ]
            };
          }
        });
      }
    };

    socket.on("updateHistoriasClinicas", handleUpdatePaciente);

    return () => {
      socket.off("updateHistoriasClinicas", handleUpdatePaciente);
    };
  }, [getData]);

  return (
    <>
      <div className="containerGeneral" style={{ "marginBottom": "1.8%" }}>
        <div className="container-button">
          <Button color="success"
            type="primary" onClick={() => showModal(1, null)}
            disabled={session.user.name.rol_id === 2 ? true : false}
          >
            Agregar
          </Button>
        </div>
      </div>
      <HistoriasClinicasModal
        one={getData ? getData.one : getData}
        option={option}
        valorCloseModal={valorCloseModal}
        user={session}
      //router={router}
      />
      <Table
        columns={columns}
        dataSource={getData ? getData.allHistorias : []}
        size='small'
      //loading={loading}
      />
    </>
  )
}
