'use client'

import { Table, Button, List, Tag, Popconfirm, notification } from "antd"
import { FolderViewOutlined, FormOutlined, SnippetsOutlined } from '@ant-design/icons';
import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import HallazgosClinicosModal from "@/app/components/modal/HallazgosClinicosModal";
import { socket } from '../../../socket';
import ActividadesRealizadasModal from "@/app/components/modal/ActividadesRealizadasModal";
import dayjs from "dayjs";
import { statusString } from '@/app/components/general';


export default function Page() {
  const [getData, setGetData] = useState(null)
  const { data: session, status } = useSession()
  const [option, setOption] = useState({
    modal: false,
    option: 0,
    modalHeader: '',
    modalFooter: '',
    disabled: false,
    showHide: 'show',
    id: null
  })

  const columns = [
    { title: 'NUMERO DE HISTORIA', dataIndex: 'numero_historia', key: 'numero_historia' },
    { title: 'FECHA', dataIndex: 'fecha', key: 'fecha' },
    {
      title: 'ESTATUS',
      dataIndex: 'status',
      key: 'status',
      render: (_, status) => {
        console.log(status)
        if (status.status === 0) {
          return (
            <Tag color="geekblue">
              {statusString(status.status)}
            </Tag>
          )
        } else if (status.status === 1) {
          return (
            <Tag color="green">
              {statusString(status.status)}
            </Tag>
          )
        } else if (status.status === 2) {
          return (
            <Tag color="volcano">
              {statusString(status.status)}
            </Tag>
          )
        }
      }
    },
    {
      title: 'ACCION', key: 'action', render: (record) => {
        return (
          <div>
            <Button icon={<FolderViewOutlined />}
              size="middle"
              type='primary'
              shape='circle'

              style={{ marginRight: '8px', background: "#1677ff" }}
              onClick={() => showModal(2, record.key)}
            />
          </div>
        )
      }
    },
  ];

  const showModal = (option, _id) => {
    if (option === 1) {
      setOption({
        modal: true,
        option: option,
        modalHeader: 'Registrar Hallazgos Clinicos',
        modalFooter: 'Guardar',
        disabled: false,
        showHide: 'show',
        id: null
      })
    } else if (option === 2) {
      fetchPostData(option, _id)

      setOption({
        modal: true,
        option: 2,
        modalHeader: 'Ver Hallazgos Clinicos',
        modalFooter: '',
        disabled: true,
        showHide: 'hide',
        id: _id
      })

    } else if (option === 3) {
      fetchPostData(option, _id)
      setOption({
        modal: true,
        option: option,
        modalHeader: 'Editar Hallazgos Clinicos',
        modalFooter: 'Editar',
        disabled: false,
        showHide: 'show',
        id: _id
      })
    }

  };

  const valorCloseModal = () => {
    setOption({
      modal: false,
      option: 0,
      modalHeader: '',
      modalFooter: '',
      disabled: false,
      showHide: 'show',
      id: null
    })
  }

  async function fetchData(data) {
    let response = await fetch('/api/actividadesRealizadas', {
      method: "POST",
      body: JSON.stringify({
        option: 0,
        usuario: data
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    const result = await response.json();
    console.log("RESULT", result)
    setGetData(result)

  }

  async function fetchPostData(option, id) {
    let response = await fetch('/api/actividadesRealizadas', {
      method: "Post",
      body: JSON.stringify({
        option, id
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    const result = await response.json();

    setGetData(prevData => ({
      ...prevData,
      ...result
    }));
    console.log("getData", getData)
  }

  async function fetchDataPut(data, callback) {
    let respon = await fetch('/api/actividadesRealizadas', {
      method: "PUT",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(async (data) => {
      let a = await data.json()
      if (a.code === 403) {
        notification.error({
          message: a.message
        })
        setSpinActive(false);
      } else {
        notification.success({
          message: a.message
        })
      }
    })
  }


  useEffect(() => {
    if (status === "authenticated" && session) {
      fetchData(session.user.name)
      console.log("getData", session, status)
      console.log("EFECTO",)
    }
  }, [!getData, session])

  const confirm = async (id) => {
    let data = {
      id: id,
      usuario: session.user.name,
    }
    fetchDataPut(data)
  }


  useEffect(() => {
    const handleUpdatePaciente = (data) => {
      setGetData(prevData => {
        return {
          ...prevData,
          allHistorias: data
        }
      })
    };

    socket.on("updateActividades", handleUpdatePaciente);

    return () => {
      socket.off("updateActividades");
    };
  }, [getData]);

  return (
    <>
      <div className="containerGeneral" style={{ "marginBottom": "1.8%" }}>
        <div className="container-button">
          <Button color="success"
            type="primary" onClick={() => showModal(1, null)}
            disabled={session.user.name.rol_id === 2 ? true : false}
          >
            Agregar
          </Button>
        </div>
      </div>
      <ActividadesRealizadasModal
        one={getData ? getData.one : getData}
        option={option}
        valorCloseModal={valorCloseModal}
        user={session}
      //router={router}
      />

      <Table
        columns={columns}
        expandable={{
          expandedRowRender: (record) => {
            return (
              <List
                dataSource={record.actividades_realizadas}
                // pagination={{
                //   pageSize: 5
                // }}
                renderItem={(item, index) => (
                  <List.Item key={item.id}>
                    <List.Item.Meta description={dayjs(item.fecha).format('DD-MM-YYYY')} />
                    <List.Item.Meta description={item.actividad_realizada} />

                    <Popconfirm
                      title="Advertencia"
                      description="¿Seguro que quiere eliminar este elemento?"
                      onConfirm={() => confirm(item.id)}
                     // onOpenChange={() => console.log('open change')}
                    >
                      <Button icon={<FormOutlined />}
                        disabled={session.user.name.rol_id === 2 ? true : false}
                        size="middle"
                        //type='primary'
                        danger
                        shape='circle'
                      //style={{ marginRight: '8px', background: "#1677ff" }}
                      />
                    </Popconfirm>
                  </List.Item>
                )}
              />
            )
          },
          rowExpandable: (record) => record.name !== 'Not Expandable',
        }}
        dataSource={getData ? getData.allHistorias : []}
      />
    </>
  )
}