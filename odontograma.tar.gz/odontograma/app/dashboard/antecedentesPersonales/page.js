'use client'

import { Table, Button } from "antd"
import { FolderViewOutlined, FormOutlined, SnippetsOutlined } from '@ant-design/icons';
import { useEffect, useState } from "react";
import AntecedentesPersonalesModal from '../../components/modal/AntecedentesPersonalesModal';
import { useSession } from "next-auth/react";
import { socket } from '@/socket';


export default function Page() {
  const [option, setOption] = useState({
    modal: false,
    option: 0,
    modalHeader: '',
    modalFooter: '',
    disabled: false,
    showHide: 'show',
    id: null
  })
  const [getData, setGetData] = useState(null)
  const { data: session, status } = useSession()
  const columns = [
    { title: 'NERVIOS AL ODONTOLOGO', dataIndex: 'nervios_al_odontologo', key: 'nervios_al_odontologo' },
    { title: 'DOLOR/MOLESTIA EN BOCA', dataIndex: 'dolor_boca', key: 'dolor_boca' },
    { title: 'DOLOR DE LA DENTADURA', dataIndex: 'dolor_dentadura', key: 'dolor_dentadura' },
    { title: '', dataIndex: '', key: '' },
    {
      title: 'ACCION', key: 'action', render: (record) => {
        return (
          <div>
            <Button icon={<FolderViewOutlined />}
              size="middle"
              type='primary'
              shape='circle'

              style={{ marginRight: '8px', background: "#1677ff" }}
              onClick={() => showModal(2, record.key)}
            />

            <Button icon={<FormOutlined />}
              size="middle"
              type='primary'
              shape='circle'
              disabled={session.user.name.rol_id === 2 ? true : false}
              style={{ marginRight: '8px', background: "#1677ff" }}
              onClick={() => showModal(3, record.key)}
            />
          </div>
        )
      }
    },
  ];

  const showModal = (option, _id) => {
    if (option === 1) {
      setOption({
        modal: true,
        option: option,
        modalHeader: 'Registrar Antecedentes Personales',
        modalFooter: 'Guardar',
        disabled: false,
        showHide: 'show',
        id: null
      })
    } else if (option === 2) {
      fetchPostData(option, _id)

      setOption({
        modal: true,
        option: 2,
        modalHeader: 'Ver Antecedentes Personales',
        modalFooter: '',
        disabled: true,
        showHide: 'hide',
        id: _id
      })

    } else if (option === 3) {
      fetchPostData(option, _id)
      setOption({
        modal: true,
        option: option,
        modalHeader: 'Editar Antecedentes Personales',
        modalFooter: 'Editar',
        disabled: false,
        showHide: 'show',
        id: _id
      })
    }

  };

  const valorCloseModal = () => {
    setOption({
      modal: false,
      option: 0,
      modalHeader: '',
      modalFooter: '',
      disabled: false,
      showHide: 'show',
      id: null
    })
  }

  async function fetchData(data) {
    let response = await fetch('/api/antecedentesPersonales', {
      method: "POST",
      body: JSON.stringify({
        option: 0,
        usuario: data
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    const result = await response.json();

    setGetData(result)

  }

  async function fetchPostData(option, id) {
    let response = await fetch('/api/antecedentesPersonales', {
      method: "Post",
      body: JSON.stringify({
        option, id
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    const result = await response.json();

    setGetData(prevData => ({
      ...prevData,
      ...result
    }));
  }

  useEffect(() => {
    if (status === "authenticated" && session) {
      fetchData(session.user.name)
      console.log("getData", session, status)
      console.log("EFECTO",)
    }
  }, [!getData, session])

  useEffect(() => {
    const handleUpdatePaciente = (data) => {
      console.log({
        ...data,
        key: data.id,
      })
      if (getData) {
        setGetData(prevData => {
          const pacienteExists = prevData.allHistorias.some(paciente => paciente.key === data.id);

          if (pacienteExists) {

            return {
              ...prevData,
              allHistorias: prevData.allHistorias.map(paciente => {
                if (paciente.key === data.id) {
                  return {
                    dolor_boca: data.dolor_boca === 0 ? "NO" : "SI",
                    dolor_dentadura: data.dolor_dentadura === 0 ? "NO" : "SI",
                    id: data.id,
                    key: data.id,
                    nervios_al_odontologo: data.nervios_al_odontologo === 0 ? "NO" : "SI"
                  };
                }
                return paciente;
              })
            };
          } else {
            // Agrega un nuevo paciente
            return {
              ...prevData,
              allHistorias: [
                ...prevData.allHistorias,
                {
                  dolor_boca: data.dolor_boca === 0 ? "NO" : "SI",
                  dolor_dentadura: data.dolor_dentadura === 0 ? "NO" : "SI",
                  id: data.id,
                  key: data.id,
                  nervios_al_odontologo: data.nervios_al_odontologo === 0 ? "NO" : "SI"
                }
              ]
            };
          }
        });
      }
    };

    socket.on("updateAntecedentesPersonales", handleUpdatePaciente);

    return () => {
      socket.off("updateAntecedentesPersonales");
    };
  }, [getData]);

  return (
    <>
      <div className="containerGeneral" style={{ "marginBottom": "1.8%" }}>
        <div className="container-button">
          <Button color="success"
            disabled={session.user.name.rol_id === 2 ? true : false}
            type="primary" onClick={() => showModal(1, null)}
          // disabled={disabledCreate}>
          >
            Agregar
          </Button>
        </div>
      </div>
      <AntecedentesPersonalesModal
        one={getData ? getData.one : getData}
        option={option}
        valorCloseModal={valorCloseModal}
        user={session}
      //router={router}
      />
      <Table
        columns={columns}
        dataSource={getData ? getData.allHistorias : []}
        size='small'
      //loading={loading}
      />
    </>
  )
}