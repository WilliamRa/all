// mark as client component
"use client";

// importing necessary functions
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation";
import { useEffect } from "react";

const SessionVerifier = ({ children }) => {
  const { data: session, status } = useSession();
  const router = useRouter();

  useEffect(() => {
    // Si la sesión no está cargada o el usuario no está autenticado,
    // redirige a la página de inicio de sesión
    if (status === "loading" || !session) {
      router.replace("/dashboard"); // Cambia "/login" por tu ruta de inicio de sesión
    }
  }, [session, status, router]);

  // Renderiza el contenido solo si el usuario está autenticado
  return session ? children : null;
};


export default function Home() {
  return (
    <SessionVerifier>
      <>
      </>
    </SessionVerifier>
  );

}