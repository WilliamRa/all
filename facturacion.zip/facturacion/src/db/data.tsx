export let fetchProducts = [
 {
    id:1,
    name:"Cable de cobre",
    mount:123.35,
    stock:10
 },
 {
    id:2,
    name:"Cable de aliacion",
    mount:112.90,
    stock:10
 },
 {
    id:3,
    name:"Bloque de concreto",
    mount:8.87,
    stock:10
 },
 {
    id:4,
    name:"Saco de semento",
    mount:34.98,
    stock:10
 },
 {
    id:5,
    name:"Saco de pego",
    mount:26.090,
    stock:10
 },
 {
    id:6,
    name:"Alicate grande",
    mount:123.33,
    stock:10
 },
 {
    id:7,
    name:"Cable UTP",
    mount:6.2,
    stock:10
 },  
 {
    id:8,
    name:"Cable de alto voltaje",
    mount:43.0,
    stock:10
 },      
]

export let fecthMethod = [
    {
        id:1,
        method:"Pago movil"
    },
    {
        id:2,
        method:"Tarjeta"
    },
    {
        id:3,
        method:"Divisas"
    },
    {
        id:4,
        method:"Efectivo Bs"
    },
    {
        id:5,
        method:"Binance"
    },

]