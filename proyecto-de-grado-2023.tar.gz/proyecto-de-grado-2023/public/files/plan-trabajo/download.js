import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {
  const { method, body } = req;

  if (method === 'POST') {
    try {
      if (!body.id) return res.status(401).json({ type: 'REQUEST_FAILED_MISSING_PARAM', message: 'Falta el identificador del archivo' });

      let plan_trabajo = await prisma.plan_trabajo.findUnique({
        where: {
          id: parseInt(body.id)
        },
        select: {
          plan_trabajo_document: true
        }
      });



      return res.status(200).json({
        carta_aceptacion_pasantia: plan_trabajo.plan_trabajo_document
      });

    } catch (err) {

    } finally {
      prisma.$disconnect();
    }

  } else {
    res.setHeader('Allow', ['GET']);
    res.status(405).end(`Method ${method} Not Allowed`);
  }

}