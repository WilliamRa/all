import React, {
  useState,
  useEffect,
  useCallback,
  createContext
} from 'react';
import axios from 'axios';


export const DEFAULT_AUTH_STATE_VALUES = {
  accessToken: null,
  isAuthenticated: false,
  user: {
    id: null,
    username: null,
    fullname: null,
    email: null
  }
};

export const AuthContext = createContext(DEFAULT_AUTH_STATE_VALUES); 

export const AuthProvider = ({ children }) => {

  const isProd = process.env.NODE_ENV === 'production';
  const BACKEND_HOST = isProd ? 'http://localhost:3000' : 'http://localhost:3000';
  const [ authData, setAuthData ] = useState(DEFAULT_AUTH_STATE_VALUES);
  const [ loading, setLoading ] = useState(true);

  const loadApp = useCallback(async () => {
    try {
      let { data } = await axios.get(`${BACKEND_HOST}/api/refresh`, {
        withCredentials: true
      });

      if ( data?.accessToken ) {
        setAuthData({
          accessToken: data.accessToken,
          isAuthenticated: true,
          user: data.user
        });
      } else {
        setAuthData(DEFAULT_AUTH_STATE_VALUES);
      }
    } catch (e) {
      console.log('Error thrown', e);
      setAuthData(DEFAULT_AUTH_STATE_VALUES);
    }
    

    setLoading(false);

  });

  useEffect(() => {
    loadApp();
  }, []);

  return (
    <AuthContext.Provider value={[ authData, setAuthData ]}>
      { !loading && children || <div>Loading</div> }
    </AuthContext.Provider>
  );

};