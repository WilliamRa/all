import { useSession } from 'next-auth/react';

import VerticalNavLink from './VerticalNavLink'
import VerticalNavSectionTitle from './VerticalNavSectionTitle'

const VerticalNavItems = props => {
  const { data: session } = useSession();
  const { verticalNavItems } = props;

  const RenderMenuItems = verticalNavItems?.map((item, index) => {
    if ( item?.sectionTitle ) {
      const TagName = VerticalNavSectionTitle;

      return (
        <TagName 
          {...props}
          key={index}
          item={item}
        />
      );
    };

    if ( item?.onlyFor.includes(session?.user.name.role_id) ) {
      const TagName = VerticalNavLink;
  
      return (
        <TagName 
          {...props}
          key={index}
          item={item}
        />
      );
    }
  });

  return (
    <>
      {RenderMenuItems}
    </>
  );
}

export default VerticalNavItems
