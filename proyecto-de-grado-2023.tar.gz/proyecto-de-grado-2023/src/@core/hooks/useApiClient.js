import axios from 'axios';

const isProduction = process.env.NODE_ENV === 'production';

const defaultOptions = {
  baseURL: isProduction ? 'http://localhost:3000/api' : 'http://localhost:3000/api',
  headers: {
    'Content-Type': 'application/json'
  }
};

function useApiClient(options = {}) {
  options = Object.assign(defaultOptions, options);
  const proxyClient = axios.create(options);
  return proxyClient;
}

export default useApiClient;
