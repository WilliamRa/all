import { useContext } from 'react';
import axios from 'axios';
import { AuthContext, DEFAULT_AUTH_STATE_VALUES } from './../context/AuthContext';

function useAuth() {

  const isProd = process.env.NODE_ENV === 'production';
  const BACKEND_HOST = isProd ? 'https://wonderful-longma-e490ae.netlify.app' : 'http://localhost:3000';
  const [authData, setAuthData] = useContext(AuthContext);

  const removeAuthData = () => {
    setAuthData(DEFAULT_AUTH_STATE_VALUES);
  };

  const refreshAuth = async () => {
    const { data } = await axios.get(`${BACKEND_HOST}/api/refresh`, {
      withCredentials: true
    });

    if (data?.accessToken) {
      setAuthData({
        accessToken: data.accessToken,
        isAuthenticated: true,
        user: data.user
      });
    } else if (data?.error && data?.error?.name === 'TokenExpiredError') {
      removeAuthData();
    }
    return data?.accessToken || null;
  };

  const _authenticationAction = async (endpoint, data, callback) => {
    try {
      const response = await axios.post(`${BACKEND_HOST}/api/${endpoint}`, data, {
        withCredentials: true
      });

      if (response) {
        callback(null, response);
      }
    } catch (err) {
      callback(err, null);
    }
  };

  const register = ({ fullname, username, email, password }, callback) => {
    _authenticationAction('register', { fullname, username, email, password }, callback);
  };

  const logIn = async ({ username, password, rememberMe }, callback) => {
    _authenticationAction('login', { username, password, rememberMe }, callback);
  };

  const logOut = async () => {
    try {
      await axios.get(`${BACKEND_HOST}/api/logout`, {
        withCredentials: true
      });
      removeAuthData();
    } catch (err) {
      console.log(
        'Something went wrong while trying to log out the user'
      );
    }
  };

  return {
    authData,
    setAuthData,
    removeAuthData,
    refreshAuth,
    register,
    logIn,
    logOut
  };
}

export default useAuth;