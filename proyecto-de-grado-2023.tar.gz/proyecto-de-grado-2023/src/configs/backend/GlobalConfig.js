export default {
    message: 'hello world!!!'
};