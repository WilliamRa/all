const themeConfig = {
  // ** Layout Configs
  templateName: 'Coordinacion de pasantias' /* App Name */,
  mode: 'light' /* light | dark */,
  contentWidth: 'boxed' /* full | boxed */,
  // ** Routing Configs
  routingLoader: true /* true | false */,
  // ** Navigation (Menu) Configs
  menuTextTruncate: true /* true | false */,
  navigationSize: 260 /* Number in PX(Pixels) /*! Note: This is for Vertical navigation menu only */,
  // ** Other Configs
  responsiveFontSizes: true /* true | false */,
  disableRipple: false /* true | false */,
  boxesShadow: '0 0 15px rgba(0, 0, 0, .45)',
  layoutBorder: '1px solid #042e94',
  standardColor: '#F4F5FA',
};

export default themeConfig;
