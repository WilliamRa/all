// ** React Imports
import { useState, Fragment } from 'react';

// ** Next Imports
import { useSession } from 'next-auth/react';

// ** MUI Imports
import Box from '@mui/material/Box';
import Alert from '@mui/material/Alert';
import Button from '@mui/material/Button';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import CircularProgress from '@mui/material/CircularProgress';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import Typography from '@mui/material/Typography';
import CardContent from '@mui/material/CardContent';
import { styled, useTheme } from '@mui/material/styles';

import Check from 'mdi-material-ui/Check';
import Information from 'mdi-material-ui/Information';
import AlertIcon from 'mdi-material-ui/Alert';

import useApiClient from 'src/@core/hooks/useApiClient';
import { TextField } from '@mui/material';

const ImgStyled = styled('img')(({ theme }) => ({
  width: 120,
  height: 120,
  marginRight: theme.spacing(6.25),
  borderRadius: theme.shape.borderRadius
}));

const ButtonStyled = styled(Button)(({ theme }) => ({
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    textAlign: 'center'
  }
}));

const ResetButtonStyled = styled(Button)(({ theme }) => ({
  // marginLeft: theme.spacing(4.5),
  marginTop: theme.spacing(4),
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    marginLeft: 0,
    textAlign: 'center',
    marginTop: theme.spacing(4)
  }
}));

const FilenameText = styled(Typography)(({ theme }) => ({
  backgroundColor: '#f2f2f2',
  padding: '3px 5px',
  borderRadius: '5px',
  border: '1px solid #dadada',
  fontFamily: 'monospace',
  fontSize: '9pt',
  fontWeight: 'bold',
  marginRight: '10px',
}));

const steps = [
  'Fase 1',
  'Fase 2',
  'Fase 3'
];

const RegisterDocuments = () => {
  
  const theme = useTheme();
  const { data: session } = useSession();
  const apiClient = useApiClient();

  const [ stepIndex, setStepIndex ] = useState(0);
  const [ success, setSuccess ] = useState(null);
  const [ submitting, setSubmitting ] = useState(false);
  const [ anchorEl, setAnchorEl ] = useState(null);

  // contiene los objetos Files del navegador
  const [ filesData, setFilesData ] = useState({
    inscripcion: null,
    aceptacion: null,
    planTrabajo: null
  });
  
  // contiene los base 64
  const [ filesInfo, setFilesInfo ] = useState({
    projectName: '',
    inscripcion: null,
    aceptacion: null,
    planTrabajo: null
  });
  
  const [ docsSrc, setDocsSrc ] = useState({
    inscripcion: '/images/filetypes/default-file.jpg',
    aceptacion: '/images/filetypes/default-file.jpg',
    planTrabajo: '/images/filetypes/default-file.jpg',
  });

  const handleDropdownOpen = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleDropdownClose = url => {
    if ( url ) {
      router.push(url);
    }

    setAnchorEl(null);
  };

  const handleFileChange = name => event => {
    event.preventDefault();

    const reader = new FileReader();
    const { files } = event.target;

    if ( files && files.length !== 0 ) {
      setFilesData({
        ...filesData,
        [name]:  files[0]
      });

      reader.onload = () => setFilesInfo({
        ...filesInfo,
        [name]: reader.result
      });
      reader.readAsDataURL(files[0]);
    }
  };

  const handleChange = prop => (event) => {
    setFilesInfo({
      ...filesInfo,
      [prop]: event.target.value
    });
  };

  const handleFileDelete = name => event => {
    event.preventDefault();

    if ( name === 'all' ) {
      setFilesData({
        inscripcion: null,
        aceptacion: null,
        planTrabajo: null
      });
      setFilesInfo({
        projectName: '',
        inscripcion: null,
        aceptacion: null,
        planTrabajo: null
      });  

      return;
    }
    setFilesData({
      ...filesData,
      [name]: null
    });
    setFilesInfo({
      ...filesInfo,
      [name]: null
    });
  };

  const handleFormSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await apiClient.post('/solicitud/registerSolicitud', {
        ...filesInfo,
        user_id: session.user.name.id
      });

      if ( response.data?.type === 'FORM_REGISTRY_SUCCESS' ) {
        setSuccess(response.data);
        setFilesData({
          inscripcion: null,
          aceptacion: null,
          planTrabajo: null
        });  
        setFilesInfo({
          projectName: '',
          inscripcion: null,
          aceptacion: null,
          planTrabajo: null
        });  
      }
    } catch (e) {
      console.log(e);
      setFilesData({
        inscripcion: null,
        aceptacion: null,
        planTrabajo: null
      });  
      setFilesInfo({
        projectName: '',
        inscripcion: null,
        aceptacion: null,
        planTrabajo: null
      });  
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card>
      <form onSubmit={handleFormSubmit}>
        <CardHeader title="Registrar Documentos" />
        <CardContent sx={{ pt: theme => `${theme.spacing(3)} !important` }}>
          <Alert color="warning" icon={<AlertIcon/>}>
            El tiempo estimado para la emision de solicitudes de archivos esta diponible entre el 25/06/2024 y el 30/06/2024 
          </Alert>
          
          <Stepper activeStep={0} sx={{ pb: 3 }}>
            {steps.map((label, i) => (
              <Step key={i}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>

          <Alert color="info" icon={<Information/>}>
            <Typography variant="body1">
              Solo se permiten archivos de tipo: <Typography variant='caption'>.png, .jpg, .jpeg, .docx o .pdf</Typography> con tamaño máximo de 800KB.
            </Typography>
          </Alert>

          <Grid container spacing={[5, 0]}>
            <Grid item xs={12} sx={{ mt: 4.8, mb: 3 }}>
              <TextField
                fullWidth
                onChange={handleChange('projectName')}
                value={filesInfo.projectName}
                type="text"
                label="Nombre del proyecto"
              />
            </Grid>
          </Grid>

          <Grid
            container
            spacing={[5, 0]}
            sx={{
              flexDirection: "row",
              flexWrap: { md: "nowrap" },
              gap: 3,
              mb: 5
            }}
          >

            {/* Cedula de identidad */}
            <Grid item xs={12} md={4} sx={{ mt: 4.8, mb: 3, pt: 10, py: 5, borderRadius: '10px', border: '1px solid #dadada' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <ImgStyled src={docsSrc.inscripcion} alt='Profile Pic' />
                <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start' }}>
                  <Typography variant="body2" sx={{ mb: 2 }}>
                    Contancia de inscripcion
                  </Typography>
                  
                  <ButtonStyled size="small" component="label" variant="contained" htmlFor="user-docs-dni">
                    Subir archivo
                    <input
                      hidden
                      type="file"
                      onChange={handleFileChange('inscripcion')}
                      accept="image/png, image/jpeg, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                      id="user-docs-dni"
                    />
                  </ButtonStyled>
                  <ResetButtonStyled size="small" color="error" variant="outlined" onClick={handleFileDelete('inscripcion')}>
                    Eliminar
                  </ResetButtonStyled>
                </Box>
              </Box>
              {filesData.inscripcion && (
                <Box sx={{ margin: 2 }}>
                  <FilenameText variant="body2">
                    {filesData.inscripcion?.name}
                  </FilenameText>
                </Box>
              )}
            </Grid>

            {/* Constancia de notas */}
            <Grid item xs={12} md={4} sx={{ mt: 4.8, mb: 3, pt: 10, py: 5, borderRadius: '10px', border: '1px solid #dadada' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <ImgStyled src={docsSrc.aceptacion} alt='Profile Pic' />
                <Box>
                  <Typography variant="body2" sx={{ mb: 5 }}>
                    Carta de aceptacion
                  </Typography>
                  <ButtonStyled size="small" component="label" variant="contained" htmlFor="user-docs-notas">
                    Subir archivo
                    <input
                      hidden
                      type="file"
                      onChange={handleFileChange('aceptacion')}
                      accept="image/png, image/jpeg, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                      id="user-docs-notas"
                    />
                  </ButtonStyled>
                  <ResetButtonStyled size="small" color="error" variant="outlined" onClick={handleFileDelete('aceptacion')}>
                    Eliminar
                  </ResetButtonStyled>
                </Box>
              </Box>
              {filesData.aceptacion && (
                <Box sx={{ margin: 2 }}>
                  <FilenameText variant="body2">
                    {filesData.aceptacion?.name}
                  </FilenameText>
                </Box>
              )}
            </Grid>

            {/* Constancia de estudio */}
            <Grid item xs={12} md={4} sx={{ mt: 4.8, mb: 3, pt: 10, py: 5, borderRadius: '10px', border: '1px solid #dadada' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <ImgStyled src={docsSrc.planTrabajo} alt='Profile Pic' />
                <Box>
                  <Typography variant="body2" sx={{ mb: 5 }}>
                    Plan de trabajo
                  </Typography>
                  <ButtonStyled size="small" component="label" variant="contained" htmlFor="user-docs-estudio">
                    Subir archivo
                    <input
                      hidden
                      type="file"
                      onChange={handleFileChange('planTrabajo')}
                      accept="image/png, image/jpeg, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                      id="user-docs-estudio"
                    />
                  </ButtonStyled>
                  <ResetButtonStyled size="small" color="error" variant="outlined" onClick={handleFileDelete('planTrabajo')}>
                    Eliminar
                  </ResetButtonStyled>
                </Box>
              </Box>
              {filesData.planTrabajo && (
                <Box sx={{ my: 2 }}>
                  <FilenameText variant="body2">
                    {filesData.planTrabajo?.name}
                  </FilenameText>
                </Box>
              )}
            </Grid>
          </Grid>

          {success && (
            <Grid item xs={12} sx={{ mb: 3 }}>
              <Alert color="success" iconMapping={<Check/>}>
                <Typography variant="body2">
                  {success?.message}
                </Typography>
              </Alert>
            </Grid>
          )}

          <Grid container  direction="row-reverse">
            <Button
              type="submit"
              variant="contained"
              {...(
                filesInfo.aceptacion
                && filesInfo.inscripcion
                && filesInfo.planTrabajo
                && filesInfo.projectName
              ) ? null : { disabled: true }
            }
            >
              {submitting ? <CircularProgress/> : "Subir documentos"}
            </Button>
            <Button
              type="reset"
              variant="outlined"
              color="secondary"
              onClick={handleFileDelete('all')}
              sx={{ mr: 3.5 }}
            >
              Reiniciar
            </Button>
          </Grid>
          
        </CardContent>
      </form>
    </Card>
  );
}

export default RegisterDocuments;