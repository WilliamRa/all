// ** Next Imports
import { useRouter } from 'next/router';

// ** MUI Imports
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import MenuItem from '@mui/material/MenuItem';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Alert from '@mui/material/Alert';
import CardHeader from '@mui/material/CardHeader';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';

import Typography from '@mui/material/Typography';
import CardContent from '@mui/material/CardContent';
import { styled, useTheme } from '@mui/material/styles';
import { useState, useEffect } from 'react';
import useApiClient from 'src/@core/hooks/useApiClient';

import Check from 'mdi-material-ui/Check';

const ImgStyled = styled('img')(({ theme }) => ({
  width: 120,
  height: 120,
  marginRight: theme.spacing(6.25),
  borderRadius: theme.shape.borderRadius
}));

const ButtonStyled = styled(Button)(({ theme }) => ({
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    textAlign: 'center'
  }
}));

const ResetButtonStyled = styled(Button)(({ theme }) => ({
  marginLeft: theme.spacing(4.5),
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    marginLeft: 0,
    textAlign: 'center',
    marginTop: theme.spacing(4)
  }
}));

const fileStatus = [
  { value: 1, name: 'Aprobado' },
  { value: 0, name: 'Rechazado' }
];

const UpdateDocument = () => {

  const router = useRouter();
  const { id } = router.query;
  const apiClient = useApiClient();

  const [success, setSuccess] = useState(null);

  const [docsSrc, setDocsSrc] = useState({
    inscripcion: '/images/filetypes/default-file.jpg',
    aceptacion: '/images/filetypes/default-file.jpg',
    planTrabajo: '/images/filetypes/default-file.jpg',
  });

  const [filesData, setFilesData] = useState({
    inscripcion: null,
    aceptacion: null,
    planTrabajo: null
  });

  useEffect(() => {
    fetchDocumentsStatus();
  }, []);

  const fetchDocumentsStatus = async () => {
    try {
      let response = await apiClient.get('/files/solicitudes/status', {
        params: {
          solicitudId: id
        }
      });

      if (response.data) {
        setFilesData({
          inscripcion: response.data[0].constancia_status,
          aceptacion: response.data[0].carta_aceptacion_status,
          planTrabajo: response.data[0].plan_trabajo_status
        });
      }
    } catch (e) {

    } finally {

    }
  };

  const handleSelectChange = prop => event => {
    setFilesData({
      ...filesData,
      [prop]: event.target.value
    });
  };

  const handleFormSubmit = async (event) => {
    event.preventDefault();

    try {
      const response = await apiClient.put('/solicitud/updateSolicitud', filesData, {
        params: {
          solicitudId: id,
          fase: 1
        }
      });

      if (response.data) {
        setFilesData({
          inscripcion: null,
          aceptacion: null,
          planTrabajo: null
        });
        setSuccess(response.data);
        setTimeout(() => {
          router.back();
        }, 1500);
      }
    } catch (err) {
      console.log(err);
      alert('Error en consola');
    } finally {

    }
  };

  const handleFileDownload = async (document) => {
    try {
      // Realiza la solicitud al servidor para descargar el archivo
      let response = await apiClient.get("/files/solicitudes/download", {
        params: {
          file: document,
          solicitudId: id
        }
      });

      // Verifica si la respuesta contiene el archivo en base64 con prefijo MIME
      const inscripcion = response.data[0]?.inscripcion;
      const aceptacion = response.data[0]?.aceptacion;
      const planTrabajo = response.data[0]?.planTrabajo;
      let base64WithMimeType;

      if (inscripcion) {
        // Verifica si la cadena contiene "data:" y ",", de lo contrario asume que el string base64 es el contenido sin el prefijo MIME
        base64WithMimeType = inscripcion.startsWith('data:') ? inscripcion : `application/pdf;base64,${inscripcion}`;
      }

      if (aceptacion) {
        // Verifica si la cadena contiene "data:" y ",", de lo contrario asume que el string base64 es el contenido sin el prefijo MIME
        base64WithMimeType = aceptacion.startsWith('data:') ? aceptacion : `application/pdf;base64,${aceptacion}`;
      }

      if (planTrabajo) {
        // Verifica si la cadena contiene "data:" y ",", de lo contrario asume que el string base64 es el contenido sin el prefijo MIME
        base64WithMimeType = planTrabajo.startsWith('data:') ? planTrabajo : `application/pdf;base64,${planTrabajo}`;
      }

      // Separar el tipo MIME y el contenido base64
      const [prefix, base64] = base64WithMimeType.split(',');
      const mimeType = prefix.match(/:(.*?);/)[1];

      // Decodificar la cadena Base64 y crear un Blob
      const byteCharacters = atob(base64);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });

      let extension = '';

      if (mimeType === 'application/pdf') {
        extension = 'pdf';
      } else if (mimeType === 'application/msword') {
        extension = 'doc';
      } else if (mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        extension = 'docx';
      } else {
        throw new Error(`Unsupported MIME type: ${mimeType}`);
      }

      const fileName = `${document}.${extension}`;

      const link = window.document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = fileName;
      window.document.body.appendChild(link);
      link.click();
      window.document.body.removeChild(link);

    } catch (error) {
      console.error('Error downloading file:', error);
    } finally {
      return
    }
  }

  return (
    <Card>
      <form onSubmit={handleFormSubmit}>
        <CardHeader title="Revision de solicitud" />
        <CardContent sx={{ pt: theme => `${theme.spacing(3)} !important` }}>
          <Grid
            container
            spacing={[5, 0]}
            sx={{
              flexDirection: "row",
              gap: 3,
              mb: 5
            }}
          >

            {/* Cedula de identidad */}
            <Grid item xs={12} sx={{ mb: 3, pt: 10, py: 5, px: 3, borderRadius: '10px', border: '1px solid #dadada' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <ImgStyled src={docsSrc.inscripcion} alt='Profile Pic' />
                <Box sx={{ width: '100%' }}>
                  <Typography variant="body2" sx={{ mb: 2 }}>
                    Contancia de inscripcion
                  </Typography>

                  <Box sx={{ mb: 2 }}>
                    <ButtonStyled onClick={() => handleFileDownload('inscripcion')} size="small" component="label" variant="contained" htmlFor="user-docs-dni">
                      Descargar
                    </ButtonStyled>
                    <FormControl size="small" sx={{ ml: 3 }}>
                      <InputLabel>Status</InputLabel>
                      <Select label="Status" value={filesData.inscripcion} onChange={handleSelectChange('inscripcion')}>
                        {fileStatus.map((status, i) => (
                          <MenuItem key={i} value={status.value}>{status.name}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Box>

                  {/* <Box sx={{ width: '100%' }}>
                    <TextField
                      size="small"
                      fullWidth
                      type="text"
                      label="Motivo de rechazo"
                    />
                  </Box> */}

                </Box>
              </Box>
            </Grid>

            {/* Constancia de notas */}
            <Grid item xs={12} sx={{ mb: 3, pt: 10, py: 5, px: 3, borderRadius: '10px', border: '1px solid #dadada' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <ImgStyled src={docsSrc.aceptacion} alt='Profile Pic' />
                <Box sx={{ width: '100%' }}>
                  <Typography variant="body2" sx={{ mb: 5 }}>
                    Carta de aceptacion
                  </Typography>

                  <Box sx={{ mb: 2 }}>
                    <ButtonStyled onClick={() => handleFileDownload('aceptacion')} size="small" component="label" variant="contained" htmlFor="user-docs-notas">
                      Descargar
                    </ButtonStyled>

                    <FormControl size="small" sx={{ ml: 3 }}>
                      <InputLabel>Status</InputLabel>
                      <Select label="Status" value={filesData.aceptacion} onChange={handleSelectChange('aceptacion')}>
                        {fileStatus.map((status, i) => (
                          <MenuItem key={i} value={status.value}>{status.name}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Box>

                  {/* <Box sx={{ width: '100%' }}>
                    <TextField
                      size="small"
                      fullWidth
                      type="text"
                      label="Motivo de rechazo"
                    />
                  </Box> */}
                </Box>
              </Box>
            </Grid>

            {/* Constancia de estudio */}
            <Grid item xs={12} sx={{ mb: 3, pt: 10, py: 5, px: 3, borderRadius: '10px', border: '1px solid #dadada' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <ImgStyled src={docsSrc.planTrabajo} alt='Profile Pic' />
                <Box sx={{ width: '100%' }}>
                  <Typography variant="body2" sx={{ mb: 5 }}>
                    Plan de trabajo
                  </Typography>

                  <Box sx={{ mb: 2 }}>
                    <ButtonStyled onClick={() => handleFileDownload('planTrabajo')} size="small" component="label" variant="contained" htmlFor="user-docs-estudio">
                      Descargar
                    </ButtonStyled>

                    <FormControl size="small" sx={{ ml: 3 }}>
                      <InputLabel>Status</InputLabel>
                      <Select label="Status" value={filesData.planTrabajo} onChange={handleSelectChange('planTrabajo')}>
                        {fileStatus.map((status, i) => (
                          <MenuItem key={i} value={status.value}>{status.name}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Box>

                  {/* <Box sx={{ width: '100%' }}>
                    <TextField
                      size="small"
                      fullWidth
                      type="text"
                      label="Motivo de rechazo"
                    />
                  </Box> */}
                </Box>
              </Box>
            </Grid>
          </Grid>

          {success && (
            <Grid item xs={12}>
              <Alert color="success" icon={<Check />}>
                {success?.message}
              </Alert>
            </Grid>
          )}

          <Grid container direction="row-reverse">
            <Button type="submit" variant="contained">
              Actualizar solicitud
            </Button>
            <Button type="reset" variant="outlined" color="secondary" sx={{ marginRight: 3.5 }}>
              Reiniciar
            </Button>
          </Grid>
        </CardContent>
      </form>
    </Card>
  )
}

export default UpdateDocument;