// ** Next Imports
import { useSession } from 'next-auth/react';

import _ from 'lodash';
import dayjs from 'dayjs';

// ** React Imports
import { useState, useEffect, useCallback, Fragment } from 'react';
import Alert from '@mui/material/Alert';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import CircularProgress from '@mui/material/CircularProgress';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import Typography from '@mui/material/Typography';
import CardContent from '@mui/material/CardContent';

// ** Material UI icons
import Check from 'mdi-material-ui/Check';
import AlertIcon from 'mdi-material-ui/Alert';
import InformationIcon from 'mdi-material-ui/Information';

// ** App Hooks
import useApiClient from 'src/@core/hooks/useApiClient';

// ** App Components
import Fase1 from './formularios/Fase1';
import Fase2 from './formularios/Fase2';
import Fase3 from './formularios/Fase3';

function FormAlert(props) {
  const { message, type } = props;

  return (
    <Grid item xs={12}>
      <Alert color={type} sx={{ pb: 3 }} icon={<InformationIcon />}>
        {message}
      </Alert>
    </Grid>
  );
}

function RegisterDocumentsCopy() {

  const { data: session } = useSession();
  const apiClient = useApiClient();

  // ** State Vars
  const [curdate, setCurdate] = useState(new Date());
  const [currentActiveSystemPeriod, setCurrentActiveSystemPeriod] = useState([]);
  const [activeFase, setActiveFase] = useState(0);
  const [formStatus, setFormStatus] = useState(null);
  const [success, setSuccess] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const [filesData, setFilesData] = useState({
    // Fase 1
    projectName: '',
    inscripcion: null,
    aceptacion: null,
    planTrabajo: null,

    // Fase 2
    visita1: null,
    visita2: null,
    tutor_empresarial: '',
    tutor_academico: '',
    nombre_empresa: '',
    proyecto_status: null,

    // Fase 3
    evaluacion_empresarial: null,
    evaluacion_academica: null,
    informe: null,
    carta_culminacion: null,
    evaluacion_coordinacion: null
  });

  // Objeto donde se guardan los base64
  const [filesInfo, setFilesInfo] = useState({
    // Fase 1
    projectName: '',
    inscripcion: null,
    aceptacion: null,
    planTrabajo: null,

    // Fase 2
    visita1: null,
    visita2: null,
    tutor_empresarial: '',
    tutor_academico: '',
    tutor_academico_correo: '',
    tutor_academico_telefono: '',
    nombre_empresa: '',
    proyecto_status: null,

    // Fase 3
    evaluacion_empresarial: null,
    evaluacion_academica: null,
    informe: null,
    carta_culminacion: null,
    evaluacion_coordinacion: null
  });

  const [docsSrc, setDocsSrc] = useState({
    inscripcion: '/images/filetypes/default-file.jpg',
    aceptacion: '/images/filetypes/default-file.jpg',
    planTrabajo: '/images/filetypes/default-file.jpg',
    success: '/status/success.webp',
    danger: '/status/danger.png',
    proyect: '/status/proyect.png',
  });

  const [errors, setErrors] = useState({});

  const validateFiles = () => {
    const newErrors = {};
    if (!filesData.evaluacion_empresarial) newErrors.evaluacion_empresarial = 'Falta el archivo de Evaluacion del Tutor Empresarial';
    if (!filesData.evaluacion_academica) newErrors.evaluacion_academica = 'Falta el archivo de Evaluacion del Tutor Academico';
    if (!filesData.informe) newErrors.informe = 'Falta el archivo de Informe de Pasantias';
    if (!filesData.carta_culminacion) newErrors.carta_culminacion = 'Falta el archivo de Carta de Culminacion';
    if (!filesData.evaluacion_coordinacion) newErrors.evaluacion_coordinacion = 'Falta el archivo de Evaluacion Coordinacion';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // ** Render actions
  useEffect(() => {
    if (currentActiveSystemPeriod.length === 0) {
      fetchCurrentPeriod();
      return;
    }

    if (currentActiveSystemPeriod.length === 3) {
      let actFase = _.findIndex(currentActiveSystemPeriod, (fase) => fase.fase_status === 1);

      if (actFase > -1) {
        setActiveFase(currentActiveSystemPeriod[actFase].fase_index);
      } else {
        setActiveFase(actFase);
      }

    } else {
      // Mostrar ventana de aviso sobre periodo no activo
    }

    // como son funciones asincronas primero hace fetch a los periodos
    // y cuando cambie, hace fetch a los documentos del usuario para
    // trabajar con las fases.
    fetchCurrentStudentDocument();
  }, [ currentActiveSystemPeriod, activeFase ]);

  const fetchCurrentStudentDocument = async () => {
    try {
      const response = await apiClient.get(`/solicitud/verifyCurrentStudentSolicitud`, {
        params: {
          id: session?.user?.name?.id,
          fase: currentActiveSystemPeriod[_.findIndex(currentActiveSystemPeriod, (fase) => fase.fase_status === 1)]?.fase_index
        }
      });
     
      if ( response.data ) {
        console.log("Respuesta fetch", response.data);
        if (response.data.type === 'DB_NOT_FOUND_DATA') {
          console.log("Data no encontrada");
          setFormStatus(response.data);
          return;
        };

        setFormStatus(response.data);

        if ( activeFase === 1 ) {
          setFilesInfo({
            ...filesInfo,
            projectName: response.data.result[0].proyecto_nombre
          });
        }

        if ( activeFase === 2 ) {
          console.log(response.data);
          setFilesInfo({
            ...filesInfo,
            tutor_academico: response.data.result.documentos[0].tutor_academico_firstname && response.data.result.documentos[0].tutor_academico_lastname ? `${response.data.result.documentos[0].tutor_academico_firstname} ${response.data.result.documentos[0].tutor_academico_lastname}` : null,
            tutor_academico_correo: response.data.result.documentos[0].tutor_academico_email,
            tutor_academico_telefono: response.data.result.documentos[0].tutor_academico_phone,
            tutor_empresarial: response.data.result.documentos[0].tutor_empresarial_firstname && response.data.result.documentos[0].tutor_empresarial_lastname ? `${response.data.result.documentos[0].tutor_empresarial_firstname} ${response.data.result.documentos[0].tutor_empresarial_lastname}` : null,
            nombre_empresa: response.data.result.documentos[0].nombre_empresa,
            projectName: response.data.result.documentos[0].proyecto_nombre,
            proyecto_status: response.data.result.documentos[0].proyecto_status
          });
        }

        if ( activeFase === 3 ) {
          setFilesInfo({
            ...filesInfo,
            projectName: response.data.result[0].proyecto_nombre,
            proyecto_status: response.data.result[0].proyecto_status
          });
        }

        if ( activeFase <= 0 ) {
          // Hacer algo cuando no hay fases activas
          setFormStatus({
            type: 'FORM_NOT_AVAILABLE_NOTICE',
            enabled: false,
            result: {}
          });
        }
      }
    } catch (err) {
      // alert('error fetching');
      // console.log('Error', err);
    } finally {

    }
  };

  const fetchCurrentPeriod = async () => {
    try {
      const response = await apiClient.get('/periodos/getCurrentActiveSystemPeriod');

      if (response.data) {
        console.log("Periof", response.data);
        setCurrentActiveSystemPeriod(response.data.result);
      }
    } catch (err) {
      // console.log(err);
      // alert(`Error: Fetching 'getCurrentActiveSystemPeriod'.`);
    } finally {

    }
  };

  // ** Handlers
  const handleFileChange = (name) => (event) => {
    event.preventDefault();
    const reader = new FileReader();
    const { files } = event.target;

    if (files && files.length !== 0) {
      setFilesData({
        ...filesData,
        [name]: files[0],
      });

      reader.onload = () =>
        
        setFilesInfo({
          ...filesInfo,
          [name]: reader.result,
        });
      reader.readAsDataURL(files[0]);
    }
  };

  const handleChange = (prop) => (event) => {
    setFilesInfo({
      ...filesInfo,
      [prop]: event.target.value,
    });
  };

  const handleFileDelete = (name) => (event) => {
    event.preventDefault();
    if (name === 'all') {
      setFilesData({
        inscripcion: null,
        aceptacion: null,
        planTrabajo: null,
        visita1: null,
        visita2: null,
        evaluacion_empresarial: null,
        evaluacion_academica: null,
        informe: null,
        carta_culminacion: null,
        evaluacion_coordinacion: null
      });
      setFilesInfo({
        projectName: '',
        inscripcion: null,
        aceptacion: null,
        planTrabajo: null,
        visita1: null,
        visita2: null,
        evaluacion_empresarial: null,
        evaluacion_academica: null,
        informe: null,
        carta_culminacion: null,
        evaluacion_coordinacion: null
      });
      return;
    }
    setFilesData({
      ...filesData,
      [name]: null,
    });
    setFilesInfo({
      ...filesInfo,
      [name]: null,
    });
  };

  const handleFormSubmit = useCallback(async (event) => {
    event.preventDefault();
    setSubmitting(true);

    // console.log(filesInfo);

    try {
      let response, data;

      if (activeFase === 1) {
        data = {
          user_id: session.user.name.id,
          projectName: filesInfo.projectName,
          aceptacion: filesInfo.aceptacion,
          inscripcion: filesInfo.inscripcion,
          planTrabajo: filesInfo.planTrabajo
        };

        if (formStatus?.result[0].solicitud_status === 0) {  // Actualizar solicitud despues del rechazo
          response = await apiClient.put('/solicitud/updateSolicitudClient', {
            ...data,
            aceptacionId: formStatus?.result[0].carta_aceptacion_id,
            planTrabajoId: formStatus?.result[0].plan_trabajo_id,
            proyectoId: formStatus?.result[0].proyecto_id
          }, {
            params: {
              fase: 1,
              solicitudId: formStatus?.result[0].id
            }
          });
        } else {
          response = await apiClient.post('/solicitud/registerSolicitud', data, {
            params: {
              fase: 1
            }
          });
        }

      } else if (activeFase === 2) {
        console.log("activeFase", {
          visita1: formStatus?.result.visitas[0] ? null : filesInfo.visita1,
          visita2: formStatus?.result.visitas[1] ? null : filesInfo.visita2,
          proyecto_id: session?.user?.name?.id
        });
        data = {
          visita1: formStatus?.result.visitas[0] ? null : filesInfo.visita1,
          visita2: formStatus?.result.visitas[1] ? null : filesInfo.visita2,
          proyecto_id: session?.user?.name?.id
        };
        console.log(data);

        response = await apiClient.post('/projects/registerVisitas', data, {
          params: {
            fase: 2
          }
        });
      } else if (activeFase === 3) {
        if ( validateFiles() ) {
          response = await apiClient('/projects/registerNotas', {
            method: 'post',
            url: '/projects/registerNotas',
            data: {
              evaluacion_empresarial: filesInfo.evaluacion_empresarial,
              evaluacion_academica: filesInfo.evaluacion_academica,
              informe: filesInfo.informe,
              carta_culminacion: filesInfo.carta_culminacion,
              evaluacion_coordinacion: filesInfo.evaluacion_coordinacion,

              proyecto_id: session.user.name.id
            }
          });

          // response = await apiClient.post('/projects/registerNotas', {
          //   evaluacion_empresarial: filesInfo.evaluacion_empresarial,
          //   evaluacion_academica: filesInfo.evaluacion_academica,
          //   informe: filesInfo.informe,
          //   proyecto_id: formStatus?.result[0].proyecto_id
          // });
        } 
      }

      if (response.data?.type === 'FORM_REGISTRY_SUCCESS') {
        setSuccess(response.data);
        setFilesData({
          projectName: '',
          inscripcion: null,
          aceptacion: null,
          planTrabajo: null,
          visita1: null,
          visita2: null,
          evaluacion_empresarial: null,
          evaluacion_academica: null,
          informe: null
        });
        
        setFilesInfo({
          projectName: '',
          inscripcion: null,
          aceptacion: null,
          planTrabajo: null,
          visita1: null,
          visita2: null,
          evaluacion_empresarial: null,
          evaluacion_academica: null,
          informe: null,
          carta_culminacion: null
        });
        setTimeout(() => {
          setFormStatus({
            type: 'info',
            enabled: false,
            message: 'La solicitud ha sido emitida de manera exitosa, este formulario permanecera inactivo hasta nuevo aviso.'
          });
        }, 2000);
      }
    } catch (err) {
      console.log(err);
      setFilesData({
        inscripcion: null,
        aceptacion: null,
        planTrabajo: null,
      });
      setFilesInfo({
        projectName: '',
        inscripcion: null,
        aceptacion: null,
        planTrabajo: null,
      });
    } finally {
      setSubmitting(false);
    }
  }, [formStatus, filesInfo]);

  const renderFase = (fase) => {
    // console.log("fase", fase)
    switch (fase) {
      case 0:
        return (
          <Fase1
            formStatus={formStatus}
            filesData={filesData}
            filesInfo={filesInfo}
            docsSrc={docsSrc}
            handleFileChange={handleFileChange}
            handleFileDelete={handleFileDelete}
            handleChange={handleChange}
          />
        );
      case 1:
        return (
          <Fase2
            formStatus={formStatus}
            filesData={filesData}
            filesInfo={filesInfo}
            docsSrc={docsSrc}
            handleFileChange={handleFileChange}
            handleFileDelete={handleFileDelete}
            handleChange={handleChange}
          />
        );
      case 2:
        return (
          <Fase3
            formStatus={formStatus}
            filesData={filesData}
            filesInfo={filesInfo}
            docsSrc={docsSrc}
            handleFileChange={handleFileChange}
            handleFileDelete={handleFileDelete}
            handleChange={handleChange}
            errors={errors}
          />
        );
      default:
        break;
    }
  };

  return (
    <Card>
      <form onSubmit={handleFormSubmit}>
        <CardHeader title="Registrar Documentos" />
        <CardContent sx={{ pt: theme => `${theme.spacing(3)} !important` }}>
          {currentActiveSystemPeriod.length === 3 && (
            <Fragment>
              <Alert color="warning" sx={{ mb: 4 }} icon={<AlertIcon />}>
                El tiempo estimado para la fase <b>{_.findIndex(currentActiveSystemPeriod, fase => fase.fase_status === 1) + 1}</b> esta diponible entre el <b>{dayjs(currentActiveSystemPeriod[_.findIndex(currentActiveSystemPeriod, fase => fase.fase_status === 1)]?.fecha_inicio_fase).format('DD/MM/YYYY')}</b> y el <b>{dayjs(currentActiveSystemPeriod[_.findIndex(currentActiveSystemPeriod, fase => fase.fase_status === 1)]?.fecha_culminacion_fase).format('DD/MM/YYYY')}</b>
              </Alert>
              <Stepper
                activeStep={_.findIndex(currentActiveSystemPeriod, fase => fase.fase_status === 1)}
                sx={{ mb: 4, width: '100%' }}
                alternativeLabel
              >
                {currentActiveSystemPeriod.map((fase, i) => (
                  <Step key={i}>
                    <StepLabel>
                      {fase.fase_name}
                    </StepLabel>
                  </Step>
                ))}
              </Stepper>

              {formStatus !== null && formStatus?.enabled === false && <FormAlert type={formStatus?.type} message={formStatus?.message} />}

              {(formStatus?.enabled || formStatus === null || formStatus?.type === 'DB_NOT_FOUND_DATA') && (
                <>
                  <Box sx={{ mb: 3 }}>
                    {(formStatus?.enabled && formStatus?.message) ? <FormAlert type={formStatus?.type} message={formStatus?.message} /> : null}
                  </Box>
                  {renderFase(_.findIndex(currentActiveSystemPeriod, fase => fase.fase_status === 1))}
                  {success && (
                    <Grid item xs={12} sx={{ mb: 3 }}>
                      <Alert color="success" iconMapping={<Check />}>
                        <Typography variant="body2">
                          {success?.message}
                        </Typography>
                      </Alert>
                    </Grid>
                  )}
                  <Grid container direction="row-reverse">
                    <Button
                      type="submit"
                      variant="contained"
                    >
                      {submitting ? <CircularProgress /> : "Subir documentos"}
                    </Button>
                    <Button
                      type="reset"
                      variant="outlined"
                      color="secondary"
                      onClick={handleFileDelete('all')}
                      sx={{ mr: 3.5 }}
                    >
                      Reiniciar
                    </Button>
                  </Grid>
                </>
              )}
            </Fragment>
          ) || <p>No existen fases activas en este periodo</p>}
        </CardContent>
      </form>
    </Card>
  );
}

export default RegisterDocumentsCopy;