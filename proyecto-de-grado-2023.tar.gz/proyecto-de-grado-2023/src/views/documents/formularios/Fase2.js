// FileUploadForm.js
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import { styled } from '@mui/material/styles';
import { useEffect } from 'react';

const ImgStyled = styled('img')(({ theme }) => ({
  width: 120,
  height: 120,
  marginRight: theme.spacing(6.25),
  borderRadius: theme.shape.borderRadius,
}));

const ButtonStyled = styled(Button)(({ theme }) => ({
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    textAlign: 'center',
  },
}));

const ResetButtonStyled = styled(Button)(({ theme }) => ({
  marginTop: theme.spacing(4),
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    marginLeft: 0,
    textAlign: 'center',
    marginTop: theme.spacing(4),
  },
}));

const FilenameText = styled(Typography)(({ theme }) => ({
  backgroundColor: '#f2f2f2',
  padding: '3px 5px',
  borderRadius: '5px',
  border: '1px solid #dadada',
  fontFamily: 'monospace',
  fontSize: '9pt',
  fontWeight: 'bold',
  marginRight: '10px',
}));

function Fase2({
  formStatus,
  filesData,
  filesInfo,
  docsSrc,
  handleFileChange,
  handleFileDelete
}) {

  const proyecto_status = {
    '0': 'En desarrollo',
    '1': 'Aprobado',
  };

  useEffect(() => {
    console.log('filesInfo', filesInfo);

  }, [ formStatus ]);

  if ( formStatus?.type === 'DB_NOT_FOUND_DATA' ) {
    <Box>
      <Grid container sx={{  gap: { sm: 3, xs: 0 }, flexWrap: { sm: "nowrap", xs: "wrap" } }} spacing={[5, 0]}>
        <Grid item flexDirection="column" xs={12} sx={{ mt: 4.8, mb: 3 }}>
          <ImgStyled src={docsSrc.danger} alt='Profile Pic' />
          <Typography variant="body1">
            Usted no cumple con los requisitos de la fase anterior para rellenar este formulario
          </Typography>
        </Grid>
      </Grid>
    </Box>
  }

  return (
    <Box>
      <Grid container sx={{  gap: { sm: 3, xs: 0 }, flexWrap: { sm: "nowrap", xs: "wrap" } }} spacing={[5, 0]}>
        <Grid item xs={12} sx={{ mt: 4.8, mb: 3 }}>
          <Typography align="center" variant="body1" fontSize={24}>Detalles del proyecto</Typography>
        </Grid>
      </Grid>

      <Grid container sx={{  gap: { sm: 3, xs: 0 }, flexWrap: { sm: "nowrap", xs: "wrap" } }} spacing={[5, 0]}>
        <Grid item xs={12} sm={6} sx={{ mt: 4.8, mb: 3 }}>
          <Box sx={{ mb: 2, flexDirection: 'column', flexWrap: 'nowrap', border: '1px solid', px: 3, py: 2, borderRadius: '10px', height: '100%', backgroundColor: '#FFFFFF', borderColor: '#dadada' }}>
            <Box display="block">
              <ImgStyled src={docsSrc.proyect} alt='Profile Pic' />
              <Typography variant="body2">Estatus:</Typography>
              <Typography variant="body1">{proyecto_status[filesInfo?.proyecto_status]}</Typography>
            </Box>
            <Box display="block">
              <Typography variant="body2">Nombre del proyecto:</Typography>
              <Typography variant="body1" fontSize={24}>{filesInfo?.projectName}</Typography>
              {/* <Typography variant="body2">Fecha de inicio:</Typography>
              <Typography variant="body1">12 de Julio de 2024</Typography>
              <Typography variant="body2">Fecha de culminacion:</Typography>
              <Typography variant="body1">15 de Septiembre de 2024</Typography> */}
            </Box>
          </Box>
        </Grid>

        <Grid item xs={12} sm={6} sx={{ mt: 4.8, mb: 3 }}>
          <Box sx={{ mb: 2, border: '1px solid', px: 3, py: 2, borderRadius: '10px', height: '70px', backgroundColor: filesInfo?.tutor_empresarial ? '#FFFFFF' : '#fff5c5', borderColor: filesInfo?.tutor_empresarial ? '#dadada' : '#FFA500' }}>
            <Typography variant="body2">Tutor empresarial:</Typography>
            <Typography variant="body1" {...filesInfo?.tutor_empresarial ? { fontSize: 24 } : { color: "orange" }}>
            {filesInfo?.tutor_empresarial || "En espera de asignación"}
            </Typography>
          </Box>

          <Box sx={{ mb: 2, border: '1px solid', px: 3, py: 2, borderRadius: '10px', height: '70px', backgroundColor: filesInfo?.tutor_academico ? '#FFFFFF' : '#fff5c5', borderColor: filesInfo?.tutor_academico ? '#dadada' : '#FFA500' }}>
            <Typography variant="body2">Tutor Academico:</Typography>
            <Typography variant="body1" {...filesInfo?.tutor_academico ? { fontSize: 24 } : { color: "orange" }}>
              {filesInfo?.tutor_academico || "En espera de asignación"}
            </Typography>
          </Box>


          <Box sx={{ mb: 2, border: '1px solid', px: 3, py: 2, borderRadius: '10px', height: '70px', backgroundColor: filesInfo?.tutor_academico_correo ? '#FFFFFF' : '#fff5c5', borderColor: filesInfo?.tutor_academico_correo ? '#dadada' : '#FFA500' }}>
            <Typography variant="body2">Correo Tutor Academico:</Typography>
            <Typography variant="body1" {...filesInfo?.tutor_academico_correo ? { fontSize: 24 } : { color: "orange" }}>
              {filesInfo?.tutor_academico_correo || "En espera de asignación"}
            </Typography>
          </Box>

          <Box sx={{ mb: 2, border: '1px solid', px: 3, py: 2, borderRadius: '10px', height: '70px', backgroundColor: filesInfo?.tutor_academico_telefono ? '#FFFFFF' : '#fff5c5', borderColor: filesInfo?.tutor_academico_telefono ? '#dadada' : '#FFA500' }}>
            <Typography variant="body2">Telefono Tutor Academico:</Typography>
            <Typography variant="body1" {...filesInfo?.tutor_academico_telefono ? { fontSize: 24 } : { color: "orange" }}>
              {filesInfo?.tutor_academico_telefono || "En espera de asignación"}
            </Typography>
          </Box>

          <Box sx={{ mb: 2, border: '1px solid', px: 3, py: 2, borderRadius: '10px', height: '70px', backgroundColor: filesInfo?.nombre_empresa ? '#FFFFFF' : '#fff5c5', borderColor: filesInfo?.nombre_empresa ? '#dadada' : '#FFA500' }}>
            <Typography variant="body2">Nombre de la Empresa:</Typography>
            <Typography variant="body1" {...filesInfo?.nombre_empresa ? { fontSize: 24 } : { color: "orange" }}>
              {filesInfo?.nombre_empresa || "En espera de asignación"}
            </Typography>
          </Box>
        </Grid>
      </Grid>

      <Grid
        container
        spacing={[5, 0]}
        sx={{
          flexDirection: "row",
          flexWrap: { md: "nowrap" },
          gap: 3,
          mb: 5
        }}
      > 
        <Grid item xs={12} md={6} sx={{ mt: 4.8, mb: 3, pt: 10, py: 5, borderRadius: '10px', border: '1px solid #dadada', backgroundColor: formStatus?.result.visitas[0] ? '#EAF9E0' : '#FFFFFF', borderColor: formStatus?.result.visitas[0] ? '#77ce4d' : '#DADADA' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <ImgStyled src={docsSrc.inscripcion} alt='Profile Pic' />
            <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start' }}>
              <Typography variant="body2" sx={{ mb: 2 }}>
                1ra Visita
              </Typography>

              <ButtonStyled
                disabled={formStatus?.result.visitas[0] || false}
                size="small"
                component="label"
                variant="contained"
                htmlFor="user-docs-dni"
              >
                Subir archivo
                <input
                  hidden
                  type="file"
                  onChange={handleFileChange('visita1')}
                  accept="image/png, image/jpeg, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                  id="user-docs-dni"
                />
              </ButtonStyled>
              <ResetButtonStyled
                disabled={formStatus?.result.visitas[0] || false}
                size="small"
                color="error"
                variant="outlined"
                onClick={handleFileDelete('visita1')}
              >
                Eliminar
              </ResetButtonStyled>
            </Box>
          </Box>
          {filesData.visita1 && (
            <Box sx={{ margin: 2 }}>
              <FilenameText variant="body2">
                {filesData.visita1?.name}
              </FilenameText>
            </Box>
          )}
        </Grid>

        <Grid item xs={12} md={6} sx={{ mt: 4.8, mb: 3, pt: 10, py: 5, borderRadius: '10px', border: '1px solid #dadada', backgroundColor: formStatus?.result.visitas[1] ? '#EAF9E0' : '#FFFFFF', borderColor: formStatus?.result.visitas[1] ? '#77ce4d' : '#DADADA' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <ImgStyled src={docsSrc.planTrabajo} alt='Profile Pic' />
            <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start' }}>
              <Typography variant="body2" sx={{ mb: 2 }}>
                2da Visita
              </Typography>
              <ButtonStyled
                disabled={formStatus?.result.visitas[1] || false}
                size="small"
                component="label"
                variant="contained"
                htmlFor="user-docs-estudio"
              >
                Subir archivo
                <input
                  hidden
                  type="file"
                  onChange={handleFileChange('visita2')}
                  accept="image/png, image/jpeg, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                  id="user-docs-estudio"
                />
              </ButtonStyled>
              <ResetButtonStyled
                disabled={formStatus?.result.visitas[1] || false}
                size="small"
                color="error"
                variant="outlined"
                onClick={handleFileDelete('visita2')}
              >
                Eliminar
              </ResetButtonStyled>
            </Box>
          </Box>
          {filesData.visita2 && (
            <Box sx={{ my: 2 }}>
              <FilenameText variant="body2">
                {filesData.visita2?.name}
              </FilenameText>
            </Box>
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default Fase2;
