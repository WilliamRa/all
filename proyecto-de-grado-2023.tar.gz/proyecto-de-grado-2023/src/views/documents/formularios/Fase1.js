// FileUploadForm.js
import { useState, useEffect, Fragment } from 'react';
import { useSession } from 'next-auth/react';
import Box from '@mui/material/Box';
import Alert from '@mui/material/Alert';
import Button from '@mui/material/Button';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import CircularProgress from '@mui/material/CircularProgress';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import Typography from '@mui/material/Typography';
import CardContent from '@mui/material/CardContent';
import { styled, useTheme } from '@mui/material/styles';

import Check from 'mdi-material-ui/Check';
import Information from 'mdi-material-ui/Information';
import AlertIcon from 'mdi-material-ui/Alert';
import { TextField } from '@mui/material';

const ImgStyled = styled('img')(({ theme }) => ({
  width: 120,
  height: 120,
  marginRight: theme.spacing(6.25),
  borderRadius: theme.shape.borderRadius,
}));

const ButtonStyled = styled(Button)(({ theme }) => ({
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    textAlign: 'center',
  },
}));

const ResetButtonStyled = styled(Button)(({ theme }) => ({
  marginTop: theme.spacing(4),
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    marginLeft: 0,
    textAlign: 'center',
    marginTop: theme.spacing(4),
  },
}));

const FilenameText = styled(Typography)(({ theme }) => ({
  backgroundColor: '#f2f2f2',
  padding: '3px 5px',
  borderRadius: '5px',
  border: '1px solid #dadada',
  fontFamily: 'monospace',
  fontSize: '9pt',
  fontWeight: 'bold',
  marginRight: '10px',
}));

const Fase1 = ({
  formStatus,
  filesData,
  filesInfo,
  docsSrc,
  handleFileChange,
  handleFileDelete,
  handleChange,
  alert
}) => {

  useEffect(() => {
    // console.log('Fase 1 Estatus: ', formStatus === null);
  }, [ !formStatus ])

  return (
    <Box>
      {(formStatus?.enabled || formStatus === null) && (
        <Fragment>
          <Grid container sx={{  gap: { sm: 3, xs: 0 }, flexWrap: { sm: "nowrap", xs: "wrap" } }} spacing={[5, 0]}>
            <Grid item xs={12} sx={{ mt: 4.8, mb: 3 }}>
              <Typography align="center" variant="body1" fontSize={24}>Emision de solicitud</Typography>
            </Grid>
          </Grid>
          <Alert color="info" icon={<Information/>} sx={{ mb: 4 }}>
            <Typography variant="body1">
              Solo se permiten archivos de tipo: <Typography variant='caption'>.png, .jpg, .jpeg, .docx o .pdf</Typography> con tamaño máximo de 800KB.
            </Typography>
          </Alert>
          <Grid container spacing={[5, 0]}>
            <Grid item xs={12} sx={{ mt: 4.8, mb: 3 }}>
              <TextField
                fullWidth
                values={filesInfo.projectName}
                onChange={handleChange('projectName')}
                value={filesInfo.projectName}
                type="text"
                label="Nombre del proyecto"
              />
            </Grid>
          </Grid>

          <Grid
            container
            spacing={[5, 0]}
            sx={{
              flexDirection: "row",
              flexWrap: { md: "nowrap" },
              gap: 3,
              mb: 5
            }}
          >
            <Grid
              item
              xs={12}
              md={4}
              sx={{
                mt: 4.8,
                mb: 3,
                pt: 10,
                py: 5,
                borderRadius: '10px',
                border: '1px solid #dadada',
                backgroundColor: formStatus?.result[0].constancia_status === 0 && filesInfo.inscripcion === null ? '#FF000020' : 'transparent'
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <ImgStyled src={docsSrc.inscripcion} alt='Profile Pic' />
                <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start' }}>
                  <Typography variant="body2" sx={{ mb: 2 }}>
                    Contancia de inscripcion
                  </Typography>
                  
                  <ButtonStyled size="small" component="label" variant="contained" htmlFor="user-docs-dni">
                    Subir archivo
                    <input
                      hidden
                      type="file"
                      onChange={handleFileChange('inscripcion')}
                      accept="image/png, image/jpeg, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                      id="user-docs-dni"
                    />
                  </ButtonStyled>
                  <ResetButtonStyled size="small" color="error" variant="outlined" onClick={handleFileDelete('inscripcion')}>
                    Eliminar
                  </ResetButtonStyled>
                </Box>
              </Box>
              {filesData.inscripcion && (
                <Box sx={{ margin: 2 }}>
                  <FilenameText variant="body2">
                    {filesData.inscripcion?.name}
                  </FilenameText>
                </Box>
              )}
            </Grid>

            <Grid
              item
              xs={12}
              md={4}
              sx={{
                mt: 4.8,
                mb: 3,
                pt: 10,
                py: 5,
                borderRadius: '10px',
                border: '1px solid #dadada',
                backgroundColor: formStatus?.result[0].carta_aceptacion_status === 0 && filesInfo.aceptacion === null ? '#FF000020' : 'transparent'
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <ImgStyled src={docsSrc.aceptacion} alt='Profile Pic' />
                <Box>
                  <Typography variant="body2" sx={{ mb: 5 }}>
                    Carta de aceptacion
                  </Typography>
                  <ButtonStyled size="small" component="label" variant="contained" htmlFor="user-docs-notas">
                    Subir archivo
                    <input
                      hidden
                      type="file"
                      onChange={handleFileChange('aceptacion')}
                      accept="image/png, image/jpeg, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                      id="user-docs-notas"
                    />
                  </ButtonStyled>
                  <ResetButtonStyled size="small" color="error" variant="outlined" onClick={handleFileDelete('aceptacion')}>
                    Eliminar
                  </ResetButtonStyled>
                </Box>
              </Box>
              {filesData.aceptacion && (
                <Box sx={{ margin: 2 }}>
                  <FilenameText variant="body2">
                    {filesData.aceptacion?.name}
                  </FilenameText>
                </Box>
              )}
            </Grid>

            <Grid
              item
              xs={12}
              md={4}
              sx={{
                mt: 4.8,
                mb: 3,
                pt: 10,
                py: 5,
                borderRadius: '10px',
                border: '1px solid #dadada',
                backgroundColor: formStatus?.result[0].plan_trabajo_status === 0 && filesInfo.planTrabajo === null ? '#FF000020' : 'transparent'
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <ImgStyled src={docsSrc.planTrabajo} alt='Profile Pic' />
                <Box>
                  <Typography variant="body2" sx={{ mb: 5 }}>
                    Plan de trabajo
                  </Typography>
                  <ButtonStyled size="small" component="label" variant="contained" htmlFor="user-docs-estudio">
                    Subir archivo
                    <input
                      hidden
                      type="file"
                      onChange={handleFileChange('planTrabajo')}
                      accept="image/png, image/jpeg, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                      id="user-docs-estudio"
                    />
                  </ButtonStyled>
                  <ResetButtonStyled size="small" color="error" variant="outlined" onClick={handleFileDelete('planTrabajo')}>
                    Eliminar
                  </ResetButtonStyled>
                </Box>
              </Box>
              {filesData.planTrabajo && (
                <Box sx={{ my: 2 }}>
                  <FilenameText variant="body2">
                    {filesData.planTrabajo?.name}
                  </FilenameText>
                </Box>
              )}
            </Grid>
          </Grid>
        </Fragment>
      )}
    </Box>
  );
};

export default Fase1;
