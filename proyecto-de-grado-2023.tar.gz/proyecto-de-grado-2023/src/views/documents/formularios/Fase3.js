import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import Box from '@mui/material/Box';
import Alert from '@mui/material/Alert';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import { styled, useTheme } from '@mui/material/styles';

const ImgStyled = styled('img')(({ theme }) => ({
  width: 120,
  height: 120,
  marginRight: theme.spacing(6.25),
  borderRadius: theme.shape.borderRadius,
}));

const ButtonStyled = styled(Button)(({ theme }) => ({
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    textAlign: 'center',
  },
}));

const ResetButtonStyled = styled(Button)(({ theme }) => ({
  marginTop: theme.spacing(4),
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    marginLeft: 0,
    textAlign: 'center',
    marginTop: theme.spacing(4),
  },
}));

const FilenameText = styled(Typography)(({ theme }) => ({
  backgroundColor: '#f2f2f2',
  padding: '3px 5px',
  borderRadius: '5px',
  border: '1px solid #dadada',
  fontFamily: 'monospace',
  fontSize: '9pt',
  fontWeight: 'bold',
  marginRight: '10px',
}));

const Fase3 = ({
  formStatus,
  filesData,
  filesInfo,
  docsSrc,
  handleFileChange,
  handleFileDelete,
  handleChange,
  errors
}) => {

  // useEffect(() => {
  //   console.log("Response", formStatus);
  // }, []);

  return (
    <Box>
      <Grid
        container
        rowSpacing={1}
        columnSpacing={{ xs: 1, sm: 1, md: 3 }}
      >
        {/* Evaluacion del Tutor Empresarial */}
        <Grid item xs={12} md={6} sx={{ mt: 4.8, mb: 3, pt: 10, py: 5, ml: 2, borderRadius: '10px', border: '1px solid #dadada', backgroundColor: formStatus?.result[0].calificacion_tutor_academico ? '#EAF9E0' : '#FFFFFF', borderColor: formStatus?.result[0].calificacion_tutor_academico ? '#77ce4d' : '#DADADA' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <ImgStyled src={docsSrc.inscripcion} alt='Profile Pic' />
            <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start' }}>
              <Typography variant="body2" sx={{ mb: 2 }}>
                Evaluacion del Tutor Empresarial
              </Typography>
              <ButtonStyled
                disabled={formStatus?.result[0].calificacion_tutor_empresarial || false}
                size="small"
                component="label"
                variant="contained"
                htmlFor="user-docs-dni"
              >
                Subir archivo
                <input
                  hidden
                  type="file"
                  onChange={handleFileChange('evaluacion_empresarial')}
                  accept="image/png, image/jpeg, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                  id="user-docs-dni"
                  
                />
              </ButtonStyled>
              <ResetButtonStyled
                disabled={formStatus?.result[0].calificacion_tutor_empresarial || false}
                size="small"
                color="error"
                variant="outlined"
                onClick={handleFileDelete('evaluacion_empresarial')}
              >
                Eliminar
              </ResetButtonStyled>
            </Box>
          </Box>
          {errors.evaluacion_empresarial && (
            <Alert severity="error">{errors.evaluacion_empresarial}</Alert>
          )}
          {formStatus?.result[0].calificacion_tutor_empresarial > 1 && (
            <Box sx={{ margin: 2 }}>
              <FilenameText variant="body2">
                Nota asignada: {formStatus?.result[0].calificacion_tutor_empresarial}
              </FilenameText>
            </Box>
          )}
          {filesData.evaluacion_empresarial && (
            <Box sx={{ margin: 2 }}>
              <FilenameText variant="body2">
                {filesData.evaluacion_empresarial?.name}
              </FilenameText>
            </Box>
          )}
        </Grid>

        {/* Evaluacion del Tutor Academico */}
        <Grid item xs={12} md={6} sx={{ mt: 4.8, mb: 3, pt: 10, py: 5, ml: 2, borderRadius: '10px', border: '1px solid #dadada', backgroundColor: formStatus?.result[0].calificacion_tutor_empresarial ? '#EAF9E0' : '#FFFFFF', borderColor: formStatus?.result[0].calificacion_tutor_empresarial ? '#77ce4d' : '#DADADA' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <ImgStyled src={docsSrc.aceptacion} alt='Profile Pic' />
            <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start' }}>
              <Typography variant="body2" sx={{ mb: 2 }}>
                Evaluacion del Tutor Academico
              </Typography>
              <ButtonStyled
                disabled={formStatus?.result[0].calificacion_tutor_academico || false}
                size="small"
                component="label"
                variant="contained"
                htmlFor="user-docs-notas"
              >
                Subir archivo
                <input
                  hidden
                  type="file"
                  onChange={handleFileChange('evaluacion_academica')}
                  accept="image/png, image/jpeg, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                  id="user-docs-notas"
                  
                />
              </ButtonStyled>
              <ResetButtonStyled
                disabled={formStatus?.result[0].calificacion_tutor_academico || false}
                size="small"
                color="error"
                variant="outlined"
                onClick={handleFileDelete('evaluacion_academica')}
              >
                Eliminar
              </ResetButtonStyled>
            </Box>
          </Box>
          {errors.evaluacion_academica && (
            <Alert severity="error">{errors.evaluacion_academica}</Alert>
          )}
          {formStatus?.result[0].calificacion_tutor_academico > 1 && (
            <Box sx={{ margin: 2 }}>
              <FilenameText variant="body2">
                Nota asignada: {formStatus?.result[0].calificacion_tutor_academico}
              </FilenameText>
            </Box>
          )}
          {filesData.evaluacion_academica && (
            <Box sx={{ margin: 2 }}>
              <FilenameText variant="body2">
                {filesData.evaluacion_academica?.name}
              </FilenameText>
            </Box>
          )}
        </Grid>

        {/* Informe de Pasantias */}
        <Grid item xs={12} md={6} sx={{ mt: 4.8, mb: 3, pt: 10, py: 5, ml: 2, borderRadius: '10px', border: '1px solid #dadada', backgroundColor: formStatus?.result[0].calificacion_coordinacion ? '#EAF9E0' : '#FFFFFF', borderColor: formStatus?.result[0].calificacion_coordinacion ? '#77ce4d' : '#DADADA' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <ImgStyled src={docsSrc.planTrabajo} alt='Profile Pic' />
            <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start' }}>
              <Typography variant="body2" sx={{ mb: 5 }}>
                Informe de Pasantias
              </Typography>
              <ButtonStyled
                disabled={formStatus?.result[0].calificacion_coordinacion || false}
                size="small"
                component="label"
                variant="contained"
                htmlFor="user-docs-estudio"
              >
                Subir archivo
                <input
                  hidden
                  type="file"
                  onChange={handleFileChange('informe')}
                  accept="image/png, image/jpeg, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                  id="user-docs-estudio"
                  
                />
              </ButtonStyled>
              <ResetButtonStyled
                disabled={formStatus?.result[0].calificacion_coordinacion || false}
                size="small"
                color="error"
                variant="outlined"
                onClick={handleFileDelete('informe')}
              >
                Eliminar
              </ResetButtonStyled>
            </Box>
          </Box>
          {errors.informe && (
            <Alert severity="error">{errors.informe}</Alert>
          )}
          {formStatus?.result[0].calificacion_coordinacion > 1 && (
            <Box sx={{ margin: 2 }}>
              <FilenameText variant="body2">
                Nota asignada: {formStatus?.result[0].calificacion_coordinacion}
              </FilenameText>
            </Box>
          )}
          {filesData.informe && (
            <Box sx={{ margin: 2 }}>
              <FilenameText variant="body2">
                {filesData.informe?.name}
              </FilenameText>
            </Box>
          )}
        </Grid>

        {/* Carta de Culminacion */}
        <Grid item xs={12} md={6} sx={{ mt: 4.8, mb: 3, pt: 10, py: 5, ml: 2, borderRadius: '10px', border: '1px solid #dadada', backgroundColor: formStatus?.result[0].calificacion_coordinacion ? '#EAF9E0' : '#FFFFFF', borderColor: formStatus?.result[0].calificacion_coordinacion ? '#77ce4d' : '#DADADA' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <ImgStyled src={docsSrc.planTrabajo} alt='Profile Pic' />
            <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start' }}>
              <Typography variant="body2" sx={{ mb: 5 }}>
                Carta de Culminacion
              </Typography>
              <ButtonStyled
                disabled={formStatus?.result[0].calificacion_coordinacion || false}
                size="small"
                component="label"
                variant="contained"
                htmlFor="user-docs-culminacion"
              >
                Subir archivo
                <input
                  hidden
                  type="file"
                  onChange={handleFileChange('carta_culminacion')}
                  accept="image/png, image/jpeg, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                  id="user-docs-culminacion"
                  
                />
              </ButtonStyled>
              <ResetButtonStyled
                disabled={formStatus?.result[0].calificacion_coordinacion || false}
                size="small"
                color="error"
                variant="outlined"
                onClick={handleFileDelete('carta_culminacion')}
              >
                Eliminar
              </ResetButtonStyled>
            </Box>
          </Box>
          {errors.carta_culminacion && (
            <Alert severity="error">{errors.carta_culminacion}</Alert>
          )}
          {formStatus?.result[0].calificacion_coordinacion > 1 && (
            <Box sx={{ margin: 2 }}>
              <FilenameText variant="body2">
                Nota asignada: {formStatus?.result[0].calificacion_coordinacion}
              </FilenameText>
            </Box>
          )}
          {filesData.carta_culminacion && (
            <Box sx={{ margin: 2 }}>
              <FilenameText variant="body2">
                {filesData.carta_culminacion?.name}
              </FilenameText>
            </Box>
          )}
        </Grid>

        {/* Evaluacion Coordinacion */}
        <Grid item xs={12} md={6} sx={{ mt: 4.8, mb: 3, pt: 10, py: 5, ml: 2, borderRadius: '10px', border: '1px solid #dadada', backgroundColor: formStatus?.result[0].calificacion_coordinacion ? '#EAF9E0' : '#FFFFFF', borderColor: formStatus?.result[0].calificacion_coordinacion ? '#77ce4d' : '#DADADA' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <ImgStyled src={docsSrc.planTrabajo} alt='Profile Pic' />
            <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start' }}>
              <Typography variant="body2" sx={{ mb: 5 }}>
                Evaluacion Coordinacion
              </Typography>
              <ButtonStyled
                disabled={formStatus?.result[0].calificacion_coordinacion || false}
                size="small"
                component="label"
                variant="contained"
                htmlFor="user-docs-coordinacion"
              >
                Subir archivo
                <input
                  hidden
                  type="file"
                  onChange={handleFileChange('evaluacion_coordinacion')}
                  accept="image/png, image/jpeg, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                  id="user-docs-coordinacion"
                  
                />
              </ButtonStyled>
              <ResetButtonStyled
                disabled={formStatus?.result[0].calificacion_coordinacion || false}
                size="small"
                color="error"
                variant="outlined"
                onClick={handleFileDelete('evaluacion_coordinacion')}
              >
                Eliminar
              </ResetButtonStyled>
            </Box>
          </Box>
          {errors.evaluacion_coordinacion && (
            <Alert severity="error">{errors.evaluacion_coordinacion}</Alert>
          )}
          {formStatus?.result[0].calificacion_coordinacion > 1 && (
            <Box sx={{ margin: 2 }}>
              <FilenameText variant="body2">
                Nota asignada: {formStatus?.result[0].calificacion_coordinacion}
              </FilenameText>
            </Box>
          )}
          {filesData.evaluacion_coordinacion && (
            <Box sx={{ margin: 2 }}>
              <FilenameText variant="body2">
                {filesData.evaluacion_coordinacion?.name}
              </FilenameText>
            </Box>
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default Fase3;
