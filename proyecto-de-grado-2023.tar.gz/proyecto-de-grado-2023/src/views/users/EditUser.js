// ** React Imports
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';

// ** MUI Imports
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Select from '@mui/material/Select';
import { styled } from '@mui/material/styles';
import MenuItem from '@mui/material/MenuItem';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import InputLabel from '@mui/material/InputLabel';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardHeader from '@mui/material/CardHeader';
import FormControl from '@mui/material/FormControl';
import Button from '@mui/material/Button';
import Alert from '@mui/material/Alert';

// ** MUI Icons
import Check from 'mdi-material-ui/Check';
import EyeOutline from 'mdi-material-ui/EyeOutline';
import EyeOffOutline from 'mdi-material-ui/EyeOffOutline';
import useApiClient from 'src/@core/hooks/useApiClient';

const ImgStyled = styled('img')(({ theme }) => ({
  width: 120,
  height: 120,
  marginRight: theme.spacing(6.25),
  borderRadius: theme.shape.borderRadius
}));

const ButtonStyled = styled(Button)(({ theme }) => ({
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    textAlign: 'center'
  }
}));

const ResetButtonStyled = styled(Button)(({ theme }) => ({
  marginLeft: theme.spacing(4.5),
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    marginLeft: 0,
    textAlign: 'center',
    marginTop: theme.spacing(4)
  }
}));

const dniRegExp = /^(?:V-){0,1}[0-9]+$/;
const usernameRegExp = /^(?:@){0,1}[a-zA-Z0-9\-\_\.]+$/;
const emailRegExp = /^(([^<>()\[\]\\.,;:\s@\"]+(\.[^<>()\[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

function EditUser() {
  
  const apiClient = useApiClient();
  const router = useRouter();
  const { id } = router.query;

  // ** State
  const [ success, setSuccess ] = useState(null);
  const [ roles, setRoles ] = useState([]);
  const [ submitting, setSubmitting ] = useState(false);
  const [ status, setStatus ] = useState([]);
  const [ imgSrc, setImgSrc ] = useState('/images/avatars/default-profile.png');
  const [ typingPassword, setTypingPassword ] = useState(false);
  const [ passwordDifferentError, setPasswordDifferentError ] = useState(false);
  const [ error, setError ] = useState({ hasError: false, msg: null });
  
  const [ values, setValues ] = useState({
    firstname: '',
    lastname: '',
    dni: '',
    username: '',
    email: '',
    password: '',
    rol: null,
    status: null,
    reTypePassword: '',
    showPassword: false
  });

  const [ errorTypes, setErrorTypes ] = useState({
    'FORM_FIELD_WRONG_DNI': false,
    'FORM_FIELD_WRONG_USERNAME': false,
    'FORM_FIELD_WRONG_EMAIL': false,
    'FORM_FIELD_MISSING_FIRSTNAME': false,
    'FORM_FIELD_MISSING_LASTNAME': false,
    'FORM_FIELD_MISSING_DNI': false,
    'FORM_FIELD_MISSING_USERNAME': false,
    'FORM_FIELD_MISSING_EMAIL': false,
    'FORM_FIELD_MISSING_PASSWORD': false,
    'FORM_FIELD_DUPLICATED_DNI': false,
    'FORM_FIELD_DUPLICATED_USERNAME': false,
    'FORM_FIELD_DUPLICATED_EMAIL': false
  });

  useEffect(() => {
    fetchRoles();
    fetchStatus();
    fetchUser(id);
  }, []);

  useEffect(() => {
    if ( typingPassword ) {
      if ( values.password === values.reTypePassword ) {
        setPasswordDifferentError(false);
        } else {
        setPasswordDifferentError(true);
      } 
    }
  }, [ values.password, values.reTypePassword ]);

  const fetchRoles = async () => {
    try {
      const response = await apiClient('/roles/getAllRoles');

      if ( response.data ) {
        setRoles(response.data.roles);
      }
    } catch (e) {

    } finally {

    }
  };

  const fetchStatus = async () => {
    try {
      const response = await apiClient('/user-status/getAllUserStatus');

      if ( response.data ) {
        setStatus( response.data.users_status );
      }
    } catch (e) {

    } finally {

    }
  };

  const fetchUser = async (id) => {
    try {
      const response = await apiClient(`/users/getOneUser?id=${id}`);

      if ( response.data ) {
        setValues({
          firstname: response.data.firstname,
          lastname: response.data.lastname,
          dni: response.data.dni_number,
          username: response.data.username,
          email: response.data.email,
          rol: response.data.role_id,
          status: response.data.status_id
        });
      }
    } catch( err ) {

    } finally {

    }
  };

  const handleFormReset = () => {
    setValues({
      firstname: '',
      lastname: '',
      dni: '',
      username: '',
      email: '',
      password: '',
      rol: null,
      status: null,
      reTypePassword: '',
      showPassword: false
    });
    setErrorTypes({
      'FORM_FIELD_WRONG_DNI': false,
      'FORM_FIELD_WRONG_USERNAME': false,
      'FORM_FIELD_WRONG_EMAIL': false,
      'FORM_FIELD_MISSING_FIRSTNAME': false,
      'FORM_FIELD_MISSING_LASTNAME': false,
      'FORM_FIELD_MISSING_DNI': false,
      'FORM_FIELD_MISSING_USERNAME': false,
      'FORM_FIELD_MISSING_EMAIL': false,
      'FORM_FIELD_MISSING_PASSWORD': false,
      'FORM_FIELD_DUPLICATED_DNI': false,
      'FORM_FIELD_DUPLICATED_USERNAME': false,
      'FORM_FIELD_DUPLICATED_EMAIL': false
    });
  };

  const handleChange = prop => event => {
    
    if ( error.hasError || Object.values(errorTypes).filter((val) => val === true).length > 0 ) {
      setError({ hasError: false, msg: null });
      setErrorTypes({
        'FORM_FIELD_WRONG_DNI': false,
        'FORM_FIELD_WRONG_USERNAME': false,
        'FORM_FIELD_WRONG_EMAIL': false,
        'FORM_FIELD_MISSING_FIRSTNAME': false,
        'FORM_FIELD_MISSING_LASTNAME': false,
        'FORM_FIELD_MISSING_DNI': false,
        'FORM_FIELD_MISSING_USERNAME': false,
        'FORM_FIELD_MISSING_EMAIL': false,
        'FORM_FIELD_MISSING_PASSWORD': false,
        'FORM_FIELD_DUPLICATED_DNI': false,
        'FORM_FIELD_DUPLICATED_USERNAME': false,
        'FORM_FIELD_DUPLICATED_EMAIL': false
      });
    }
    
    if ( prop === 'password' || prop === 'reTypePassword' ) {
      if ( values.password !== '' || values.reTypePassword !== '' ) {
        setTypingPassword(true);
      } else {
        setTypingPassword(false);
      }
    }

    if ( prop === 'email' ) {
      if ( emailRegExp.test(event.target.value) ) {
        setValues({
          ...values,
          [prop]: event.target.value
        });
      } else {
        if ( event.target.value === '' ) {
          setErrorTypes({
            ...errorTypes,
            FORM_FIELD_WRONG_EMAIL: false
          });
          setValues({
            ...values,
            [prop]: event.target.value
          });
          return;
        }

        setErrorTypes({
          ...errorTypes,
          FORM_FIELD_WRONG_EMAIL: true
        });
        setValues({
          ...values,
          [prop]: event.target.value
        });
        return;
      }
    }

    if ( prop === 'username' ) {
      if ( usernameRegExp.test(event.target.value) ) {
        if ( values.username !== '' ) {

          setValues({
            ...values,
            [prop]: event.target.value
            });
        } else {

          setValues({
            ...values,
            [prop]: '@' + event.target.value
          });
        }
      } else {
        if ( event.target.value === '' ) {
          setErrorTypes({
            ...errorTypes,
            FORM_FIELD_WRONG_USERNAME: false
          });
          setValues({
            ...values,
            [prop]: event.target.value
          });
          return;
        }

        setErrorTypes({
          ...errorTypes,
          FORM_FIELD_WRONG_USERNAME: true
        });
        setValues({
          ...values,
          [prop]: event.target.value
        });
      }
    }

    if ( prop === 'dni' ) {
      if ( dniRegExp.test(event.target.value) ) {
        if ( values.dni !== '' ) {
          setValues({
            ...values,
            [prop]: event.target.value
          });
        } else {
          setValues({
            ...values,
            [prop]: 'V-' + event.target.value
          });
        }
      } else {
        if ( values.dni === 'V-' ) {
          setErrorTypes({ ...errorTypes, FORM_FIELD_WRONG_DNI: false });
          setValues({
            ...values,
            [prop]: ''
          });
          return;
        }
        
        if ( event.target.value === '' ) {
          setErrorTypes({ ...errorTypes, FORM_FIELD_WRONG_DNI: false });
          setValues({
            ...values,
            [prop]: ''
          });
          return;
        }
        
        setErrorTypes({ ...errorTypes, FORM_FIELD_WRONG_DNI: true });
        setValues({
          ...values,
          [prop]: event.target.value
        });
      }

      return;
    }

    setValues({
      ...values,
      [prop]: event.target.value
    });
  };

  const handleClickShowPassword = () => {
    setValues({
      ...values,
      showPassword: !values.showPassword
    });
  };

  const handleMouseDownPassword = event => {
    event.preventDefault()
  };

  const handleFileChange = file => {
    const reader = new FileReader();
    const { files } = file.target;
    if ( files && files.length !== 0 ) {
      reader.onload = () => setImgSrc(reader.result);
      reader.readAsDataURL(files[0]);
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSubmitting(true);

    try {
      const response = await apiClient.put(`/users/updateUser?id=${id}`, {
        firstname: values.firstname,
        lastname: values.lastname,
        dni: values.dni,
        username: values.username,
        email: values.email,
        password: values.password,
        rol: values.rol,
        status: values.status,
      });

      if ( response.data?.type === 'FORM_REGISTRY_SUCCESS' ) {
        setSuccess(response.data);
        setValues({
          firstname: '',
          lastname: '',
          dni: '',
          username: '',
          email: '',
          password: '',
          rol: null,
          status: null,
          reTypePassword: '',
          showPassword: false
        });
      }
    } catch ( e ) {
      const { type } = e.response.data;
      setErrorTypes({
        ...errorTypes,
        [type]: true
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card>
      {values.firstname && values.lastname && <CardHeader title={`Actualizar el usuario: ${values.firstname} ${values.lastname}`}/>}
      <CardContent>
        <form onSubmit={handleSubmit}>
          <Grid container spacing={4} sx={{ mb: 3 }}>
            <Grid item xs={12} sx={{ mb: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <ImgStyled src={imgSrc} alt='Profile Pic' />
                <Box>
                  <ButtonStyled component="label" variant="contained" htmlFor="create-user-upload-image">
                    Subir nueva foto
                    <input
                      hidden
                      type="file"
                      onChange={handleFileChange}
                      accept="image/png, image/jpeg"
                      id="create-user-upload-image"
                    />
                  </ButtonStyled>
                  <ResetButtonStyled color="error" variant="outlined" onClick={() => setImgSrc('/images/avatars/default-profile.png')}>
                    Eliminar Foto
                  </ResetButtonStyled>
                  <Typography variant="body2" sx={{ marginTop: 5 }}>
                    Solo se permiten imágenes PNG o JPEG, Tamano máximo de 800KB.
                  </Typography>
                </Box>
              </Box>
            </Grid>

            <Grid item md={6} xs={12} >
              <TextField
                disabled={submitting}
                fullWidth
                id="firstname"
                value={values.firstname}
                onChange={handleChange('firstname')}
                label="Nombre"
                placeholder="Jhon"
              />
            </Grid>
            <Grid item md={6} xs={12} >
              <TextField
                disabled={submitting}
                fullWidth
                id="lastname"
                value={values.lastname}
                onChange={handleChange('lastname')}
                label="Apellido"
                placeholder="Doe"
                
              />
            </Grid>
            
            <Grid item md={4} xs={12} >
              <TextField
                disabled={submitting}
                error={errorTypes['FORM_FIELD_WRONG_DNI'] || errorTypes['FORM_FIELD_DUPLICATED_DNI']}
                fullWidth
                id="cedula"
                value={values.dni}
                onChange={handleChange('dni')}
                label="Numero de Cedula"
                placeholder="V-12345678"
                {...(errorTypes['FORM_FIELD_WRONG_DNI'] || errorTypes['FORM_FIELD_DUPLICATED_DNI']) && ({sx: { mb: 2 } })}
              
              />
              {(errorTypes['FORM_FIELD_WRONG_DNI'] || errorTypes['FORM_FIELD_DUPLICATED_DNI']) && (
                <Box
                  sx={{
                    mb: 4,
                    display: 'flex',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                    justifyContent: 'space-between'
                  }}
                >
                  {errorTypes['FORM_FIELD_WRONG_DNI'] && (
                    <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                      El numero de cedula es invalido
                    </Typography>
                  )}

                  {errorTypes['FORM_FIELD_DUPLICATED_DNI'] && (
                    <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                      El numero de cedula ya existe
                    </Typography>
                  )}
                </Box>
              )}
            </Grid>
            <Grid item md={4} xs={12} /* sx={{ px: { md: 2 } }} */>
              <TextField 
                disabled={submitting}
                error={errorTypes['FORM_FIELD_WRONG_USERNAME'] || errorTypes['FORM_FIELD_DUPLICATED_USERNAME']}
                fullWidth
                id="username"
                value={values.username}
                onChange={handleChange('username')}
                label="Nombre de Usuario"
                placeholder="@jhondoe"
                {...(errorTypes['FORM_FIELD_WRONG_USERNAME'] || errorTypes['FORM_FIELD_DUPLICATED_USERNAME']) && ({sx: { mb: 2 } })}
              />
              {(errorTypes['FORM_FIELD_WRONG_USERNAME'] || errorTypes['FORM_FIELD_DUPLICATED_USERNAME']) && (
                <Box
                  sx={{
                    mb: 4,
                    display: 'flex',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                    justifyContent: 'space-between'
                  }}
                >
                  {errorTypes['FORM_FIELD_WRONG_USERNAME'] && (
                    <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                      El nombre de usuario es invalido
                    </Typography>
                  )}

                  {errorTypes['FORM_FIELD_DUPLICATED_USERNAME'] && (
                    <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                      El nombre de usuario ya existe
                    </Typography>
                  )}
                </Box>
              )}
            </Grid >
            <Grid item md={4} xs={12} >
              <TextField
                fullWidth
                disabled={submitting}
                error={errorTypes['FORM_FIELD_WRONG_EMAIL'] || errorTypes['FORM_FIELD_DUPLICATED_EMAIL']}
                type="email"
                value={values.email}
                onChange={handleChange('email')}
                label="Email"
                placeholder="jhondoe@example.com"
                {...(errorTypes['FORM_FIELD_WRONG_EMAIL'] || errorTypes['FORM_FIELD_DUPLICATED_EMAIL']) && ({sx: { mb: 2 } })}
              />
              {(errorTypes['FORM_FIELD_WRONG_EMAIL'] || errorTypes['FORM_FIELD_DUPLICATED_EMAIL']) && (
                <Box
                  sx={{
                    mb: 4,
                    display: 'flex',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                    justifyContent: 'space-between'
                  }}
                >
                  {errorTypes['FORM_FIELD_WRONG_EMAIL'] && (
                    <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                      El correo electronico es invalido
                    </Typography>
                  )}

                  {errorTypes['FORM_FIELD_DUPLICATED_EMAIL'] && (
                    <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                      El correo electronico ya existe
                    </Typography>
                  )}
                </Box>
              )}
            </Grid>
            <Grid item md={6} xs={12}>
              <FormControl fullWidth>
                <InputLabel error={passwordDifferentError} htmlFor='auth-register-password'>
                  Contraseña
                </InputLabel>
                <OutlinedInput
                  label="Contraseña"
                  disabled={submitting}
                  error={passwordDifferentError}
                  value={values.password}
                  id="auth-register-password"
                  onChange={handleChange('password')}
                  type={values.showPassword ? 'text' : 'password'}
                  endAdornment={
                    <InputAdornment position='end'>
                      <IconButton
                        edge='end'
                        onClick={handleClickShowPassword}
                        onMouseDown={handleMouseDownPassword}
                        aria-label="alternar visibilidad de contraseña"
                      >
                        {values.showPassword ? <EyeOutline fontSize='small' /> : <EyeOffOutline fontSize='small' />}
                      </IconButton>
                    </InputAdornment>
                  }
                />
              </FormControl>
            </Grid>
            
            <Grid item md={6} xs={12}>
              <FormControl fullWidth>
                <InputLabel error={passwordDifferentError} htmlFor="auth-register-retype-password">
                  Repetir Contraseña
                </InputLabel>
                <OutlinedInput
                  label="Repetir Contraseña"
                  disabled={submitting}
                  error={passwordDifferentError}
                  value={values.reTypePassword}
                  id="auth-register-retype-password"
                  onChange={handleChange('reTypePassword')}
                  type={values.showPassword ? 'text' : 'password'}
                  endAdornment={
                    <InputAdornment position='end'>
                      <IconButton
                        edge="end"
                        onClick={handleClickShowPassword}
                        onMouseDown={handleMouseDownPassword}
                        aria-label="alternar visibilidad de contraseña"
                      >
                        {values.showPassword ? <EyeOutline fontSize='small' /> : <EyeOffOutline fontSize='small' />}
                      </IconButton>
                    </InputAdornment>
                  }
                />
              </FormControl>
              
              {passwordDifferentError && (
                <Box
                  sx={{
                    mb: 4,
                    display: 'flex',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                    justifyContent: 'space-between'
                  }}
                >
                  <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                    Las contraseñas no coinciden
                  </Typography>
                </Box>
              )}
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Rol</InputLabel>
                <Select label="Rol" value={values.rol} onChange={handleChange('rol')}>
                  {roles.map((rol, i) => (
                    <MenuItem key={i} value={rol.id}>
                      {rol.display_name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Status</InputLabel>
                <Select label="Status" value={values.status} onChange={handleChange('status')}>
                  {status.map((status, i) => (
                    <MenuItem key={i} value={status.id}>
                      {status.display_name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            {success && (
              <Grid item xs={12}>
                <Alert color="success" icon={<Check/>}>
                  <Typography variant="body2">
                    {success?.message}
                  </Typography>
                </Alert>
              </Grid>
            )}
            
          </Grid>

          <Grid container direction="row-reverse">
            <Grid item>
              <Button
                type="reset"
                variant="outlined"
                color="secondary"
                onClick={handleFormReset}
                sx={{ marginRight: 3.5 }}
              >
                Reiniciar
              </Button>

              <Button
                {...(
                  submitting
                  || !values.firstname
                  || !values.lastname
                  || !values.dni
                  || !values.username
                  || !values.email
                  || !values.email
                  || !values.rol
                  || !values.status
                  || passwordDifferentError
                  || errorTypes['FORM_FIELD_WRONG_DNI']
                  || errorTypes['FORM_FIELD_WRONG_USERNAME']
                  || errorTypes['FORM_FIELD_WRONG_EMAIL']
                )
                  ? { disabled: true }
                  : null
                }
                type="submit"
                variant="contained"
              >
                Actualizar usuario
              </Button>
            </Grid>
          </Grid>

        </form>
      </CardContent>
    </Card>
  );
}

export default EditUser;
