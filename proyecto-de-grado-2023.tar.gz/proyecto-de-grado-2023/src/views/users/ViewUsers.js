import { useRouter } from 'next/router';
import { useEffect, useState, Fragment, useCallback } from 'react';
import dayjs from 'dayjs';
import useApiClient from 'src/@core/hooks/useApiClient';
import _ from 'lodash';

// ** MUI Imports
import Box from '@mui/material/Box';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Divider from '@mui/material/Divider';
import Grid from '@mui/material/Grid';
import Chip from '@mui/material/Chip';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import CardContent from '@mui/material/CardContent';
import CircularProgress from '@mui/material/CircularProgress';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TableCell from '@mui/material/TableCell';
import TableBody from '@mui/material/TableBody';
import Modal from '@mui/material/Modal';
import { List, ListItem, ListSubheader } from '@mui/material';

// ** Icons Imports
import File from 'mdi-material-ui/File';
import Pencil from 'mdi-material-ui/Pencil';
import Delete from 'mdi-material-ui/Delete';
import DotsVertical from 'mdi-material-ui/DotsVertical';

function ViewUsers() {
  const router = useRouter();
  const apiClient = useApiClient();

  const [ openModal, setOpenModal ] = useState(false);
  const [ users, setUsers ] = useState([]);
  const [ isFecthing, setIsFecthing ] = useState(false);
  const [ anchorEl, setAnchorEl ] = useState(null);
  const [ selectedUserId, setSelectedUserId ] = useState(null);
  const [ isModalFecthing, setIsModalFecthing ] = useState(true);
  const [ modalValues, setModalValues ] = useState({});

  useEffect(() => {
    setIsFecthing(true);
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await apiClient.get('/users/getAllUsers');
      if ( response.data ) {
        setUsers(response.data.users);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsFecthing(false);
    }
  };

  const handleDropdownOpen = (event, userId) => {
    setAnchorEl(event.currentTarget);
    setSelectedUserId(userId);
  };

  const handleDropdownClose = (url) => {
    if (url) {
      router.push(url);
    }
    setAnchorEl(null);
    setSelectedUserId(null);
  };

  const closeModal = () => {
    setOpenModal(false);
    setModalValues({});
  };

  const refetchUsers = () => {
    setIsFecthing(true);
    fetchUsers();
  };

  const viewDetails = async (id) => {
    setOpenModal(true);

    try {
      const response = await apiClient.post('/users/getOneUser', { id: parseInt(id) });
      if (response.data) {
        setModalValues(response.data.userOne);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsModalFecthing(false);
    }
  };

  const handleConfirmDelete = async (id) => {
    if ( confirm('Esta seguro que desea eliminar a este Tutor?') ) {
     
      try {
        const response = await apiClient.delete(`/users/deleteOneUser?id=${id}`);

        if ( response.data ) {
          alert(`Usuario '${response.data.firstname} ${response.data.lastname}' eliminado exitosamente`);
        }
      } catch ( err ) {
        alert(`Ha ocurrido un error al eliminar el Usuario: ${users[ _.findIndex(users, user => user.id === id) ].firstname} ${tutors[ _.findIndex(users, user => user.id === id) ].lastname}`);
      } finally {
        refetchUsers();
      }
    }
  };

  const filterUsers = useCallback((event) => {

  }, []);

  return (
    <Card>
      <CardHeader title="Listado de Usuarios" />
      <CardContent sx={{ pt: theme => `${theme.spacing(3)} !important` }}>
        <Grid container direction="row-reverse" marginTop={4.8}>
          <Grid item>
            <Button variant="contained" onClick={() => router.push('/dashboard/users/create')}>
              Crear usuario
            </Button>
          </Grid>
          <Grid item>
            <TextField sx={{ mr: 4 }} size="small" onChange={filterUsers} label="Buscar usuario" />
          </Grid>
        </Grid>
        <Grid item>
          {isFecthing ? <CircularProgress sx={{ margin: 'auto', marginTop: 10 }} /> : (
            <TableContainer>
              <Table sx={{ minWidth: 800 }} aria-label='table in dashboard'>
                <TableHead>
                  <TableRow>
                    <TableCell>ID</TableCell>
                    <TableCell>Usuario</TableCell>
                    <TableCell>Nombre</TableCell>
                    <TableCell>Apellido</TableCell>
                    <TableCell>Fecha de Creación</TableCell>
                    <TableCell>Rol</TableCell>
                    <TableCell>Acciones</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {users.map((row) => (
                    <TableRow hover key={row.id} sx={{ '&:last-of-type td, &:last-of-type th': { border: 0 } }}>
                      <TableCell>{row.id.toString()}</TableCell>
                      <TableCell sx={{ py: theme => `${theme.spacing(0.5)} !important` }}>
                        <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                          <Typography sx={{ fontWeight: 500, fontSize: '0.875rem !important' }}>{row.username}</Typography>
                        </Box>
                      </TableCell>
                      <TableCell>{row.firstname}</TableCell>
                      <TableCell>{row.lastname}</TableCell>
                      <TableCell>{dayjs(row.created_at).format('DD/MM/YYYY')}</TableCell>
                      <TableCell>
                        <Chip
                          label={row.user_roles.display_name}
                          sx={{
                            height: 24,
                            fontSize: '0.75rem',
                            textTransform: 'capitalize',
                            '& .MuiChip-label': { fontWeight: 500 }
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                          <Fragment>
                            <IconButton size='small' onClick={(e) => handleDropdownOpen(e, row.id)} aria-label='settings' sx={{ width: 40, height: 40, color: 'text.secondary' }}>
                              <DotsVertical />
                            </IconButton>
                            <Menu
                              anchorEl={anchorEl}
                              open={Boolean(anchorEl) && selectedUserId === row.id}
                              onClose={() => handleDropdownClose()}
                              sx={{ '& .MuiMenu-paper': { width: 170, marginTop: 10 } }}
                              anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                              transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                            >
                              <MenuItem sx={{ py: 1 }} onClick={() => viewDetails(row.id)}>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <File />
                                  <Typography variant="body2" sx={{ ml: 1 }}>
                                    Ver detalles
                                  </Typography>
                                </Box>
                              </MenuItem>
                              <Divider />
                              <MenuItem sx={{ py: 1 }} onClick={() => router.push(`/dashboard/users/${row.id}`)}>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Pencil />
                                  <Typography variant="body2" sx={{ ml: 1 }}>
                                    Editar
                                  </Typography>
                                </Box>
                              </MenuItem>
                              <Divider />
                              <MenuItem sx={{ py: 1 }} onClick={() => handleConfirmDelete(row.id)}>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Delete />
                                  <Typography variant="body2" sx={{ ml: 1 }}>
                                    Borrar
                                  </Typography>
                                </Box>
                              </MenuItem>
                            </Menu>
                          </Fragment>
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
                
              </Table>
            </TableContainer>
          )}
        </Grid>
      </CardContent>
      <Modal
        open={openModal}
        onClose={closeModal}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Card sx={{ width: '500px', margin: 'auto', marginTop: 40 }}>
          <CardContent>
            {isModalFecthing ? <CircularProgress sx={{ margin: 'auto', marginTop: 10, marginLeft: "45%" }} /> : (
              <List
                sx={{ width: '100%', bgcolor: 'background.paper' }}
                aria-labelledby="nested-list-subheader"
                subheader={
                  <ListSubheader component="div" id="nested-list-subheader">
                    Detalles
                  </ListSubheader>
                }
              >
                <ListItem>
                  <Grid container>
                    <Grid item xs={6}>
                      <Typography variant='body2'>
                        Nombres:
                      </Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant='body2'>
                        {modalValues.firstname}
                      </Typography>
                    </Grid>
                  </Grid>
                </ListItem>
                <ListItem>
                  <Grid container>
                    <Grid item xs={6}>
                      <Typography variant='body2'>
                        Apellidos:
                      </Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant='body2'>
                        {modalValues.lastname}
                      </Typography>
                    </Grid>
                  </Grid>
                </ListItem>
                <ListItem>
                  <Grid container>
                    <Grid item xs={6}>
                      <Typography variant='body2'>
                        Correo:
                      </Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant='body2'>
                        {modalValues.email}
                      </Typography>
                    </Grid>
                  </Grid>
                </ListItem>
              </List>
            )}
          </CardContent>
        </Card>
      </Modal>
    </Card>
  );
}

export default ViewUsers;
