// ** next
import { useRouter } from 'next/router';
import { useState, Fragment, useEffect } from 'react';

// ** MUI Imports
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Alert from '@mui/material/Alert';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import CardContent from '@mui/material/CardContent';
import TextField from '@mui/material/TextField';

// ** Icons Imports
import Check from 'mdi-material-ui/Check';

import useApiClient from 'src/@core/hooks/useApiClient';
import { CircularProgress } from '@mui/material';

const EditPeriods = () => {

  const router = useRouter();
  const { id } = router.query;
  const [ success, setSuccess ] = useState(null);
  const apiClient = useApiClient();
  const [anchorEl, setAnchorEl] = useState(null)
  const [isFecthing, setIsFecthing] = useState(false);

  const [values, setValues] = useState({
    periodo_name: '',
    fecha_inicio: '',
    fecha_culminacion: '',
  });

  const setDate = (data) => {
    const periodData = data

    const formattedFechaInicio = periodData.split('T')[0];
    return formattedFechaInicio
  }

  const fetchOnePeriods = async () => {
    try {
      const response = await apiClient({
        method: 'post',
        url: '/periodos/getOnePeriods',
        data: {
          id: parseInt(id)
        }
      })
      
      if (response.data) {
        setValues(prev => {
          return {
            periodo_name: response.data.onePeriods.periodo_name,
            fecha_inicio: setDate(response.data.onePeriods.fecha_inicio),
            fecha_culminacion: setDate(response.data.onePeriods.fecha_culminacion),
          }
        })
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsFecthing(false);
    }
  };


  const handleDropdownOpen = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleChange = prop => event => {
    setValues({
      ...values,
      [prop]: event.target.value
    });
  };

  const handleUpdatePeriods = async (event) => {
    event.preventDefault();

    try {
      const response = await apiClient.post('/periodos/updatePeriods', {
        id: parseInt(id),
        periodo_name: values.periodo_name,
        fecha_inicio: values.fecha_inicio,
        fecha_culminacion: values.fecha_culminacion,
      });

      if ( response.data ) {
        setSuccess(response.data);
        setTimeout(() => {
          router.back();
        }, 1500);
      }
    } catch (e) {
      console.log(e);
    } finally {

    }

  };

  const handleDropdownClose = url => {
    if (url) {
      router.push(url);
    }

    setAnchorEl(null);
  };

  const handleReset = () => {
    setValues(prev => {
      return {
        periodo_name: '',
        fecha_inicio: '',
        fecha_culminacion: '',
      }
    })
  };

  useEffect(() => {
    if ( id ) {
      fetchOnePeriods()
    }
  }, [id]);

  return (
    <Card>
      <CardHeader title='Editar Periodo' />
      <CardContent sx={{ pt: theme => `${theme.spacing(3)} !important` }}>
        {isFecthing ? <CircularProgress sx={{ margin: 'auto', marginTop: 10 }} /> : (
          <form onSubmit={handleUpdatePeriods}>
            <Grid container spacing={7}>
              <Grid item xs={12} sm={6}>
                <TextField onChange={handleChange('periodo_name')} focused={values.periodo_name ? true : false} value={values.periodo_name} fullWidth label="Nombre del Periodo Academico" placeholder="2024-1" required={true} />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField onChange={handleChange('fecha_inicio')} value={values.fecha_inicio} fullWidth focused type='date' label="Fecha de Inicio" required={true} />
              </Grid>

              <Grid item xs={12} sm={6}>
                {/* <TextField onChange={handleChange('tutorName')} fullWidth label="Tutor Empresarial" placeholder="Jhon Doe" /> */}
              </Grid>

              <Grid item xs={12} sm={6}>
                <TextField onChange={handleChange('fecha_culminacion')} value={values.fecha_culminacion} fullWidth focused type='date' label="Fecha de Culminacion" required={true} />
              </Grid>

              {success && (
                <Grid item xs={12} sm={12}>
                  <Alert color="success" icon={<Check/>}>
                    {success?.message}
                  </Alert>
                </Grid>
              )}

              <Grid container direction="row-reverse" marginTop={3}>
                <Button variant='contained' type="submit">
                  Editar periodo
                </Button>
                <Button type='reset' variant='outlined' color='secondary' onClick={handleReset} sx={{ marginRight: 3.5 }}>
                  Reiniciar
                </Button>
              </Grid>
            </Grid>
          </form>
        )
        }
      </CardContent>


    </Card>
  )
}

export default EditPeriods;
