// ** next
import { useRouter } from 'next/router';
import { useState, Fragment } from 'react';

// ** MUI Imports
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Alert from '@mui/material/Alert';
import Checkbox from '@mui/material/Checkbox';
import CardHeader from '@mui/material/CardHeader';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import CardContent from '@mui/material/CardContent';
import TextField from '@mui/material/TextField';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';

// ** Icons Imports
import Check from 'mdi-material-ui/Check';

import useApiClient from 'src/@core/hooks/useApiClient';

const CreatePeriods = () => {

  const router = useRouter();
  const [ success, setSuccess ] = useState(null);
  const apiClient = useApiClient();
  const [anchorEl, setAnchorEl] = useState(null)
  
  const [values, setValues] = useState({
    periodo_name: '',
    fecha_inicio: '',
    fecha_culminacion: '',
    activo: true
  });

  const handleDropdownOpen = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleChange = prop => event => {
    setValues({
      ...values,
      [prop]: event.target.value
    });
  };

  const handleCreateCompany = async (event) => {
    event.preventDefault();

    try {
      const response = await apiClient.post('/periodos/registerPeriodos', {
        periodo_name: values.periodo_name,
        fecha_inicio: values.fecha_inicio,
        fecha_culminacion: values.fecha_culminacion,
        activo: values.activo,
      });

      if (response.data) {
        setSuccess(response.data);
        setTimeout(() => {
          router.back();
        }, 1500);
      }
    } catch (e) {
      console.log(e);
    } finally {

    }

  };

  const handleDropdownClose = url => {
    if (url) {
      router.push(url);
    }

    setAnchorEl(null);
  };

  return (
    <Card>
      <CardHeader title='Registrar Periodo' />
      <CardContent sx={{ pt: theme => `${theme.spacing(3)} !important` }}>

        <form onSubmit={handleCreateCompany}>
          <Grid container spacing={7}>
            <Grid item xs={12} sm={6}>
              <TextField
                value={values.periodo_name}
                onChange={handleChange('periodo_name')}
                fullWidth
                label="Nombre del Periodo Academico"
                placeholder="2024-1"
                required={true}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                value={values.fecha_inicio}
                onChange={handleChange('fecha_inicio')}
                fullWidth
                focused
                type='date'
                label="Fecha de Inicio"
                required={true}
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              {/* <TextField onChange={handleChange('tutorName')} fullWidth label="Tutor Empresarial" placeholder="Jhon Doe" /> */}
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField
                value={values.fecha_culminacion}
                onChange={handleChange('fecha_culminacion')}
                fullWidth
                focused
                type='date'
                label="Fecha de Culminacion"
                required={true} 
              />

              <FormGroup>
                <FormControlLabel
                  label="Establecer como activo"
                  control={
                    <Checkbox
                      defaultChecked
                      value={values.activo}
                      onChange={handleChange('activo')}
                    />
                  }
                />
              </FormGroup>
            </Grid>

            {success && (
              <Grid item xs={12}>
                <Alert color="success" icon={<Check/>}>
                  {success?.message}
                </Alert>
              </Grid>
            )}

          </Grid>

          <Grid container direction="row-reverse">
            <Button variant='contained' type="submit">
              Crear periodo
            </Button>
            <Button type="reset" variant="outlined" color="secondary" sx={{ mr: 3.5 }}>
              Reiniciar
            </Button>
          </Grid>
        </form>
      </CardContent>


    </Card>
  )
}

export default CreatePeriods;
