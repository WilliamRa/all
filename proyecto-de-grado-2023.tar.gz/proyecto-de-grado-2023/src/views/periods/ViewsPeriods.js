import { useRouter } from 'next/router';
import { useEffect, useState, Fragment, useCallback } from 'react';
import dayjs from 'dayjs';

// ** MUI Imports
import Box from '@mui/material/Box';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Divider from '@mui/material/Divider';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Chip from '@mui/material/Chip';
import CardHeader from '@mui/material/CardHeader';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import CardContent from '@mui/material/CardContent';
import CircularProgress from '@mui/material/CircularProgress';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TableCell from '@mui/material/TableCell';
import TableBody from '@mui/material/TableBody';
import Modal from '@mui/material/Modal';
import ListSubheader from '@mui/material/ListSubheader';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import TablePagination from '@mui/material/TablePagination';

// ** Icons Imports
import File from 'mdi-material-ui/File';
import Pencil from 'mdi-material-ui/Pencil';
import PlusCircle from 'mdi-material-ui/PlusCircle';
import Delete from 'mdi-material-ui/Delete';
import TrendingUp from 'mdi-material-ui/TrendingUp';
import CurrencyUsd from 'mdi-material-ui/CurrencyUsd';
import DotsVertical from 'mdi-material-ui/DotsVertical';
import CellphoneLink from 'mdi-material-ui/CellphoneLink';
import AccountOutline from 'mdi-material-ui/AccountOutline';

// ** Hooks
import useApiClient from 'src/@core/hooks/useApiClient';

function ViewPeriods() {

  const router = useRouter();
  const [openModal, setOpenModal] = useState(false);
  const apiClient = useApiClient();
  const [periods, setPeriods] = useState([]);
  const [isFecthing, setIsFecthing] = useState(false);
  const [isModalFecthing, setIsModalFecthing] = useState(true);
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [page, setPage] = useState(0);
  
  const [valuesOne, setValuesOne] = useState({
    periodo_name: '',
    fecha_inicio: '',
    fecha_culminacion: '',
  });

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  const fetchPeriods = async () => {
    try {
      const response = await apiClient.get('/periodos/getAllPeriodos');
      
      if ( response.data ) {
        setPeriods(response.data.allPeriods);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsFecthing(false);
    }
  };

  const handleDropdownOpen = (event, userId) => {
    setAnchorEl(event.currentTarget);
    setSelectedUserId(userId);
  };

  const handleDropdownClose = id => {
    
    if (id) {
      router.push(`/dashboard/periods/${id}`);
    }
    setAnchorEl(null);
    setSelectedUserId(null);
  };

  const handleCreateEtapa = id => {

    if (id) {
      router.push(`/dashboard/periods/etapas/${id}`);
    }
    setAnchorEl(null);
    setSelectedUserId(null);
  };


  const viewDetails = async (id) => {
    setOpenModal(true);
    setIsModalFecthing(true);
    try {
      const response = await apiClient({
        method: 'post',
        url: '/periodos/getOnePeriods',
        data: {
          id: parseInt(id)
        }
      })
      console.log(response.data.onePeriods)
      if (response.data) {
        setValuesOne(response.data.onePeriods);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsModalFecthing(false);
    }
  };

  const filterCompanies = useCallback((event) => {
    // Implement filtering logic here
  }, []);

  useEffect(() => {
    setIsFecthing(true);
    fetchPeriods();
  }, []);

  return (
    <Card>
      <CardHeader title="Periodos academicos" />
      <CardContent sx={{ pt: theme => `${theme.spacing(3)} !important` }}>
        <Grid container direction="row-reverse" spacing={2} marginTop={4.8}>
          <Grid item>
            <Button variant="contained" onClick={() => router.push('/dashboard/periods/create')}>
              Crear Periodo
            </Button>
          </Grid>
          <Grid item>
            <TextField size="small" onChange={filterCompanies} label="Buscar periodos" />
          </Grid>
        </Grid>
        <Grid container>
          <Grid item xs={12} marginTop={2}>
            {isFecthing ? <CircularProgress sx={{ margin: 'auto', marginTop: 10 }} /> : periods.length > 0 ? (
              <TableContainer>
                <Table sx={{ minWidth: 800 }} aria-label='table in dashboard'>
                  <TableHead>
                    <TableRow>
                      <TableCell>Nombre del Periodo</TableCell>
                      <TableCell>Fecha de Inicio</TableCell>
                      <TableCell>Fecha de Culminacion</TableCell>
                      <TableCell>Estatus</TableCell>
                      <TableCell>Fases</TableCell>
                      <TableCell>Acciones</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {periods.map((row, index) => (
                      <TableRow hover key={index} sx={{ '&:last-of-type td, &:last-of-type th': { border: 0 } }}>
                        <TableCell sx={{ py: theme => `${theme.spacing(0.5)} !important` }}>
                          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                            <Typography sx={{ fontWeight: 500, fontSize: '0.875rem !important' }}>{row.periodo_name}</Typography>
                            <Typography variant='caption'>{row.designation}</Typography>
                          </Box>
                        </TableCell>
                        <TableCell>{dayjs(row.fecha_inicio).format('DD/MM/YYYY')}</TableCell>
                        <TableCell>{dayjs(row.fecha_culminacion).format('DD/MM/YYYY')}</TableCell>
                        <TableCell>
                          <Chip
                            label={row.status === 0 ? "Inactivo": "Activo"}
                            color={row.status === 0 ? "error": "primary"}
                            sx={{
                              height: 24,
                              fontSize: '0.75rem',
                              textTransform: 'capitalize',
                              '& .MuiChip-label': { fontWeight: 500 }
                            }}
                          />
                        </TableCell>
                        <TableCell>{row.fases}</TableCell>
                        <TableCell>
                          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                            <Fragment>
                              <IconButton size='small' onClick={(event) => handleDropdownOpen(event, row.id)} aria-label='settings' sx={{ width: 40, height: 40, color: 'text.secondary' }}>
                                <DotsVertical />
                              </IconButton>
                              <Menu
                                anchorEl={anchorEl}
                                open={Boolean(anchorEl) && selectedUserId === row.id}
                                onClose={() => handleDropdownClose()}
                                sx={{ '& .MuiMenu-paper': { width: 170, marginTop: 10 } }}
                                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                                transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                              >
                                <MenuItem sx={{ py: 1 }} onClick={() => viewDetails(row.id)}>
                                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <File />
                                    <Typography variant="body2" sx={{ ml: 1 }}>Ver detalles</Typography>
                                  </Box>
                                </MenuItem>
                                <Divider />
                                <MenuItem sx={{ py: 1 }} onClick={() => handleCreateEtapa(row.id)}>
                                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <PlusCircle />
                                    <Typography variant="body2" sx={{ ml: 1 }}>Agregar fases</Typography>
                                  </Box>
                                </MenuItem>
                                <Divider />
                                <MenuItem sx={{ py: 1 }} onClick={() => handleDropdownClose(row.id)}>
                                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <Pencil />
                                    <Typography variant="body2" sx={{ ml: 1 }}>Editar</Typography>
                                  </Box>
                                </MenuItem>
                                <Divider />
                                <MenuItem sx={{ py: 1 }} onClick={() => handleDropdownClose()}>
                                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <Delete />
                                    <Typography variant="body2" sx={{ ml: 1 }}>Borrar</Typography>
                                  </Box>
                                </MenuItem>
                              </Menu>
                            </Fragment>
                          </Box>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                {/* <TablePagination
                  rowsPerPageOptions={[10, 25, 100]}
                  component="div"
                  count={periods.length}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  onPageChange={handleChangePage}
                  onRowsPerPageChange={handleChangeRowsPerPage}
                /> */}
              </TableContainer>
            ) : (
              <Typography align="center" variant="body1">
                No existen periodos academicos registrados
              </Typography>
            )}
          </Grid>
        </Grid>
      </CardContent>

      <Modal
        open={openModal}
        onClose={() => setOpenModal(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Card sx={{ width: '450px', margin: 'auto', marginTop: 40 }}>
          <CardContent>
            {isModalFecthing ? <CircularProgress sx={{ margin: 'auto', marginTop: 10 }} /> : (
              <List
                sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}
                aria-labelledby="nested-list-subheader"
                subheader={
                  <ListSubheader component="div" id="nested-list-subheader">
                    Detalles
                  </ListSubheader>
                }
              >
                <ListItem>
                  <ListItem >
                    <Typography variant='body2'>
                      Nombre Del Periodo
                    </Typography>
                  </ListItem>
                  <Typography variant='body2'>
                    {valuesOne.periodo_name}
                  </Typography>
                </ListItem>

                <ListItem>
                  <ListItem >
                    <Typography variant='body2'>
                      Fecha de Inicio
                    </Typography>
                  </ListItem>
                  <Typography variant='body2'>
                    {dayjs(valuesOne.fecha_inicio).format('DD/MM/YYYY')}
                  </Typography>
                </ListItem>

                <ListItem>
                  <ListItem >
                    <Typography variant='body2'>
                      Fecha de Culminacion
                    </Typography>
                  </ListItem>
                  <Typography variant='body2'>
                    {dayjs(valuesOne.fecha_culminacion).format('DD/MM/YYYY')}
                  </Typography>
                </ListItem>
              </List>
            )}
          </CardContent>
        </Card>
      </Modal>
    </Card>
  );
}

export default ViewPeriods;
