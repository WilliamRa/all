// ** Next Imports
import { useRouter } from 'next/router';

// ** MUI Imports
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CircularProgress from '@mui/material/CircularProgress';
import CardHeader from '@mui/material/CardHeader';

import Typography from '@mui/material/Typography';
import CardContent from '@mui/material/CardContent';
import { styled } from '@mui/material/styles';
import { useState, useEffect } from 'react';
import useApiClient from 'src/@core/hooks/useApiClient';

const ImgStyled = styled('img')(({ theme }) => ({
  width: 120,
  height: 120,
  marginRight: theme.spacing(6.25),
  borderRadius: theme.shape.borderRadius
}));

const ButtonStyled = styled(Button)(({ theme }) => ({
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    textAlign: 'center'
  }
}));

const ResetButtonStyled = styled(Button)(({ theme }) => ({
  marginLeft: theme.spacing(4.5),
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    marginLeft: 0,
    textAlign: 'center',
    marginTop: theme.spacing(4)
  }
}));

const ViewVisitas = () => {

  const router = useRouter();
  const { id } = router.query;
  const apiClient = useApiClient();

  const [visitas, setVisitas] = useState(null);
  const [isFecthing, setIsFecthing] = useState(true);
  
  const [docsSrc, setDocsSrc] = useState({
    // inscripcion: '/images/filetypes/default-file.jpg',
    visita1: '/images/filetypes/default-file.jpg',

    // aceptacion: '/images/filetypes/default-file.jpg',
    visita2: '/images/filetypes/default-file.jpg',
  });

  const fetchVisitasByCurrentProject = async () => {
    try {
      const response = await apiClient.get('/projects/getVisitasByProject', {
        params: {
          proyecto_id: id
        }
      });

      if (response.data) {
        setVisitas(response.data);
        setIsFecthing(false);
      }
    } catch (err) {
    
      console.log(err);
    } finally {

    }
  };

  // const handleFileDownload = async (document) => {
  //   try {
  //     // Realiza la solicitud al servidor para descargar el archivo
  //     let response = await apiClient.get("/files/visitas/download", {
  //       params: {
  //         file: document,
  //         proyecto_id: id
  //       }
  //     });

  //     // Verifica si la respuesta contiene el archivo en base64 con prefijo MIME
  //     const inscripcion = response.data[0]?.inscripcion;
  //     const aceptacion = response.data[0]?.aceptacion;
  //     const planTrabajo = response.data[0]?.planTrabajo;
  //     let base64WithMimeType;

  //     if (inscripcion) {
  //       // Verifica si la cadena contiene "data:" y ",", de lo contrario asume que el string base64 es el contenido sin el prefijo MIME
  //       base64WithMimeType = inscripcion.startsWith('data:') ? inscripcion : `application/pdf;base64,${inscripcion}`;
  //     }

  //     if (aceptacion) {
  //       // Verifica si la cadena contiene "data:" y ",", de lo contrario asume que el string base64 es el contenido sin el prefijo MIME
  //       base64WithMimeType = aceptacion.startsWith('data:') ? aceptacion : `application/pdf;base64,${aceptacion}`;
  //     }

  //     if (planTrabajo) {
  //       // Verifica si la cadena contiene "data:" y ",", de lo contrario asume que el string base64 es el contenido sin el prefijo MIME
  //       base64WithMimeType = planTrabajo.startsWith('data:') ? planTrabajo : `application/pdf;base64,${planTrabajo}`;
  //     }

  //     // Separar el tipo MIME y el contenido base64
  //     const [prefix, base64] = base64WithMimeType.split(',');
  //     const mimeType = prefix.match(/:(.*?);/)[1];

  //     // Decodificar la cadena Base64 y crear un Blob
  //     const byteCharacters = atob(base64);
  //     const byteNumbers = new Array(byteCharacters.length);
  //     for (let i = 0; i < byteCharacters.length; i++) {
  //       byteNumbers[i] = byteCharacters.charCodeAt(i);
  //     }

  //     const byteArray = new Uint8Array(byteNumbers);
  //     const blob = new Blob([byteArray], { type: mimeType });

  //     // Determinar la extensión del archivo según el tipo MIME
  //     let extension = '';

  //     if (mimeType === 'application/pdf') {
  //       extension = 'pdf';
  //     } else if (mimeType === 'application/msword') {
  //       extension = 'doc';
  //     } else if (mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
  //       extension = 'docx';
  //     } else {
  //       // Tratar otros tipos MIME si es necesario
  //       throw new Error(`Unsupported MIME type: ${mimeType}`);
  //     }

  //     // Determinar la extensión del archivo según el tipo MIME
  //     // const extension = mimeType.split('/')[1];

  //     // Asignar un nombre de archivo apropiado
  //     const fileName = `${document}.${extension}`;

  //     // Crear un enlace de descarga
  //     const link = window.document.createElement('a');
  //     link.href = window.URL.createObjectURL(blob);
  //     link.download = fileName;
  //     window.document.body.appendChild(link);
  //     link.click();
  //     window.document.body.removeChild(link);

  //     // Muestra una notificación de éxito si es necesario
  //     // notification.success({
  //     //   message: 'File downloaded successfully',
  //     // });
  //   } catch (error) {
  //     console.error('Error downloading file:', error);
  //     // Muestra una notificación de error si es necesario
  //     // notification.error({
  //     //   message: 'Error downloading file',
  //     //   description: error.message,
  //     // });
  //   } finally {
  //     // Manejo de estado de carga si es necesario
  //     // setLoading(false);
  //   }
  // }

  const handleFileDownload = (filename) => {
    try {
      // Realiza la solicitud al servidor para descargar el archivo
      // let response = await apiClient.get(files[filename]);
  
      // const data = response.data;
  
      // Verifica si la respuesta contiene el archivo en base64 con prefijo MIME
      const { documento_pasantias } = filename;
  
      // Verifica si la cadena contiene "data:" y ",", de lo contrario asume que el string base64 es el contenido sin el prefijo MIME
      const base64WithMimeType = documento_pasantias.startsWith('data:') ? documento_pasantias : `data:application/pdf;base64,${documento_pasantias}`;
  
      // Separar el tipo MIME y el contenido base64
      const [prefix, base64] = base64WithMimeType.split(',');
      const mimeType = prefix.match(/:(.*?);/)[1];
  
      // Decodificar la cadena Base64 y crear un Blob
      const byteCharacters = atob(base64);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
  
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
  
      // Determinar la extensión del archivo según el tipo MIME
      let extension = '';
      switch (mimeType) {
        case 'application/pdf':
          extension = 'pdf';
          break;
        case 'application/msword':
          extension = 'doc';
          break;
        case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
          extension = 'docx';
          break;
        case 'image/jpeg':
          extension = 'jpg';
          break;
        case 'image/png':
          extension = 'png';
          break;
        default:
          
          return;
      }
  
      // Asignar un nombre de archivo apropiado
      const fileName = `${"visitas"}.${extension}`;
  
      // Crear un enlace de descarga
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
  
      // Muestra una notificación de éxito si es necesario
      // notification.success({
      //   message: 'File downloaded successfully',
      // });
    } catch (err) {
      console.log(err);
    } finally {
      // Código opcional a ejecutar al final del bloque try-catch
    }
  };
  
  
  useEffect(() => {

    fetchVisitasByCurrentProject();

  }, [!visitas]);


  return (
    <Card>
      <CardHeader title="Revision de visitas" />
      <CardContent sx={{ pt: theme => `${theme.spacing(3)} !important` }}>
        <Grid
          container
          spacing={[5, 0]}
          sx={{
            flexDirection: "row",
            flexWrap: { md: "nowrap" },
            gap: 3,
            mb: 5
          }}
        >
          {isFecthing ? <CircularProgress /> : (
            <>
              {visitas?.result?.length === 0 && (
                <Typography variant="body1">
                  Actualmente no hay visitas registradas para este proyecto
                </Typography>
              )}

              {visitas?.result?.map((visita, idx) => (
                <Grid key={idx} item xs={12} sm={6} sx={{ mb: 3, pt: 10, py: 5, px: 3, borderRadius: '10px', border: '1px solid #dadada' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <ImgStyled src={docsSrc.visita1} alt='Profile Pic' />
                    <Box sx={{ width: '100%' }}>
                      <Typography variant="body2" sx={{ mb: 2 }}>
                        Visita {idx + 1}
                      </Typography>

                      <Box sx={{ mb: 2 }}>
                        <ButtonStyled onClick={() => handleFileDownload(visita)} size="small" component="label" variant="contained" htmlFor="user-docs-dni">
                          Descargar
                        </ButtonStyled>
                      </Box>

                    </Box>
                  </Box>
                </Grid>
              ))}
            </>
          )}


        </Grid>
      </CardContent>
    </Card>
  )
}

export default ViewVisitas;