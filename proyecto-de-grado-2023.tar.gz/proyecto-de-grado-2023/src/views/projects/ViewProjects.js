import { useRouter } from 'next/router';
import { useEffect } from 'react';
import dayjs from 'dayjs';

// ** MUI Imports
import Box from '@mui/material/Box';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Divider from '@mui/material/Divider';
import Grid from '@mui/material/Grid';
import Chip from '@mui/material/Chip';
import Card from '@mui/material/Card';
import Alert from '@mui/material/Alert';
import CardHeader from '@mui/material/CardHeader';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import CardContent from '@mui/material/CardContent';
import CircularProgress from '@mui/material/CircularProgress';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TableCell from '@mui/material/TableCell';
import TableBody from '@mui/material/TableBody';
import TableFooter from '@mui/material/TableFooter';
import TablePagination from '@mui/material/TablePagination';
import Modal from '@mui/material/Modal';

import AccountBadge from 'mdi-material-ui/AccountBadge';
import File from 'mdi-material-ui/File';
import Eye from 'mdi-material-ui/Eye';
import DotsVertical from 'mdi-material-ui/DotsVertical';
import { useState, Fragment, useCallback } from 'react';
import useApiClient from 'src/@core/hooks/useApiClient';
import { useSession } from 'next-auth/react';

const statusObj = {
  applied: { color: 'info' },
  rejected: { color: 'error' },
  current: { color: 'primary' },
  resigned: { color: 'warning' },
  accepted: { color: 'success' }
};

const estatusLabel = {
  0: 'En proceso',
  1: 'Aprobado',
  2: 'Recahazo',
};

function ViewProjects() {

  const router = useRouter();
  const { data: session } = useSession();
  const [openModal, setOpenModal] = useState(false);
  const apiClient = useApiClient();
  const [selectedRowId, setSelectedRowId] = useState(null);
  const [projects, setProjects] = useState([]);
  const [isFecthing, setIsFecthing] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  useEffect(() => {
    setIsFecthing(true);
    fetchProjects();
  }, []);


  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = event => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };


  const fetchProjects = async () => {
    try {
      const response = await apiClient.get('/projects/getAllProjects');

      if (response.data) {
        setProjects(response.data);
      }
    } catch (e) {
      console.log(e);
    } finally {
      setIsFecthing(false);
    }
  };

  const handleDropdownOpen = (event, rowId) => {
    setAnchorEl(event.currentTarget);
    setSelectedRowId(rowId);
  };

  const handleDropdownClose = id => {

    if (id) {
      router.push(`/dashboard/projects/${id}`);
    }
    setAnchorEl(null);
    setSelectedRowId(null);
  };

  const filterCompanies = useCallback((event) => {

  }, []);
  
  const paginatedProjects = projects.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);
  
  return (
    <Card>
      <CardHeader title="Lista de Proyectos" />
      <CardContent sx={{ pt: theme => `${theme.spacing(3)} !important` }}>
        <Grid container direction="row-reverse" sx={{ mt: 4.8 }}>
          <Grid item>
            <TextField size="small" onChange={filterCompanies} label="Buscar proyectos" />
          </Grid>
        </Grid>
        <Grid container>
          <Grid item xs={12} marginTop={2}>
            {isFecthing ? <CircularProgress sx={{ margin: 'auto', marginTop: 10 }} /> : paginatedProjects.length > 0 ? (
              <TableContainer>
                <Table sx={{ minWidth: 800 }} aria-label='table in dashboard'>
                  <TableHead>
                    <TableRow>
                      <TableCell>Nombre del proyecto</TableCell>
                      {session?.user?.name.role_id === 1 && (<TableCell>Estudiante</TableCell>)}
                      {/* <TableCell>Tipo de documento</TableCell> */}
                      {/* <TableCell>Formato</TableCell> */}
                      <TableCell>Tutor Academico</TableCell>
                      <TableCell>Tutor Empresarial</TableCell>
                      <TableCell>Nombre de empresa</TableCell>
                      <TableCell>Promedio</TableCell>
                      <TableCell>Visitas</TableCell>
                      <TableCell>Estatus</TableCell>
                      <TableCell>Acciones</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {paginatedProjects.map((project, i) => (
                      <TableRow hover key={i} sx={{ '&:last-of-type td, &:last-of-type th': { border: 0 } }}>
                        <TableCell sx={{ py: theme => `${theme.spacing(0.5)} !important` }}>
                          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                            <Typography sx={{ fontWeight: 500, fontSize: '0.875rem !important' }}>
                              {project.proyecto_nombre}
                            </Typography>
                            {/* <Typography variant='caption'>{row.designation}</Typography> */}
                          </Box>
                        </TableCell>
                        {/* {session.user.name.role_id === 1 && (<TableCell>{row.owner}</TableCell>)} */}
                        {/* <TableCell>{row.type}</TableCell> */}
                        {/* <TableCell>
                          <Chip
                            label={row.format}
                            // color={statusObj[row.status].color}
                            sx={{
                              height: 24,
                              fontFamily: 'monospace',
                              fontSize: '0.60rem',
                              '& .MuiChip-label': {
                                fontWeight: 500
                              }
                            }}
                          />
                        </TableCell> */}
                        <TableCell>{project.Estudiante}</TableCell>
                        <TableCell>{project.TutorAcademico ? project.TutorAcademico : <Typography color="orange" variant="body2">Sin asignar</Typography>}</TableCell>
                        <TableCell>{project.TutorEmpresarial ? project.TutorEmpresarial : <Typography color="orange" variant="body2">Sin asignar</Typography>}</TableCell>
                        <TableCell>{project.nombre_empresa ? project.nombre_empresa : <Typography color="orange" variant="body2">Sin asignar</Typography>}</TableCell>
                        <TableCell>{project.PromedioCalificaciones ? project.PromedioCalificaciones : <Typography color="orange" variant="body2">Sin Calificar</Typography>}</TableCell>
                        <TableCell>
                          <Chip
                            label={project.Visitas}
                            color="secondary"
                            sx={{
                              height: 24,
                              fontSize: '0.75rem',
                              textTransform: 'capitalize',
                              '& .MuiChip-label': {
                                fontWeight: 500
                              }
                            }}
                          />
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={estatusLabel[project.status]}
                            color={statusObj.applied.color}
                            sx={{
                              height: 24,
                              fontSize: '0.75rem',
                              textTransform: 'capitalize',
                              '& .MuiChip-label': {
                                fontWeight: 500
                              }
                            }}
                          />
                        </TableCell>
                        <TableCell>
                          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                            <Fragment>
                              <IconButton size='small' onClick={(event) => handleDropdownOpen(event, project.solicitud_id)} aria-label='settings' sx={{ width: 40, height: 40, color: 'text.secondary' }}>
                                <DotsVertical />
                              </IconButton>
                              <Menu
                                anchorEl={anchorEl}
                                open={Boolean(anchorEl) && selectedRowId === project.solicitud_id}
                                onClose={() => handleDropdownClose()}
                                sx={{ '& .MuiMenu-paper': { width: 170, marginTop: 10 } }}
                                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                                transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                              >
                                {/* <MenuItem sx={{ py: 1 }} onClick={() => setOpenModal(!openModal)}>
                                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <File />
                                    <Typography variant="body2" sx={{ ml: 1 }}>
                                      Ver detalles
                                    </Typography>
                                  </Box>
                                </MenuItem>
                                <Divider /> */}
                                <MenuItem sx={{ py: 1 }} onClick={() => router.push(`/dashboard/projects/visitas/${project.id}`)}>
                                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <File />
                                    <Typography variant="body2" sx={{ ml: 1 }}>
                                      Ver visitas
                                    </Typography>
                                  </Box>
                                </MenuItem>
                                <Divider />
                                <MenuItem sx={{ py: 1 }} onClick={() => router.push(`/dashboard/projects/${project.solicitud_id}`)}>
                                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <AccountBadge />
                                    <Typography variant="body2" sx={{ ml: 1 }}>
                                      Asignar tutores
                                    </Typography>
                                  </Box>
                                </MenuItem>

                                <MenuItem sx={{ py: 1 }} onClick={() => router.push(`/dashboard/projects/notas/${project.id}`)}>
                                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <AccountBadge />
                                    <Typography variant="body2" sx={{ ml: 1 }}>
                                      Asignar Notas
                                    </Typography>
                                  </Box>
                                </MenuItem>
                              </Menu>
                            </Fragment>
                          </Box>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                  {/* <TableFooter>
                    <TableRow>
                      <TablePagination
                        rowsPerPageOptions={[5, 10, 25]}
                        colSpan={9}
                        count={projects.length}
                        rowsPerPage={rowsPerPage}
                        page={page}
                        // SelectProps={{
                        //   inputProps: {
                        //     'aria-label': 'rows per page',
                        //   },
                        //   native: true,
                        // }}
                        onPageChange={handleChangePage}
                        onRowsPerPageChange={handleChangeRowsPerPage}
                      />
                    </TableRow>
                  </TableFooter> */}
                </Table>
              </TableContainer>
            ) : (
              <Typography align="center" variant="body1">
                No existen proyectos registrados
              </Typography>
            )}
          </Grid>
        </Grid>
      </CardContent>
      <Modal
        open={openModal}
        onClose={() => setOpenModal(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Card sx={{ width: '400px', margin: 'auto', marginTop: 40 }}>
          <CardContent>
            <Box>
              <Typography id="modal-modal-title" variant="h6" component="h2">
                Detalles de la empresa
              </Typography>
              <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                Nombre: Morrocel C.A
              </Typography>
            </Box>
          </CardContent>
        </Card>
      </Modal>
    </Card>
  );
}

export default ViewProjects;
