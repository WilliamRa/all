// ** Next Imports
import { useRouter } from 'next/router';

// ** MUI Imports
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Alert from '@mui/material/Alert';
import CardHeader from '@mui/material/CardHeader';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import CardContent from '@mui/material/CardContent';
import { styled, useTheme } from '@mui/material/styles';
import { useState, useEffect } from 'react';
import useApiClient from 'src/@core/hooks/useApiClient';

import Check from 'mdi-material-ui/Check';
import { min, values } from 'lodash';

const ImgStyled = styled('img')(({ theme }) => ({
  width: 120,
  height: 120,
  marginRight: theme.spacing(6.25),
  borderRadius: theme.shape.borderRadius
}));

const ButtonStyled = styled(Button)(({ theme }) => ({
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    textAlign: 'center'
  }
}));

const ResetButtonStyled = styled(Button)(({ theme }) => ({
  marginLeft: theme.spacing(4.5),
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    marginLeft: 0,
    textAlign: 'center',
    marginTop: theme.spacing(4)
  }
}));

const fileStatus = [
  { value: 1, name: 'Aprobado' },
  { value: 0, name: 'Rechazado' }
];

const AsignarNotas = () => {

  const router = useRouter();
  const { id } = router.query;
  const apiClient = useApiClient();

  const [success, setSuccess] = useState(null);

  const [docsSrc, setDocsSrc] = useState({
    evaluacion_tutor_academico_image: '/images/filetypes/default-file.jpg',
    evaluacion_tutor_empresarial_image: '/images/filetypes/default-file.jpg',
    informe_image: '/images/filetypes/default-file.jpg',
  });

  const [filesData, setFilesData] = useState({
    evaluacion_tutor_academico: null,
    evaluacion_tutor_empresarial: null,
    informe: null,
    carta_culmicacion: null,
    evaluacion_coordinacion: null
  });
  
  const [filesCalificacion, setFilesCalificacion] = useState({
    evaluacion_tutor_academico: "1",
    evaluacion_tutor_empresarial: "1",
    informe: "1",
    evaluacion_coordinacion: "1"
  });

  const fetchDocumentsStatus = async () => {
    try {
      let response = await apiClient({
        method: 'post',
        url: '/projects/getNotaDocuments',
        data: {
          proyecto_id: id
        }
      });

      setFilesData({
        evaluacion_tutor_academico: response.data.documentos.evaluacion_tutor_academico.evaluacion_tutor_academico_document,
        evaluacion_tutor_empresarial: response.data.documentos.evaluacion_tutor_empresarial.evaluacion_tutor_empresarial_document,
        informe: response.data.documentos.informe_pasantia.documento_final,
        carta_culmicacion: response.data.documentos.carta_culminacion.carta_document,
        evaluacion_coordinacion: response.data.documentos.evaluacion_coordinacion.evuacion_coordinacion_document
      });

    } catch (e) {
      console.group(e)
    } finally {

    }
  };

  const handleChange = prop => event => {
    setFilesCalificacion({
      ...filesCalificacion,
      [prop]: event.target.value
    });
  };

  const handleFormSubmit = async (event) => {
    event.preventDefault();

    try {
      const response = await apiClient.post('/projects/updateNotas', filesCalificacion, {
        params: {
          proyecto_id: id
        }
      });

      if ( response.data ) {
        setFilesData({
          evaluacion_tutor_academico: null,
          evaluacion_tutor_empresarial: null,
          informe: null
        });
        setSuccess(response.data);
        setTimeout(() => {
          router.back();
        }, 1500);
      }
    } catch (err) {
      console.log(err);
    } finally {

    }
  };


  const handleDownloadFile = async (filename) => {
    console.log(filesData)
    try {
      // Realiza la solicitud al servidor para descargar el archivo

      // Verifica si la respuesta contiene el archivo en base64 con prefijo MIME

      // Verifica si la cadena contiene "data:" y ",", de lo contrario asume que el string base64 es el contenido sin el prefijo MIME
      const base64WithMimeType = filename.startsWith('data:') ? filename : `data:application/pdf;base64,${filename}`;

      // Separar el tipo MIME y el contenido base64
      const [prefix, base64] = base64WithMimeType.split(',');
      const mimeType = prefix.match(/:(.*?);/)[1];

      // Decodificar la cadena Base64 y crear un Blob
      const byteCharacters = atob(base64);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });

      // Determinar la extensión del archivo según el tipo MIME
      let extension = '';
      switch (mimeType) {
        case 'application/pdf':
          extension = 'pdf';
          break;
        case 'application/msword':
          extension = 'doc';
          break;
        case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
          extension = 'docx';
          break;
        case 'image/jpeg':
          extension = 'jpg';
          break;
        case 'image/png':
          extension = 'png';
          break;
        default:
          console.log('Tipo de archivo no soportado:', mimeType);
          return;
      }

      // Asignar un nombre de archivo apropiado
      const fileName = `${"filename"}.${extension}`;

      // Crear un enlace de descarga
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // Muestra una notificación de éxito si es necesario
      // notification.success({
      //   message: 'File downloaded successfully',
      // });
    } catch (err) {
      console.log(err);
    } finally {
      // Código opcional a ejecutar al final del bloque try-catch
    }
  };


  useEffect(() => {
    if (id) {
      fetchDocumentsStatus()
    }
  }, []);


  return (
    <Card>
      <form onSubmit={handleFormSubmit}>
        <CardHeader title="Asignacion de notas" />
        <CardContent sx={{ pt: theme => `${theme.spacing(3)} !important` }}>
          <Grid
            container
            spacing={[5, 0]}
            sx={{
              flexDirection: "row",
              gap: 3,
              mb: 5
            }}
          >

            <Grid item xs={12} sx={{ mb: 3, pt: 10, py: 5, px: 3, borderRadius: '10px', border: '1px solid #dadada' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <ImgStyled src={docsSrc.evaluacion_tutor_academico_image} alt='Profile Pic' />
                <Box sx={{ width: '100%' }}>
                  <Typography variant="body2" sx={{ mb: 2 }}>
                    Evaluacion Tutor Academico
                  </Typography>

                  <Box sx={{ mb: 2 }}>
                    <ButtonStyled onClick={() => handleDownloadFile(filesData.evaluacion_tutor_academico)} size="small" component="label" variant="contained" htmlFor="user-docs-academico">
                      Descargar
                    </ButtonStyled>
                    <TextField
                      sx={{ ml: 3 }}
                      size="small"
                      type="number"
                      defaultValue={1}
                      InputProps={{ inputProps: { min: 1, max: 100 } }}
                      value={values.evaluacion_tutor_academico}
                      onChange={handleChange('evaluacion_tutor_academico')}
                      label="Calificación"
                      required
                    />
                  </Box>

                </Box>
              </Box>
            </Grid>

            {/* Constancia de notas */}
            <Grid item xs={12} sx={{ mb: 3, pt: 10, py: 5, px: 3, borderRadius: '10px', border: '1px solid #dadada' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <ImgStyled src={docsSrc.evaluacion_tutor_empresarial_image} alt='Profile Pic' />
                <Box sx={{ width: '100%' }}>
                  <Typography variant="body2" sx={{ mb: 5 }}>
                    Evaluacion Tutor Empresarial
                  </Typography>

                  <Box sx={{ mb: 2 }}>
                    <ButtonStyled onClick={() => handleDownloadFile(filesData.evaluacion_tutor_empresarial)} size="small" component="label" variant="contained" htmlFor="user-docs-empresarial">
                      Descargar
                    </ButtonStyled>

                    <TextField
                      sx={{ ml: 3 }}
                      size="small"
                      type="number"
                      defaultValue={1}
                      InputProps={{ inputProps: { min: 1, max: 100 } }}
                      value={values.evaluacion_tutor_empresarial}
                      onChange={handleChange('evaluacion_tutor_empresarial')}
                      label="Calificación"
                      required
                    />
                  </Box>

                </Box>
              </Box>
            </Grid>

            {/* Constancia de notas */}
            <Grid item xs={12} sx={{ mb: 3, pt: 10, py: 5, px: 3, borderRadius: '10px', border: '1px solid #dadada' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <ImgStyled src={docsSrc.evaluacion_tutor_empresarial_image} alt='Profile Pic' />
                <Box sx={{ width: '100%' }}>
                  <Typography variant="body2" sx={{ mb: 5 }}>
                    Informe de Pasantias
                  </Typography>

                  <Box sx={{ mb: 2 }}>
                    <ButtonStyled onClick={() => handleDownloadFile(filesData.informe)} size="small" component="label" variant="contained" htmlFor="user-docs-informe">
                      Descargar
                    </ButtonStyled>

                    <TextField
                      sx={{ ml: 3 }}
                      size="small"
                      type="number"
                      defaultValue={1}
                      InputProps={{ inputProps: { min: 1, max: 100 } }}
                      value={values.evaluacion_tutor_empresarial}
                      onChange={handleChange('informe')}
                      label="Calificación"
                      required
                    />
                  </Box>

                </Box>
              </Box>
            </Grid>


            <Grid item xs={12} sx={{ mb: 3, pt: 10, py: 5, px: 3, borderRadius: '10px', border: '1px solid #dadada' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <ImgStyled src={docsSrc.informe_image} alt='Profile Pic' />
                <Box sx={{ width: '100%' }}>
                  <Typography variant="body2" sx={{ mb: 5 }}>
                    Evaluacion coordinacion
                  </Typography>

                  <Box sx={{ mb: 2 }}>
                    <ButtonStyled onClick={() => handleDownloadFile(filesData.evaluacion_coordinacion)} size="small" component="label" variant="contained" htmlFor="user-docs-coordinacion">
                      Descargar
                    </ButtonStyled>

                    <TextField
                      sx={{ ml: 3 }}
                      size="small"
                      type="number"
                      defaultValue={1}
                      InputProps={{ inputProps: { min: 1, max: 100 } }}
                      value={values.evaluacion_coordinacion}
                      onChange={handleChange('evaluacion_coordinacion')}
                      label="Evaluacion de la Coordinacion"
                      required
                    />
                  </Box>

                </Box>
              </Box>
            </Grid>

            {/* Constancia de estudio */}
            <Grid item xs={12} sx={{ mb: 3, pt: 10, py: 5, px: 3, borderRadius: '10px', border: '1px solid #dadada' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <ImgStyled src={docsSrc.informe_image} alt='Profile Pic' />
                <Box sx={{ width: '100%' }}>
                  <Typography variant="body2" sx={{ mb: 5 }}>
                    Carta de Culminacion
                  </Typography>

                  <Box sx={{ mb: 2 }}>
                    <ButtonStyled onClick={() => handleDownloadFile(filesData.carta_culmicacion)} size="small" component="label" variant="contained" htmlFor="user-docs-culminacion">
                      Descargar
                    </ButtonStyled>
                  </Box>

                </Box>
              </Box>
            </Grid>
          </Grid>

          {success && (
            <Grid item xs={12}>
              <Alert color="success" icon={<Check />}>
                {success?.message}
              </Alert>
            </Grid>
          )}

          <Grid container direction="row-reverse">
            <Button type="submit" variant="contained">
              Asignar
            </Button>
            <Button type="reset" variant="outlined" color="secondary" sx={{ marginRight: 3.5 }}>
              Reiniciar
            </Button>
          </Grid>
        </CardContent>
      </form>
    </Card>
  )
}

export default AsignarNotas;