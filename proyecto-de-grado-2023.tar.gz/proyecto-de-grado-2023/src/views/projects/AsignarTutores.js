// ** React Imports
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';

// ** MUI Imports
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Select from '@mui/material/Select';
import { styled } from '@mui/material/styles';
import MenuItem from '@mui/material/MenuItem';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import InputLabel from '@mui/material/InputLabel';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardHeader from '@mui/material/CardHeader';
import FormControl from '@mui/material/FormControl';
import Button from '@mui/material/Button';
import Alert from '@mui/material/Alert';

// ** MUI Icons
import Check from 'mdi-material-ui/Check';
import useApiClient from 'src/@core/hooks/useApiClient';

const ImgStyled = styled('img')(({ theme }) => ({
  width: 120,
  height: 120,
  marginRight: theme.spacing(6.25),
  borderRadius: theme.shape.borderRadius
}));

const ButtonStyled = styled(Button)(({ theme }) => ({
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    textAlign: 'center'
  }
}));

const ResetButtonStyled = styled(Button)(({ theme }) => ({
  marginLeft: theme.spacing(4.5),
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    marginLeft: 0,
    textAlign: 'center',
    marginTop: theme.spacing(4)
  }
}));

function AsignarTutores() {

  const apiClient = useApiClient();
  const router = useRouter();
  const { id } = router.query;

  // ** State
  const [success, setSuccess] = useState(null);
  const [tutores_academicos, setTutoresAcademicos] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [tutores_empresariales, setTutoresEmpresariales] = useState([]);
  const [imgSrc, setImgSrc] = useState('/images/avatars/default-profile.png');
  const [typingPassword, setTypingPassword] = useState(false);
  const [passwordDifferentError, setPasswordDifferentError] = useState(false);
  const [error, setError] = useState({ hasError: false, msg: null });
  
  const [ errorTypes, setErrorTypes ] = useState({
    'FORM_FIELD_WRONG_DNI': false,
    'FORM_FIELD_WRONG_USERNAME': false,
    'FORM_FIELD_WRONG_EMAIL': false,
    'FORM_FIELD_MISSING_FIRSTNAME': false,
    'FORM_FIELD_MISSING_LASTNAME': false,
    'FORM_FIELD_MISSING_DNI': false,
    'FORM_FIELD_MISSING_USERNAME': false,
    'FORM_FIELD_MISSING_EMAIL': false,
    'FORM_FIELD_MISSING_PASSWORD': false,
    'FORM_FIELD_DUPLICATED_DNI': false,
    'FORM_FIELD_DUPLICATED_USERNAME': false,
    'FORM_FIELD_DUPLICATED_EMAIL': false
  });

  const [values, setValues] = useState({
    tutor_empresarial: "",
    tutor_academico: "",
    empresa_id: "",
    empresa_name: ""
  });

  useEffect(() => {
    fetchTutores();
  }, []);

  const fetchTutores = async () => {
    try {
      const response = await apiClient('/proyectos/getSelectAsignacion');

      if (response.data) {
        setTutoresAcademicos(response.data.tutor_academico)
        setTutoresEmpresariales(response.data.tutor_empresarial)
      }
    } catch (e) {

    } finally {

    }
  };

  const handleFormReset = () => {
    setValues({
      tutor_empresarial: "",
      tutor_academico: "",
      empresa_id: "",
      empresa_name: "",
    });
    setErrorTypes({
      'FORM_FIELD_WRONG_DNI': false,
      'FORM_FIELD_WRONG_USERNAME': false,
      'FORM_FIELD_WRONG_EMAIL': false,
      'FORM_FIELD_MISSING_FIRSTNAME': false,
      'FORM_FIELD_MISSING_LASTNAME': false,
      'FORM_FIELD_MISSING_DNI': false,
      'FORM_FIELD_MISSING_USERNAME': false,
      'FORM_FIELD_MISSING_EMAIL': false,
      'FORM_FIELD_MISSING_PASSWORD': false,
      'FORM_FIELD_DUPLICATED_DNI': false,
      'FORM_FIELD_DUPLICATED_USERNAME': false,
      'FORM_FIELD_DUPLICATED_EMAIL': false
    });
  };

  const handleChange = prop => event => {
    if ( prop === "tutor_empresarial" ) {
      let find = tutores_empresariales.find(tutor => tutor.id === event.target.value)
      setValues(prev => {
        return {
          ...prev,
          [prop]: event.target.value,
          empresa_name: find.empresa.nombre_empresa,
          empresa_id: find.empresa.id
        }
      });
    }

    setValues(prev => {
      return {
        ...prev,
        [prop]: event.target.value,
      }
    });

  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSubmitting(true);

    try {
      const response = await apiClient.post(`/proyectos/updateAsignacionTutores`, {
        id_solicitud: id,
        tutor_academico: values.tutor_academico,
        tutor_empresarial: values.tutor_empresarial,
        empresa_id: values.empresa_id,
      });

      if (response.data?.type === 'FORM_REGISTRY_SUCCESS') {
        setSuccess(response.data);
        setValues({
          firstname: '',
          lastname: '',
          dni: '',
          username: '',
          email: '',
          password: '',
          rol: null,
          status: null,
          reTypePassword: '',
          showPassword: false
        });
      }
    } catch (e) {

      const { type } = e.response.data;
      setErrorTypes({
        ...errorTypes,
        [type]: true
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card>
      {values.firstname && values.lastname && <CardHeader title={`Actualizar el usuario: ${values.firstname} ${values.lastname}`} />}
      <CardContent>
        <form onSubmit={handleSubmit}>
          <Grid container spacing={4} sx={{ mb: 3 }}>

            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Tutor Academico</InputLabel>
                <Select label="Tutor Academico" value={values.tutor_academico} required onChange={handleChange('tutor_academico')}>
                  {tutores_academicos.map((rol, i) => (
                    <MenuItem key={i} value={rol.id}>
                      {`${rol.firstname} ${rol.lastname}`}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>


            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Tutor Empresarial</InputLabel>
                <Select label="Tutor Empresarial" value={values.tutor_empresarial} required onChange={handleChange('tutor_empresarial')}>
                  {tutores_empresariales.map((rol, i) => (
                    <MenuItem key={i} value={rol.id}>
                      {`${rol.firstname} ${rol.lastname}`}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12} sm={6} >
              <TextField
                required
                fullWidth
                onChange={handleChange('empresa_name')}
                disabled={true}
                value={values.empresa_name}
              />
            </Grid>

            {success && (
              <Grid item xs={12}>
                <Alert color="success" icon={<Check/>}>
                  <Typography variant="body2">
                    {success?.message}
                  </Typography>
                </Alert>
              </Grid>
            )}

          </Grid>

          <Grid container direction="row-reverse">
            <Grid item>
              <Button
                type="reset"
                variant="outlined"
                color="secondary"
                onClick={handleFormReset}
                sx={{ marginRight: 3.5 }}
              >
                Reiniciar
              </Button>

              <Button
                type="submit"
                variant="contained"
                onClick={handleSubmit}
              >
                Asignar Tutores
              </Button>
            </Grid>
          </Grid>

        </form>
      </CardContent>
    </Card>
  );
}

export default AsignarTutores;
