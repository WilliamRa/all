// ** React Imports
import React, { forwardRef, useState } from 'react';

// ** MUI Imports
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import RadioGroup from '@mui/material/RadioGroup';
import Radio from '@mui/material/Radio';
import Switch from '@mui/material/Switch';
import Divider from '@mui/material/Divider';
import Typography from '@mui/material/Typography';
import Select from '@mui/material/Select';
import Button from '@mui/material/Button';
import MenuItem from '@mui/material/MenuItem';
import TextField from '@mui/material/TextField';
import InputLabel from '@mui/material/InputLabel';
import CardContent from '@mui/material/CardContent';
import CardHeader from '@mui/material/CardHeader';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import OutlinedInput from '@mui/material/OutlinedInput';
import FormControlLabel from '@mui/material/FormControlLabel';

// ** Icon Imports
import ArrowDown from 'mdi-material-ui/ArrowDown';

// ** Third Party Imports
import DatePicker from 'react-datepicker';

// ** Styled Components
import DatePickerWrapper from 'src/@core/styles/libs/react-datepicker';

const CustomInput = forwardRef((props, ref) => {
  return <TextField inputRef={ref} label='Fecha de nacimiento' fullWidth {...props} />
})

const TabAdvanced = () => {

  const [ expanded, setExpanded ] = useState(true);

  const handleExpand = (event) => {
    setExpanded(!expanded);
  };

  return (
    <>
      <CardHeader title='Opciones avanzadas' />
      <CardContent>
        <form>
          <Grid container spacing={7}>
            <Grid item xs={12}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Accordion expanded={expanded} onChange={handleExpand} sx={{ width: '100%' }}>
                  <AccordionSummary
                    expandIcon={<ArrowDown />}
                    aria-controls="panel1bh-content"
                    id="panel1bh-header" 
                  >
                    <Typography sx={{ width: '33%', flexShrink: 0 }}>
                      General settings
                    </Typography>
                    <Typography sx={{ color: 'text.secondary' }}>I am an accordion</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Box>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Typography sx={{ flexShrink: 0 }}>
                          Esta es una opcion simple
                        </Typography> 
                        <Switch/>
                      </Box>
                      <Divider/>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Box>
                          <Typography>
                            This is a simple option
                          </Typography>
                          <Typography sx={{ fontSize: '8pt', color: 'text.secondary' }}>
                            Esta es una pequeña descripcion para la opcion
                          </Typography>
                        </Box>
                        <Switch/>
                      </Box>
                      <Divider/>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Box>
                          <Typography>
                            This is a simple option
                          </Typography>
                          <Typography sx={{ fontSize: '8pt', color: 'text.secondary' }}>
                            Esta es una pequeña descripcion para la opcion
                          </Typography>
                        </Box>
                        <FormControl>
                          <InputLabel>Opcion</InputLabel>
                          <Select label='Opcion' defaultValue='admin'>
                            <MenuItem value='admin'>Admin</MenuItem>
                            <MenuItem value='author'>Autor</MenuItem>
                            <MenuItem value='editor'>Editor</MenuItem>
                          </Select>
                        </FormControl>

                      </Box>
                    </Box>
                  </AccordionDetails>
                </Accordion>
              </Box>
            </Grid>

            <Grid item xs={12}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Accordion sx={{ width: '100%' }}>
                  <AccordionSummary
                    expandIcon={<ArrowDown />}
                    aria-controls="panel1bh-content"
                    id="panel1bh-header"
                    
                  >
                    <Typography sx={{ width: '33%', flexShrink: 0 }}>
                      General settings
                    </Typography>
                    <Typography sx={{ color: 'text.secondary' }}>I am an accordion</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Box>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Typography sx={{ flexShrink: 0 }}>
                          Esta es una opcion simple
                        </Typography> 
                        <Switch/>
                      </Box>
                      <Divider/>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Box>
                          <Typography>
                            This is a simple option
                          </Typography>
                          <Typography sx={{ fontSize: '8pt', color: 'text.secondary' }}>
                          Esta es una pequeña descripcion para la opcion
                          </Typography>
                        </Box>
                        <Switch/>
                      </Box>
                      <Divider/>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Box>
                          <Typography>
                            This is a simple option
                          </Typography>
                          <Typography sx={{ fontSize: '8pt', color: 'text.secondary' }}>
                            Esta es una pequeña descripcion para la opcion
                          </Typography>
                        </Box>
                        <FormControl>
                          <InputLabel>Opcion</InputLabel>
                          <Select label='Opcion' defaultValue='admin'>
                            <MenuItem value='admin'>Admin</MenuItem>
                            <MenuItem value='author'>Autor</MenuItem>
                            <MenuItem value='editor'>Editor</MenuItem>
                          </Select>
                        </FormControl>

                      </Box>
                    </Box>
                  </AccordionDetails>
                </Accordion>
              </Box>
            </Grid>

            <Grid item xs={12}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Accordion sx={{ width: '100%' }}>
                  <AccordionSummary
                    expandIcon={<ArrowDown />}
                    aria-controls="panel1bh-content"
                    id="panel1bh-header"
                    
                  >
                    <Typography sx={{ width: '33%', flexShrink: 0 }}>
                      General settings
                    </Typography>
                    <Typography sx={{ color: 'text.secondary' }}>I am an accordion</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Box>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Typography sx={{ flexShrink: 0 }}>
                          Esta es una opcion simple
                        </Typography> 
                        <Switch/>
                      </Box>
                      <Divider/>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Box>
                          <Typography>
                            This is a simple option
                          </Typography>
                          <Typography sx={{ fontSize: '8pt', color: 'text.secondary' }}>
                          Esta es una pequeña descripcion para la opcion
                          </Typography>
                        </Box>
                        <Switch/>
                      </Box>
                      <Divider/>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Box>
                          <Typography>
                            This is a simple option
                          </Typography>
                          <Typography sx={{ fontSize: '8pt', color: 'text.secondary' }}>
                            Esta es una pequeña descripcion para la opcion
                          </Typography>
                        </Box>
                        <FormControl>
                          <InputLabel>Opcion</InputLabel>
                          <Select label='Opcion' defaultValue='admin'>
                            <MenuItem value='admin'>Admin</MenuItem>
                            <MenuItem value='author'>Autor</MenuItem>
                            <MenuItem value='editor'>Editor</MenuItem>
                          </Select>
                        </FormControl>

                      </Box>
                    </Box>
                  </AccordionDetails>
                </Accordion>
              </Box>
            </Grid>

            <Grid item xs={12}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Accordion sx={{ width: '100%' }}>
                  <AccordionSummary
                    expandIcon={<ArrowDown />}
                    aria-controls="panel1bh-content"
                    id="panel1bh-header"
                    
                  >
                    <Typography sx={{ width: '33%', flexShrink: 0 }}>
                      General settings
                    </Typography>
                    <Typography sx={{ color: 'text.secondary' }}>I am an accordion</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Box>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Typography sx={{ flexShrink: 0 }}>
                          Esta es una opcion simple
                        </Typography> 
                        <Switch/>
                      </Box>
                      <Divider/>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Box>
                          <Typography>
                            This is a simple option
                          </Typography>
                          <Typography sx={{ fontSize: '8pt', color: 'text.secondary' }}>
                          Esta es una pequeña descripcion para la opcion
                          </Typography>
                        </Box>
                        <Switch/>
                      </Box>
                      <Divider/>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Box>
                          <Typography>
                            This is a simple option
                          </Typography>
                          <Typography sx={{ fontSize: '8pt', color: 'text.secondary' }}>
                            Esta es una pequeña descripcion para la opcion
                          </Typography>
                        </Box>
                        <FormControl>
                          <InputLabel>Opcion</InputLabel>
                          <Select label='Opcion' defaultValue='admin'>
                            <MenuItem value='admin'>Admin</MenuItem>
                            <MenuItem value='author'>Autor</MenuItem>
                            <MenuItem value='editor'>Editor</MenuItem>
                          </Select>
                        </FormControl>

                      </Box>
                    </Box>
                  </AccordionDetails>
                </Accordion>
              </Box>
            </Grid>
            
            <Grid container direction="row-reverse" marginTop={4.8} xs={12}>
              <Button variant='contained'>
                Guardar cambios
              </Button>
              <Button type='reset' variant='outlined' color='secondary' sx={{ marginRight: 3.5 }}>
                Reinicio
              </Button>
            </Grid>
          </Grid>
        </form>
      </CardContent>
    </>    
  );

};

export default TabAdvanced;
