// ** React Imports
import { useState } from 'react';

// ** MUI Imports
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import ToggleButton from '@mui/material/ToggleButton';
import Switch from '@mui/material/Switch';
import Divider from '@mui/material/Divider';
import Link from '@mui/material/Link';
import Alert from '@mui/material/Alert';
import Select from '@mui/material/Select';
import { styled } from '@mui/material/styles';
import MenuItem from '@mui/material/MenuItem';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import InputLabel from '@mui/material/InputLabel';
import AlertTitle from '@mui/material/AlertTitle';
import IconButton from '@mui/material/IconButton';
import CardContent from '@mui/material/CardContent';
import CardHeader from '@mui/material/CardHeader';
import FormControl from '@mui/material/FormControl';
import Button from '@mui/material/Button';

// ** Components
import SubHeaderTitle from 'src/@core/layouts/components/shared-components/SubHeaderTitle'

const SubTitle = styled(Typography)(({ theme }) => ({ 
  fontSize: '1.125rem',
  color: `${theme.palette.text.secondary}`,
  '&:before, &:after': {
    borderTop: `1px solid ${theme.palette.divider}`,
    top: '-7px',
  }
}));

// ** Icons Imports
import Close from 'mdi-material-ui/Close';

const TabGeneral = () => {
  
  const [ openAlert, setOpenAlert ] = useState(true);
  const [ fileUploadEnabled, setFileUploadEnabled ] = useState(true)
  const [ extendedSessionEnabled, setExtendedSessionEnabled ] = useState(false);
  const [ platform, setPlatform ] = useState("web");

  const handlePlatform = (event, newPlatform ) => {
    setPlatform(newPlatform);
  };

  const handleFileUpload = (event) => {
    setFileUploadEnabled(!fileUploadEnabled);
  };

  const handleExtendedSession = (event) => {
    setExtendedSessionEnabled(!extendedSessionEnabled);
  };

  return (
    <>
      <CardHeader title='Ajustes Generales' />
      <CardContent>
        <form>
          <Grid container spacing={7}>
            <Grid item id="sss" xs={12} sx={{ marginBottom: 3, paddingTop: '0 !important' }}>
              <Box sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center', flexWrap: 'nowrap' }}>
                <SubHeaderTitle>
                  Archivos
                </SubHeaderTitle>
              </Box>
              <Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography sx={{ flexShrink: 0 }}>
                    Permitir subida de archivos
                  </Typography> 
                  <Switch onChange={handleFileUpload} checked={fileUploadEnabled}/>
                </Box>
                <Divider/>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', opacity: fileUploadEnabled ? 1 : 0.5 }}>
                  <Typography sx={{ flexShrink: 0 }}>
                    Tipos de archivos permitidos
                  </Typography> 
                  <Button type="button" disabled={!fileUploadEnabled} size="small" variant="outlined" color='secondary'>
                    ver
                  </Button>
                </Box>
                <Divider/>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', opacity: fileUploadEnabled ? 1 : 0.5 }}>
                  <Box>
                    <Typography>
                      Tamaño maximo de subida
                    </Typography>
                    <Typography sx={{ fontSize: '8pt', color: 'text.secondary' }}>
                      Limite maximo permitido para la subida de archivos
                    </Typography>
                  </Box>
                  <TextField
                    type="number"
                    size="small"
                    sx={{ width: '80px' }}
                    label="MB"
                    placeholder="15MB"
                    defaultValue="0"
                    disabled={!fileUploadEnabled}
                  />
                </Box>
                <Divider/>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', opacity: fileUploadEnabled ? 1 : 0.5 }}>
                  <Box>
                    <Typography>
                      A que tipos de usuarios se les permiten subir archivos
                    </Typography>
                    <Typography sx={{ fontSize: '8pt', color: 'text.secondary' }}>
                      Rol de usuario autorizado para subir archivos al servidor
                    </Typography>
                  </Box>
                  <FormControl>
                    <InputLabel>Opcion</InputLabel>
                    <Select label="Opcion" defaultValue="admin" size="small" disabled={!fileUploadEnabled}>
                      <MenuItem value="admin">Admin</MenuItem>
                      <MenuItem value="author">Autor</MenuItem>
                      <MenuItem value="editor">Editor</MenuItem>
                    </Select>
                  </FormControl>
                </Box>
                <Divider/>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', opacity: fileUploadEnabled ? 1 : 0.5 }}>
                  <Box>
                    <Typography>
                      Permitir subida archivos desde
                    </Typography>
                    <Typography sx={{ fontSize: '8pt', color: 'text.secondary' }}>
                      Plataforma admitida para la subida de archivos al sistema
                    </Typography>
                  </Box>
                  <ToggleButtonGroup
                    color="primary"
                    size="small"
                    value={platform}
                    exclusive
                    onChange={handlePlatform}
                    aria-label="Platform"
                    disabled={!fileUploadEnabled}
                  >
                    <ToggleButton value="todo">Todos</ToggleButton>
                    <ToggleButton value="web">Web</ToggleButton>
                    <ToggleButton value="android">Android</ToggleButton>
                    <ToggleButton value="ios">iOS</ToggleButton>
                  </ToggleButtonGroup>
                </Box>

              </Box>
            </Grid>

            <Grid item id="sss" xs={12} sx={{ marginBottom: 3, paddingTop: '0 !important' }}>
              <Box sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center', flexWrap: 'nowrap' }}>
                <SubHeaderTitle>
                  Inicios de Sesión
                </SubHeaderTitle>
              </Box>
              <Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography sx={{ flexShrink: 0 }}>
                    Permitir Sesiones extendidas
                  </Typography> 
                  <Switch onChange={handleExtendedSession} checked={extendedSessionEnabled}/>
                </Box>
                <Divider/>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', opacity: extendedSessionEnabled ? 1 : 0.5 }}>
                  <Typography sx={{ flexShrink: 0 }}>
                    Tipos de archivos permitidos
                  </Typography> 
                  <TextField
                    type="number"
                    size="small"
                    sx={{ width: '80px' }}
                    label="Dias"
                    placeholder="7"
                    defaultValue="0"
                    disabled={!extendedSessionEnabled}
                  />
                </Box>
              </Box>
            </Grid>

            <Grid container direction="row-reverse" marginTop={4.8} xs={12}>
              <Button variant='contained'>
                Guardar cambios
              </Button>
              <Button type='reset' variant='outlined' color='secondary' sx={{ marginRight: 3.5 }}>
                Reiniciar
              </Button>
            </Grid>
          </Grid>
        </form>
      </CardContent>
    </>
  );

};

export default TabGeneral;
