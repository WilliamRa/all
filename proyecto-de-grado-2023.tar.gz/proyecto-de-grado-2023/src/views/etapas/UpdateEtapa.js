import { useRouter } from 'next/router';
import { useState, useEffect } from 'react';

import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Alert from '@mui/material/Alert';
import CardHeader from '@mui/material/CardHeader';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import CardContent from '@mui/material/CardContent';
import TextField from '@mui/material/TextField';

import Check from 'mdi-material-ui/Check';

import useApiClient from 'src/@core/hooks/useApiClient';
import { CircularProgress } from '@mui/material';

const statusObj = {
  applied: { color: 'info' },
  rejected: { color: 'error' },
  current: { color: 'primary' },
  resigned: { color: 'warning' },
  accepted: { color: 'success' }
};

const UpdateEtapa = () => {

  const router = useRouter();
  const { id } = router.query;
  const apiClient = useApiClient();

  const [ success, setSuccess] = useState(null);
  const [ anchorEl, setAnchorEl ] = useState(null)
  const [ isFecthing, setIsFecthing ] = useState(false);
  const [ etapas, setEtapas ] = useState([])
  const [ selectedUserId, setSelectedUserId ] = useState(null);
  const [ etapasTable, setEtapasTable ] = useState([])
  
  const [ values, setValues ] = useState({
    periodo_name: '',
    fecha_inicio: '',
    fecha_culminacion: '',
    etapa_id: null
  });

  useEffect(() => {
    if ( id ) {
      fetchOnePeriods();
    }
  }, [ id ]);

  const setDate = (data) => {
    const periodData = data
    
    const formattedFechaInicio = periodData.split('T')[0];
    return formattedFechaInicio
  }

  const fetchOnePeriods = async () => {
    try {
      const response = await apiClient({
        method: 'post',
        url: '/etapas/getOneEtapa',
        data: {
          id: parseInt(id)
        }
      })
      
      if ( response.data ) {
        setValues(prev => {
          return {
            fecha_inicio: setDate(response.data.etapas.fecha_inicio),
            fecha_culminacion: setDate(response.data.etapas.fecha_fin),
          }
        })
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsFecthing(false);
    }
  };

  const fetchAllEtapas = async () => {
    try {
      const response = await apiClient({
        method: 'get',
        url: '/etapas/getAllEtapas',

      });
      
      if (response.data) {
        setEtapas(response.data.etapas)
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsFecthing(false);
    }
  };


  const handleUpdatePeriods = async (event) => {
    event.preventDefault();

    try {
      const response = await apiClient.post('/etapas/editEtapa', {
        fecha_inicio: values.fecha_inicio,
        fecha_fin: values.fecha_culminacion,
        id: parseInt(id)
      });

      if ( response.data ) {
        setSuccess(response.data);
        setTimeout(() => {
          router.back();
        }, 1500);
      }
    } catch (e) {
      console.log(e);
    } finally {

    }

  };

  const handleDropdownClose = url => {
    if (url) {
      router.push(url);
    }

    setAnchorEl(null);
  };

  const handleReset = () => {
    setValues(prev => {
      return {
        periodo_name: '',
        fecha_inicio: '',
        fecha_culminacion: '',
      }
    })
  };

  const handleChange = prop => event => {
    setValues({
      ...values,
      [prop]: event.target.value
    });
  };

  return (
    <Card>
      <CardHeader title='Editar Fase' />
      <CardContent sx={{ pt: theme => `${theme.spacing(3)} !important` }}>
        {isFecthing ? <CircularProgress sx={{ margin: 'auto', marginTop: 10 }} /> : (
          <form onSubmit={handleUpdatePeriods}>
            <Grid container spacing={7} marginBottom={4}>
              <Grid item xs={12} sm={6}>
                <TextField
                  onChange={handleChange('fecha_inicio')}
                  value={values.fecha_inicio}
                  fullWidth
                  focused
                  type="date"
                  label="Fecha de Inicio"
                  required
                />
              </Grid>

              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  onChange={handleChange('fecha_culminacion')}
                  value={values.fecha_culminacion}
                  type="date"
                  label="Fecha de Culminacion"
                />
              </Grid>

              {success && (
                <Grid item xs={12}>
                  <Alert color="success" icon={<Check/>}>
                    {success?.message}
                  </Alert>
                </Grid>
              )}
            </Grid>

            <Grid container direction="row-reverse">
                <Button variant='contained' type="submit">
                  Actualizar fase
                </Button>
                <Button type='reset' variant='outlined' color='secondary' onClick={handleReset} sx={{ mr: 3.5 }}>
                  Reiniciar
                </Button>
              </Grid>
          </form>
        )
        }
      </CardContent>
    </Card>
  )
}

export default UpdateEtapa;
