import { useRouter } from 'next/router';
import { useState, Fragment, useEffect } from 'react';
import Box from '@mui/material/Box';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';

import Divider from '@mui/material/Divider';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Alert from '@mui/material/Alert';
import CardHeader from '@mui/material/CardHeader';

import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Typography from '@mui/material/Typography';

import CardContent from '@mui/material/CardContent';
import TextField from '@mui/material/TextField';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableHead from '@mui/material/TableHead';

import TableRow from '@mui/material/TableRow';
import TableCell from '@mui/material/TableCell';
import TableBody from '@mui/material/TableBody';
import Check from 'mdi-material-ui/Check';
import DotsVertical from 'mdi-material-ui/DotsVertical';

import useApiClient from 'src/@core/hooks/useApiClient';
import { Chip, Select } from '@mui/material';
import dayjs from 'dayjs';
import { CircularProgress } from '@mui/material';
import { Pencil, PlusCircle, Delete } from 'mdi-material-ui';

const RegisterEtapas = () => {
  const statusObj = {
    applied: { color: 'info' },
    rejected: { color: 'error' },
    current: { color: 'primary' },
    resigned: { color: 'warning' },
    accepted: { color: 'success' }
  }
  
  const router = useRouter();
  const { id } = router.query;
  const [ success, setSuccess ] = useState(null);
  const apiClient = useApiClient();
  const [anchorEl, setAnchorEl] = useState(null)

  const [isFecthing, setIsFecthing] = useState(false);
  const [etapas, setEtapas] = useState([])
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [etapasTable, setEtapasTable] = useState([])

  const [values, setValues] = useState({
    periodo_name: '',
    fecha_inicio: '',
    fecha_culminacion: '',
    etapa_id: null
  });

  const setDate = (data) => {
    const periodData = data
    
    const formattedFechaInicio = periodData.split('T')[0];
    return formattedFechaInicio
  };

  useEffect(() => {
    if ( id ) {
      fetchOnePeriods();
      fetchAllEtapasTable();
      fetchAllEtapas();
    }
  }, [ id ]);

  const fetchOnePeriods = async () => {
    try {
      const response = await apiClient({
        method: 'post',
        url: '/periodos/getOnePeriods',
        data: {
          id: parseInt(id)
        }
      });
      
      if (response.data) {
        setValues(prev => {
          return {
            periodo_name: response.data.onePeriods.periodo_name,
            fecha_inicio: setDate(response.data.onePeriods.fecha_inicio),
            fecha_culminacion: setDate(response.data.onePeriods.fecha_culminacion),
          }
        })
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsFecthing(false);
    }
  };


  const fetchAllEtapas = async () => {
    try {
      const response = await apiClient({
        method: 'get',
        url: '/etapas/getAllEtapas',

      });
      
      
      if ( response.data ) {
        setEtapas(response.data.etapas)
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsFecthing(false);
    }
  };

  const fetchAllEtapasTable = async () => {
    try {
      const response = await apiClient({
        method: 'post',
        url: '/etapas/getAllEtapasTable',
        data: {
          id: parseInt(id)
        }

      });

      
      if (response.data) {
        setEtapasTable(response.data.etapas)
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsFecthing(false);
    }
  };

  const handleDropdownOpen = (event, userId) => {
    setAnchorEl(event.currentTarget);
    setSelectedUserId(userId);
  };

  const handleChange = prop => event => {
    setValues({
      ...values,
      [prop]: event.target.value
    });
  };

  const handleUpdateFase = async (event) => {
    event.preventDefault();

    try {
      const response = await apiClient.post('/etapas/registerEtapa', {
        periodo_id: parseInt(id),
        periodo_name: values.periodo_name,
        fecha_inicio: values.fecha_inicio,
        fecha_fin: values.fecha_culminacion,
        tipo_etapa_id: values.etapa_id
      });

      if ( response.data ) {
        setSuccess(response.data);
        setTimeout(() => {
          router.reload();
        }, 1500);
      }
    } catch (e) {
      console.log(e);
    } finally {

    }
  };

  const handleDropdownClose = url => {
    if (url) {
      router.push(url);
    }

    setAnchorEl(null);
  };

  const handleReset = () => {
    setValues(prev => {
      return {
        periodo_name: '',
        fecha_inicio: '',
        fecha_culminacion: '',
      }
    })
  };

  const handleExtenderEtapa = (id) =>{
    console.log(id)
    if (id) {
      router.push(`/dashboard/periods/etapas/update/${id}`);
    }
    setAnchorEl(null);
    setSelectedUserId(null);
  }

  return (
    <Card>
      <CardHeader title="Crear fase" />
      <CardContent sx={{ pt: theme => `${theme.spacing(3)} !important` }}>
        {isFecthing ? <CircularProgress sx={{ margin: 'auto', marginTop: 10 }} /> : (
          <form onSubmit={handleUpdateFase}>
            <Grid container spacing={7}>
              <Grid item xs={12} sm={6}>
                <TextField
                  focused
                  fullWidth
                  onChange={handleChange('fecha_inicio')}
                  value={values.fecha_inicio}
                  type="date"
                  label="Fecha de Inicio"
                  required={true}
                />
              </Grid>

              <Grid item xs={12} sm={6}>
                <TextField
                  onChange={handleChange('fecha_culminacion')}
                  value={values.fecha_culminacion}
                  fullWidth
                  type="date"
                  label="Fecha de Culminacion"
                  required={true}
                />
              </Grid>

              <Grid item xs={12} sm={3}>
                <FormControl fullWidth>
                  <InputLabel>Fase</InputLabel>
                  <Select
                    required
                    label="Fase"
                    value={values.etapa_id}
                    onChange={handleChange('etapa_id')}
                    placeholder="Fase 2"
                  >
                    {etapas.map((etapas, i) => (
                      <MenuItem key={i} value={etapas.id}>
                        {etapas.display_name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>

              {success && (
                <Grid item xs={12}>
                  <Alert color="success" icon={<Check/>}>
                    { success?.message }
                  </Alert>
                </Grid>
              )}

              <Grid item xs={12}>
                <Button
                  variant="contained"
                  type="submit"
                  sx={{ mr: 3.5 }}
                >
                  Registrar fase
                </Button>
                <Button
                  type="reset"
                  variant="outlined"
                  color="secondary"
                  onClick={handleReset}
                >
                  Reiniciar
                </Button>
              </Grid>
            </Grid>
          </form>
        )}
      </CardContent>

      
      <CardHeader title="Fases del periodo" />
      <CardContent sx={{ pt: theme => `${theme.spacing(3)} !important` }}>
        <Grid container>
          <Grid item xs={12}>
            {isFecthing ? <CircularProgress sx={{ margin: 'auto', marginTop: 10 }} /> : etapasTable.length > 0 ? (
              <TableContainer>
                <Table sx={{ minWidth: 800 }} aria-label='table in dashboard'>
                  <TableHead>
                    <TableRow>
                      <TableCell>Fase</TableCell>
                      <TableCell>Fecha de Inicio</TableCell>
                      <TableCell>Fecha de Culminacion</TableCell>
                      <TableCell>Estatus</TableCell>
                      <TableCell>Acciones</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {etapasTable.map((row, index) => (
                      <TableRow hover key={index} sx={{ '&:last-of-type td, &:last-of-type th': { border: 0 } }}>
                        <TableCell>{row.tipo_etapa.display_name}</TableCell>
                        <TableCell>{dayjs(row.fecha_inicio).format('DD/MM/YYYY')}</TableCell>
                        <TableCell>{dayjs(row.fecha_fin).format('DD/MM/YYYY')}</TableCell>
                        <TableCell>
                          <Chip
                            label={( row.status === 0 && "Inactivo" ) || ( row.status === 1 && "Activo" ) || ( row.status === 2 && "Culminado" )}
                            color={( row.status === 0 && "error" ) || ( row.status === 1 && "primary" ) || ( row.status === 2 && "success" )}
                            sx={{
                              height: 24,
                              fontSize: '0.75rem',
                              textTransform: 'capitalize',
                              '& .MuiChip-label': { fontWeight: 500 }
                            }}
                          />
                        </TableCell>
                        <TableCell>
                          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                            <Fragment>
                              <IconButton size='small' onClick={(event) => handleDropdownOpen(event, row.id)} aria-label='settings' sx={{ width: 40, height: 40, color: 'text.secondary' }}>
                                <DotsVertical />
                              </IconButton>
                              <Menu
                                anchorEl={anchorEl}
                                open={Boolean(anchorEl) && selectedUserId === row.id}
                                onClose={() => handleDropdownClose()}
                                sx={{ '& .MuiMenu-paper': { width: 170, marginTop: 10 } }}
                                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                                transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                              >
                                <MenuItem sx={{ py: 1 }} onClick={() => handleExtenderEtapa(row.id)}>
                                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <PlusCircle />
                                    <Typography variant="body2" sx={{ ml: 1 }}>
                                      Extender / Reducir
                                    </Typography>
                                  </Box>
                                </MenuItem>
                                
                              </Menu>
                            </Fragment>
                          </Box>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            ) : (
              <Typography align="center" variant="body1">
                No existen fases registradas para este periodo
              </Typography>
            )}
          </Grid>
        </Grid>
      </CardContent>

    </Card>
  )
}

export default RegisterEtapas;
