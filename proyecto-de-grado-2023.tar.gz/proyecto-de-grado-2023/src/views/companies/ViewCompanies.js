"use client";

import { useState, useEffect, useCallback, Fragment } from 'react';
import { useRouter } from 'next/router';
import useApiClient from 'src/@core/hooks/useApiClient';
import _ from 'lodash'; 

// ** MUI Imports
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';
import Grid from '@mui/material/Grid';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import TextField from '@mui/material/TextField';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Divider from '@mui/material/Divider';
import TableContainer from '@mui/material/TableContainer';
import TablePagination from '@mui/material/TablePagination';
import Table from '@mui/material/Table';
import TableHead from '@mui/material/TableHead';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import TableFooter from '@mui/material/TableFooter';
import { styled } from '@mui/material/styles';
import Modal from '@mui/material/Modal';

// ** Icons Imports
import DotsVertical from 'mdi-material-ui/DotsVertical';
import Eye from 'mdi-material-ui/Eye';
import Pencil from 'mdi-material-ui/Pencil';
import Delete from 'mdi-material-ui/Delete';

const DeleteMenuItem = styled(MenuItem)(({ theme }) => ({
  '&:hover': {
    backgroundColor: 'red',
    color: 'white'
  },
  '&:hover *': {
    color: 'white'
  }
}));

function ViewCompanies() {
  
  const router = useRouter();
  const apiClient = useApiClient();
  const [ anchorEl, setAnchorEl ] = useState(null);
  const [ selectedRowId, setSelectedRowId ] = useState(null);
  const [ isFecthing, setIsFecthing ] = useState(true);
  const [ error, setError ] = useState(null);
  const [ companies, setCompanies ] = useState([]);
  const [ openModal, setOpenModal ] = useState(false);

  useEffect(() => {
    fetchCompanies();
  }, []);

  const fetchCompanies = async () => {
    try {
      const response = await apiClient.get('/empresa/getAllEmpresas');

      if ( response.data ) {
        setCompanies(response.data.empresas);
        setIsFecthing(false);
      }
    } catch (e) {
      setError({ message: 'Error al buscar empresas' })
    } finally {
      setIsFecthing(false);
    }
  };

  const refetchCompanies = () => {
    setIsFecthing(true);
    fetchCompanies();
  };

  const handleDropdownOpen = (event, rowId) => {
    setAnchorEl(event.currentTarget);
    setSelectedRowId(rowId);
  };

  const handleDropdownClose = () => {
    // console.log(id)
    // if ( id ) {
    //   router.push(`/dashboard/tutors/academic/edit/${id}`);
    // }

    setAnchorEl(null);
    setSelectedRowId(null);
  };

  const filterCompanies = useCallback((event) => {
    
  }, []);

  const handleConfirmDelete = async ( id ) => {
    if ( confirm('Esta seguro que desea eliminar esta empresa?') ) {
      // Verificar si el tutor no tiene registros de tutoria previos
      // con otros estudiantes, si no los tiene, el tutor se puede eliminar
      // caso contrario se deniega el borrado para mantener la consistencia
      // de la data en la db.
      try {
        const response = await apiClient.delete(`/empresa/deleteOneEmpresa?id=${id}`);

        if ( response.data ) {
          alert(`Empresa '${response.data.nombre_empresa}' eliminada exitosamente`);
        }
      } catch ( err ) {
        alert(`Ha ocurrido un error al eliminar la empresa: ${companies[ _.findIndex(companies, company => company.id === id) ].nombre_empresa}`);
      } finally {
        refetchCompanies();
      }
    }
  };

  return (
    <Card>
      <CardHeader title="Listado de Empresas"/>
      <CardContent sx={{ pt: theme => `${theme.spacing(3)} !important` }}>
        <Grid container direction="row-reverse" marginTop={4.8}>
          <Grid item>
            <TextField sx={{ mr: 4 }} size="small" onChange={filterCompanies} label="Buscar empresa"/>
            <Button variant="contained" onClick={() => router.push('/dashboard/companies/create')}>
              Crear empresa
            </Button>
          </Grid>
        </Grid>
        <Grid container>
          <Grid item xs={12} marginTop={2}>
            {isFecthing ? <CircularProgress sx={{ margin: 'auto', marginTop: 10 }}/> : companies.length > 0 ? (
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow>
                      {/* <TableCell>ID</TableCell> */}
                      <TableCell>Nombre</TableCell>
                      <TableCell>Rif</TableCell>
                      <TableCell>Direccion</TableCell>
                      <TableCell>Acciones</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {companies.map((company, i) => (
                      <TableRow hover key={i} sx={{ '&:last-of-type td, &:last-of-type th': { border: 0 } }}>
                        {/* <TableCell>{company.id}</TableCell> */}
                        <TableCell sx={{ py: theme => `${theme.spacing(0.5)} !important` }}>
                          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                            <Typography sx={{ fontWeight: 500, fontSize: '0.875rem !important' }}>{company.nombre_empresa}</Typography>
                            {/* <Typography variant='caption'>{company.designation}</Typography> */}
                          </Box>
                        </TableCell>
                        <TableCell>{company.rif}</TableCell>
                        <TableCell>{company.direccion}</TableCell>
                        <TableCell>
                          <Fragment>
                            <IconButton size='small' onClick={event => handleDropdownOpen(event, company.id)} aria-label='settings' sx={{ width: 40, height: 40, color: 'text.secondary' }}>
                              <DotsVertical/>
                            </IconButton>
                            <Menu
                              anchorEl={anchorEl}
                              open={Boolean(anchorEl) && selectedRowId === company.id}
                              onClose={handleDropdownClose}
                              sx={{ '& .MuiMenu-paper': { width: 170, marginTop: 10 } }}
                              anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                              transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                            >
                              <MenuItem sx={{ py: 1 }} onClick={() => setOpenModal(!openModal)}>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Eye/>
                                  <Typography variant="body2" sx={{ ml: 1 }}>
                                    Ver detalles
                                  </Typography>
                                </Box>
                              </MenuItem>
                              <Divider />
                              <MenuItem sx={{ py: 1 }} onClick={() => router.push(`/dashboard/companies/${company.id}`)}>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Pencil/>
                                  <Typography variant="body2" sx={{ ml: 1 }}>
                                    Editar
                                  </Typography>
                                </Box>
                              </MenuItem>
                              <DeleteMenuItem sx={{ py: 1 }} onClick={() => handleConfirmDelete(company.id)}>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Delete/>
                                  <Typography variant="body2" sx={{ ml: 1 }}>
                                    Borrar
                                  </Typography>
                                </Box>
                              </DeleteMenuItem>
                            </Menu>
                          </Fragment>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                  {/* <TableFooter>
                    <TablePagination
                      rowsPerPageOptions={[5, 10, 25, { label: 'All', value: -1 }]}
                      colSpan={4}
                      count={companies.length}
                      // rowsPerPage={rowsPerPage}
                      // page={page}
                      slotProps={{
                        select: {
                          inputProps: {
                            'aria-label': 'rows per page',
                          },
                          native: true,
                        },
                      }}
                      // onPageChange={handleChangePage}
                      // onRowsPerPageChange={handleChangeRowsPerPage}
                      // ActionsComponent={TablePaginationActions}
                    />
                  </TableFooter> */}
                </Table>
              </TableContainer>
            ) : (
              <Typography align="center" variant="body1">
                No existen empresas registradas
              </Typography>
            )}
          </Grid>
        </Grid>
      </CardContent>
      <Modal
        open={openModal}
        onClose={() => setOpenModal(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Card sx={{ width: '400px', margin: 'auto', marginTop: 40 }}>
          <CardContent>
            <Box>
              <Typography id="modal-modal-title" variant="h6" component="h2">
                Detalles de la empresa
              </Typography>
              <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                Nombre: Morrocel C.A
              </Typography>
            </Box>
          </CardContent>
        </Card>
      </Modal>
    </Card>
  );
}

export default ViewCompanies;
