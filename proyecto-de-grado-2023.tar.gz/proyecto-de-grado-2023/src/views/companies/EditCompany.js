// ** next
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import useApiClient from 'src/@core/hooks/useApiClient';

// ** MUI Imports
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Alert from '@mui/material/Alert';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';

// ** MUI Icons
import Check from 'mdi-material-ui/Check';

const CreateCompany = () => {

  const apiClient = useApiClient();
  const router = useRouter();
  const { id } = router.query;
  
  const [ submitting, setSubmitting ] = useState(false);
  const [ success, setSuccess ] = useState(null);
  
  const [ values, setValues ] = useState({
    name: '',
    rif: '',
    address: '',
  });

  const [ errorTypes, setErrorTypes ] = useState({
    'FORM_FIELD_WRONG_RIF': false,
    'FORM_FIELD_DUPLICATED_RIF': false
  });

  useEffect(() => {
    if ( id ) {
      fetchOneCompany(id);
    }
  }, [ id ]);

  const fetchOneCompany = async (id) => {
    try {
      const response = await apiClient.get(`/empresa/getOneEmpresa?id=${id}`);

      if ( response.data ) {
        setValues({
          name: response.data.nombre_empresa,
          rif: response.data.rif,
          address: response.data.direccion
        });
      }
    } catch ( err ) {
      console.log(err);
    } finally {

    }
  };

  const handleChange = prop => event => {
    setValues({
      ...values,
      [prop]: event.target.value
    });
  };

  const handleCreateCompany = async (event) => {
    event.preventDefault();
    setSubmitting(true);

    try {
      const response = await apiClient.put(`/empresa/updateEmpresa?id=${id}`, {
        empresa_name: values.name,
        rif: values.rif,
        direccion: values.address
      });

      if ( response.data ) {
        setSuccess(response.data);
        setValues({
          name: '',
          rif: '',
          address: '',
        });
        setErrorTypes({
          'FORM_FIELD_WRONG_RIF': false,
          'FORM_FIELD_DUPLICATED_RIF': false
        });
      }
    } catch (err) {
      console.log(err.response.data);
      setErrorTypes({
        ...errorTypes,
        [err.response.data.type]: true
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleFormReset = (event) => {
    setValues({
      firstname: '',
      lastname: '',
      email: '',
      phoneNumber: '',
    });
    setErrorTypes({
      'FORM_FIELD_WRONG_RIF': false,
      'FORM_FIELD_DUPLICATED_RIF': false
    });
  };

  return (
    <Card>
      <CardHeader title='Registrar Empresa' />
      <CardContent sx={{ pt: theme => `${theme.spacing(3)} !important` }}>
        <form onSubmit={handleCreateCompany}>
          <Grid container spacing={7} sx={{ mb: 4 }}>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                onChange={handleChange('name')}
                value={values.name}
                label="Nombre de empresa"
                placeholder="Morrocel C.A"
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                error={errorTypes['FORM_FIELD_WRONG_RIF'] || errorTypes['FORM_FIELD_DUPLICATED_RIF']}
                onChange={handleChange('rif')}
                value={values.rif}
                label="RIF"
                placeholder="J-1234568"
                {...(errorTypes['FORM_FIELD_WRONG_RIF'] || errorTypes['FORM_FIELD_DUPLICATED_RIF']) && ({sx: { mb: 2 } })}
              />
              {(errorTypes['FORM_FIELD_WRONG_RIF'] || errorTypes['FORM_FIELD_DUPLICATED_RIF']) && (
                <Box
                  sx={{
                    mb: 4,
                    display: 'flex',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                    justifyContent: 'space-between'
                  }}
                >
                  {errorTypes['FORM_FIELD_WRONG_RIF'] && (
                    <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                      El RIF es invalido
                    </Typography>
                  )}

                  {errorTypes['FORM_FIELD_DUPLICATED_RIF'] && (
                    <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                      El RIF ya existe para otra empresa
                    </Typography>
                  )}
                </Box>
              )}
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                value={values.address}
                onChange={handleChange('address')}
                label="Dirección"
                placeholder="Av. Bolivar"
              />
            </Grid>

            {success && (
              <Grid item xs={12}>
                <Alert color="success" icon={<Check/>}>
                  {success?.message}
                </Alert>
              </Grid>
            )}

          </Grid>

          <Grid container direction="row-reverse">
            <Button
              type="submit"
              variant="contained"
              {...(
                !values.name
                || !values.rif
                || !values.address
                || errorTypes['FORM_FIELD_WRONG_EMAIL']
                ? { disabled: true }
                : null
              )}
            >
              Crear empresa
            </Button>
            <Button
              type="reset"
              variant="outlined"
              color="secondary"
              onClick={handleFormReset}
              sx={{ mr: 3.5 }}
            >
              Reiniciar
            </Button>
          </Grid>
        </form>
      </CardContent>
    </Card>
  );
}

export default CreateCompany;
