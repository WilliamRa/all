"use client";

import { useState, useEffect, Fragment } from 'react';
import { useRouter } from 'next/router';
import useApiClient from 'src/@core/hooks/useApiClient';
import _ from 'lodash'; 


import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';
import Grid from '@mui/material/Grid';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import TextField from '@mui/material/TextField';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Divider from '@mui/material/Divider';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableHead from '@mui/material/TableHead';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';

import { styled } from '@mui/material/styles';

import DotsVertical from 'mdi-material-ui/DotsVertical';
import Eye from 'mdi-material-ui/Eye';
import Pencil from 'mdi-material-ui/Pencil';
import Delete from 'mdi-material-ui/Delete';

const _tutors = [
  {
    id: 1,
    firstname: 'Luis',
    lastname: 'Mujica',
    email: 'luis-m@example.com',
    phone_number: '+584124390325',
  },
  {
    id: 2,
    firstname: 'Luis',
    lastname: 'Mujica',
    email: 'luis-m@example.com',
    phone_number: '+584124390325',
  },
  {
    id: 3,
    firstname: 'Luis',
    lastname: 'Mujica',
    email: 'luis-m@example.com',
    phone_number: '+584124390325',
  },
  {
    id: 4,
    firstname: 'Luis',
    lastname: 'Mujica',
    email: 'luis-m@example.com',
    phone_number: '+584124390325',
  },
  {
    id: 5,
    firstname: 'Luis',
    lastname: 'Mujica',
    email: 'luis-m@example.com',
    phone_number: '+584124390325',
  },
  {
    id: 6,
    firstname: 'Luis',
    lastname: 'Mujica',
    email: 'luis-m@example.com',
    phone_number: '+584124390325',
  },
  {
    id: 7,
    firstname: 'Luis',
    lastname: 'Mujica',
    email: 'luis-m@example.com',
    phone_number: '+584124390325',
  },
];

const DeleteMenuItem = styled(MenuItem)(({ theme }) => ({
  '&:hover': {
    backgroundColor: 'red',
    color: 'white'
  },
  '&:hover *': {
    color: 'white'
  }
}));

function ViewAcademicTutors() {

  const router = useRouter();
  const apiClient = useApiClient();
  
  const [ anchorEl, setAnchorEl ] = useState(null);
  const [ selectedRowId, setSelectedRowId ] = useState(null);
  const [ isFecthing, setIsFecthing ] = useState(true);
  const [ error, setError ] = useState(null);
  const [ tutors, setTutors ] = useState([]);

  useEffect(() => {
    fetchAcademicTutors();
  }, []);

  const fetchAcademicTutors = async () => {
    try {
      const response = await apiClient.get('/tutors/academico/getAllTutoresAcademicos')

      if ( response.data ) {
        setTutors(response.data.tutoresAcademicos);
        setIsFecthing(false);
      }
    } catch ( err ) {
      setError({ message: 'Error al buscar tutores' })
    } finally {
      setIsFecthing(false);
    }
  };

  const refetchAcademicTutors = () => {
    setIsFecthing(true);
    fetchAcademicTutors();
  };

  const handleDropdownOpen = (event, rowId) => {
    setAnchorEl(event.currentTarget);
    setSelectedRowId(rowId);
  };

  const handleDropdownClose = () => {

    setAnchorEl(null);
    setSelectedRowId(null);
  };

  const handleConfirmDelete = async ( id ) => {
    if ( confirm('Esta seguro que desea eliminar a este Tutor?') ) {
    
      try {
        const response = await apiClient.delete(`/tutors/academico/deleteOneTutorAcademico?id=${id}`);

        if ( response.data ) {
          alert(`Tutor '${response.data.firstname} ${response.data.lastname}' eliminado exitosamente`);
        }
      } catch ( err ) {
        alert(`Ha ocurrido un error al eliminar el tutor: ${tutors[ _.findIndex(tutors, tutor => tutor.id === id) ].firstname} ${tutors[ _.findIndex(tutors, tutor => tutor.id === id) ].lastname}`);
      } finally {
        refetchAcademicTutors();
      }
    }
  };

  return (
    <Card>
      <CardHeader title="Tutores academicos"/>
      <CardContent>
        <Grid container direction="row-reverse" sx={{ mt: 4.8}}>
          <Grid item>
            <TextField sx={{ mr: 4 }} size="small" onChange={() => void 0} label="Buscar Tutores"/>
            <Button variant="contained" onClick={() => router.push('/dashboard/tutors/academic/create')}>
              Crear Tutor
            </Button>
          </Grid>
        </Grid>
        <Grid container>
          <Grid item xs={12} marginTop={2}>
            {isFecthing ? <CircularProgress sx={{ margin: 'auto', marginTop: 10 }} /> : tutors.length > 0 ? (
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow>

                      <TableCell>Nombre y Apellido</TableCell>
                      <TableCell>Correo</TableCell>
                      <TableCell>Telefono</TableCell>
                      <TableCell>Acciones</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {tutors.map((tutor, i) => (
                      <TableRow hover key={i} sx={{ '&:last-of-type td, &:last-of-type th': { border: 0 } }}>
                      
                        <TableCell>
                          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                            <Typography sx={{ fontWeight: 500, fontSize: '0.875rem !important' }}>{tutor.firstname} {tutor.lastname}</Typography>

                          </Box>
                        </TableCell>
                        <TableCell>{tutor.email}</TableCell>
                        <TableCell>{tutor.phone_number}</TableCell>
                        <TableCell>
                          <Fragment>
                            <IconButton size='small' onClick={event => handleDropdownOpen(event, tutor.id)} aria-label='settings' sx={{ width: 40, height: 40, color: 'text.secondary' }}>
                              <DotsVertical/>
                            </IconButton>
                            <Menu
                              anchorEl={anchorEl}
                              open={Boolean(anchorEl) && selectedRowId === tutor.id}
                              onClose={handleDropdownClose}
                              sx={{ '& .MuiMenu-paper': { width: 170, marginTop: 10 } }}
                              anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                              transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                            >

                              <MenuItem sx={{ py: 1 }} onClick={() => router.push(`/dashboard/tutors/academic/${tutor.id}`)}>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Pencil/>
                                  <Typography variant="body2" sx={{ ml: 1 }}>
                                    Editar
                                  </Typography>
                                </Box>
                              </MenuItem>
                              <DeleteMenuItem sx={{ py: 1 }} onClick={() => handleConfirmDelete(tutor.id)}>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Delete/>
                                  <Typography variant="body2" sx={{ ml: 1 }}>
                                    Borrar
                                  </Typography>
                                </Box>
                              </DeleteMenuItem>
                            </Menu>
                          </Fragment>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            ) : (
              <Typography align="center" variant="body1">
                No existen tutores academicos registrados
              </Typography>
            )}
          </Grid>
        </Grid>
      </CardContent>
    </Card>
  );
}

export default ViewAcademicTutors;
