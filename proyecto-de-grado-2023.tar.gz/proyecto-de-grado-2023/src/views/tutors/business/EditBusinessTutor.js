import { useState, useEffect } from 'react';
import useApiClient from 'src/@core/hooks/useApiClient';
import { useRouter } from 'next/router';

import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Alert from '@mui/material/Alert';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';

import Check from 'mdi-material-ui/Check';

const emailRegExp = /^(([^<>()\[\]\\.,;:\s@\"]+(\.[^<>()\[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

function EditAcademicTutor() {

  const apiClient = useApiClient();
  const router = useRouter();
  const { id } = router.query;

  const [ submitting, setSubmitting ] = useState(false);
  const [ success, setSuccess ] = useState(null);
  const [ error, setError ] = useState(null);
  const [ companies, setCompanies ] = useState([]);

  const [ values, setValues ] = useState({
    firstname: '',
    lastname: '',
    email: '',
    phoneNumber: '',
    empresa: null
  });

  const [ errorTypes, setErrorTypes ] = useState({
    'FORM_FIELD_WRONG_EMAIL': false,
    'FORM_FIELD_WRONG_PHONE_NUMBER': false,
    'FORM_FIELD_DUPLICATED_EMAIL': false
  });

  useEffect(() => {
    if ( id ) {
      fetchOneBusinessTutor(id);
    }
    fetchCompanies();
  }, [ id ]);

  const fetchOneBusinessTutor = async (id) => {
    try {
      const response = await apiClient.get(`/tutors/empresarial/getOneTutorEmpresarial?id=${id}`);

      if ( response.data ) {
        setValues({
          firstname: response.data.firstname,
          lastname: response.data.lastname,
          email: response.data.email,
          phoneNumber: response.data.phone_number,
          empresa: response.data.empresa_id
        });
      }
    } catch ( err ) {
      console.log(err);
    } finally {

    }
  };

  const fetchCompanies = async () => {
    try {
      const response = await apiClient.get('/empresa/getAllEmpresas');

      if ( response.data ) {
        setCompanies(response.data.empresas);
      }
    } catch ( err ) {

    } finally {

    }
  };

  const handleChange = prop => event => {
    // if ( prop === 'email' ) {
    //   if ( emailRegExp.test(event.target.value) ) {
    //     setValues({
    //       ...values,
    //       [prop]: event.target.value
    //     });
    //   } else {
    //     if ( event.target.value === '' ) {
    //       setErrorTypes({
    //         ...errorTypes,
    //         FORM_FIELD_WRONG_EMAIL: false
    //       });
    //       setValues({
    //         ...values,
    //         [prop]: event.target.value
    //       });
    //       return;
    //     }

    //     setErrorTypes({
    //       ...errorTypes,
    //       FORM_FIELD_WRONG_EMAIL: true
    //     });
    //     setValues({
    //       ...values,
    //       [prop]: event.target.value
    //     });
    //     return;
    //   }
    // }

    setValues({
      ...values,
      [prop]: event.target.value
    })
  };

  const handleFormReset = (event) => {
    setValues({
      firstname: '',
      lastname: '',
      email: '',
      phoneNumber: '',
      empresa: null
    });
    
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSubmitting(true);
    
    try {
      const response = await apiClient.put(`/tutors/empresarial/updateTutorEmpresarial?id=${id}`, {
        firstname: values.firstname,
        lastname: values.lastname,
        email: values.email,
        phoneNumber: values.phoneNumber,
        empresa: values.empresa
      });

      if ( response.data ) {
        setSuccess(response.data);
        setValues({
          firstname: '',
          lastname: '',
          email: '',
          phoneNumber: '',
          empresa: null
        });
      }

    } catch ( err ) {
      console.log(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card>
      <CardHeader title="Actualizar Tutor Empresarial"/>
      <CardContent>
        <form onSubmit={handleSubmit}>
          
          <Grid container spacing={7} sx={{ mb: 4 }}>

            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                value={values.firstname}
                onChange={handleChange('firstname')}
                type="text"
                label="Nombre"
                placeholder="Jhon"
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                value={values.lastname}
                onChange={handleChange('lastname')}
                type="text"
                label="Apellido"
                placeholder="Doe"
              />
            </Grid>
            
            <Grid item xs={12} sm={4}>
              <TextField
                required
                fullWidth
                value={values.email}
                error={errorTypes['FORM_FIELD_WRONG_EMAIL'] || errorTypes['FORM_FIELD_DUPLICATED_EMAIL']}
                onChange={handleChange('email')}
                type="email"
                label="Correo electronico"
                placeholder="jhondoe@example.com"
                {...(errorTypes['FORM_FIELD_WRONG_EMAIL'] || errorTypes['FORM_FIELD_DUPLICATED_EMAIL']) && ({sx: { mb: 2 } })}
              />
              {(errorTypes['FORM_FIELD_WRONG_EMAIL'] || errorTypes['FORM_FIELD_DUPLICATED_EMAIL']) && (
                <Box
                  sx={{
                    mb: 4,
                    display: 'flex',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                    justifyContent: 'space-between'
                  }}
                >
                  {errorTypes['FORM_FIELD_WRONG_EMAIL'] && (
                    <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                      El correo electronico es invalido
                    </Typography>
                  )}

                  {errorTypes['FORM_FIELD_DUPLICATED_EMAIL'] && (
                    <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                      El correo electronico ya existe
                    </Typography>
                  )}
                </Box>
              )}
            </Grid>

            <Grid item xs={12} sm={4}>
              <TextField
                required
                fullWidth
                value={values.phoneNumber}
                onChange={handleChange('phoneNumber')}
                type="tel"
                label="Numero de telefono"
                placeholder="(+58)4124390325, 04124390325"
              />
            </Grid>

            <Grid item xs={12} sm={4}>
              <FormControl fullWidth>
                <InputLabel>Empresa</InputLabel>
                <Select
                  required
                  label="Empresa"
                  value={values.empresa}
                  onChange={handleChange('empresa')}
                  placeholder="El Negocio C.A"
                >
                  {companies.map((company, i) => (
                    <MenuItem key={i} value={company.id}>
                      {company.nombre_empresa}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            {success && (
              <Grid item xs={12}>
                <Alert color="success" icon={<Check/>}>
                  {success?.message}
                </Alert>
              </Grid>
            )}

          </Grid>
          
          <Grid container direction="row-reverse">
            <Button
              type="submit"
              variant="contained"
              {...(
                !values.firstname
                || !values.lastname
                || !values.email
                || !values.phoneNumber
                || !values.empresa
                || errorTypes['FORM_FIELD_WRONG_EMAIL']
                ? { disabled: true }
                : null
              )}
            >
              Crear Tutor
            </Button>
            <Button
              type="reset"
              variant="outlined"
              color="secondary"
              onClick={handleFormReset}
              sx={{ mr: 3.5 }}
            >
              Reiniciar
            </Button>
          </Grid>
        </form>
      </CardContent>
    </Card>
  );
}

export default EditAcademicTutor;
