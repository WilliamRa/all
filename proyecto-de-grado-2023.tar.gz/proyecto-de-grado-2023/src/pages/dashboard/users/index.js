// ** React Imports
import { useState } from 'react'

// ** MUI Imports
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

// ** Demo Components Imports
import ViewUsers from 'src/views/users/ViewUsers';

const UsersPage = () => {
  // ** State
  const [value, setValue] = useState('account')

  const handleChange = (event, newValue) => {
    setValue(newValue)
  }

  return (
    <Box>
      <Grid container spacing={6}>
        <Grid item xs={12} md={12}>
          <ViewUsers />
        </Grid>
      </Grid>
    </Box>
  )
}

export default UsersPage
