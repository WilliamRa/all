// ** MUI Imports
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

// ** Demo Components Imports
import EditUser from 'src/views/users/EditUser';

const EditUserPage = () => {
  return (
    <Box>
      <Grid container spacing={6}>
        <Grid item xs={12} md={12}>
          <EditUser />
        </Grid>
      </Grid>
    </Box>
  );
}

export default EditUserPage;
