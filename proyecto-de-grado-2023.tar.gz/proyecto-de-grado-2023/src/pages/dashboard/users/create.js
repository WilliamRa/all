// ** MUI Imports
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

// ** Demo Components Imports
import CreateUser from 'src/views/users/CreateUser';

const CreateUserPage = () => {
  return (
    <Box>
      <Grid container spacing={6}>
        <Grid item xs={12} md={12}>
          <CreateUser />
        </Grid>
      </Grid>
    </Box>
  );
}

export default CreateUserPage;
