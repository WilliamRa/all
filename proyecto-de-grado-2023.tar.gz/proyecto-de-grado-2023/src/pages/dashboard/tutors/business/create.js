// ** MUI Imports
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

// ** Demo Components Imports
import RegisterBusinessTutor from 'src/views/tutors/business/RegisterBusinessTutor';

function CreateBusinessTutorsPage() {
  return (
    <Box>
      <Grid container >
        <Grid item xs={12} md={12}>
          <RegisterBusinessTutor />
        </Grid>
      </Grid>
    </Box>
  );
}

export default CreateBusinessTutorsPage;
