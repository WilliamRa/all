import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

import ViewBusinessTutors from 'src/views/tutors/business/ViewBusinessTutors';

function BusinessTutorsPage() {
  return (
    <Box>
      <Grid container spacing={6}>
        <Grid item xs={12} md={12}>
          <ViewBusinessTutors/>
        </Grid>
      </Grid>
    </Box>
  );
}

export default BusinessTutorsPage;
