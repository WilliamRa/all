import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

import ViewAcademicTutors from 'src/views/tutors/academic/ViewAcademicTutors';

function AcademicTutorsPage() {
  return (
    <Box>
      <Grid container spacing={6}>
        <Grid item xs={12} md={12}>
          <ViewAcademicTutors/>
        </Grid>
      </Grid>
    </Box>
  );
}

export default AcademicTutorsPage;
