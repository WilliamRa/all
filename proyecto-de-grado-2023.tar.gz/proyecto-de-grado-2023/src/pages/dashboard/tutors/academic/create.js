// ** MUI Imports
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

// ** Demo Components Imports
import RegisterAcademicTutor from 'src/views/tutors/academic/RegisterAcademicTutor';

function CreateAcademicTutorsPage() {
  return (
    <Box>
      <Grid container >
        <Grid item xs={12} md={12}>
          <RegisterAcademicTutor />
        </Grid>
      </Grid>
    </Box>
  );
}

export default CreateAcademicTutorsPage;
