// ** MUI Imports
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

// ** Demo Components Imports
import UpdateDocument from 'src/views/documents/UpdateDocument';
import AsignarNotas from 'src/views/projects/notas/AsignarNotas';

const NotasPage = () => {
  return (
    <Box>
      <Grid container >
        <Grid item xs={12} md={12}>
          <AsignarNotas />
        </Grid>
      </Grid>
    </Box>
  );
}

export default NotasPage;
