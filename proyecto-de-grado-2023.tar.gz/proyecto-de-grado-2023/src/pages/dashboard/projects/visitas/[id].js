// ** MUI Imports
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

// ** Demo Components Imports
import ViewVisitas from 'src/views/projects/visitas/ViewVisitas';

function AsignarTutoresPage() {
  return (
    <Box>
      <Grid container >
        <Grid item xs={12} md={12}>
          <ViewVisitas />
        </Grid>
      </Grid>
    </Box>
  );
}

export default AsignarTutoresPage;
