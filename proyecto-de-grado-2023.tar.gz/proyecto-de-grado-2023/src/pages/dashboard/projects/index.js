// ** MUI Imports
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

// ** Demo Components Imports
import ViewProjects from 'src/views/projects/ViewProjects';

const ProjectsPage = () => {
  return (
    <Box>
      <Grid container spacing={6}>
        <Grid item xs={12} md={12}>
          <ViewProjects />
        </Grid>
      </Grid>
    </Box>
  )
}

export default ProjectsPage;
