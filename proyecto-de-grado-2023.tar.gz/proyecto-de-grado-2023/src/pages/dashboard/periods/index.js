
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';


import ViewPeriods from '../../../views/periods/ViewsPeriods';

const PeriodsPage = () => {
  return (
    <Box>
      <Grid container spacing={6}>
        <Grid item xs={12} md={12}>
          <ViewPeriods />
        </Grid>
      </Grid>
    </Box>
  );
}

export default PeriodsPage;
