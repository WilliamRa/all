
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';


import UpdateEtapa from 'src/views/etapas/UpdateEtapa';

const UpdateFasesPage = () => {
  return (
    <Box>
      <Grid container spacing={6}>
        <Grid item xs={12} md={12}>
          <UpdateEtapa />
        </Grid>
      </Grid>
    </Box>
  )
}

export default UpdateFasesPage;
