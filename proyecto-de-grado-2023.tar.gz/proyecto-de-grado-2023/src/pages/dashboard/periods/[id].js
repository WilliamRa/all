
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';


import EditPeriods from 'src/views/periods/EditPeriods';

const UpdatePeriodsPage = () => {
  return (
    <Box>
      <Grid container spacing={6}>
        <Grid item xs={12} md={12}>
          <EditPeriods />
        </Grid>
      </Grid>
    </Box>
  )
}

export default UpdatePeriodsPage;
