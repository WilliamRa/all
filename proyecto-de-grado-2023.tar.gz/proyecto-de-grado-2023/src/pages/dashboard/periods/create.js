
import Grid from '@mui/material/Grid';
import ApexChartWrapper from 'src/@core/styles/libs/react-apexcharts';

import CreatePeriods from 'src/views/periods/CreatePeriods';

const CreateCompaniesPage = () => {
  return (
    <ApexChartWrapper>
      <Grid container spacing={6}>
        <Grid item xs={12} md={12}>
          <CreatePeriods />
        </Grid>
      </Grid>
    </ApexChartWrapper>
  )
}

export default CreateCompaniesPage;
