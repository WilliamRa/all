// ** MUI Imports
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

// ** Demo Components Imports
import EditCompany from 'src/views/companies/EditCompany';

function EditAcademicTutorsPage() {
  return (
    <Box>
      <Grid container >
        <Grid item xs={12} md={12}>
          <EditCompany/>
        </Grid>
      </Grid>
    </Box>
  );
}

export default EditAcademicTutorsPage;
