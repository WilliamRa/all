// ** MUI Imports
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

// ** Demo Components Imports
import ViewCompanies from 'src/views/companies/ViewCompanies';

const CompaniesPage = () => {
  return (
    <Box>
      <Grid container spacing={6}>
        <Grid item xs={12} md={12}>
          <ViewCompanies />
        </Grid>
      </Grid>
    </Box>
  );
}

export default CompaniesPage;
