// ** MUI Imports
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

// ** Demo Components Imports
import RegisterCompany from 'src/views/companies/RegisterCompany';

const CreateCompaniesPage = () => {
  return (
    <Box>
      <Grid container spacing={6}>
        <Grid item xs={12} md={12}>
          <RegisterCompany/>
        </Grid>
      </Grid>
    </Box>
  );
}

export default CreateCompaniesPage;
