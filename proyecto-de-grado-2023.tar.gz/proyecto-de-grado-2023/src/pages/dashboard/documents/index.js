import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

import { useSession } from 'next-auth/react';
import ViewDocuments from 'src/views/documents/ViewDocuments';
import RegisterDocumentsCopy from '../../../views/documents/RegisterDocumentsCopy';

function DocumentsPage() {

  const { data: session } = useSession();

  return (
    <Box>
      <Grid container spacing={6}>
        <Grid item xs={12}>
          {session?.user.name?.role_id === 1 && <ViewDocuments />}

          {session?.user.name?.role_id === 3 && <RegisterDocumentsCopy />}
        </Grid>
      </Grid>
    </Box>
  );
}

export default DocumentsPage;
