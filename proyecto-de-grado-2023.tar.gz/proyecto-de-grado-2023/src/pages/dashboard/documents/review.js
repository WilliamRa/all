// ** 
import Link from 'next/link';

import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardHeader from '@mui/material/CardHeader';
import Typography from '@mui/material/Typography';

function ReviewDocumentsPage() {
    return (
      <Card>
        <CardHeader title="Revision de solicitud"/>
        <CardContent>
          <Grid container>
            <Grid item xs={23}>
              <Box>
                <Typography variant="body1">
                  Revision
                </Typography>
              </Box>
            </Grid>
          </Grid>
        </CardContent>
      </Card>      
    );
}

export default ReviewDocumentsPage;
