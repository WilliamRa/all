// ** React Imports
import { useLayoutEffect, useState } from 'react';

// ** Next Imports
import Link from 'next/link';
import { useRouter } from 'next/router';

// ** MUI Components
import Box from '@mui/material/Box';
import CircularProgress from '@mui/material/CircularProgress';
import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import Divider from '@mui/material/Divider';
import Checkbox from '@mui/material/Checkbox';
import TextField from '@mui/material/TextField';
import InputLabel from '@mui/material/InputLabel';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import CardContent from '@mui/material/CardContent';
import FormControl from '@mui/material/FormControl';
import OutlinedInput from '@mui/material/OutlinedInput';
import { styled, useTheme } from '@mui/material/styles';
import MuiCard from '@mui/material/Card';
import InputAdornment from '@mui/material/InputAdornment';
import MuiFormControlLabel from '@mui/material/FormControlLabel';

// ** Icons Imports
import Instagram from 'mdi-material-ui/Instagram';
import EyeOutline from 'mdi-material-ui/EyeOutline';
import EyeOffOutline from 'mdi-material-ui/EyeOffOutline';
import { signIn } from "next-auth/react";

// ** Configs
import themeConfig from 'src/configs/themeConfig';

// ** Layout Import
import BlankLayout from 'src/@core/layouts/BlankLayout';

// Icons
import UnergIcon from 'src/@core/components/icons/UnergIcon';

// ** Styled Components
const Card = styled(MuiCard)(({ theme }) => ({
  [theme.breakpoints.up('sm')]: {
    width: '28rem'
  }
}));

const LinkStyled = styled('a')(({ theme }) => ({
  fontSize: '0.875rem',
  textDecoration: 'none',
  color: theme.palette.primary.main
}))

const FormControlLabel = styled(MuiFormControlLabel)(({ theme }) => ({
  '& .MuiFormControlLabel-label': {
    fontSize: '0.875rem',
    color: theme.palette.text.secondary
  }
}))

const LoginPage = () => {

  const [ submitting, setSubmitting ] = useState(false);
  const [ error, setError ] = useState({ hasError: false, msg: null });
  
  const [ values, setValues ] = useState({
    username: '',
    password: '',
    rememberMe: false,
    showPassword: false
  });

  const theme = useTheme()
  const router = useRouter()

  const handleChange = (prop) => (event) => {
    if ( error.hasError ) setError({ hasError: false, msg: null });

    setValues({
      ...values,
      [prop]: event.target.value
    });
  };

  const handleClickShowPassword = () => {
    setValues({
      ...values,
      showPassword: !values.showPassword
    });
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSubmitting(true);

    let res = await signIn('credentials', {
      redirect: false,
      username: values.username,
      password: values.password
    });

    if ( res.error ) {
      setError({ hasError: true, msg: res.error });
      setSubmitting(false);
    } else {
      router.push('/dashboard');
    }
  };

  return (
    <Box className="content-center">
      <Card sx={{ zIndex: 1 }}>
        <CardContent sx={{ padding: theme => `${theme.spacing(12, 9, 7)} !important` }}>
          <Box sx={{ mb: 8, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <UnergIcon width={120} height={50} />
            <Typography
              variant="h6"
              sx={{
                marginTop: '20px',
                lineHeight: 1,
                fontWeight: 600,
                textTransform: 'uppercase',
                fontSize: '1.5rem !important',
                textAlign: 'center'

              }}
            >
              {themeConfig.templateName}
            </Typography>
          </Box>
          <Box sx={{ mb: 6 }}>
            <Typography variant="body2" sx={{ textAlign: 'center' }}>
              Iniciar sesión
            </Typography>
          </Box>
          <form noValidate autoComplete="off" onSubmit={handleSubmit}>
            <Grid container spacing={4}>
              <Grid item xs={12}>
                <TextField
                  autoFocus
                  disabled={submitting}
                  error={error.hasError}
                  fullWidth
                  onChange={handleChange('username')}
                  value={values.username}
                  id="email"
                  label="Usuario o Correo"
                  placeholder="@jhondoe, jhondoe@example.com"
                />
              </Grid>
              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel error={error.hasError} htmlFor="auth-login-password">
                    Contraseña
                  </InputLabel>
                  <OutlinedInput
                    label="Contraseña"
                    disabled={submitting}
                    error={error.hasError}
                    value={values.password}
                    id="auth-login-password"
                    onChange={handleChange('password')}
                    type={values.showPassword ? 'text' : 'password'}
                    endAdornment={
                      <InputAdornment position="end">
                        <IconButton
                          edge="end"
                          onClick={handleClickShowPassword}
                          onMouseDown={handleMouseDownPassword}
                          aria-label="alternar visibilidad de contraseña"
                        >
                          {values.showPassword ? <EyeOutline /> : <EyeOffOutline />}
                        </IconButton>
                      </InputAdornment>
                    }
                  />
                </FormControl>
                {error.hasError && (
                  <Box
                    sx={{
                      mb: 4,
                      display: 'flex',
                      alignItems: 'center',
                      flexWrap: 'wrap',
                      justifyContent: 'space-between'
                    }}
                  >
                    <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                      {error.msg}
                    </Typography>
                  </Box>
                )}
              </Grid>
              <Grid item xs={12}>
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                    justifyContent: 'space-between'
                  }}
                >
                  <FormControlLabel
                    onChange={handleChange('rememberMe')}
                    value={values.rememberMe}
                    control={<Checkbox />}
                    label="Recordarme"
                  />
                  <Link passHref href="/">
                    <LinkStyled onClick={e => e.preventDefault()}>
                      Contraseña olvidada?
                    </LinkStyled>
                  </Link>
                </Box>
              </Grid>
              <Grid item xs={12}>
                <Button
                  type="submit"
                  fullWidth
                  size="large"
                  variant="contained"
                  onClick={handleSubmit}
                  {...(
                    submitting
                    || !values.username
                    || !values.password
                  )
                    ? { disabled: true }
                    : null
                  }
                  sx={{
                    marginBottom: 7,
                    backgroundColor: '#042E94',
                    '&:hover': {
                      backgroundColor: '#042E94',
                    }
                  }}
                >
                  {submitting ? <CircularProgress/> : "Ingresar"}
                </Button>
              </Grid>
              <Grid item xs={12}>
                <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', justifyContent: 'center' }}>
                  <Typography variant="body2" sx={{ marginRight: 2 }}>
                    Nuevo usuario?
                  </Typography>
                  <Typography variant="body2">
                    <Link passHref href="/register">
                      <LinkStyled>Crear una cuenta</LinkStyled>
                    </Link>
                  </Typography>
                </Box>
                <Divider sx={{ my: 0 }}>o</Divider>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5 }}>
                  <a target="_blank" href="https://www.instagram.com/pasantiasaisunerg">
                    <Instagram sx={{ color: '#f3425f' }} />
                  </a>
                  <a target="_blank" href="https://t.me/pasantiasaisunerg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 24 24">
                      <path d="M9.78 18.65l.28-4.23l7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3L3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z" fill="#2aabee" />
                    </svg>
                  </a>
                </Box>
              </Grid>
            </Grid>
          </form>
        </CardContent>
      </Card>
      {/* <FooterIllustrationsV1 /> */}
    </Box>
  );

}

LoginPage.getLayout = page => (
  <BlankLayout>
    {page}
  </BlankLayout>
);

export default LoginPage;
