// ** React Imports
import { useState, useEffect, Fragment } from 'react';

// ** Next Imports
import Link from 'next/link';
import { useRouter } from 'next/router';

// ** MUI Components
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import Divider from '@mui/material/Divider';
import Checkbox from '@mui/material/Checkbox';
import Alert from '@mui/material/Alert';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import InputLabel from '@mui/material/InputLabel';
import IconButton from '@mui/material/IconButton';
import CardContent from '@mui/material/CardContent';
import FormControl from '@mui/material/FormControl';
import OutlinedInput from '@mui/material/OutlinedInput';
import { styled, useTheme } from '@mui/material/styles';
import MuiCard from '@mui/material/Card';
import InputAdornment from '@mui/material/InputAdornment';
import MuiFormControlLabel from '@mui/material/FormControlLabel';

import Check from 'mdi-material-ui/Check';
import Instagram from 'mdi-material-ui/Instagram';
import EyeOutline from 'mdi-material-ui/EyeOutline';
import EyeOffOutline from 'mdi-material-ui/EyeOffOutline';

import themeConfig from 'src/configs/themeConfig';
import BlankLayout from 'src/@core/layouts/BlankLayout';
import useAxios from 'src/@core/hooks/useApiClient';
import UnergIcon from 'src/@core/components/icons/UnergIcon';

const Card = styled(MuiCard)(({ theme }) => ({
  [theme.breakpoints.up('md')]: { 
    width: '900px !important',
  },
  [theme.breakpoints.up('sm')]: {
    width: '28rem'
  },
  
}));

const LinkStyled = styled('a')(({ theme }) => ({
  fontSize: '0.875rem',
  textDecoration: 'none',
  color: theme.palette.primary.main
}))

const FormControlLabel = styled(MuiFormControlLabel)(({ theme }) => ({
  marginTop: theme.spacing(1.5),
  marginBottom: theme.spacing(4),
  '& .MuiFormControlLabel-label': {
    fontSize: '0.875rem',
    color: theme.palette.text.secondary
  }
}))

const dniRegExp = /^(?:V-){0,1}[0-9]+$/;
const usernameRegExp = /^(?:@){0,1}[a-zA-Z0-9\-\_\.]+$/;
const emailRegExp = /^(([^<>()\[\]\\.,;:\s@\"]+(\.[^<>()\[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

function RegisterPage() {
  
  const apiClient = useAxios();
  const router = useRouter();

  const [ submitting, setSubmitting ] = useState(false);
  const [ typingPassword, setTypingPassword ] = useState(false);
  const [ success, setSuccess ] = useState(null);
  const [ passwordDifferentError, setPasswordDifferentError ] = useState(false);
  const [ error, setError ] = useState({ hasError: false, msg: null });
  
  const [ values, setValues ] = useState({
    firstname: '',
    lastname: '',
    dni: '',
    username: '',
    email: '',
    password: '',
    reTypePassword: '',
    showPassword: false
  });

  const [ errorTypes, setErrorTypes ] = useState({
    'FORM_FIELD_WRONG_DNI': false,
    'FORM_FIELD_WRONG_USERNAME': false,
    'FORM_FIELD_WRONG_EMAIL': false,
    'FORM_FIELD_MISSING_FIRSTNAME': false,
    'FORM_FIELD_MISSING_LASTNAME': false,
    'FORM_FIELD_MISSING_DNI': false,
    'FORM_FIELD_MISSING_USERNAME': false,
    'FORM_FIELD_MISSING_EMAIL': false,
    'FORM_FIELD_MISSING_PASSWORD': false,
    'FORM_FIELD_DUPLICATED_DNI': false,
    'FORM_FIELD_DUPLICATED_USERNAME': false,
    'FORM_FIELD_DUPLICATED_EMAIL': false
  });

  useEffect(() => {
    if ( typingPassword ) {
      if ( values.password === values.reTypePassword ) {
        setPasswordDifferentError(false);
        } else {
        setPasswordDifferentError(true);
      }
    }
  }, [ values.password, values.reTypePassword ]);

  const handleChange = prop => event => {

    // Verify if there's an error message or an error flag active
    if ( error.hasError || Object.values(errorTypes).filter((val) => val === true).length > 0 ) {
      setError({ hasError: false, msg: null });
      setErrorTypes({
        'FORM_FIELD_WRONG_DNI': false,
        'FORM_FIELD_WRONG_USERNAME': false,
        'FORM_FIELD_WRONG_EMAIL': false,
        'FORM_FIELD_MISSING_FIRSTNAME': false,
        'FORM_FIELD_MISSING_LASTNAME': false,
        'FORM_FIELD_MISSING_DNI': false,
        'FORM_FIELD_MISSING_USERNAME': false,
        'FORM_FIELD_MISSING_EMAIL': false,
        'FORM_FIELD_MISSING_PASSWORD': false,
        'FORM_FIELD_DUPLICATED_DNI': false,
        'FORM_FIELD_DUPLICATED_USERNAME': false,
        'FORM_FIELD_DUPLICATED_EMAIL': false
      });
    }
    
    if ( prop === 'password' || prop === 'reTypePassword' ) {
      if ( values.password !== '' || values.reTypePassword !== '' ) {
        setTypingPassword(true);
      } else {
        setTypingPassword(false);
      }
    }

    if ( prop === 'email' ) {
      if ( emailRegExp.test(event.target.value) ) {
        setValues({
          ...values,
          [prop]: event.target.value
        });
      } else {
        if ( event.target.value === '' ) {
          setErrorTypes({
            ...errorTypes,
            FORM_FIELD_WRONG_EMAIL: false
          });
          setValues({
            ...values,
            [prop]: event.target.value
          });
          return;
        }

        setErrorTypes({
          ...errorTypes,
          FORM_FIELD_WRONG_EMAIL: true
        });
        setValues({
          ...values,
          [prop]: event.target.value
        });
        return;
      }
    }

    if ( prop === 'username' ) {
      if ( usernameRegExp.test(event.target.value) ) {
        if ( values.username !== '' ) {
          console.log(values.username, 'validates');
          setValues({
            ...values,
            [prop]: event.target.value
            });
        } else {
          console.log(values.username, 're-validates');
          setValues({
            ...values,
            [prop]: '@' + event.target.value
          });
        }
      } else {
        if ( event.target.value === '' ) {
          setErrorTypes({
            ...errorTypes,
            FORM_FIELD_WRONG_USERNAME: false
          });
          setValues({
            ...values,
            [prop]: event.target.value
          });
          return;
        }

        setErrorTypes({
          ...errorTypes,
          FORM_FIELD_WRONG_USERNAME: true
        });
        setValues({
          ...values,
          [prop]: event.target.value
        });
      }
    }

    if ( prop === 'dni' ) {
      if ( dniRegExp.test(event.target.value) ) {
        if ( values.dni !== '' ) {
          setValues({
            ...values,
            [prop]: event.target.value
          });
        } else {
          setValues({
            ...values,
            [prop]: 'V-' + event.target.value
          });
        }
      } else {
        if ( values.dni === 'V-' ) {
          setErrorTypes({ ...errorTypes, FORM_FIELD_WRONG_DNI: false });
          setValues({
            ...values,
            [prop]: ''
          });
          return;
        }
        
        if ( event.target.value === '' ) {
          setErrorTypes({ ...errorTypes, FORM_FIELD_WRONG_DNI: false });
          setValues({
            ...values,
            [prop]: ''
          });
          return;
        }
        
        setErrorTypes({ ...errorTypes, FORM_FIELD_WRONG_DNI: true });
        setValues({
          ...values,
          [prop]: event.target.value
        });
      }

      return;
    }

    setValues({
      ...values,
      [prop]: event.target.value
    });
    
  };

  const handleClickShowPassword = () => {
    setValues({
      ...values,
      showPassword: !values.showPassword
    });
  }

  const handleMouseDownPassword = event => {
    event.preventDefault()
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSubmitting(true);

    try {
      const response = await apiClient.post('/register/registerStudent', {
        firstname: values.firstname,
        lastname: values.lastname,
        dni: values.dni,
        username: values.username,
        email: values.email,
        password: values.password
      });

      if ( response.data?.type === 'FORM_REGISTRY_SUCCESS' ) {
        setSuccess(response.data);
        setValues({
          firstname: '',
          lastname: '',
          dni: '',
          username: '',
          email: '',
          password: '',
          reTypePassword: '',
          showPassword: false
        });
        setTimeout(() => {
          router.push('/login');
        }, 1500);
      } else {
        setErrorTypes({
          ...errorTypes,
          [response.type]: true
        });
      }
    } catch (e) {
      const { type } = e.response.data;
      console.log(e);
      setErrorTypes({
        ...errorTypes,
        [type]: true
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Box className='content-center'>
      <Card id="my-container" sx={{ zIndex: 1 }}>
        <CardContent sx={{ padding: theme => `${theme.spacing(12, 9, 7)} !important` }}>
          <form noValidate autoComplete='off' onSubmit={handleSubmit}>
            <Box sx={{ mb: 8, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
              <UnergIcon width={120} height={50}/>
              <Typography
                variant='h6'
                sx={{
                  lineHeight: 1,
                  fontWeight: 600,
                  textTransform: 'uppercase',
                  fontSize: '1.5rem !important',
                  textAlign: 'center'
                }}
              >
                {themeConfig.templateName}
              </Typography>
            </Box>
            <Box sx={{ mb: 6 }}>
              <Typography variant='body2' sx={{ textAlign: 'center' }}>
                Registrese
              </Typography>
            </Box>
            <Grid container spacing={4} >
              <Grid item md={6} xs={12} >
                <TextField
                  disabled={submitting}
                  fullWidth
                  id="firstname"
                  value={values.firstname}
                  onChange={handleChange('firstname')}
                  label="Nombre"
                  placeholder="Jhon"
                />
              </Grid>
              <Grid item md={6} xs={12}>
                <TextField
                  disabled={submitting}
                  fullWidth
                  id="lastname"
                  value={values.lastname}
                  onChange={handleChange('lastname')}
                  label="Apellido"
                  placeholder="Doe"
                />
              </Grid>
              
              <Grid item md={4} xs={12} >
                <TextField
                  disabled={submitting}
                  error={errorTypes['FORM_FIELD_WRONG_DNI'] || errorTypes['FORM_FIELD_DUPLICATED_DNI']}
                  fullWidth
                  id="cedula"
                  value={values.dni}
                  onChange={handleChange('dni')}
                  label="Numero de Cedula"
                  placeholder="V-12345678"
                  {...(errorTypes['FORM_FIELD_WRONG_DNI'] || errorTypes['FORM_FIELD_DUPLICATED_DNI']) && ({sx: { mb: 2 } })}
                />
                {(errorTypes['FORM_FIELD_WRONG_DNI'] || errorTypes['FORM_FIELD_DUPLICATED_DNI']) && (
                  <Box
                    sx={{
                      mb: 4,
                      display: 'flex',
                      alignItems: 'center',
                      flexWrap: 'wrap',
                      justifyContent: 'space-between'
                    }}
                  >
                    {errorTypes['FORM_FIELD_WRONG_DNI'] && (
                      <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                        El numero de cedula es invalido
                      </Typography>
                    )}

                    {errorTypes['FORM_FIELD_DUPLICATED_DNI'] && (
                      <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                        El numero de cedula ya existe
                      </Typography>
                    )}
                  </Box>
                )}
              </Grid>
              <Grid item md={4} xs={12} /* sx={{ px: { md: 2 } }} */>
                <TextField 
                  disabled={submitting}
                  error={errorTypes['FORM_FIELD_WRONG_USERNAME'] || errorTypes['FORM_FIELD_DUPLICATED_USERNAME']}
                  fullWidth
                  id="username"
                  value={values.username}
                  onChange={handleChange('username')}
                  label="Nombre de Usuario"
                  placeholder="@jhondoe"
                  {...(errorTypes['FORM_FIELD_WRONG_USERNAME'] || errorTypes['FORM_FIELD_DUPLICATED_USERNAME']) && ({sx: { mb: 2 } })}
                />
                {(errorTypes['FORM_FIELD_WRONG_USERNAME'] || errorTypes['FORM_FIELD_DUPLICATED_USERNAME']) && (
                  <Box
                    sx={{
                      mb: 4,
                      display: 'flex',
                      alignItems: 'center',
                      flexWrap: 'wrap',
                      justifyContent: 'space-between'
                    }}
                  >
                    {errorTypes['FORM_FIELD_WRONG_USERNAME'] && (
                      <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                        El nombre de usuario es invalido
                      </Typography>
                    )}

                    {errorTypes['FORM_FIELD_DUPLICATED_USERNAME'] && (
                      <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                        El nombre de usuario ya existe
                      </Typography>
                    )}
                  </Box>
                )}
              </Grid >
              <Grid item md={4} xs={12} /* sx={{ pl: { md: 2 } }} */>
                <TextField
                  fullWidth
                  disabled={submitting}
                  error={errorTypes['FORM_FIELD_WRONG_EMAIL'] || errorTypes['FORM_FIELD_DUPLICATED_EMAIL']}
                  type="email"
                  value={values.email}
                  onChange={handleChange('email')}
                  label="Email"
                  placeholder="jhondoe@example.com"
                  {...(errorTypes['FORM_FIELD_WRONG_EMAIL'] || errorTypes['FORM_FIELD_DUPLICATED_EMAIL']) && ({sx: { mb: 2 } })}
                />
                {(errorTypes['FORM_FIELD_WRONG_EMAIL'] || errorTypes['FORM_FIELD_DUPLICATED_EMAIL']) && (
                  <Box
                    sx={{
                      mb: 4,
                      display: 'flex',
                      alignItems: 'center',
                      flexWrap: 'wrap',
                      justifyContent: 'space-between'
                    }}
                  >
                    {errorTypes['FORM_FIELD_WRONG_EMAIL'] && (
                      <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                        El correo electronico es invalido
                      </Typography>
                    )}

                    {errorTypes['FORM_FIELD_DUPLICATED_EMAIL'] && (
                      <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                        El correo electronico ya existe
                      </Typography>
                    )}
                  </Box>
                )}
              </Grid>
              <Grid item md={6} xs={12}>
                <FormControl fullWidth>
                  <InputLabel error={passwordDifferentError} htmlFor='auth-register-password'>
                    Contraseña
                  </InputLabel>
                  <OutlinedInput
                    label="Contraseña"
                    disabled={submitting}
                    error={passwordDifferentError}
                    value={values.password}
                    id="auth-register-password"
                    onChange={handleChange('password')}
                    type={values.showPassword ? 'text' : 'password'}
                    endAdornment={
                      <InputAdornment position='end'>
                        <IconButton
                          edge='end'
                          onClick={handleClickShowPassword}
                          onMouseDown={handleMouseDownPassword}
                          aria-label="alternar visibilidad de contraseña"
                        >
                          {values.showPassword ? <EyeOutline fontSize='small' /> : <EyeOffOutline fontSize='small' />}
                        </IconButton>
                      </InputAdornment>
                    }
                  />
                </FormControl>
              </Grid>
              
              <Grid item md={6} xs={12}>
                <FormControl fullWidth>
                  <InputLabel error={passwordDifferentError} htmlFor="auth-register-retype-password">
                    Repetir Contraseña
                  </InputLabel>
                  <OutlinedInput
                    label="Repetir Contraseña"
                    disabled={submitting}
                    error={passwordDifferentError}
                    value={values.reTypePassword}
                    id="auth-register-retype-password"
                    onChange={handleChange('reTypePassword')}
                    type={values.showPassword ? 'text' : 'password'}
                    endAdornment={
                      <InputAdornment position='end'>
                        <IconButton
                          edge="end"
                          onClick={handleClickShowPassword}
                          onMouseDown={handleMouseDownPassword}
                          aria-label="alternar visibilidad de contraseña"
                        >
                          {values.showPassword ? <EyeOutline fontSize='small' /> : <EyeOffOutline fontSize='small' />}
                        </IconButton>
                      </InputAdornment>
                    }
                  />
                </FormControl>
                {passwordDifferentError && (
                  <Box
                    sx={{
                      mb: 4,
                      display: 'flex',
                      alignItems: 'center',
                      flexWrap: 'wrap',
                      justifyContent: 'space-between'
                    }}
                  >
                    <Typography variant="body2" sx={{ textAlign: 'center', color: 'red' }}>
                      Las contraseñas no coinciden
                    </Typography>
                  </Box>
                )}
              </Grid>
              <Grid item xs={12}>
                <FormControlLabel
                  control={<Checkbox />}
                  label={
                    <Fragment>
                      <span>Estoy de acuerdo con los </span>
                      <Link href='/' passHref>
                        <LinkStyled onClick={e => e.preventDefault()}>términos y política de privacidad</LinkStyled>
                      </Link>
                    </Fragment>
                  }
                />
              </Grid>

              {success && (
                <Grid item xs={12}>
                  <Alert color="success" icon={<Check/>}>
                    <Typography variant="body2">
                        {success?.message}
                    </Typography>
                  </Alert>
                </Grid>
              )}

              <Grid item xs={12}>
                <Button
                  fullWidth
                  {...(submitting
                    || !values.firstname
                    || !values.lastname
                    || !values.dni
                    || !values.username
                    || !values.email
                    || !values.password
                    || !values.reTypePassword
                    || passwordDifferentError
                    || errorTypes['FORM_FIELD_WRONG_DNI']
                    || errorTypes['FORM_FIELD_WRONG_USERNAME']
                    || errorTypes['FORM_FIELD_WRONG_EMAIL']
                  )
                    ? { disabled: true }
                    : null
                  }
                  size="large"
                  type="submit"
                  variant="contained"
                  sx={{
                    marginBottom: 7,
                    backgroundColor: '#042E94',
                    '&:hover': {
                      backgroundColor: '#042E94',
                    }
                  }}
                >
                  Registrarse
                </Button>
              </Grid>
              <Grid item xs={12}>
                <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', justifyContent: 'center' }}>
                  <Typography variant='body2' sx={{ marginRight: 2 }}>
                    Ya posee una cuenta?
                  </Typography>
                  <Typography variant='body2'>
                    <Link passHref href='/login'>
                      <LinkStyled>Iniciar sesión</LinkStyled>
                    </Link>
                  </Typography>
                </Box>
                <Divider sx={{ my: 0 }}>o</Divider>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5 }}>
                  <a target="_blank" href="https://www.instagram.com/pasantiasaisunerg">
                    <Instagram sx={{ color: '#f3425f' }} />
                  </a>

                  <a target="_blank" href="https://t.me/pasantiasaisunerg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 24 24">
                      <path d="M9.78 18.65l.28-4.23l7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3L3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z" fill="#2aabee"/>
                    </svg>
                  </a>
                </Box>
              </Grid>
            </Grid>
          </form>
        </CardContent>
      </Card>
      {/* <FooterIllustrationsV1 /> */}
    </Box>
  );
}

RegisterPage.getLayout = page => (
  <BlankLayout>
    {page}
  </BlankLayout>
);

export default RegisterPage;
