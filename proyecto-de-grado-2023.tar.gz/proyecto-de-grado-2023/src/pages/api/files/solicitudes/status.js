import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {
    const { method, query } = req;

    if ( method === 'GET' ) {
      try {
        let documentsStatus;

        if ( !query.solicitudId ) {
          return res.status(401).json({ error: `Param 'solicitudId' is missing ` });
        }

        documentsStatus = await prisma.$queryRaw`
          SELECT
            SO.id,
            SO.constancia_status AS constancia_status,
            CA.status AS carta_aceptacion_status,
            PT.status AS plan_trabajo_status
          FROM solicitud AS SO
          LEFT JOIN proyecto AS PR ON SO.proyecto_id = PR.id
          LEFT JOIN plan_trabajo AS PT ON PR.plan_trabajo_id = PT.id
          LEFT JOIN carta_aceptacion_pasantia AS CA ON SO.carta_aceptacion_pasantia_id = CA.id
          WHERE SO.id = ${query.solicitudId};
        `;

        if ( documentsStatus ) {
          return res.status(200).json(documentsStatus);
        }

        return res.status(200).json({ err: 'NO_DATA_FOUND'});
        
      } catch ( err ) {
        return res.status(401).json({ err });
      } finally {
        prisma.$disconnect();
      }
    } else {
      // Manejar otros métodos HTTP o devolver un error
      res.setHeader('Allow', [ 'GET' ]);
      res.status(405).end(`Method ${req.method} Not Allowed`);
    }
}