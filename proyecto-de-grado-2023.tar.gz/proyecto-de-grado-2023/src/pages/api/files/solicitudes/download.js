import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {
    const { method, query } = req;

    if ( method === 'GET' ) {
      try {
        let targetDocument;

        if ( !query.solicitudId ) {
          return res.status(401).json({ error: `Param 'solicitudId' is missing ` });
        }

        if ( query.file ) {
          switch ( query.file ) {
            case 'inscripcion':
              targetDocument = await prisma.$queryRaw`
                SELECT
                  SO.id,
                  SO.constancia_inscripcion AS inscripcion
                FROM solicitud AS SO
                LEFT JOIN proyecto AS PR ON SO.proyecto_id = PR.id
                WHERE SO.id = ${parseInt(query.solicitudId)};
              `;
              break;
            
            case 'aceptacion':
              targetDocument = await prisma.$queryRaw`
                SELECT
                  SO.id,
                  CA.carta_aceptacion_document AS aceptacion
                FROM solicitud AS SO
                LEFT JOIN carta_aceptacion_pasantia AS CA ON SO.carta_aceptacion_pasantia_id = CA.id
                WHERE SO.id = ${parseInt(query.solicitudId)};
              `;
              break;
            case 'planTrabajo':
              targetDocument = await prisma.$queryRaw`
                SELECT
                  SO.id,
                  PT.plan_trabajo_document AS planTrabajo
                FROM solicitud AS SO
                LEFT JOIN proyecto AS PR ON SO.proyecto_id = PR.id
                LEFT JOIN plan_trabajo AS PT ON PR.plan_trabajo_id = PT.id
                WHERE SO.id = ${parseInt(query.solicitudId)};;
              `;
              break;
            default: // Todos los documentos
              targetDocument = await prisma.$queryRaw`
                SELECT
                  SO.id,
                  CONCAT(US.firstname, ' ', US.lastname) AS Estudiante,
                  SO.constancia_inscripcion AS inscripcion,
                  CA.carta_aceptacion_document AS aceptacion,
                  PT.plan_trabajo_document AS planTrabajo
                FROM solicitud AS SO
                LEFT JOIN proyecto AS PR ON SO.proyecto_id = PR.id
                LEFT JOIN plan_trabajo AS PT ON PR.plan_trabajo_id = PT.id
                LEFT JOIN carta_aceptacion_pasantia AS CA ON SO.carta_aceptacion_pasantia_id = CA.id
                LEFT JOIN users AS US ON SO.users_id = US.id
                WHERE SO.id = ${parseInt(query.solicitudId)};
              `;
          }

          if ( targetDocument ) {
            return res.status(200).json(targetDocument);
          }

          return res.status(200).json({});
        }

        return res.status(401).json({ error: `Param 'id' is missing ` });
      } catch ( err ) {
        return res.status(401).json({ err });
      } finally {
        prisma.$disconnect();
      }
    } else {
      // Manejar otros métodos HTTP o devolver un error
      res.setHeader('Allow', [ 'GET' ]);
      res.status(405).end(`Method ${req.method} Not Allowed`);
    }
}