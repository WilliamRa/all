import { prisma } from "src/configs/backend/prisma";

export default async function handler(req, res) {
  const { method } = req;

  if ( method === 'GET' ) {
    try {
      let roles = await prisma.user_roles.findMany({
        select: {
          display_name: true,
          id: true,
        },
        where: {
          NOT: {
            id: 1 // Admin
          }
        }
      });

      if ( !roles ) return res.status(401).json({ message: "No existen roles registradas" })

      return res.status(200).json({ roles });
    
    } catch (error) {
      res.status(500).json({
          message: "Error en el servidor",
          error: error.message
      });
    } finally {
      prisma.$disconnect();
    }

  } else {
      // Manejar otros métodos HTTP o devolver un error
      res.setHeader('Allow', ['GET', 'POST']);
      res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
