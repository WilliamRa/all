import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {
  const { method, body, query } = req;

  if ( !query.solicitudId ) {
    return res.status(401).json({
      type: 'FORM_FIELD_MISSING_USER',
      message: "Parametro 'solicitudId' es requerido"
    });
  }

  if ( !query.fase ) {
    return res.status(401).json({
      type: 'FORM_FIELD_MISSING_USER',
      message: "Parametro 'fase' es requerido"
    });
  }

  if ( method === 'PUT' ) {
    if ( query.fase == '1' ) {
      try {
        
        if ( ( !body.user_id ) || ( body.user_id === "" ) ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_USER', message: "Requieres el usuario id" });
        if ( ( !body.projectName ) || ( body.projectName === "" ) ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_PROJECT_NAME', message: "Requieres el nombre del proyecto" });
        if ( ( !body.aceptacion ) || ( body.aceptacion === "" ) ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_CONSTANCIA', message: "Requieres la carta de aceptacion" });
        if ( ( !body.inscripcion ) || ( body.inscripcion === "" ) ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_INSCRIPCION', message: "Requieres la constancia de incripcion" });
        if ( ( !body.planTrabajo ) || ( body.planTrabajo === "" ) ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_PLAN_TRABAJO', message: "Requieres el plan de trabajo" });
        if ( ( !body.aceptacionId ) || ( body.aceptacionId === "" ) ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_CONSTANCIA', message: "Requieres el id de la carta de aceptacion" });
        if ( ( !body.planTrabajoId ) || ( body.planTrabajoId === "" ) ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_PLAN_TRABAJO', message: "Requieres el id del plan de trabajo" });
        if ( ( !body.proyectoId ) || ( body.proyectoId === "" ) ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_PLAN_TRABAJO', message: "Requieres el id del proyecto" });
  
        let updateAceptacion, updateContanciaInscripcion, updatePlanTrabajo, updateProyecto;
        let updateSolicitud;
  
        // console.log('Cuerpo recibido', body);
        if ( body.aceptacion ) {
          updateAceptacion = await prisma.carta_aceptacion_pasantia.update({
            data: {
              carta_aceptacion_document: body.aceptacion,
              status: null
            },
            where: {
              id: parseInt(body.aceptacionId)
            }
          });
        }
  
        if ( body.inscripcion ) {
          updateContanciaInscripcion = await prisma.solicitud.update({
            data: {
              constancia_inscripcion: body.inscripcion,
              constancia_status: null,
              status: 2
            },
            where: {
              id: parseInt(query.solicitudId)
            }
          });
        }
  
        if ( body.planTrabajo && body.projectName ) {
          updatePlanTrabajo = await prisma.plan_trabajo.update({
            data: {
              plan_trabajo_document: body.planTrabajo,
              status: null
            },
            where: {
              id: parseInt(body.planTrabajoId)
            }
          });
          
          updateProyecto = await prisma.proyecto.update({
            data: {
              proyecto_nombre: body.projectName,
            },
            where: {
              id: parseInt(body.proyectoId)
            }
          });

          return res.status(200).json({
            type: 'FORM_REGISTRY_SUCCESS',
            message: 'La solicitud ha sido actualizada satisfactoriamente'
          });
        }
  
        return res.status(200).json({
          type: 'FORM_REGISTRY_ERROR',
          message: 'Ha ocurrido un error inesperado al actualizar la solicitud'
        });
  
      } catch (error) {
        // console.log(error);
        res.status(500).json({
          message: "Error en el servidor",
          error: error.message
        });
      } finally {
        prisma.$disconnect();
      }
    }
    
  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', [ 'PUT' ]);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}