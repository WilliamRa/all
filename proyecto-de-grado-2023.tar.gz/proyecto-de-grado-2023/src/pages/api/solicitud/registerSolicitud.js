import bcryptjs from 'bcryptjs';
import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {
  const { method, body, query } = req;

  if ( method === 'POST' ) {
    if ( query.fase == '1' ) {
      try {
        if ( ( !body.user_id ) || ( body.user_id === "" ) ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_USER', message: "Requieres el usuario id" });
        if ( ( !body.projectName ) || ( body.projectName === "" ) ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_PROJECT_NAME', message: "Requieres el nombre del proyecto" });
        if ( ( !body.aceptacion ) || ( body.aceptacion === "" ) ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_CONTANCIA', message: "Requieres la carta de aceptacion" });
        if ( ( !body.inscripcion ) || ( body.inscripcion === "" ) ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_INSCRIPCION', message: "Requieres la constancia de incripcion" });
        if ( ( !body.planTrabajo ) || ( body.planTrabajo === "" ) ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_PLAN_TRABAJO', message: "Requieres el plan de trabajo" });
  
        let createAceptacion, createContanciaInscripcion, createPlanTrabajo, createProyecto;
        let updateSolicitud;
  
        if ( body.aceptacion ) {
          createAceptacion = await prisma.carta_aceptacion_pasantia.create({
            data: {
              carta_aceptacion_document: body.aceptacion
            }
          });
        }
  
  
        if ( body.inscripcion ) {
          createContanciaInscripcion = await prisma.solicitud.create({
            data: {
              constancia_inscripcion: body.inscripcion,
              carta_aceptacion_pasantia_id: createAceptacion.id,
              users_id: body.user_id,
              status: 0,
            }
          });
        }
  
        if ( body.planTrabajo && body.projectName ) {
          createPlanTrabajo = await prisma.plan_trabajo.create({
            data: {
              plan_trabajo_document: body.planTrabajo
            }
          });
          
          createProyecto = await prisma.proyecto.create({
            data: {
              proyecto_nombre: body.projectName,
              plan_trabajo_id: createPlanTrabajo.id
            }
          });
        }
  
        if ( createProyecto ) {
          updateSolicitud = await prisma.solicitud.update({
            data: {
              proyecto_id: createProyecto.id,
              status: 2 
            },
            where: {
              id: createContanciaInscripcion.id
            }
          })
        }
  
     
        return res.status(200).json({
          type: 'FORM_REGISTRY_SUCCESS',
          message: 'La solicitud ha sido enviada satisfactoriamente'
        });
  
      } catch (error) {
        console.log(error);
        res.status(500).json({
          message: "Error en el servidor",
          error: error.message
        });
      } finally {
        prisma.$disconnect();
      }
    }
    
  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}