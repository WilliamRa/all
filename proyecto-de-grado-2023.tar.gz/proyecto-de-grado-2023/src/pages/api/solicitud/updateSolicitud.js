import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {
  const { method, body, query } = req;

  if ( method === 'PUT' ) {
    try {
      if (( body.inscripcion === undefined ) || ( body.inscripcion === "" )) return res.status(401).json({ type: 'FORM_FIELD_MISSING_INSCRIPCION', message: "Requieres el estatus de la inscripcion" });
      if (( body.aceptacion === undefined ) || ( body.aceptacion === "" )) return res.status(401).json({ type: 'FORM_FIELD_MISSING_ACEPTACION', message: "Ingrese el estatus de la aceptacion" });
      if (( body.planTrabajo === undefined ) || ( body.planTrabajo === "" )) return res.status(401).json({ type: 'FORM_FIELD_CONSTANCIA_PLAN_TRABAJO', message: "Ingrese el estatus del plan de Trabajo" });
      if (( !query.solicitudId ) || ( query.solicitudId === undefined )) return res.status(401).json({ type: 'FORM_FIELD_ID', message: "Se requiere el identificador unico" });

      if ( query.solicitudId ) {
        let documentos = await prisma.$queryRaw`
          SELECT
            SO.id AS solicitud_id,
            CA.id AS carta_aceptacion_id,
            PT.id AS plan_trabajo_id
          FROM solicitud AS SO
          LEFT JOIN proyecto AS PR ON SO.proyecto_id = PR.id
          LEFT JOIN plan_trabajo AS PT ON PR.plan_trabajo_id = PT.id
          LEFT JOIN carta_aceptacion_pasantia AS CA ON SO.carta_aceptacion_pasantia_id = CA.id
          WHERE SO.id = ${parseInt(query.solicitudId)};
        `;

        if ( !documentos ) return res.status(401).json({ type: 'NO_DATA_FOUND', message: "No se han encontrado los IDs de los documentos" });

        // return res.status(200).json({ documentos });
        
        // update inscripcion
        let inscripcionResult = await prisma.solicitud.update({
          data: {
            constancia_status: parseInt(body.inscripcion),
          },
          where: {
            id: documentos[0].solicitud_id
          }
        });
        
        if ( !inscripcionResult ) return res.status(401).json({ type: 'DB_DATA_UPDATE_FAILED', message: "Ocurrio un error al actualizar los datos" });

        // update aceptacion
        let cartaAceptacionResult = await prisma.carta_aceptacion_pasantia.update({
          data: {
            status: parseInt(body.aceptacion)
          },
          where: {
            id: documentos[0].carta_aceptacion_id
          }
        });
        
        if ( !cartaAceptacionResult ) return res.status(401).json({ type: 'DB_DATA_UPDATE_FAILED', message: "Ocurrio un error al actualizar los datos" });

        // update planTrabajo
        let planTrabajoResult = await prisma.plan_trabajo.update({
          data: {
            status: parseInt(body.planTrabajo)
          },
          where: {
            id: documentos[0].plan_trabajo_id
          }
        });
        
        if ( !planTrabajoResult ) return res.status(401).json({ type: 'DB_DATA_UPDATE_FAILED', message: "Ocurrio un error al actualizar los datos" });

        // // Verifica que todos los documentos hayan sido aprobados para actualizar
        // // el estatus general de la solicitud y establecerla como 'Aprobado'
        let solicitudResult;

        if ( body.inscripcion === 1 && body.aceptacion === 1 && body.planTrabajo === 1 ) {
          solicitudResult = await prisma.solicitud.update({
            data: {
              status: 1,  // Aprobado
            },
            where: {
              id: parseInt(query.solicitudId)
            }
          });
        } else {
          solicitudResult = await prisma.solicitud.update({
            data: {
              status: 0,  // Rechazado
            },
            where: {
              id: parseInt(query.solicitudId)
            }
          });
        }

        if ( inscripcionResult && cartaAceptacionResult && planTrabajoResult ) {
          let additional = '';
          if ( solicitudResult ) {
            additional = 'El estatus de la solicitud ha cambiado.'
          }

          return res.status(200).json({
            type: 'FORM_UPDATE_SUCCESS',
            message: 'Los documentos han sido actualizados exitosamente. ' + additional
          });
        }
      }


      // if ( body.carta_aceptacion_pasantia ) {
      //   let createSolicitudCarta = await prisma.solicitud.update({
      //     where: { id: body.id },
      //     data: {
      //       constancia_inscripcion: body.constancia_inscripcion,
      //       copia_cedula: body.copia_cedula,
      //       constancia_notas: body.constancia_notas,
      //       carta_aceptacion_pasantia: {
      //         create: {
      //           carta_aceptacion_pasantia_document: body.carta_aceptacion_pasantia
      //         }
      //       }
      //     }
      //   });

      //   return res.status(200).json({
      //     message: "exito"
      //   });
      // }

      // let createSolicitud = await prisma.solicitud.create({
      //   data: {
      //     constancia_inscripcion: body.constancia_inscripcion,
      //     copia_cedula: body.copia_cedula,
      //     constancia_notas: body.constancia_notas,
      //   }
      // });

      // return res.status(200).json({
      //   message: "exito"
      // });
    } catch (error) {
      console.log(error);
      res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect();
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', [ 'PUT' ]);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}