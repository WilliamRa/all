import bcryptjs from 'bcryptjs';
import { prisma } from 'src/configs/backend/prisma';

/*
{
    "user_id": 6
}
*/
export default async function handler(req, res) {
  const { method, body } = req;

  if (method === 'POST') {
    try {
      if ((!body.user_id) || (body.user_id === "")) return res.status(401).json({ type: 'FORM_FIELD_MISSING_USER', message: "Requieres el usuario id" });
      
      const getAll = await prisma.solicitud.findMany({
        where: {
          users_id: body.user_id
        },
        include: {
          proyecto: {
            include: {
              evaluacion_coordinacion: true,
              evaluacion_tutor_academico: true,
              evaluacion_tutor_empresarial: true,
              informe_pasantia: true,
              plan_trabajo: true,
              visitas: true
            }
          }
        }
      })
      return res.status(200).json({
        getAll
      });

    } catch (error) {
      console.log(error);
      res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect();
    }
  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}