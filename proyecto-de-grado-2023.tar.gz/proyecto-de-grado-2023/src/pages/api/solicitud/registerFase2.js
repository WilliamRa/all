import bcryptjs from 'bcryptjs';
import { prisma } from 'src/configs/backend/prisma';

/*
{
  username:  String
  email: String
  password: String
  firstname: String
  lastname: String
}
*/
export default async function handler(req, res) {
  const { method, body } = req;

  if (method === 'POST') {
    try {
      if ((!body.user_id) || (body.user_id === "")) return res.status(401).json({ type: 'FORM_FIELD_MISSING_USER', message: "Requieres el usuario id" });
      if ((!body.visita1) || (body.aceptacion === "")) return res.status(401).json({ type: 'FORM_FIELD_MISSING_CONTANCIA', message: "Requieres la carta de aceptacion" });
      if ((!body.visita2) || (body.inscripcion === "")) return res.status(401).json({ type: 'FORM_FIELD_MISSING_INSCRIPCION', message: "Requieres la constancia de incripcion" });

      let findSolicitud = await prisma.solicitud.findFirst({
        where: { users_id: body.user_id },
      })

     
      let arrayClean = [{
        proyect_id: findSolicitud.proyecto_id,
        documento_pasantias: body.visita1
      },
      {
        proyect_id: findSolicitud.proyecto_id,
        documento_pasantias: body.visita2
      }
      ]


      let createVisitas = await prisma.visitas.createMany({
        data: arrayClean
      })

      return res.status(200).json({
        type: 'FORM_REGISTRY_SUCCESS',
        message: 'La solicitud ha sido enviada satisfactoriamente'
      });

    } catch (error) {
      console.log(error);
      res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect();
    }
  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}