import bcryptjs from 'bcryptjs';
import { prisma } from 'src/configs/backend/prisma';

/*
{
  username:  String
  email: String
  password: String
  firstname: String
  lastname: String
}
*/
export default async function handler(req, res) {
  const { method, body } = req;

  if (method === 'POST') {
    try {
      if ((!body.user_id) || (body.user_id === "")) return res.status(401).json({ type: 'FORM_FIELD_MISSING_USER', message: "Requieres el usuario id" });
      if ((!body.evaluacion_academico) || (body.evaluacion_academico === "")) return res.status(401).json({ type: 'FORM_FIELD_MISSING_EVALUACION_ACADEMICO', message: "Requieres la evaluacion del tutor academico" });
      if ((!body.evaluacion_empresarial) || (body.evaluacion_empresarial === "")) return res.status(401).json({ type: 'FORM_FIELD_MISSING_EVALUACION_EMPRESARIAL', message: "Requieres la evaluacion del tutor empresarial" });
      if ((!body.informe) || (body.informe === "")) return res.status(401).json({ type: 'FORM_FIELD_MISSING_INFORME', message: "Requieres el informe" });

      let findSolicitud = await prisma.solicitud.findFirst({
        where: { users_id: body.user_id },
      })


      let proyectoUpdate = await prisma.proyecto.update({
        where: {
          id: findSolicitud.proyecto_id
        },
        data: {
          evaluacion_tutor_empresarial: {
            create: {
              evaluacion_tutor_empresarial_document: body.evaluacion_empresarial,
            }
          },
          evaluacion_tutor_academico: {
            create: {
              evaluacion_tutor_academico_document: body.evaluacion_academico
            }
          },
          informe_pasantia: {
            create: {
              documento_final: body.informe
            }
          }
        }
      })

      return res.status(200).json({
        type: 'FORM_REGISTRY_SUCCESS',
        message: 'La solicitud ha sido enviada satisfactoriamente'
      });

    } catch (error) {
      console.log(error);
      res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect();
    }
  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}