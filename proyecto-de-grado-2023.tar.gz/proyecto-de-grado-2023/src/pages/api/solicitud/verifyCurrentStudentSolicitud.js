import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {

  const { method, query } = req;

  if ( method === 'GET' ) {
    if ( !query.id ) {
      return res.status(401).end(`Required Param 'id' is missing.`);
    }

    if ( !query.fase ) {
      return res.status(401).end(`Required Param 'fase' is missing.`);
    }

    try {
      let documentos, visitas;

      switch (query.fase) {
        case '1':
          documentos = await prisma.$queryRaw`
            SELECT
              SO.id,
              PR.proyecto_nombre,
              PR.id AS proyecto_id,
              SO.status AS solicitud_status,
              SO.constancia_status AS constancia_status,
              CA.status AS carta_aceptacion_status,
              CA.id AS carta_aceptacion_id,
              PT.status AS plan_trabajo_status,
              PT.id AS plan_trabajo_id
            FROM solicitud AS SO
            LEFT JOIN proyecto AS PR ON SO.proyecto_id = PR.id
            LEFT JOIN plan_trabajo AS PT ON PR.plan_trabajo_id = PT.id
            LEFT JOIN carta_aceptacion_pasantia AS CA ON SO.carta_aceptacion_pasantia_id = CA.id
            WHERE SO.users_id = ${parseInt(query.id)};
          `;
          break;
        case '2':
          documentos = await prisma.$queryRaw`
          SELECT
            PR.id AS proyecto_id,
            PR.proyecto_nombre,
            PR.status AS proyecto_status,
            SO.id AS solicitud_id,
            TA.id AS tutor_academico_id,
            TA.firstname AS tutor_academico_firstname,
            TA.lastname AS tutor_academico_lastname,
            TA.email AS tutor_academico_email,
            TA.phone_number AS tutor_academico_phone,
            TE.email AS tutor_empresarial_id,
            TE.firstname AS tutor_empresarial_firstname,
            TE.lastname AS tutor_empresarial_lastname,
            EM.id AS empresa_id,
            EM.nombre_empresa,
            EM.direccion AS empresa_direccion
          FROM
            proyecto AS PR
          LEFT JOIN solicitud AS SO ON PR.id = SO.proyecto_id
          LEFT JOIN tutor_academico AS TA ON SO.tutor_academico_id = TA.id
          LEFT JOIN tutor_empresarial AS TE ON SO.tutor_empresarial_id = TE.id
          LEFT JOIN empresa AS EM ON TE.empresa_id = EM.id
          WHERE
            SO.users_id = ${parseInt(query.id)};
          `;
          break;
        case '3':
          documentos = await prisma.$queryRaw`
            SELECT
              PR.id AS proyecto_id,
              PR.proyecto_nombre,
              PR.status AS proyecto_status,
              CONCAT(US.firstname, ' ', US.lastname) AS estudiante_nombre,
              US.dni_number AS estudiante_cedula,
              ETA.calificacion AS calificacion_tutor_academico,
              ETE.calificacion AS calificacion_tutor_empresarial,
              EC.calificacion AS calificacion_coordinacion,
              CC.calificacion AS calificacion_carta_culminacion
            FROM proyecto AS PR
            LEFT JOIN solicitud AS SO ON PR.id = SO.proyecto_id
            LEFT JOIN evaluacion_tutor_academico AS ETA ON PR.evaluacion_tutor_academico_id = ETA.id
            LEFT JOIN evaluacion_tutor_empresarial AS ETE ON PR.evaluacion_tutor_empresarial_id = ETE.id
            LEFT JOIN evaluacion_coordinacion AS EC ON PR.evaluacion_coordinacion_id = EC.id
            LEFT JOIN carta_culminacion AS CC ON PR.carta_culminacion_id = CC.id
            LEFT JOIN users AS US ON US.id = SO.users_id
            WHERE SO.users_id = ${parseInt(query.id)};
          `;
          break;
      }

      if ( documentos.length > 0 ) {
        let message, type, enabled;

        if ( query.fase == '1' ) {
          if (documentos[0].solicitud_status === 0) {
            message = 'Su solicitud ha sido rechazada debido a inconsistencias encontradas en los documentos emitidos, por favor comuniquese con el administrador y revise los detalles';
            type = 'error';
            enabled = true;
          }

          if (documentos[0].solicitud_status === 1) {
            message = 'Su solicitud ha sido aprobada, espere a que culmine el perido de la primera fase';
            type = 'success';
            enabled = false;
          }

          if (documentos[0].solicitud_status === 2) {
            message = 'Su solicitud ha sido enviada y se encuentra en proceso de revision';
            type = 'info';
            enabled = false;
          }
        }

        if ( query.fase == '2' ) {
          enabled = true;

          let visitas = await prisma.visitas.findMany({
            select: {
              numero_visitas: true
            },
            where: {
              proyect_id: documentos[0].proyecto_id
            }
          });

          if (visitas) {
            return res.status(200).json({
              type: type,
              message: message,
              enabled: enabled,
              result: { documentos, visitas },
              operationName: ''
            });
          } else {
            return res.status(200).json({
              type: type,
              message: message,
              enabled: enabled,
              result: { documentos, visitas: {} },
              operationName: ''
            });
          }
        }


        if ( query.fase == '3' ) {
          enabled = true;

          if ( documentos[0].proyecto_status === 1 ) {
            message = 'Su proyecto ha culimnado y ha sido aprobado, por favor envie las calificaciones de los tutores y coordinacion de pasantias';
            type = 'success';
            enabled = false;
          }
        }

       return res.status(200).json({
          type: type || null,
          message: message || null,
          enabled: enabled,
          result: documentos,
          operationName: ''
        });

      }

      return res.status(200).json(null);



    } catch (err) {
      return res.status(200).json({
        type: 'FORM_FETCH_DATA',
        err
      });
    } finally {
      prisma.$disconnect();
    }
  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', [ 'GET' ]);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }

}