import { prisma } from "src/configs/backend/prisma";

export default async function handler(req, res) {
  const { method, body } = req;

  if (method === 'GET') {
    try {
      const result = await prisma.$queryRaw`
          SELECT
            SO.id,
            PO.proyecto_nombre,
            ( CONCAT(US.firstname, ' ', US.lastname) ) AS estudiante,
            '2024-1' AS periodo,
            SO.createdAt AS fecha_emision,
            SO.status
          FROM solicitud AS SO
          LEFT JOIN proyecto AS PO ON SO.proyecto_id = PO.id
          LEFT JOIN users AS US ON US.id = SO.users_id;
        `;

      if (!result) return res.status(401).json({ message: "No existen registros de solicitudes" })

      return res.status(200).json(result);

    } catch (error) {
      return res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect()
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}