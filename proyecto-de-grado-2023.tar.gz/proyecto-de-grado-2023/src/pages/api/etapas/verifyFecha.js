import bcryptjs from 'bcryptjs';
import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {
  const { method, body } = req;

  if (method === 'POST') {
    try {
      if ((!body.fecha) || (body.fecha === "")) return res.status(401).json({ type: 'FORM_FIELD_FECHA_INICIO', message: "Requieres el fecha inicio" });
      
      let getActividad = await prisma.nuevas_etapas.findMany({
        where: {
          status: 0
        }
      })

      if (getActividad.fecha_fin > body.fecha) {
        let createEtapa = await prisma.nuevas_etapas.update({
          where: {
            id: getActividad.id
          },
          data: {
            status: 1
          }
        })
      }

      return res.status(200).json({
        getActividad
      });

    } catch (error) {
      return res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect();
    }
  } else {
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}