import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {
  const { method, body } = req;

  if (method === 'POST') {
    if ((!body.fecha_inicio) || (body.fecha_inicio === '')) return res.status(401).json({ type: 'FORM_FIELD_FECHA_INICIO', message: "Requieres el fecha inicio" });
    if ((!body.fecha_fin) || (body.fecha_fin === '')) return res.status(401).json({ type: 'FORM_FIELD_MISSING_FECHA_FIN', message: "Requieres el fecha fin" });
    if ((!body.id) || (body.id === '')) return res.status(401).json({ type: 'FORM_FIELD_ETAPA_ID', message: "Requieres la etapa id" });

    let curdate = new Date();
    let fecha_inicio = new Date(body.fecha_inicio);
    let fecha_fin = new Date(body.fecha_fin);
    let status;

    // si todavia no ha llegado a la fecha, entonces el estatus es 'Inactivo'
    if (fecha_inicio >= curdate && fecha_fin >= fecha_inicio) {
      status = 0;
    }

    // si ya llego a la fecha, entonces el estatus es 'Activo'
    if (curdate >= fecha_inicio && fecha_fin >= fecha_inicio && curdate <= fecha_fin) {
      status = 1;
    }

    // si ya llego a la fecha, entonces el estatus es 'Culminado'
    if (curdate >= fecha_fin && fecha_fin >= fecha_inicio) {
      status = 2;
    }

    try {
      let updateEtapa = await prisma.nuevas_etapas.update({
        where: { id: body.id },
        data: {
          fecha_inicio: new Date(body.fecha_inicio),
          fecha_fin: new Date(body.fecha_fin),
          status: status
        }
      });

      if (updateEtapa) {
        return res.status(200).json({
          type: 'FORM_REGISTRY_SUCCESS',
          message: 'Fase actualizada exitosamente',
        });
      }

      return res.status(200).json({
        type: 'FORM_REGISTRY_ERROR',
        message: 'Ha ocurrido un error al actualizar la fase seleccionada',
      });

    } catch (error) {
      console.log(error);
      return res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect();
    }
  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}