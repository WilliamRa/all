import bcryptjs from 'bcryptjs';
import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {
  const { method, body } = req;
  
  if (method === 'POST') {
    if ((!body.fecha_inicio) || (body.fecha_inicio === "")) return res.status(401).json({ type: 'FORM_FIELD_FECHA_INICIO', message: "Requieres el fecha inicio" });
    if ((!body.fecha_fin) || (body.fecha_fin === "")) return res.status(401).json({ type: 'FORM_FIELD_MISSING_FECHA_FIN', message: "Requieres el fecha fin" });
    if ((!body.tipo_etapa_id) || (body.tipo_etapa_id === "")) return res.status(401).json({ type: 'FORM_FIELD_ETAPA_ID', message: "Requieres la etapa id" });
    if ((!body.periodo_id) || (body.periodo_id === "")) return res.status(401).json({ type: 'FORM_FIELD_PERIODO_ID', message: "Requieres el periodo id" });

    try {
      let validateRankDate = await prisma.periodo.findUnique({ where: { id: body.periodo_id } });

      if (new Date(body.fecha_inicio) < validateRankDate.fecha_inicio) return res.status(401).json({ type: 'FORM_FIELD_PERIODO_ID', message: "La fecha de inicio esta fuera del rango del periodo" });
      if (new Date(body.fecha_fin) > validateRankDate.fecha_culminacion) return res.status(401).json({ type: 'FORM_FIELD_PERIODO_ID', message: "La fecha de finalizacion esta fuera del rango del periodo" });

      // let validateFecha = await prisma.nuevas_etapas.count({
      //   where: {
      //     status: 0
      //   }
      // })

      // if (validateFecha > 0) return res.status(401).json({ type: 'FORM_FIELD_FACE_ACTIVA', message: "Solo Puedes poseer una fase Activa a la vez" });

      let curdate = new Date();

      let createEtapa = await prisma.nuevas_etapas.create({
        data: {
          fecha_inicio: new Date(body.fecha_inicio),
          fecha_fin: new Date(body.fecha_fin),
          tipo_etapa_id: body.tipo_etapa_id,
          periodo_id: body.periodo_id,
          status: new Date(body.fecha_inicio) < curdate && new Date(body.fecha_fin) > curdate ? 1 : 0
        }
      });

      if (createEtapa) {
        return res.status(200).json({
          type: 'FORM_REGISTRY_SUCCESS',
          message: 'La Fase ha sido creada exitosamente'
        });
      }

      return res.status(401).json({
        type: 'FORM_REGISTRY_ERROR',
        message: 'Ha ocurrido un error al registrar la fase'
      });

    } catch (error) {
      console.log(error);
      return res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect();
    }
  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}