import NextAuth from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import { prisma } from 'src/configs/backend/prisma';
import bcryptjs from 'bcryptjs';

export const authOptions = {
  pages: {
    signIn: '/login',
  },
  providers: [
    CredentialsProvider({
      name: "credentials",
      credentials: {
        username: { label: "Correo electrónico", type: "email", placeholder: "correo@email.com" },
        password: { label: "Contraseña", type: "password" }
      },
      async authorize(credentials) {

        const messages = {
          userNotFoundError: 'Usuario no encontrado',
          wrongUserOrPassError: 'Usuario, Correo o Contraseña erroneos',
          databaseConnectionError: 'No se pudo conectar a la base de datos',
          success: 'Inicio de sesión exitoso'
        };

        try {
          const user = await prisma.users.findFirst({
            where: {
              OR: [
                {
                  email: {
                    equals: credentials?.username
                  } 
                },
                { 
                  username: {
                    equals: credentials?.username
                  }
                }
              ]
            },
            include: {
              user_roles: true
            }
          });

          if ( !user ) throw new Error(messages.userNotFoundError);
          
          if ( !bcryptjs.compareSync(credentials.password, user.password) ) {
            throw new Error(messages.wrongUserOrPassError);
          }

          return {
            name: user
          };

        } catch (e) {
          throw new Error(e.message);
        } finally {
          prisma.$disconnect();
        }
        
      },
    }),
  ],
  
  callbacks: {
    async jwt({ token, account }) {
      
      if ( account ) {
        token.accessToken = account.access_token
      }
      return token
    },
    async session({ session, token, user }) {
      // Send properties to the client, like an access_token from a provider.
      session.accessToken = token.accessToken
      return session
    },

  }
}

// const handler = NextAuth(authOptions)
// export { handler as GET, handler as POST, handler as PUT }

export default NextAuth(authOptions);
