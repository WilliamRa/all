import { prisma } from "src/configs/backend/prisma";


/*
{
  fecha_inicio: Date
  fecha_culminacion: Date
  periodo_name: String
}
*/
export default async function handler(req, res) {
  const { method, body } = req

  if (method === 'GET') {
    try {
      let getTutorAcademico = await prisma.tutor_academico.findMany()
      
      let getTutorEmpresarial = await prisma.tutor_empresarial.findMany({
        include: {
          empresa: true
        }
      })

      return res.status(200).json({
        tutor_academico: getTutorAcademico,
        tutor_empresarial: getTutorEmpresarial
      })
    } catch (error) {
      res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect()
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}