import { prisma } from "src/configs/backend/prisma";


/*
{
  fecha_inicio: Date
  fecha_culminacion: Date
  periodo_name: String
}
*/
export default async function handler(req, res) {
  const { method, body } = req

  if (method === 'POST') {
    try {
      if ((!body.id_solicitud) || (body.fecha_inicio === "")) return res.status(401).json({ message: "Requieres el identificador de la solicitud" })
      if ((!body.tutor_academico) || (body.tutor_academico === "")) return res.status(401).json({ message: "Requieres el tutor academico" })
      if ((!body.tutor_empresarial) || (body.tutor_empresarial === "")) return res.status(401).json({ message: "Requieres el tutor Empresarial" })
      if ((!body.empresa_id) || (body.empresa_id === "")) return res.status(401).json({ message: "Requieres el id de la empresa" })

      const update = await prisma.solicitud.update({
        where: { id: parseInt(body.id_solicitud) },
        data: {
          tutor_academico_id: body.tutor_academico,
          tutor_empresarial_id: body.tutor_empresarial,
          empresa_id: body.empresa_id
        }
      })

      return res.status(200).json({
        type: 'FORM_REGISTRY_SUCCESS',
        message: "Los tutores han sido asignados exitosamente"
      })
    } catch (error) {
      res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect()
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}