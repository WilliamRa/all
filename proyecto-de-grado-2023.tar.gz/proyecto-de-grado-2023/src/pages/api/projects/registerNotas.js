import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {
  const { method, body } = req;

  if (method === 'POST') {
    try {
      if ((!body.proyecto_id) || (body.proyecto_id === "")) return res.status(401).json({ type: 'FORM_FIELD_MISSING_CONTANCIA', message: "Requieres el id" });

      let solicitud = await prisma.solicitud.findFirst({
        where: {
          users_id: body.proyecto_id
        },
        include: {
          proyecto: true
        }
      })

      let createEvaluacionEmpresarial, createEvaluacionAcademica, createInforme, createCartaCulminacion, createEvaluacionCoordinador

      if (body.evaluacion_empresarial) {
        createEvaluacionEmpresarial = await prisma.evaluacion_tutor_empresarial.create({
          data: {
            evaluacion_tutor_empresarial_document: body.evaluacion_empresarial,
            calificacion: 1
          }
        });

        let updateEvaluacionEmpresarial = await prisma.proyecto.update({
          data: {
            evaluacion_tutor_empresarial_id: createEvaluacionEmpresarial.id
          },
          where: {
            id: solicitud.proyecto_id
          }
        });
      }

      if (body.evaluacion_academica) {
        createEvaluacionAcademica = await prisma.evaluacion_tutor_academico.create({
          data: {
            evaluacion_tutor_academico_document: body.evaluacion_academica,
            calificacion: 1
          }
        });

        let updateEvaluacionAcademica = await prisma.proyecto.update({
          data: {
            evaluacion_tutor_academico_id: createEvaluacionAcademica.id
          },
          where: {
            id: solicitud.proyecto_id
          }
        });
      }

      if (body.informe) {
        createInforme = await prisma.informe_pasantia.create({
          data: {
            documento_final: body.informe,
            calificacion: 1
          }
        });

        let updateInforme = await prisma.proyecto.update({
          data: {
            informe_pasantia_id: createInforme.id
          },
          where: {
            id: solicitud.proyecto_id
          }
        });
      }

      if (body.carta_culminacion) {
        createCartaCulminacion = await prisma.carta_culminacion.create({
          data: {
            carta_document: body.carta_culminacion,
            calificacion: 1
          }
        });

        let updateCartaCulminacion = await prisma.proyecto.update({
          data: {
            carta_culminacion_id: createCartaCulminacion.id
          },
          where: {
            id: solicitud.proyecto_id
          }
        });
      }

      if (body.evaluacion_coordinacion) {
        createEvaluacionCoordinador = await prisma.evaluacion_coordinacion.create({
          data: {
            evuacion_coordinacion_document: body.evaluacion_coordinacion,
            calificacion: 1
          }
        });
        
        let updateEvaluacionCoordinador = await prisma.proyecto.update({
          data: {
            evaluacion_coordinacion_id: createEvaluacionCoordinador.id
          },
          where: {
            id: solicitud.proyecto_id
          }
        });

      }

        return res.status(200).json({
          type: 'FORM_REGISTRY_SUCCESS',
          message: 'Los informes de evaluacion han sido cargados exitosamente'
        });


      // return res.status(200).json({
      //   type: 'FORM_REGISTRY_ERROR',
      //   message: 'Ha ocurrido un error al registrar los informes'
      // });


      // return res.status(401).json({
      //   type: 'FORM_REGISTRY_ERROR',
      //   message: 'Ha ocurrido un error al registrar los informes'
      // });
    } catch (err) {
      console.log(err);
      return res.status(401).json({
        err: err
      });
    } finally {
      prisma.$disconnect();
    }
  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }

}