import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {
  const { method, body, query } = req;

  if (!query.fase) {
    return res.status(401).json({
      type: 'BAD_REQUEST_ERROR',
      message: 'Se requiere el parametro: \'fase\''
    });
  }

  if (method === 'POST') {
    if (query.fase === '2') {
      try {
        if ((!body.proyecto_id) || (body.proyecto_id === "")) return res.status(401).json({ type: 'FORM_FIELD_MISSING_PROJECT_NAME', message: "Requieres el nombre del proyecto" });
        
        let solicitud = await prisma.solicitud.findFirst({
          where: {
            users_id: body.proyecto_id
          },
          include: {
            proyecto: true
          }
        })


        let createVisita1, createVisita2;

        if (body.visita1) {
          createVisita1 = await prisma.visitas.create({
            data: {
              numero_visitas: 1,
              documento_pasantias: body.visita1,
              proyect_id: solicitud.proyecto_id
            }
          });
        }

        if (body.visita2) {
          createVisita2 = await prisma.visitas.create({
            data: {
              numero_visitas: 2,
              documento_pasantias: body.visita2,
              proyect_id: solicitud.proyecto_id
            }
          });
        }

        return res.status(200).json({
          type: 'FORM_REGISTRY_SUCCESS',
          message: 'Las visitas han sido enviadas satisfactoriamente'
        });

        return res.status(200).json({
          type: 'FORM_REGISTRY_ERROR',
          message: 'Ha ocurrido un error inesperado al registrar las visitas'
        });


      } catch (error) {
        console.log(error);
        res.status(500).json({
          message: "Error en el servidor",
          error: error.message
        });
      } finally {
        prisma.$disconnect();
      }
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}