
import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {
  const { method, body, query } = req;

  if (method === 'POST') {
    try {
      if ((body.proyecto_id === undefined) || (body.proyecto_id === "")) return res.status(401).json({ type: 'FORM_FIELD_MISSING_INSCRIPCION', message: "Requieres el estatus de la inscripcion" });

      let proyecto = await prisma.proyecto.findFirst({
        where: { id: parseInt(body.proyecto_id) },
        include: {
          evaluacion_tutor_academico: true,
          evaluacion_tutor_empresarial: true,
          informe_pasantia: true,
          carta_culminacion: true,
          evaluacion_coordinacion: true
        }
      })
      return res.status(200).json({
        message: "Exito",
        documentos: proyecto
      });
    } catch (error) {
      console.log(error);
      return res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect();
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}