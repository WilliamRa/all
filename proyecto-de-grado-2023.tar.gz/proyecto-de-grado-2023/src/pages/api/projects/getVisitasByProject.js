import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {
  const { method, query } = req;

  if (method === 'GET') {
    try {
      let visitas = await prisma.visitas.findMany({
        where: {
          proyect_id: parseInt(query.proyecto_id)
        }
      });

      if (visitas.length > 0) {
        return res.status(200).json({
          type: 'REQUEST_FETCH_SUCCESS',
          message: null,
          result: visitas
        });
      }

      return res.status(200).json({
        type: 'REQUEST_FETCH_SUCCESS',
        message: 'No se han encontrado visitas para este proyecto',
        result: null
      });

    } catch (err) {
      console.log(err)
      return res.status(401).json({
        type: 'DB_ERROR',
        message: 'Ha ocurrido un error inesperado'
      });
    } finally {
      prisma.$disconnect();
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET']);
    res.status(405).end(`Method ${method} Not Allowed`);
  }
}