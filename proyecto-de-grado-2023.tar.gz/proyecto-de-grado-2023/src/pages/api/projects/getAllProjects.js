import { prisma } from "src/configs/backend/prisma";

export default async function handler(req, res) {
  const { method, body } = req;

  if (method === 'GET') {
    try {
      let result = await prisma.$queryRaw`
         SELECT
            PR.id AS id,
            SO.id AS solicitud_id,
            PR.proyecto_nombre,
            CONCAT(US.firstname, ' ', US.lastname) AS Estudiante,
            CONCAT(TA.firstname, ' ', TA.lastname) AS TutorAcademico,
            CONCAT(TE.firstname, ' ', TE.lastname) AS TutorEmpresarial,
            EM.nombre_empresa,
            PE.periodo_name,
            (SELECT COUNT(*) FROM visitas AS VI WHERE VI.proyect_id = PR.id) AS Visitas,
            PR.status,
            (
              (SELECT AVG(EC.calificacion) FROM evaluacion_coordinacion AS EC WHERE EC.id = PR.evaluacion_coordinacion_id) +
              (SELECT AVG(ETA.calificacion) FROM evaluacion_tutor_academico AS ETA WHERE ETA.id = PR.evaluacion_tutor_academico_id) +
              (SELECT AVG(ETE.calificacion) FROM evaluacion_tutor_empresarial AS ETE WHERE ETE.id = PR.evaluacion_tutor_empresarial_id) +
              (SELECT AVG(IP.calificacion) FROM informe_pasantia AS IP WHERE IP.id = PR.informe_pasantia_id)
            ) / 4 AS PromedioCalificaciones
              FROM
                proyecto AS PR
              LEFT JOIN
                solicitud AS SO ON PR.id = SO.proyecto_id
              LEFT JOIN
                users AS US ON US.id = SO.users_id
              LEFT JOIN
                periodo AS PE ON PR.periodo_id = PE.id
              LEFT JOIN
                tutor_academico AS TA ON SO.tutor_academico_id = TA.id
              LEFT JOIN
                tutor_empresarial AS TE ON SO.tutor_empresarial_id = TE.id
              LEFT JOIN
                empresa AS EM ON TE.empresa_id = EM.id
              WHERE
                SO.status = 1;
                        
                      `;

      if (!result) return res.status(401).json({ message: "No existen registros de solicitudes" })

      // validando conversion de numero desde bigint a int
      // para su envio en deserializacion JSON 
      result = result.map(result => ({
        ...result,
        Visitas: parseInt(result.Visitas)
      }));

      return res.status(200).json(result);

    } catch (error) {
      return res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect()
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}