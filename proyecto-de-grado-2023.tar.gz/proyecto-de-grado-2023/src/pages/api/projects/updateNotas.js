import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {
  const { method, body, query } = req;

  if (method === 'POST') {
    try {
      if ( (body.evaluacion_coordinacion === undefined) || (body.evaluacion_coordinacion === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_INSCRIPCION', message: "Requieres el estatus de la inscripcion" });
      if ( (body.evaluacion_tutor_academico === undefined) || (body.evaluacion_tutor_academico === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_INSCRIPCION', message: "Requieres el estatus de la inscripcion" });
      if ( (body.evaluacion_tutor_empresarial === undefined) || (body.evaluacion_tutor_empresarial === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_ACEPTACION', message: "Ingrese el estatus de la aceptacion" });
      if ( (body.informe === undefined) || (body.informe === "") ) return res.status(401).json({ type: 'FORM_FIELD_CONSTANCIA_PLAN_TRABAJO', message: "Ingrese el estatus del plan de Trabajo" });

      if ((!query.proyecto_id) || (query.proyecto_id === undefined)) return res.status(401).json({ type: 'FORM_FIELD_ID', message: "Se requiere el identificador unico" });

      if ( query.proyecto_id ) {
        let documentos = await prisma.proyecto.findFirst({

          where: {
            id: parseInt(query.proyecto_id)
          }
        })

        if (!documentos) return res.status(401).json({ type: 'NO_DATA_FOUND', message: "No se han encontrado los IDs de los documentos" });

        // update informe
        let informeResult = await prisma.informe_pasantia.update({
          data: {
            calificacion: parseInt(body.informe),
          },
          where: {
            id: parseInt(documentos.informe_pasantia_id)
          }
        });

        if (!informeResult) return res.status(401).json({ type: 'DB_DATA_UPDATE_FAILED', message: "Ocurrio un error al actualizar los datos" });

        // update tutor empresarial
        let tutorEmpresarialResult = await prisma.evaluacion_tutor_empresarial.update({
          data: {
            calificacion: parseInt(body.evaluacion_tutor_empresarial)
          },
          where: {
            id: documentos.evaluacion_tutor_empresarial_id
          }
        });

        if (!tutorEmpresarialResult) return res.status(401).json({ type: 'DB_DATA_UPDATE_FAILED', message: "Ocurrio un error al actualizar los datos" });

        // update tutor academico
        let tutorAcademicoResult = await prisma.evaluacion_tutor_academico.update({
          data: {
            calificacion: parseInt(body.evaluacion_tutor_academico)
          },
          where: {
            id: documentos.evaluacion_tutor_academico_id
          }
        });

        if (!tutorAcademicoResult) return res.status(401).json({ type: 'DB_DATA_UPDATE_FAILED', message: "Ocurrio un error al actualizar los datos" });


        let evaluacionCoordinacionResult = await prisma.evaluacion_coordinacion.update({
          data: {
            calificacion: parseInt(body.evaluacion_coordinacion)
          },
          where: {
            id: documentos.evaluacion_coordinacion_id
          }
        });

        if (!evaluacionCoordinacionResult) return res.status(401).json({ type: 'DB_DATA_UPDATE_FAILED', message: "Ocurrio un error al actualizar los datos" });

        if (evaluacionCoordinacionResult && tutorEmpresarialResult && tutorAcademicoResult) {
          return res.status(200).json({
            type: 'FORM_UPDATE_SUCCESS',
            message: 'Los documentos han sido actualizados exitosamente. '
          });
        }
      }

    } catch (error) {
      console.log(error);
      return res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect();
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}