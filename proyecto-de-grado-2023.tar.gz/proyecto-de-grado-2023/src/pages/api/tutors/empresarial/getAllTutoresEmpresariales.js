import { prisma } from "src/configs/backend/prisma";

export default async function handler(req, res) {

  const { method } = req;

  if ( method === 'GET' ) {
    try {
      const tutoresEmpresariales = await prisma.tutor_empresarial.findMany({
        include: {
          empresa: true
        }
      });
      if ( !tutoresEmpresariales || tutoresEmpresariales.length === 0 ) return res.status(401).json({ message: "No existen tutores empresariales registrados" });
    
      res.status(200).json({
        tutoresEmpresariales
      });

    } catch (e) {
      console.log('Error obteniendo tutores empresariales');
      res.status(500).json({
        error: true
      });
    } finally {
      prisma.$disconnect();
    }
  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}