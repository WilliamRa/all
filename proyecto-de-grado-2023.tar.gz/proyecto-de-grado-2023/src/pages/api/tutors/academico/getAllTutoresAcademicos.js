import { prisma } from "src/configs/backend/prisma";

export default async function handler(req, res) {

  const { method } = req;

  if ( method === 'GET' ) {
    try {
      const tutoresAcademicos = await prisma.tutor_academico.findMany({});
      if ( !tutoresAcademicos || tutoresAcademicos.length === 0 ) return res.status(401).json({ message: "No existen tutores academicos registrados" });
    
      res.status(200).json({
        tutoresAcademicos
      });

    } catch (e) {
      console.log('Error obteniendo tutores academicos');
      res.status(500).json({
          error: true
      });
    } finally {
      prisma.$disconnect();
    }
  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', [ 'GET', 'POST' ]);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}