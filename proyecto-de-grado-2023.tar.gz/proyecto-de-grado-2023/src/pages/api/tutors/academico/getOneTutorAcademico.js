import { prisma } from "src/configs/backend/prisma";

export default async function handler(req, res) {
  const { method, query } = req;

  if ( method === 'GET' ) {
    try {
      if ( !query.id ) return res.status(401).json({ message: "Requieres el Identificador unico" })
      let getOneTutorAcademico = await prisma.tutor_academico.findUnique({ where: { id: parseInt(query.id) } })

      return res.status(200).json(getOneTutorAcademico);

    } catch (error) {
      res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect()
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}