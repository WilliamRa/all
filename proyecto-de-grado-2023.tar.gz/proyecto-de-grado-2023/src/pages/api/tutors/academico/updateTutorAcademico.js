import { prisma } from "src/configs/backend/prisma";

export default async function handler (req, res) {

  const { method, body, query } = req;

  if ( method === 'PUT' ) {
    try {
      if ( ( !body.firstname ) || (body.firstname === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_FIRSTNAME', message: "Requieres el nombre" })
      if ( ( !body.lastname ) || (body.lastname === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_LASTNAME', message: "Requieres el Apellido" })
      if ( ( !body.email ) || (body.email === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_EMAIL', message: "Requieres el correo electronico" })
      if ( ( !body.phoneNumber ) || (body.phoneNumber === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_PHONE_NUMBER', message: "Requieres el numero de telefono" })

      let verifyEmail = await prisma.tutor_academico.findFirst({ where: { email: body.email } });
      if ( verifyEmail ) {
        if ( verifyEmail.id !== parseInt(query.id) ) {
          return res.status(401).json({ type: 'FORM_FIELD_DUPLICATED_EMAIL', message: 'El correo electronico ya esta registrado para otro tutor' });
        }
      }

      let verifyPhoneNumber = await prisma.tutor_academico.findFirst({ where: { phone_number: body.phoneNumber } });
      if ( verifyPhoneNumber ) {
        if ( verifyPhoneNumber.id !== parseInt(query.id) ) {
          return res.status(401).json({ type: 'FORM_FIELD_DUPLICATED_PHONE_NUMBER', message: 'El numero de telefono ya esta registrado para otro tutor' });
        }
      }

      let updateTutorAcademico = await prisma.tutor_academico.update({
        data: {
          firstname: body.firstname,
          lastname: body.lastname,
          email: body.email,
          phone_number: body.phoneNumber
        },
        where: {
            id: parseInt(query.id)
        }
      });

      return res.status(200).json({
        type: 'FORM_REGISTRY_SUCCESS',
        message: `Tutor '${body.firstname} ${body.lastname}' actualizado exitosamente.`
      });
    } catch (err) {
      res.status(500).json({
        message: "Error en el servidor",
        error: err.message
      });
    } finally {
      prisma.$disconnect();
    }
  }
}