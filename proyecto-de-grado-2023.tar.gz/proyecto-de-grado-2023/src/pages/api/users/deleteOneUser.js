import { prisma } from "src/configs/backend/prisma";

export default async function handler (req, res) {

  const { method, query } = req;

  if ( method === 'DELETE' ) {
    try {
      let verifyUser = await prisma.users.findUnique({
        where: {
          id: parseInt(query.id)
        }
      });
      
      if ( verifyUser ) {
        let confirmDeleteUser = await prisma.users.delete({
          where: {
            id: parseInt(query.id)
          }
        })

        // console.log(confirmDeleteUser);
        // console.log(verifyUser);
        return res.status(200).json({
          ...verifyUser,
          message: 'Este usuario ya ha sido borrado'
        });
      } else {
        return res.status(200).json({
          message: 'Este usuario no se encuentra o ha sido eliminado'
        });
      }

    } catch (err) {
      // console.log(err);
      res.status(500).json({
        message: "Error en el servidor",
        error: err.message
      });
    } finally {
      prisma.$disconnect();
    }
  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', [ 'DELETE' ]);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}