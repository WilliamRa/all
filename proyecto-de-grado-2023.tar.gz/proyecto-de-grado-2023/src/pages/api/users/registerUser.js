import bcryptjs from 'bcryptjs';
import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {
  
  const { method, body } = req;

  if ( method === 'POST' ) {
    try {
      if ( ( !body.firstname ) || (body.firstname === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_FIRSTNAME', message: "Ingrese los nombres" });
      if ( ( !body.lastname ) || (body.lastname === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_LASTNAME', message: "Ingrese los Apellidos" });
      if ( ( !body.dni ) || (body.dni === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_DNI', message: "Requieres el numero de cedula" });
      if ( ( !body.username ) || (body.username === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_USERNAME', message: "Requieres el nombre de usuario" });
      if ( ( !body.email ) || (body.email === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_EMAIL', message: "Ingrese el Correo" });
      if ( ( !body.password ) || (body.password === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_PASSWORD', message: "Ingrese la Contraseña" });
      if ( ( !body.rol ) || (body.rol === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_ROLE', message: "Ingrese los Roles" });
      if ( ( !body.status ) || (body.status === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_STATUS', message: "Ingrese el estatus" });

      let verifyDni = await prisma.users.findUnique({ where: { dni_number: body.dni } });
      if ( verifyDni ) return res.status(401).json({ type: 'FORM_FIELD_DUPLICATED_DNI', message: 'Número de cedula ya registrado' });

      const username = body.username.replace('@', '');

      let verifyUsername = await prisma.users.findUnique({ where: { username: body.username } })
      if ( verifyUsername ) return res.status(401).json({ type: 'FORM_FIELD_DUPLICATED_USERNAME', message: "Ya se encuentra registrado este nombre de usuario" })

      let verifyEmail = await prisma.users.findUnique({ where: { email: body.email } })
      if ( verifyEmail ) return res.status(401).json({ type: 'FORM_FIELD_DUPLICATED_EMAIL', message: "Este correo ya esta siendo usado" })

      const salt = bcryptjs.genSaltSync(10);

      let createUser = await prisma.users.create({
        data: {
          firstname: body.firstname,
          lastname: body.lastname,
          dni_number: body.dni,
          username: body.username,
          email: body.email,
          password: bcryptjs.hashSync(body.password, salt),
          role_id: parseInt(body.rol),
          status_id: parseInt(body.status) 
        }
      });

      if ( createUser ) {
        return res.status(200).json({
          type: 'FORM_REGISTRY_SUCCESS',
          message: `El usuario '${body.firstname} ${body.lastname}' ha sido registrado exitosamente`
        });
      }
      
      return res.status(401).json({
        type: 'FORM_REGISTRY_ERROR',
        message: `Error al registrar el usuario '${body.firstname} ${body.lastname}'`
      });
    } catch ( error ) {
      res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect();
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', [ 'POST' ]);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}