import { prisma } from "src/configs/backend/prisma";

export default async function handler(req, res) {
    const { method, body } = req
  
    if ( method === 'GET' ) {
      try {
        let users = await prisma.users.findMany({
            select: {
                id: true,
                firstname: true,
                lastname: true,
                username: true,
                email: true,
                role_id: true,
                created_at: true,
                user_roles: {
                    select: {
                        display_name: true
                    }
                }
            }
        });

        if ( !users ) return res.status(401).json({ message: "No existen usuarios registrados" })
  
        return res.status(200).json({ users });
        
      } catch (error) {
        res.status(500).json({
          message: "Error en el servidor",
          error: error.message
        });
      } finally {
        prisma.$disconnect()
      }
  
    } else {
      // Manejar otros métodos HTTP o devolver un error
      res.setHeader('Allow', ['GET', 'POST']);
      res.status(405).end(`Method ${req.method} Not Allowed`);
    }
}