import bcryptjs from 'bcryptjs';
import { prisma } from "src/configs/backend/prisma";

export default async function handler (req, res) {

  const { method, body, query } = req;

  if ( method === 'PUT' ) {
    try {
      if ( ( !body.firstname ) || (body.firstname === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_FIRSTNAME', message: "Ingrese los nombres" });
      if ( ( !body.lastname ) || (body.lastname === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_LASTNAME', message: "Ingrese los Apellidos" });
      if ( ( !body.dni ) || (body.dni === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_DNI', message: "Requieres el numero de cedula" });
      if ( ( !body.username ) || (body.username === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_USERNAME', message: "Requieres el nombre de usuario" });
      if ( ( !body.email ) || (body.email === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_EMAIL', message: "Ingrese el Correo" });
      if ( ( !body.rol ) || (body.rol === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_ROLE', message: "Ingrese los Roles" });
      if ( ( !body.status ) || (body.status === "") ) return res.status(401).json({ type: 'FORM_FIELD_MISSING_STATUS', message: "Ingrese el estatus" });

      let verifyDni = await prisma.users.findUnique({ where: { dni_number: body.dni } });
      if ( verifyDni ) {
        if ( verifyDni.id !== parseInt(query.id) ) {
          return res.status(401).json({ type: 'FORM_FIELD_DUPLICATED_DNI', message: 'Número de cedula ya registrado para otro usuario' });
        }
      }

      const username = body.username.replace('@', '');

      let verifyUsername = await prisma.users.findUnique({ where: { username: body.username } })
      if ( verifyUsername ) {
        if ( verifyUsername.id !== parseInt(query.id) ) {
          return res.status(401).json({ type: 'FORM_FIELD_DUPLICATED_USERNAME', message: "Nombre de usuario ya registrado para otro usuario" });
        }
      }

      let verifyEmail = await prisma.users.findUnique({ where: { email: body.email } });
      if ( verifyEmail ) {
        if ( verifyEmail.id !== parseInt(query.id) ) {
          return res.status(401).json({ type: 'FORM_FIELD_DUPLICATED_EMAIL', message: "Correo electronico ya registrado para otro usuario" });
        }
      }

      const salt = bcryptjs.genSaltSync(10);
      let password;
      
      if ( !body.password || body.password === '' ) {
        password = verifyDni.password;
      } else {
        password = bcryptjs.hashSync(body.password, salt);
      }

      let updateTutorAcademico = await prisma.users.update({
        data: {
          firstname: body.firstname,
          lastname: body.lastname,
          dni_number: body.dni,
          username: body.username,
          email: body.email,
          password: password,
          role_id: parseInt(body.rol),
          status_id: parseInt(body.status)
        },
        where: {
            id: parseInt(query.id)
        }
      });

      return res.status(200).json({
        type: 'FORM_REGISTRY_SUCCESS',
        message: `Usuario '${body.firstname} ${body.lastname}' actualizado exitosamente.`
      });
    } catch (err) {
      res.status(500).json({
        message: "Error en el servidor",
        error: err.message
      });
    } finally {
      prisma.$disconnect();
    }
  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', [ 'PUT' ]);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}