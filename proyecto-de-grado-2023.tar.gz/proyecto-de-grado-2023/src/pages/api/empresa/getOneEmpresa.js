import { prisma } from "src/configs/backend/prisma";

export default async function handler(req, res) {
  const { method, query } = req;

  if (method === 'GET') {
    try {
      if (!query.id) return res.status(401).json({ message: "Requieres el Identificador unico" });

      let getOneEmpresa = await prisma.empresa.findUnique({ where: { id: parseInt(query.id) } });
      if (!getOneEmpresa) return res.status(401).json({ message: "La empresa solicitada no existe o ha sido eliminada" });

      return res.status(200).json(getOneEmpresa);
    } catch (error) {
      return res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect();
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}