import { prisma } from "src/configs/backend/prisma";

export default async function handler(req, res) {
  const { method, body } = req

  if (method === 'POST') {
    try {
      if ((!body.empresa_name) || (body.empresa_name === "")) return res.status(401).json({ message: "Requieres el nombre de la Empresa" })
      if ((!body.rif) || (body.rif === "")) return res.status(401).json({ message: "Requieres el Rif" })
      if ((!body.direccion) || (body.direccion === "")) return res.status(401).json({ message: "Requieres la Direccion de la empresa" })

      let verifyEmpresaRif = await prisma.empresa.findFirst({
        where: {
          rif: body.rif
        }
      });

      if (verifyEmpresaRif) return res.status(401).json({ message: "Existe Otra Empresa con este Rif" })

      let createEmpresa = await prisma.empresa.create({
        data: {
          nombre_empresa: body.empresa_name,
          rif: body.rif,
          direccion: body.direccion
        }
      })

      return res.status(200).json({
        type: 'FORM_REGISTRY_SUCCESS',
        message: `Empresa '${body.empresa_name}' registrada exitosamente.`
      });
    } catch (error) {
      return res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect()
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}