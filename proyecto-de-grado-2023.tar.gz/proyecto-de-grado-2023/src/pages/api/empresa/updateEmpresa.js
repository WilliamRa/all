import { prisma } from "src/configs/backend/prisma";

export default async function handler(req, res) {

  const { method, body, query } = req;

  if (method === 'PUT') {
    try {
      if ((!body.empresa_name) || (body.empresa_name === "")) return res.status(401).json({ message: "Requieres el nombre de la Empresa" })
      if ((!body.rif) || (body.rif === "")) return res.status(401).json({ message: "Requieres el Rif" })
      if ((!body.direccion) || (body.direccion === "")) return res.status(401).json({ message: "Requieres la Direccion de la empresa" })

      let verifyRif = await prisma.empresa.findFirst({ where: { rif: body.rif } });

      if (verifyRif) {
        if (verifyRif.id !== parseInt(query.id)) {
          return res.status(401).json({ type: 'FORM_FIELD_DUPLICATED_RIF', message: 'El RIF ya se encuentra registrado para otra empresa' });
        }
      }

      let updateTutorAcademico = await prisma.empresa.update({
        data: {
          nombre_empresa: body.empresa_name,
          rif: body.rif,
          direccion: body.direccion
        },
        where: {
          id: parseInt(query.id)
        }
      });

      return res.status(200).json({
        type: 'FORM_REGISTRY_SUCCESS',
        message: `Empresa '${body.empresa_name}' actualizada exitosamente.`
      });
    } catch (err) {
      return res.status(500).json({
        message: "Error en el servidor",
        error: err.message
      });
    } finally {
      prisma.$disconnect();
    }
  }
}