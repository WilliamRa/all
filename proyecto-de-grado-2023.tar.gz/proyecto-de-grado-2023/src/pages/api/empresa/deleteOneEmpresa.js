import { prisma } from "src/configs/backend/prisma";

export default async function handler(req, res) {

  const { method, query } = req;

  if (method === 'DELETE') {
    try {
      let verifyEmpresa = await prisma.empresa.findUnique({
        where: {
          id: parseInt(query.id)
        }
      });

      if (verifyEmpresa) {
        let confirmDeleteEmpresa = await prisma.empresa.delete({
          where: {
            id: parseInt(query.id)
          }
        })
        
        return res.status(200).json({
          ...verifyEmpresa,
          message: `Empresa '${verifyEmpresa.nombre_empresa}' eliminada exitosamente`
        });
      } else {
        return res.status(200).json({
          message: 'Esta empresa no se encuentra o ha sido eliminada'
        });
      }

    } catch (err) {
      return res.status(500).json({
        message: "Error en el servidor",
        error: err.message
      });
    } finally {
      prisma.$disconnect();
    }
  } else {
    res.setHeader('Allow', ['DELETE']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}