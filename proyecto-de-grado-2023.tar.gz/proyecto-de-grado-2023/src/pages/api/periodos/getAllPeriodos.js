import { prisma } from "src/configs/backend/prisma";


/*
{
  fecha_inicio: Date
  fecha_culminacion: Date
  periodo_name: String
}
*/
export default async function handler(req, res) {
  const { method, body } = req

  if (method === 'GET') {
    try {

      let getallPeriods = await prisma.$queryRaw`
        SELECT
          PE.id,
          PE.periodo_name,
          PE.fecha_inicio,
          PE.fecha_culminacion,
          (SELECT COUNT(*) FROM nuevas_etapas AS NE WHERE NE.periodo_id = PE.id) AS fases,
          PE.status
        FROM periodo AS PE
        LEFT JOIN nuevas_etapas AS NE ON PE.id = NE.periodo_id
        GROUP BY PE.id, PE.fecha_inicio, PE.fecha_culminacion;
      `;

      if (getallPeriods) {
        // Convertir de BigInt a Int en el count de las fases
        getallPeriods = getallPeriods.map((period) => ({
          ...period,
          fases: parseInt(period.fases)
        }));

        return res.status(200).json({
          allPeriods: getallPeriods
        });
      }

    } catch (error) {
      return res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect()
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}