import { prisma } from "src/configs/backend/prisma";


/*
{
  fecha_inicio: Date
  fecha_culminacion: Date
  periodo_name: String
}
*/
export default async function handler(req, res) {
  const { method, body } = req

  if (method === 'POST') {
    try {
      if ((!body.fecha_inicio) || (body.fecha_inicio === "")) return res.status(401).json({ message: "Requieres la Fecha de inicio del Periodo" })
      if ((!body.fecha_culminacion) || (body.fecha_culminacion === "")) return res.status(401).json({ message: "Requieres la fecha de Culminacion del Periodo" })
      if ((!body.periodo_name) || (body.periodo_name === "")) return res.status(401).json({ message: "Requieres el Nombre del Periodo" })

      let updatePeriodo = await prisma.periodo.update({
        where: { id: body.id },
        data: {
          periodo_name: body.periodo_name,
          fecha_inicio: new Date(body.fecha_inicio),
          fecha_culminacion: new Date(body.fecha_culminacion),
        }
      });

      return res.status(200).json({
        type: 'FORM_REGISTRY_SUCESS',
        message: "Periodo actualizado exitosamente"
      });

    } catch (error) {
      return res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect()
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}