import { prisma } from "src/configs/backend/prisma";

export default async function handler(req, res) {
  const { method, body } = req

  if (method === 'POST') {
    try {
      if ((!body.fecha_inicio) || (body.fecha_inicio === "")) return res.status(401).json({ message: "Requieres la Fecha de inicio del Periodo" })
      if ((!body.fecha_culminacion) || (body.fecha_culminacion === "")) return res.status(401).json({ message: "Requieres la fecha de Culminacion del Periodo" })
      if ((!body.periodo_name) || (body.periodo_name === "")) return res.status(401).json({ message: "Requieres el Nombre del Periodo" })

      let verifyPeriodo = await prisma.periodo.findFirst({
        where: {
          periodo_name: body.periodo_name
        }
      });

      if (verifyPeriodo) return res.status(401).json({ message: "El Nombre del Periodo no puede estar Repetido" })

      let createPeriodo, periodoUpdate;

      if (body.activo) {
        let periodoUpdate = await prisma.$queryRaw`
          UPDATE periodo SET status = 0;
        `;

        if (!periodoUpdate) {
          return res.status(401).json({
            type: 'FORM_REGISTRY_ERROR',
            message: 'Ocurrio un error al registrar los datos proporcionados'
          });
        }

        createPeriodo = await prisma.periodo.create({
          data: {
            periodo_name: body.periodo_name,
            fecha_inicio: new Date(body.fecha_inicio),
            fecha_culminacion: new Date(body.fecha_culminacion),
            status: 1
          }
        });
      } else {
        createPeriodo = await prisma.periodo.create({
          data: {
            periodo_name: body.periodo_name,
            fecha_inicio: new Date(body.fecha_inicio),
            fecha_culminacion: new Date(body.fecha_culminacion),
            status: 0
          }
        });
      }

      if (createPeriodo) {
        return res.status(200).json({
          type: 'FORM_REGISTRY_SUCCESS',
          message: 'El periodo ha sido registrado exitosamente'
        });
      }

      return res.status(401).json({
        type: 'FORM_REGISTRY_ERROR',
        message: 'Ocurrio un error al registrar los datos proporcionados'
      });

    } catch (error) {
      return res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect();
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}