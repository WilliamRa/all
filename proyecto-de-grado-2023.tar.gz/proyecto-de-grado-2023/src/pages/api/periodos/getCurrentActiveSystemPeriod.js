import { prisma } from 'src/configs/backend/prisma';

export default async function handler(req, res) {

  const { method } = req;

  if (method === 'GET') {
    try {
      let periodoActual = await prisma.$queryRaw`
        SELECT
          PE.periodo_name,
          PE.fecha_inicio AS fecha_inicio_periodo,
          PE.fecha_culminacion AS fecha_culminacion_periodo,
          TE.display_name AS fase_name,
          TE.id AS fase_index,
          TE.type as fase_type,
          NE.status AS fase_status,
          NE.fecha_inicio AS fecha_inicio_fase,
          NE.fecha_fin AS fecha_culminacion_fase
        FROM periodo AS PE
        LEFT JOIN nuevas_etapas AS NE ON PE.id = NE.periodo_id
        LEFT JOIN tipo_etapa AS TE ON TE.id = NE.tipo_etapa_id
        WHERE PE.status = 1
        ORDER BY TE.id ASC
        LIMIT 3;
      `;

      if (periodoActual) {
        return res.status(200).json({
          type: 'SYSTEM_FETCH_SUCCESS',
          result: periodoActual,
          message: null,
          operationName: 'CURRENT_ACTIVE_SYSTEM_PERIOD'
        });
      }

      return res.status(200).json({
        type: 'SYSTEM_FETCH_ERROR',
        result: null,
        message: 'Ha ocurrido un error inesperado o los datos solicitados no pudieron ser entregados.',
        operationName: 'CURRENT_ACTIVE_SYSTEM_PERIOD'
      });
    } catch (err) {
      console.log(err);
      return res.status(401).json({
        type: 'SYSTEM_FETCH_ERROR',
        result: null,
        message: 'Ha ocurrido un error inesperado o los datos solicitados no pudieron ser entregados.',
        operationName: 'CURRENT_ACTIVE_SYSTEM_PERIOD'
      });
    } finally {
      prisma.$disconnect();
    }
  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
