import { prisma } from "src/configs/backend/prisma";

/*
{
  username:  String
  email: String
  password: String
  firstname: String
  lastname: String
}
*/
export default async function handler(req, res) {
  const { method, body } = req

  if (method === 'GET') {
    try {
      let getAllRoles = await prisma.user_roles.findMany({
        select:{
          display_name: true,
          id: true
          
        }
      })


      return res.status(200).json({
        roles: getAllRoles
      })
    } catch (error) {
      res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect()
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}