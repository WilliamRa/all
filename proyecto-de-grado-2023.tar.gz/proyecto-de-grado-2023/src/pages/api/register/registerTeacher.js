import { prisma } from "src/configs/backend/prisma";

/*
{
  username:  String
  email: String
  password: String
  firstname: String
  lastname: String
  role_id: Number
}
*/

export default async function handler(req, res) {
  const { method, body } = req

  if (method === 'POST') {
    try {
      if ((!body.username) || (body.username === "")) return res.status(401).json({ message: "Requieres el nombre de usuario" })
      if ((!body.email) || (body.email === "")) return res.status(401).json({ message: "Ingrese el Correo" })
      if ((!body.password) || (body.password === "")) return res.status(401).json({ message: "Ingrese la Contraseña" })
      if ((!body.firstname) || (body.firstname === "")) return res.status(401).json({ message: "Ingrese los nombres" })
      if ((!body.lastname) || (body.lastname === "")) return res.status(401).json({ message: "Ingrese los Apellidos" })
      if (!body.role_id) return res.status(401).json({ message: "Se Requiere un rol" })

      let verifyUsername = await prisma.users.findUnique({ where: { username: body.username } })
      if (verifyUsername) return res.status(401).json({ message: "Ya se encuentra registrado este nombre de usuario" })

      let verifyEmail = await prisma.users.findUnique({ where: { email: body.email } })
      if (verifyEmail) return res.status(401).json({ message: "Este correo ya esta siendo usado" })

      let verifyRole = await prisma.user_roles.findUnique({ where: { id: body.role_id } })
      if (!verifyRole) return res.status(401).json({ message: "El Rol Proporcionado no existe" })

      let createUser = await prisma.users.create({
        data: {
          username: body.username,
          email: body.email,
          password: body.password,
          firstname: body.firstname,
          lastname: body.lastname,
          role_id: 3,
          status_id: body.role_id
        }
      })

      return res.status(200).json({ message: "Registro Exitoso" })
    } catch (error) {
      res.status(500).json({
        message: "Error en el servidor",
        error: error.message
      });
    } finally {
      prisma.$disconnect()
    }

  } else {
    // Manejar otros métodos HTTP o devolver un error
    res.setHeader('Allow', ['GET', 'POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}