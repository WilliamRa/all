// ** React Imports
import { useState } from 'react';

// ** Next Imports
import Link from 'next/link';

// ** MUI Components
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Divider from '@mui/material/Divider';
import Typography from '@mui/material/Typography';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import MuiCard from '@mui/material/Card';
import MuiFormControlLabel from '@mui/material/FormControlLabel';

import useApiClient from 'src/@core/hooks/useApiClient';

// ** Icons Imports
import Instagram from 'mdi-material-ui/Instagram';
import Download from 'mdi-material-ui/Download';

// ** Configs
import themeConfig from 'src/configs/themeConfig';

// ** Layout Import
import BlankLayout from 'src/@core/layouts/BlankLayout';

// Icons
import UnergIcon from 'src/@core/components/icons/UnergIcon';

// ** Styled Components
const Card = styled(MuiCard)(({ theme }) => ({
  [theme.breakpoints.up('md')]: { // 900px >
    width: '900px !important',
  },
  [theme.breakpoints.up('sm')]: {
    width: '28rem'
  },

}));

const ImgStyled = styled('img')(({ theme }) => ({
  width: 120,
  height: 120,
  marginRight: theme.spacing(6.25),
  borderRadius: theme.shape.borderRadius
}));

const LinkStyled = styled('a')(({ theme }) => ({
  fontSize: '0.875rem',
  textDecoration: 'none',
  color: theme.palette.primary.main
}))

const FormControlLabel = styled(MuiFormControlLabel)(({ theme }) => ({
  '& .MuiFormControlLabel-label': {
    fontSize: '0.875rem',
    color: theme.palette.text.secondary
  }
}))

const files = {
  'ManualTrabajoModelo': '/files/plan-trabajo-modelo.docx',
  'ManualInformePasantias': '/files/manual-informe-pasantias.pdf',
  'CartaPostulacion': '/files/carta-postulacion-pasantias.docx',
  'ManualTecnico': '/files/',
  'EvaluacionTutorEmpresarial': '/files/evaluacion-tutor-empresarial.docx',
  'EvaluacionTutorAcademico': '/files/evaluacion-tutor-academico.doc'
};

const PasantiasPage = () => {

  const apiClient = useApiClient();

  const [docsSrc, setDocsSrc] = useState({
    inscripcion: '/images/filetypes/default-file.jpg',
    aceptacion: '/images/filetypes/default-file.jpg',
    planTrabajo: '/images/filetypes/default-file.jpg',
  });

 

  const handleDownloadFile = (filename) => {
    const fileUrl = files[filename];
    const link = document.createElement('a');
    link.href = fileUrl;
    link.download = fileUrl.substring(fileUrl.lastIndexOf('/') + 1);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Box className="content-center">
      <Card sx={{ zIndex: 1 }}>
        <CardContent sx={{ padding: theme => `${theme.spacing(12, 9, 7)} !important` }}>
          <Box sx={{ mb: 8, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <UnergIcon width={120} height={50} />
            <Typography
              variant="h6"
              sx={{
                mt: '20px',
                lineHeight: 1,
                fontWeight: 600,
                textTransform: 'uppercase',
                fontSize: '1.5rem !important',
                textAlign: 'center'
              }}
            >
              {themeConfig.templateName}
            </Typography>
          </Box>
          <Box sx={{ mb: 6 }}>
            <Typography variant="body1" sx={{ textAlign: 'center' }}>
              Descargue aqui los documentos de postulacion
            </Typography>
          </Box>

          <Box>
            <Grid container spacing={4}>

              <Grid item xs={12} sm={4}>
                <Box sx={{ borderRadius: '10px', border: '1px solid #dadada', py: 2, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                  <Typography variant="body2">
                    Manual de trabajo
                  </Typography>
                  <ImgStyled src={docsSrc.inscripcion} alt='Profile Pic' />

                  <Button onClick={() => handleDownloadFile('ManualTrabajoModelo')} variant="contained" size="small">
                    <Download color="white" />
                    <Typography color="white">Descargar</Typography>
                  </Button>
                </Box>
              </Grid>

              <Grid item xs={12} sm={4}>
                <Box sx={{ borderRadius: '10px', border: '1px solid #dadada', py: 2, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                  <Typography variant="body2">
                    Manual para el informe de pasantias
                  </Typography>
                  <ImgStyled src={docsSrc.inscripcion} alt='Profile Pic' />

                  <Button onClick={() => handleDownloadFile('ManualInformePasantias')} variant="contained" size="small">
                    <Download color="white" />
                    <Typography color="white">Descargar</Typography>
                  </Button>
                </Box>
              </Grid>

              <Grid item xs={12} sm={4}>
                <Box sx={{ borderRadius: '10px', border: '1px solid #dadada', py: 2, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                  <Typography variant="body2">
                    Carta de postulacion
                  </Typography>
                  <ImgStyled src={docsSrc.inscripcion} alt='Profile Pic' />

                  <Button onClick={() => handleDownloadFile('CartaPostulacion')} variant="contained" size="small">
                    <Download color="white" />
                    <Typography color="white">Descargar</Typography>
                  </Button>
                </Box>
              </Grid>
{/* 
              <Grid item xs={12} sm={4}>
                <Box sx={{ borderRadius: '10px', border: '1px solid #dadada', py: 2, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                  <Typography variant="body2">
                    Manual tecnico
                  </Typography>
                  <ImgStyled src={docsSrc.inscripcion} alt='Profile Pic' />

                  <Button onClick={() => handleDownloadFile('ManualTecnico')} variant="contained" size="small">
                    <Download color="white" />
                    <Typography color="white">Descargar</Typography>
                  </Button>
                </Box>
              </Grid> */}

              <Grid item xs={12} sm={4}>
                <Box sx={{ borderRadius: '10px', border: '1px solid #dadada', py: 2, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                  <Typography variant="body2">
                    Evaluacion Tutor Empresarial
                  </Typography>
                  <ImgStyled src={docsSrc.inscripcion} alt='Profile Pic' />

                  <Button onClick={() => handleDownloadFile('EvaluacionTutorEmpresarial')} variant="contained" size="small">
                    <Download color="white" />
                    <Typography color="white">Descargar</Typography>
                  </Button>
                </Box>
              </Grid>

              <Grid item xs={12} sm={4}>
                <Box sx={{ borderRadius: '10px', border: '1px solid #dadada', py: 2, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                  <Typography variant="body2">
                    Evaluacion Tutor Academico
                  </Typography>
                  <ImgStyled src={docsSrc.inscripcion} alt='Profile Pic' />

                  <Button onClick={() => handleDownloadFile('EvaluacionTutorAcademico')} variant="contained" size="small">
                    <Download color="white" />
                    <Typography color="white">Descargar</Typography>
                  </Button>
                </Box>
              </Grid>

              <Grid item xs={12}>
                <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', justifyContent: 'center' }}>
                  <Typography variant="body2" sx={{ marginRight: 2 }}>
                    Ya registrado?
                  </Typography>
                  <Typography variant="body2">
                    <Link passHref href="/login">
                      <LinkStyled>Iniciar Sesión</LinkStyled>
                    </Link>
                  </Typography>
                </Box>
                <Divider sx={{ my: 0 }}>o</Divider>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5 }}>
                  <a target="_blank" href="https://www.instagram.com/pasantiasaisunerg">
                    <Instagram sx={{ color: '#f3425f' }} />
                  </a>
                  <a target="_blank" href="https://t.me/pasantiasaisunerg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 24 24">
                      <path d="M9.78 18.65l.28-4.23l7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3L3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z" fill="#2aabee" />
                    </svg>
                  </a>
                </Box>
              </Grid>
            </Grid>
          </Box>
        </CardContent>
      </Card>
      {/* <FooterIllustrationsV1 /> */}
    </Box>
  );

}

PasantiasPage.getLayout = page => (
  <BlankLayout>
    {page}
  </BlankLayout>
);

export default PasantiasPage;
