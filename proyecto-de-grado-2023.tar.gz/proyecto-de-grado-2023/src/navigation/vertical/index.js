import OfficeBuilding from 'mdi-material-ui/OfficeBuilding';
import Cog from 'mdi-material-ui/Cog';
import HomeOutline from 'mdi-material-ui/HomeOutline';

import Account from 'mdi-material-ui/Account';
import Cctv from 'mdi-material-ui/Cctv';
import FileDocument from 'mdi-material-ui/FileDocument';
import AccountBadge from 'mdi-material-ui/AccountBadge';
import FileCabinet from 'mdi-material-ui/FileCabinet';
import Email from 'mdi-material-ui/Email';
import Clock from 'mdi-material-ui/Clock';

import Home from 'mdi-material-ui/Home';
import { useSession } from 'next-auth/react';

const navigation = () => {
  return [
    {
      title: 'Panel',
      icon: HomeOutline,
      path: '/dashboard',
      onlyFor: [ 1, 2, 3 ]
    },
    {
      title: 'Usuarios',
      icon: Account,
      path: '/dashboard/users',
      onlyFor: [ 1 ]
    },
    {
      title: 'Proyectos',
      icon: FileCabinet,
      path: '/dashboard/projects',
      onlyFor: [ 1 ]
    },
    {
      title: 'Tutores Empresariales',
      icon: AccountBadge,
      path: '/dashboard/tutors/business',
      onlyFor: [ 1 ]
    },
    {
      title: 'Tutores Academicos',
      icon: AccountBadge,
      path: '/dashboard/tutors/academic',
      onlyFor: [ 1 ]
    },
    {
      title: 'Empresas',
      icon: OfficeBuilding,
      path: '/dashboard/companies',
      onlyFor: [ 1 ]
    },
    {
      title: 'Periodos Academicos',
      icon: Clock,
      path: '/dashboard/periods',
      onlyFor: [ 1 ]
    },
    {
      title: 'Solicitudes de pasantias',
      icon: FileDocument,
      path: '/dashboard/documents',
      onlyFor: [ 1, 3 ]
    },
  ]
}

export default navigation
