# databse config

crear un archivo de variables de entorno `.env` con las siguentes configuraciones

```
#DATABASE_URL="mysql://root:jonlem1234@localhost:3306/pasantias"
#DATABASE_URL="mysql://root:qwerty1505.@localhost:3306/pasantias"
NEXTAUTH_URL='http://localhost:3000'
NEXTAUTH_SECRET="deja wl wordpress"
```